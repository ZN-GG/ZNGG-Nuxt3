<template>
    <div>主页</div>
</template>

<script setup lang="ts">



</script>

<style>
</style>