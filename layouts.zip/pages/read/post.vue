<template>
    <div>
        <NuxtPage />
    </div>
</template>
<script setup lang="ts">
</script>