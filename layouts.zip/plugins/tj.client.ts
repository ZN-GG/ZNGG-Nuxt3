import '~/assets/js/tj.js'


export default defineNuxtPlugin(nuxtApp => {

})