<template>
    <div>
        <Toolbar />
        <NuxtLoadingIndicator />
        <NuxtPage class="mt-16" />
    </div>
</template>