<template>
    <NuxtLayout />
</template>
<script setup lang="ts">
import '~/assets/fonts/iconfont.css';

onMounted(() => {

})

useHead({

})



</script>