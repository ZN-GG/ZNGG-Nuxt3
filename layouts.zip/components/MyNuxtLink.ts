export default defineNuxtLink({
    componentName: 'MyNuxtLink',
    externalRelAttribute: 'activeactiveactive',
    activeClass: 'nuxt-link-active',
    exactActiveClass: 'nuxt-link-exact-active'
  })