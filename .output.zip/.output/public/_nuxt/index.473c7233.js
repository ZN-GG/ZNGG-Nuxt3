import{D as e,o as c,h as n}from"./entry.499d94e6.js";const o={};function r(t,s){return c(),n("div",null,"\u4E3B\u9875")}const _=e(o,[["render",r]]);export{_ as default};
