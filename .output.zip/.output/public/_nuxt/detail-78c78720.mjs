import{_ as t,A as o,b as a,c,f as n}from"./entry-096cd8e8.mjs";const r={};function s(_,l){const e=o("NuxtPage");return a(),c("div",null,[n(e)])}var d=t(r,[["render",s]]);export{d as default};
