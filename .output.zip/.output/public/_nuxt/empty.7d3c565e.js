import{D as o,E as t,o as c,c as n}from"./entry.3246477a.js";const r={};function s(_,a){const e=t("NuxtChild");return c(),n(e)}const f=o(r,[["render",s]]);export{f as default};
