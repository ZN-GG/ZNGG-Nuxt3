import{_ as m}from"./entry.b866546e.js";var k={size:"1em",strokeWidth:4,strokeLinecap:"round",strokeLinejoin:"round",theme:"outline",colors:{outline:{fill:"#333",background:"transparent"},filled:{fill:"#333",background:"#FFF"},twoTone:{fill:"#333",twoTone:"#2F88FF"},multiColor:{outStrokeColor:"#333",outFillColor:"#2F88FF",innerStrokeColor:"#FFF",innerFillColor:"#43CCF8"}},prefix:"i"};function g(){return"icon-"+((1+Math.random())*4294967296|0).toString(16).substring(1)}function f(t,i,o){var e=typeof i.fill=="string"?[i.fill]:i.fill||[],r=[],s=i.theme||o.theme;switch(s){case"outline":r.push(typeof e[0]=="string"?e[0]:"currentColor"),r.push("none"),r.push(typeof e[0]=="string"?e[0]:"currentColor"),r.push("none");break;case"filled":r.push(typeof e[0]=="string"?e[0]:"currentColor"),r.push(typeof e[0]=="string"?e[0]:"currentColor"),r.push("#FFF"),r.push("#FFF");break;case"two-tone":r.push(typeof e[0]=="string"?e[0]:"currentColor"),r.push(typeof e[1]=="string"?e[1]:o.colors.twoTone.twoTone),r.push(typeof e[0]=="string"?e[0]:"currentColor"),r.push(typeof e[1]=="string"?e[1]:o.colors.twoTone.twoTone);break;case"multi-color":r.push(typeof e[0]=="string"?e[0]:"currentColor"),r.push(typeof e[1]=="string"?e[1]:o.colors.multiColor.outFillColor),r.push(typeof e[2]=="string"?e[2]:o.colors.multiColor.innerStrokeColor),r.push(typeof e[3]=="string"?e[3]:o.colors.multiColor.innerFillColor);break}return{size:i.size||o.size,strokeWidth:i.strokeWidth||o.strokeWidth,strokeLinecap:i.strokeLinecap||o.strokeLinecap,strokeLinejoin:i.strokeLinejoin||o.strokeLinejoin,colors:r,id:t}}var w=k;function y(){return w}function C(t,i){return function(o){var e=y(),r=f(g(),o,e);return i(r)}}var F=C("chart-graph",function(t){return'<?xml version="1.0" encoding="UTF-8"?><svg width="'+t.size+'" height="'+t.size+'" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="48" height="48" fill="white" fill-opacity="0.01"/><rect x="17" y="6" width="14" height="9" fill="'+t.colors[1]+'" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linejoin="'+t.strokeLinejoin+'"/><rect x="6" y="33" width="14" height="9" fill="'+t.colors[1]+'" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linejoin="'+t.strokeLinejoin+'"/><rect x="28" y="33" width="14" height="9" fill="'+t.colors[1]+'" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linejoin="'+t.strokeLinejoin+'"/><path d="M24 16V24" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linecap="'+t.strokeLinecap+'" stroke-linejoin="'+t.strokeLinejoin+'"/><path d="M13 33V24H35V33" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linecap="'+t.strokeLinecap+'" stroke-linejoin="'+t.strokeLinejoin+'"/></svg>'});const p="Entity relationship diagram",v="Flow chart",S="Gantt chart",L="Mermaid diagrams",M="Pie chart",D="Sequence diagram",j="State diagram",A="User journey diagram";var E={class:"Class diagram",er:p,flowchart:v,gantt:S,mermaid:L,pie:M,sequence:D,state:j,uj:A};function b({locale:t,...i}={}){const o={...E,...t};let e;const r=[{title:o.flowchart,code:`graph TD
Start --> Stop`},{title:o.sequence,code:`sequenceDiagram
Alice->>John: Hello John, how are you?
John-->>Alice: Great!
Alice-)John: See you later!`},{title:o.class,code:`classDiagram
Animal <|-- Duck
Animal <|-- Fish
Animal <|-- Zebra
Animal : +int age
Animal : +String gender
Animal: +isMammal()
Animal: +mate()
class Duck{
+String beakColor
+swim()
+quack()
}
class Fish{
-int sizeInFeet
-canEat()
}
class Zebra{
+bool is_wild
+run()
}`},{title:o.state,code:`stateDiagram-v2
[*] --> Still
Still --> [*]

Still --> Moving
Moving --> Still
Moving --> Crash
Crash --> [*]`},{title:o.er,code:`erDiagram
CUSTOMER ||--o{ ORDER : places
ORDER ||--|{ LINE-ITEM : contains
CUSTOMER }|..|{ DELIVERY-ADDRESS : uses`},{title:o.uj,code:`journey
title My working day
section Go to work
Make tea: 5: Me
Go upstairs: 3: Me
Do work: 1: Me, Cat
section Go home
Go downstairs: 5: Me
Sit down: 5: Me`},{title:o.gantt,code:`gantt
title A Gantt Diagram
dateFormat  YYYY-MM-DD
section Section
A task           :a1, 2014-01-01, 30d
Another task     :after a1  , 20d
section Another
Task in sec      :2014-01-12  , 12d
another task      : 24d`},{title:o.pie,code:`pie title Pets adopted by volunteers
"Dogs" : 386
"Cats" : 85
"Rats" : 15`}];return{viewerEffect({markdownBody:s}){(async()=>{const a=s.querySelectorAll("pre>code.language-mermaid");a.length!==0&&(e||(e=await m(()=>import("./mermaid.esm.min.6d6fe547.js"),[],import.meta.url).then(n=>n.default),i&&e.initialize(i)),a.forEach((n,u)=>{const c=n.parentElement,h=n.innerText,l=document.createElement("div");l.classList.add("bytemd-mermaid"),l.style.lineHeight="initial",c.replaceWith(l);try{e.render(`bytemd-mermaid-${Date.now()}-${u}`,h,d=>{l.innerHTML=d},l)}catch{}}))})()},actions:[{title:o.mermaid,icon:F({}),cheatsheet:"```mermaid",handler:{type:"dropdown",actions:r.map(({title:s,code:a})=>({title:s,handler:{type:"action",click({editor:n,appendBlock:u,codemirror:c}){const{line:h}=u("```mermaid\n"+a+"\n```");n.setSelection(c.Pos(h+1,0),c.Pos(h+a.split(`
`).length)),n.focus()}}})),...o}}]}}export{b as default};
