const s=""+globalThis.__publicAssetsURL("ad/ScreenRecAD.jpg");export{s as _};
