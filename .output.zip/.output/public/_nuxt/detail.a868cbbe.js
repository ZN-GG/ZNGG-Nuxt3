import{D as o,E as t,o as n,h as c,j as a}from"./entry.499d94e6.js";const r={};function s(_,l){const e=t("NuxtPage");return n(),c("div",null,[a(e)])}const f=o(r,[["render",s]]);export{f as default};
