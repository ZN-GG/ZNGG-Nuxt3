const s=""+globalThis.__publicAssetsURL("ad/NplayerAD.jpg");export{s as _};
