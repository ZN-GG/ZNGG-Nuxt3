import{_ as j,__tla as _}from"./entry.9b4e70bb.js";import{I as v}from"./index.7db9d376.js";let h,L=Promise.all([(()=>{try{return _}catch{}})()]).then(async()=>{const m=v("chart-graph",function(t){return'<?xml version="1.0" encoding="UTF-8"?><svg width="'+t.size+'" height="'+t.size+'" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="17" y="6" width="14" height="9" fill="'+t.colors[1]+'" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linejoin="'+t.strokeLinejoin+'"/><rect x="6" y="33" width="14" height="9" fill="'+t.colors[1]+'" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linejoin="'+t.strokeLinejoin+'"/><rect x="28" y="33" width="14" height="9" fill="'+t.colors[1]+'" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linejoin="'+t.strokeLinejoin+'"/><path d="M24 16V24" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linecap="'+t.strokeLinecap+'" stroke-linejoin="'+t.strokeLinejoin+'"/><path d="M13 33V24H35V33" stroke="'+t.colors[0]+'" stroke-width="'+t.strokeWidth+'" stroke-linecap="'+t.strokeLinecap+'" stroke-linejoin="'+t.strokeLinejoin+'"/></svg>'}),k="Entity relationship diagram",g="Flow chart",p="Gantt chart",w="Mermaid diagrams",u="Pie chart",y="Sequence diagram",M="State diagram",D="User journey diagram",S={class:"Class diagram",er:k,flowchart:g,gantt:p,mermaid:w,pie:u,sequence:y,state:M,uj:D};h=function({locale:f,...d}={}){const e={...S,...f};let r;const A=[{title:e.flowchart,code:`graph TD
Start --> Stop`},{title:e.sequence,code:`sequenceDiagram
Alice->>John: Hello John, how are you?
John-->>Alice: Great!
Alice-)John: See you later!`},{title:e.class,code:`classDiagram
Animal <|-- Duck
Animal <|-- Fish
Animal <|-- Zebra
Animal : +int age
Animal : +String gender
Animal: +isMammal()
Animal: +mate()
class Duck{
+String beakColor
+swim()
+quack()
}
class Fish{
-int sizeInFeet
-canEat()
}
class Zebra{
+bool is_wild
+run()
}`},{title:e.state,code:`stateDiagram-v2
[*] --> Still
Still --> [*]

Still --> Moving
Moving --> Still
Moving --> Crash
Crash --> [*]`},{title:e.er,code:`erDiagram
CUSTOMER ||--o{ ORDER : places
ORDER ||--|{ LINE-ITEM : contains
CUSTOMER }|..|{ DELIVERY-ADDRESS : uses`},{title:e.uj,code:`journey
title My working day
section Go to work
Make tea: 5: Me
Go upstairs: 3: Me
Do work: 1: Me, Cat
section Go home
Go downstairs: 5: Me
Sit down: 5: Me`},{title:e.gantt,code:`gantt
title A Gantt Diagram
dateFormat  YYYY-MM-DD
section Section
A task           :a1, 2014-01-01, 30d
Another task     :after a1  , 20d
section Another
Task in sec      :2014-01-12  , 12d
another task      : 24d`},{title:e.pie,code:`pie title Pets adopted by volunteers
"Dogs" : 386
"Cats" : 85
"Rats" : 15`}];return{viewerEffect({markdownBody:l}){(async()=>{const o=l.querySelectorAll("pre>code.language-mermaid");o.length!==0&&(r||(r=await j(()=>import("./mermaid.core.be9847e1.js"),["./mermaid.core.be9847e1.js","./_commonjsHelpers.a7148835.js","./_commonjs-dynamic-modules.80216356.js","./_baseUniq.2a25bf19.js"],import.meta.url).then(i=>i.default),d&&r.initialize(d)),o.forEach((i,c)=>{const n=i.parentElement,s=i.innerText,a=document.createElement("div");a.classList.add("bytemd-mermaid"),a.style.lineHeight="initial",n.replaceWith(a);try{r.render(`bytemd-mermaid-${Date.now()}-${c}`,s,E=>{a.innerHTML=E},a)}catch{}}))})()},actions:[{title:e.mermaid,icon:m({}),cheatsheet:"```mermaid",handler:{type:"dropdown",actions:A.map(({title:l,code:o})=>({title:l,handler:{type:"action",click({editor:i,appendBlock:c,codemirror:n}){const{line:s}=c("```mermaid\n"+o+"\n```");i.setSelection(n.Pos(s+1,0),n.Pos(s+o.split(`
`).length)),i.focus()}}})),...e}}]}}});export{L as __tla,h as default};
