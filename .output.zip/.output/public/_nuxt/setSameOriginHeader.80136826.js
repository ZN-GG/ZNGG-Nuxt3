function a(o,i,e){i==null||i.setHeader("Cross-Origin-Embedder-Policy","require-corp"),i==null||i.setHeader("Cross-Origin-Opener-Policy","same-origin"),e()}export{a as default};
