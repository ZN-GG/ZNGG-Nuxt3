import{D as e,o,h as r}from"./entry.9be4863f.js";const t={};function c(n,s,a,p,_,d){return o(),r("div",null,"\u8BA2\u5355")}const l=e(t,[["render",c]]);export{l as default};
