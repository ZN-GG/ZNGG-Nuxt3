import{_ as o,B as t,b as c,j as n}from"./entry-51c93615.mjs";const r={};function s(_,a){const e=t("NuxtChild");return c(),n(e)}var f=o(r,[["render",s]]);export{f as default};
