import{_ as t,B as o,b as c,c as n,f as r}from"./entry-1bb3e2d9.mjs";const a={};function s(_,l){const e=o("NuxtChild");return c(),n("div",null,[r(e)])}var f=t(a,[["render",s]]);export{f as default};
