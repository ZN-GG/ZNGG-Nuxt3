import{_ as o,O as t,b as c,c as n,f as a}from"./entry-21763359.mjs";const r={};function s(_,f){const e=t("NuxtPage");return c(),n("div",null,[a(e)])}var p=o(r,[["render",s]]);export{p as default};
