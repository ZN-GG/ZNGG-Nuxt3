import{_ as o,B as t,b as a,c,f as n}from"./entry-e302007f.mjs";const r={};function s(_,f){const e=t("NuxtPage");return a(),c("div",null,[n(e)])}var d=o(r,[["render",s]]);export{d as default};
