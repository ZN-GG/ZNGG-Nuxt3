import{_ as o,O as t,b as a,c,f as n}from"./entry-c271a5f5.mjs";const r={};function s(_,f){const e=t("NuxtPage");return a(),c("div",null,[n(e)])}var d=o(r,[["render",s]]);export{d as default};
