import{_ as e,b as c,c as r}from"./entry-c271a5f5.mjs";const n={};function t(a,o){return c(),r("div",null,"\u4E3B\u9875")}var s=e(n,[["render",t]]);export{s as default};
