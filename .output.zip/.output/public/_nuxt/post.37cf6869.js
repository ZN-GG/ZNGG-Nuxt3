import{D as o,E as t,o as n,h as c,j as s}from"./entry.77e855d7.js";const a={};function r(_,l){const e=t("NuxtPage");return n(),c("div",null,[s(e)])}const f=o(a,[["render",r]]);export{f as default};
