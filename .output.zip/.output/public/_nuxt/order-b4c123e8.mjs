import{_ as e,b as r,c as o}from"./entry-096cd8e8.mjs";const t={};function c(a,n,s,_,p,d){return r(),o("div",null,"\u8BA2\u5355")}var l=e(t,[["render",c]]);export{l as default};
