const s=""+globalThis.__publicAssetsURL("img/XGPlayer.png");export{s as _};
