import{_ as n,A as o,b as t,c,f as a}from"./entry-6d3cdba2.mjs";const r={};function s(_,l){const e=o("NuxtPage");return t(),c("div",null,[a(e)])}var m=n(r,[["render",s]]);export{m as default};
