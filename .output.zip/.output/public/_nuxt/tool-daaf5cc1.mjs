import{_ as o,B as t,b as c,j as n}from"./entry-49b9f9c2.mjs";const r={};function a(s,_){const e=t("NuxtPage");return c(),n(e)}var p=o(r,[["render",a]]);export{p as default};
