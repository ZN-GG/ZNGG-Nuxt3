import{D as o,E as n,o as t,h as c,j as a}from"./entry.b866546e.js";const r={};function s(_,l){const e=n("NuxtPage");return t(),c("div",null,[a(e)])}const m=o(r,[["render",s]]);export{m as default};
