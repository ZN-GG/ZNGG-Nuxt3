import{_ as o,A as t,b as c,c as n,f as a}from"./entry-6d3cdba2.mjs";const r={};function s(_,f){const e=t("NuxtPage");return c(),n("div",null,[a(e)])}var p=o(r,[["render",s]]);export{p as default};
