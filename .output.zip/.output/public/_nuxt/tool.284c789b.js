import{D as o,E as t,o as n,h as c,j as a}from"./entry.c124cdc1.js";const r={};function s(_,l){const e=t("NuxtPage");return n(),c("div",null,[a(e)])}const m=o(r,[["render",s]]);export{m as default};
