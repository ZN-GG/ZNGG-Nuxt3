import{_ as n,B as o,b as t,c,f as a}from"./entry-d3288a86.mjs";const r={};function s(_,l){const e=o("NuxtPage");return t(),c("div",null,[a(e)])}var m=n(r,[["render",s]]);export{m as default};
