import{_ as t,B as o,b as a,c,f as n}from"./entry-d3288a86.mjs";const r={};function s(_,l){const e=o("NuxtPage");return a(),c("div",null,[n(e)])}var d=t(r,[["render",s]]);export{d as default};
