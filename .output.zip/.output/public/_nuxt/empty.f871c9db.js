import{D as o,E as t,o as n,h as c,j as r}from"./entry.77e855d7.js";const s={};function a(_,l){const e=t("NuxtChild");return n(),c("div",null,[r(e)])}const m=o(s,[["render",a]]);export{m as default};
