import{_ as t,B as o,b as a,c,f as n}from"./entry-dcae128d.mjs";const r={};function s(_,l){const e=o("NuxtPage");return a(),c("div",null,[n(e)])}var d=t(r,[["render",s]]);export{d as default};
