import{_ as o,B as t,b as a,j as c}from"./entry-06ac1f02.mjs";const n={};function r(s,_){const e=t("NuxtPage");return a(),c(e)}var p=o(n,[["render",r]]);export{p as default};
