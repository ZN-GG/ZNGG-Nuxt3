import{_ as o,O as t,b as c,c as n,f as a}from"./entry-6a31fad7.mjs";const r={};function s(_,l){const e=t("NuxtPage");return c(),n("div",null,[a(e)])}var m=o(r,[["render",s]]);export{m as default};
