import{_ as o,B as t,b as c,j as n}from"./entry-d3288a86.mjs";const r={};function s(_,a){const e=t("NuxtChild");return c(),n(e)}var f=o(r,[["render",s]]);export{f as default};
