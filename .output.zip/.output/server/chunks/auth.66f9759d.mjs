import { __tla as __tla$1, i as defineNuxtRouteMiddleware, n as navigateTo } from './server.mjs';
import { _ as __tla$2, u as useCookie } from './cookie.3a889f6e.mjs';
import { _ as __tla$3, a as api } from './api.883a6098.mjs';
import { _ as __tla$4, u as userStore } from './user.da01cd42.mjs';
import { _ as __tla$5 } from './request.785c1b89.mjs';
import 'vue';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'vue/server-renderer';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let auth;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  auth = defineNuxtRouteMiddleware((to, from) => {
    const token = useCookie("token");
    const store = userStore();
    if (typeof token.value == "undefined") {
      return navigateTo("/");
    }
    api.user.getInfo().then((info) => {
      if (!info.success) {
        store.$patch({
          isLogin: !store.isLogin
        });
        store.$patch({
          isLogin: false
        });
        token.value = void 0;
        store.$patch({
          showLogin: true
        });
        navigateTo("/");
      }
    });
  });
});

export { __tla, auth as default };
//# sourceMappingURL=auth.66f9759d.mjs.map
