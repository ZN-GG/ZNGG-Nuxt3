import { __tla as __tla$1, f as useRuntimeConfig } from './server.mjs';
import { h, useSSRContext } from 'vue';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = {
    props: {
      adClient: {
        type: String,
        default: void 0
      },
      adSlot: {
        type: String,
        default: null
      },
      adFormat: {
        type: String,
        default: "auto"
      },
      adLayout: {
        type: String,
        default: null
      },
      adLayoutKey: {
        type: String,
        default: null
      },
      adStyle: {
        type: Object,
        default() {
          return {
            display: "block"
          };
        }
      },
      adFullWidthResponsive: {
        type: Boolean,
        default: false
      },
      pageUrl: {
        type: String,
        default: null
      },
      analyticsUacct: {
        type: String,
        default: void 0
      },
      analyticsDomainName: {
        type: String,
        default: void 0
      },
      includeQuery: {
        type: Boolean,
        default: void 0
      }
    },
    data() {
      return {
        show: true,
        renderQueue: [],
        key: Math.random()
      };
    },
    computed: {
      options() {
        const options = {
          ...useRuntimeConfig()["google-adsense"] || {}
        };
        if (options.test) {
          options.id = "ca-google";
        }
        return options;
      },
      _includeQuery() {
        return this.includeQuery || typeof this.includeQuery === "undefined" && this.options.includeQuery;
      }
    },
    watch: {
      "$route"(to, from) {
        if (this.$el && !this.$el.isConnected) {
          return;
        }
        if (to.fullPath === from.fullPath) {
          return;
        }
        const keys = Object.keys;
        const toQuery = to.query;
        const fromQuery = from.query;
        let changed = false;
        if (to.path !== from.path) {
          changed = true;
        } else if (this._includeQuery) {
          changed = keys(toQuery).length !== keys(fromQuery).length || !keys(toQuery).every((k) => toQuery[k] === fromQuery[k]);
        }
        if (changed) {
          this.updateAd();
        }
      }
    },
    mounted() {
      this.showAd();
    },
    methods: {
      adRegion() {
        return "page-" + Math.random();
      },
      updateAd() {
        if (this.isServer) {
          return;
        }
        this.show = false;
        this.$nextTick(this.showAd);
      },
      showAd() {
        this.show = true;
        setTimeout(() => {
          if (this.$el.innerHTML) {
            return;
          }
          try {
            (window.adsbygoogle = window.adsbygoogle || []).push({});
          } catch (error) {
            console.error(error);
          }
        }, 50);
      }
    },
    render() {
      return h("ins", {
        class: [
          "adsbygoogle"
        ],
        style: this.adStyle,
        "data-ad-client": this.adClient || this.options.id,
        "data-ad-slot": this.adSlot || null,
        "data-ad-format": this.adFormat,
        "data-ad-region": this.show ? this.adRegion() : null,
        "data-ad-layout": this.adLayout || null,
        "data-ad-layout-key": this.adLayoutKey || null,
        "data-page-url": this.pageUrl ? this.pageUrl : null,
        "data-analytics-uacct": this.analyticsUacct || this.options.analyticsUacct || null,
        "data-analytics-domain-name": this.analyticsDomainName || this.options.analyticsDomainName || null,
        "data-adtest": this.options.test ? "on" : null,
        "data-adsbygoogle-status": this.show ? null : "",
        "data-full-width-responsive": this.adFullWidthResponsive || null,
        innerHTML: this.show ? "" : " ",
        key: Math.random()
      });
    }
  };
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/@nuxtjs/google-adsense/dist/runtime/components-v3/Adsbygoogle.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla as _, _sfc_main as a };
//# sourceMappingURL=Adsbygoogle.9ce7b80f.mjs.map
