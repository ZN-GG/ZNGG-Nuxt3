import { c as _export_sfc, d as useRoute, e as useRequestHeaders, u as useHead, _ as __nuxt_component_0$2 } from './server.mjs';
import { useSSRContext, defineComponent, withAsyncContext, ref, onUnmounted, mergeProps, createVNode, resolveDynamicComponent, withCtx, unref, createTextVNode, toDisplayString } from 'vue';
import { u as useAsyncData } from './asyncData.1e8f0c0d.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr, ssrRenderStyle, ssrRenderVNode, ssrRenderClass, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_0 } from './ScreenRecAD.16518c41.mjs';
import { a as api } from './api.51f27357.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const { Viewer } = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/vue-next')), __temp = await __temp, __restore(), __temp);
    const breaks = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-breaks')), __temp = await __temp, __restore(), __temp).default;
    const gemoji = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-gemoji')), __temp = await __temp, __restore(), __temp).default;
    const gfm = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-gfm')), __temp = await __temp, __restore(), __temp).default;
    const highlight = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-highlight')), __temp = await __temp, __restore(), __temp).default;
    const math = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-math-ssr')), __temp = await __temp, __restore(), __temp).default;
    const medium = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-medium-zoom')), __temp = await __temp, __restore(), __temp).default;
    const mermaid = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-mermaid')), __temp = await __temp, __restore(), __temp).default;
    const frontmatter = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-frontmatter')), __temp = await __temp, __restore(), __temp).default;
    const marked = ([__temp, __restore] = withAsyncContext(() => import('marked')), __temp = await __temp, __restore(), __temp);
    const themes = ([__temp, __restore] = withAsyncContext(() => import('./theme.a19ed3dc.mjs')), __temp = await __temp, __restore(), __temp).themes;
    const isSuccess = ref(false);
    const isSuccessViewer = ref(false);
    const isRender = ref(false);
    ref(true);
    const rightFixedContainerWidth = ref("100%");
    const docMenu = ref([]);
    const tocActive = ref(0);
    const route = useRoute();
    let rightNormalContainer = ref(null);
    let rightFixedContainer = ref(null);
    let articleContents = ref(null);
    const isSpeader = ref(false);
    const headers = useRequestHeaders();
    const userAgent = (_a = headers == null ? void 0 : headers["user-agent"]) != null ? _a : navigator.userAgent;
    const article = ref();
    const plugins = [
      breaks(),
      frontmatter(),
      {
        viewerEffect({ file }) {
          var _a2, _b;
          if (typeof file.value != "object") {
            return;
          }
          const $style = document.createElement("style");
          try {
            $style.innerHTML = (_b = (_a2 = themes[file.value.frontmatter.theme]) == null ? void 0 : _a2.style) != null ? _b : themes.juejin.style;
          } catch (e) {
            $style.innerHTML = themes.juejin.style;
          }
          document.head.appendChild($style);
          return () => {
            $style.remove();
          };
        }
      },
      gemoji(),
      gfm(),
      highlight(),
      math(),
      medium(),
      mermaid()
    ];
    const articleHtmlContent = ref();
    let mdHTMl = "";
    const { data: articleData, pending, refresh, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("read_Detail", () => api.article.getDetail(route.params.id.toString()))), __temp = await __temp, __restore(), __temp);
    if (articleData.value.success) {
      mdHTMl = marked.parse(articleData.value.data.content);
      article.value = articleData.value.data;
      isSuccess.value = true;
      if (userAgent.indexOf("Baiduspider") != -1) {
        isSpeader.value = true;
      }
    }
    onUnmounted(() => {
      window.removeEventListener("scroll", handleScroll);
    });
    function setFloatContainer() {
      if (rightNormalContainer.value.getBoundingClientRect().bottom <= 0) {
        rightFixedContainer.value.style.position = "fixed";
        rightFixedContainer.value.style.top = "0.5rem";
        rightFixedContainerWidth.value = rightNormalContainer.value.offsetWidth + "px";
      } else if (rightNormalContainer.value.getBoundingClientRect().bottom > 0) {
        rightFixedContainerWidth.value = "100%";
        rightFixedContainer.value.style.top = "";
        rightFixedContainer.value.style.position = "absolute";
      }
    }
    function handleScroll() {
      let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
      if (scrollTop > 20) {
        setFloatContainer();
        setContentsActive();
      }
    }
    function handleChange(v) {
      articleHtmlContent.value = v;
    }
    function setContentsActive() {
      const titleNavList = document.querySelectorAll(
        "#markdown-body h1,#markdown-body h2,#markdown-body h3,#markdown-body h4,#markdown-body h5,#markdown-body h6"
      );
      const offsetTopList = [];
      titleNavList.forEach((item) => {
        offsetTopList.push(item.offsetTop);
      });
      const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
      let navIndex = 0;
      for (let n = 0; n < offsetTopList.length; n++) {
        if (scrollTop >= offsetTopList[n]) {
          navIndex = n;
        }
      }
      tocActive.value = navIndex;
      let cateList = Array.prototype.slice.call(
        articleContents.value.querySelectorAll("li")
      );
      for (let i = 0; i < cateList.length; i++) {
        if (navIndex === i) {
          const top = getElementTop(
            cateList[i],
            articleContents.value
          );
          articleContents.value.scrollTop = top - articleContents.value.offsetHeight / 2;
        }
      }
    }
    function getElementTop(el, by = null) {
      let top = el.offsetTop;
      if (by) {
        top = top - by.offsetTop;
      }
      return top;
    }
    useHead({
      title: isSuccess.value ? article.value.title : "\u6587\u7AE0\u4E0D\u5B58\u5728",
      titleTemplate: (title) => `${title} - \u6587\u7AE0 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "\u524D\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u540E\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u5728\u7EBF\u5C0F\u5DE5\u5177\uFF0C\u8BBE\u8BA1\u6280\u5DE7" },
        { name: "description", content: isSuccess.value ? article.value.summary : "ZNGG\u5728\u7EBF\u5DE5\u5177\u662F\u4E00\u4E2A\u6301\u7EED\u63D0\u4F9B\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA\u5E73\u53F0\uFF0C\u5E76\u5C06\u8F93\u51FA\u5185\u5BB9\u8F6C\u53D8\u4E3A\u6210\u679C\uFF0C\u63D0\u4F9B\u5404\u79CD\u5404\u6837\u7684\u5728\u7EBF\u5DE5\u5177\u3002" }
      ],
      link: [
        { rel: "stylesheet", href: "/fonts/katex.min.css" },
        { rel: "stylesheet", href: "/css/bytemd.css" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ ref: "html" }, _attrs))} data-v-613c9b1b><div class="mx-auto container my-8" data-v-613c9b1b><div class="flex flex-wrap relative" data-v-613c9b1b><div class="bg-white p-6 rounded-md mt-4 w-full lg:w-8/12" data-v-613c9b1b>`);
      if (isSuccess.value) {
        _push(`<div class="" data-v-613c9b1b><div class="" data-v-613c9b1b><h1 class="font-semibold w-full text-xl lg:text-3xl" data-v-613c9b1b>${ssrInterpolate(article.value.title)}</h1><div class="flex py-4 w-fll justify-between items-center" data-v-613c9b1b><div class="flex items-center" data-v-613c9b1b><img${ssrRenderAttr("src", article.value.user.avatar)} class="w-10 h-10 rounded-full" data-v-613c9b1b><div class="ml-2" data-v-613c9b1b><p class="custom-font-16" data-v-613c9b1b>${ssrInterpolate(article.value.user.name)}</p><p class="custom-font-14 text-gray-500" data-v-613c9b1b>${ssrInterpolate(article.value.updateTime)}\xA0\xA0\xA0\xA0<span class="block md:inline-block" data-v-613c9b1b>\u9605\u8BFB\uFF1A${ssrInterpolate(article.value.viewCount)}</span></p></div></div><div class="" data-v-613c9b1b><a href="#" data-v-613c9b1b><p class="btn-2 w-auto" data-v-613c9b1b>${ssrInterpolate(article.value.category.name)}</p></a></div></div><div style="${ssrRenderStyle(!isSuccessViewer.value && !isSpeader.value ? null : { display: "none" })}" class="block w-full animate-pulse" data-v-613c9b1b><div class="flex mt-6 mb-2" data-v-613c9b1b><div class="w-2/12" data-v-613c9b1b></div><div class="w-10/12 h-6 bg-gray-200" data-v-613c9b1b></div></div><div class="w-full h-6 bg-gray-200 my-6" data-v-613c9b1b></div><div class="w-full h-64 bg-gray-200 my-6" data-v-613c9b1b></div><div class="w-full h-6 bg-gray-200 my-6" data-v-613c9b1b></div><div class="w-8/12 h-6 bg-gray-200 my-6" data-v-613c9b1b></div></div>`);
        if (isSpeader.value) {
          ssrRenderVNode(_push, createVNode(resolveDynamicComponent("style"), null, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(unref(themes).juejin.style)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(unref(themes).juejin.style), 1)
                ];
              }
            }),
            _: 1
          }), _parent);
        } else {
          _push(`<!---->`);
        }
        _push(`<div style="${ssrRenderStyle(isSpeader.value ? null : { display: "none" })}" class="${ssrRenderClass([isSpeader.value ? "" : "opacity-0", "markdown-body overflow-auto"])}" data-v-613c9b1b>${unref(mdHTMl)}</div>`);
        if (isRender.value && !isSpeader.value) {
          _push(ssrRenderComponent(unref(Viewer), {
            style: isSuccessViewer.value ? null : { display: "none" },
            id: "markdown-body",
            value: articleHtmlContent.value,
            plugins,
            onChange: handleChange
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<div class="h-80 relative" data-v-613c9b1b><div class="absolute empty items-center text-2xl" data-v-613c9b1b><span class="iconfont icon-cry" style="${ssrRenderStyle({ "font-size": "24px" })}" data-v-613c9b1b></span><p class="text-gray-700" data-v-613c9b1b>\u6CA1\u6709\u627E\u5230\u8BE5\u6587\u7AE0\uFF01</p><p data-v-613c9b1b><a href="/" class="text-blue-600 custom-font-14 my-4" data-v-613c9b1b>\u8FD4\u56DE\u9996\u9875</a></p></div></div>`);
      }
      _push(`</div><div class="bg-white p-6 rounded-md mt-4 w-full lg:w-8/12" data-v-613c9b1b>`);
      if (isSuccess.value) {
        _push(`<div class="" data-v-613c9b1b><div class="" data-v-613c9b1b><p class="font-bold text-xl my-2" data-v-613c9b1b>\u8BC4\u8BBA</p><div class="flex w-fll justify-between items-center mt-4" data-v-613c9b1b><div class="flex w-full" data-v-613c9b1b><img${ssrRenderAttr("src", article.value.user.avatar)} class="w-10 h-10 rounded-full" data-v-613c9b1b><div class="w-full px-4" data-v-613c9b1b><div contenteditable="true" class="w-full min-h-20 bg-gray-50 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2" data-v-613c9b1b></div></div></div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="mt-4 hidden lg:block w-full lg:w-4/12 absolute right-0" data-v-613c9b1b><div class="pl-6 w-full" data-v-613c9b1b>`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/tool/detail/ScreenRec" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="w-full h-auto" alt="" srcset="" data-v-613c9b1b${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "w-full h-auto",
                alt: "",
                srcset: ""
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div style="${ssrRenderStyle({
        width: rightFixedContainerWidth.value
      })}" class="h-20 pl-6 my-4 hidden lg:block w-full" data-v-613c9b1b><div style="${ssrRenderStyle(docMenu.value.length > 0 ? null : { display: "none" })}" class="bg-white rounded-md" data-v-613c9b1b><div class="flex justify-between items-center p-6" data-v-613c9b1b><div class="flex items-center" data-v-613c9b1b><p class="font-semibold text-2xl" data-v-613c9b1b>\u76EE\u5F55</p><p class="hidden lg:inline leading-8 mx-4 text-sm text-gray-400" data-v-613c9b1b> Contents </p></div></div><hr class="mx-6" data-v-613c9b1b><div data-v-613c9b1b><ul class="article-contents overflow-y-auto py-2 px-6" data-v-613c9b1b><!--[-->`);
      ssrRenderList(docMenu.value, (item, index) => {
        _push(`<li class="${ssrRenderClass([`level_${item.level}`, "leading-9 relative"])}" data-v-613c9b1b><a${ssrRenderAttr("href", "#" + item.id)} class="${ssrRenderClass({ "text-blue-600 active": tocActive.value === index })}" data-v-613c9b1b>${ssrInterpolate(item.text)}</a></li>`);
      });
      _push(`<!--]--></ul></div></div></div></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/read/post/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-613c9b1b"]]);

export { _id_ as default };
//# sourceMappingURL=_id_.9fc09f8f.mjs.map
