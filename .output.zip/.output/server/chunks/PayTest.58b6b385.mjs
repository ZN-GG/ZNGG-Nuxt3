import { defineComponent, ref, onUpdated, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "PayTest",
    __ssrInlineRender: true,
    setup(__props) {
      const msg = ref("\u7B49\u5F85\u751F\u6210\u8BA2\u5355...");
      ref({
        uid: "",
        codeUrl: "",
        status: ""
      });
      const QrCodeUrl = ref("/img/paytest.gif");
      const textareaRef = ref();
      onUpdated(() => {
        textareaRef.value.scrollTop = textareaRef.value.scrollHeight;
      });
      useHead({
        title: "\u652F\u4ED8\u6D4B\u8BD5",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u652F\u4ED8\u6D4B\u8BD5"
          },
          {
            name: "description",
            content: "\u7528\u4E8E\u6D4B\u8BD5\u626B\u7801\u652F\u4ED8"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">\u626B\u7801\u652F\u4ED8\u6D4B\u8BD5</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12"><div class="w-full flex flex-wrap"><div class="relative w-full md:w-6/12 md:pr-2"><div class="relative w-full"><p class="mx-auto text-center">\u652F\u4ED8\u4E8C\u7EF4\u7801</p><img class="mx-auto"${ssrRenderAttr("src", unref(QrCodeUrl))} alt=""><button class="flex mx-auto m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none leading"> \u751F\u6210\u8BA2\u5355 </button></div></div><div class="relative w-full md:w-6/12 md:pl-2"><div class="relative"><textarea readonly class="text-green-700 w-full bg-black boder-left boder-bottom outline-none p-3" rows="12">${ssrInterpolate(unref(msg))}</textarea></div></div></div></section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u672C\u5DE5\u5177\u7528\u4E8E\u6F14\u793A\u5982\u4F55\u4F7F\u7528\u652F\u4ED8\u63A5\u53E3\u521B\u5EFA\u626B\u7801\u652F\u4ED8\u529F\u80FD\u3002</p></blockquote><ul><li>\u751F\u6210\u7684\u4E8C\u7EF4\u7801\u53EA\u80FD\u4F7F\u7528\u624B\u673A\u6444\u50CF\u5934\u626B\u63CF\uFF01\uFF01\uFF01</li><li>\u4EC5\u7528\u4E8E\u652F\u4ED8\u6D4B\u8BD5\uFF0C\u91D1\u989D\u56FA\u5B9A\u4E3A0.1\u5143\uFF0C\u6D4B\u8BD5\u91D1\u989D\u4E0D\u8FDB\u884C\u9000\u6B3E\uFF01</li><li>\u6587\u7AE0\u5730\u5740\uFF1A<a href="/read/post/1260995610887061504">https://www.zngg.net/read/post/1260995610887061504</a></li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/PayTest.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=PayTest.58b6b385.mjs.map
