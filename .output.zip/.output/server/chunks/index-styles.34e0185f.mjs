const index_vue_vue_type_style_index_0_lang = ".RightFixedContainer-absolute{position:absolute}.RightFixedContainer-fixed{position:fixed;top:.5rem}.border-t-1{border-top-width:1px}.icon-arrow-down{transition-duration:.1s}.reverse{transform:rotate(180deg)}";

const indexStyles_34e0185f = [index_vue_vue_type_style_index_0_lang];

export { indexStyles_34e0185f as default };
//# sourceMappingURL=index-styles.34e0185f.mjs.map
