import { a as useNuxtApp, u as useHead } from './server.mjs';
import { defineComponent, ref, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ScreenRec",
  __ssrInlineRender: true,
  setup(__props) {
    useNuxtApp();
    ref(null);
    const recordMedia = ref("record-audio-plus-screen");
    const recordMediaList = ref([
      {
        "name": "\u5C4F\u5E55+\u9EA6\u514B\u98CE",
        "value": "record-audio-plus-screen"
      },
      {
        "name": "\u5C4F\u5E55",
        "value": "record-screen"
      }
    ]);
    const recordFormat = ref("video/webm;codecs=h264");
    const recordFormatList = ref([
      {
        "name": "MP4",
        "value": "video/webm;codecs=h264"
      },
      {
        "name": "webm",
        "value": "video/webm"
      },
      {
        "name": "vp8",
        "value": "video/webm;codecs=vp8"
      },
      {
        "name": "vp9",
        "value": "video/webm;codecs=vp9"
      },
      {
        "name": "mkv",
        "value": "video/x-matroska;codecs=avc1"
      }
    ]);
    const recordResolutions = ref("3840x2160");
    const recordResolutionsList = ref([
      {
        "name": "4K",
        "value": "3840x2160"
      },
      {
        "name": "2K",
        "value": "2560x1440"
      },
      {
        "name": "1080P",
        "value": "1920x1080"
      },
      {
        "name": "720P",
        "value": "1280x720"
      },
      {
        "name": "480P",
        "value": "640x480"
      }
    ]);
    useHead({
      title: "\u5728\u7EBF\u5C4F\u5E55\u5F55\u5236",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "\u5728\u7EBF\u5F55\u5C4F,\u5728\u7EBF\u5C4F\u5E55\u5F55\u5236\u5DE5\u5177,\u514D\u4E0B\u8F7D\u5F55\u5236\u5C4F\u5E55,\u4E0D\u7528\u4E0B\u8F7D\u5C31\u53EF\u4EE5\u5F55\u5C4F\u7684\u5DE5\u5177,RecordRTC,webrtc\u5F55\u5C4F" },
        { name: "description", content: "\u5728\u7EBF\u5F55\u5C4F\u5DE5\u5177\uFF0C\u65E0\u9700\u4E0B\u8F7D\u5373\u53EF\u5F55\u5236\u5C4F\u5E55\u5185\u5BB9\u548C\u9EA6\u514B\u98CE\u7684\u58F0\u97F3\u30024K\u514D\u8D39\u5728\u7EBF\u5F55\u5C4F\u5DE5\u5177\uFF0C\u4E0D\u82B1\u94B1\u4E0D\u4E0B\u8F7D\u5C31\u80FD\u7528\u7684\u5728\u7EBF\u5F55\u5C4F\u5DE5\u5177\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white" }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">\u5728\u7EBF\u5C4F\u5E55\u5F55\u5236</h1></div></div></div></section><div class="w-full container mx-auto h-72 md:hidden"><h2 class="text-xl p-4"> \u8BE5\u5DE5\u5177\u4E0D\u652F\u6301\u624B\u673A\u4F7F\u7528\uFF01 </h2></div><section class="w-full container px-4 mx-auto py-12 hidden md:block"><div class="flex"><div class="w-6/12 px-6"><video class="w-auto h-72 bg-black"></video></div><div class="w-6/12 pl-4"><div class="flex flex-wrap mb-4"><h2 class="w-full font-semibold text-gray-900">\u8BF7\u9009\u62E9\u5F55\u5236\u65B9\u5F0F\uFF1A</h2><!--[-->`);
      ssrRenderList(recordMediaList.value, (item, index) => {
        _push(`<button class="${ssrRenderClass([item.value == recordMedia.value ? "bg-blue-600 text-white" : "bg-gray-100", "cursor-pointer my-1 select-none mr-2 px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"])}">${ssrInterpolate(item.name)}</button>`);
      });
      _push(`<!--]--></div><div class="flex flex-wrap mb-4"><h2 class="w-full font-semibold text-gray-900">\u8BF7\u9009\u62E9\u5F55\u5236\u683C\u5F0F\uFF1A</h2><!--[-->`);
      ssrRenderList(recordFormatList.value, (item, index) => {
        _push(`<button class="${ssrRenderClass([item.value == recordFormat.value ? "bg-blue-600 text-white" : "bg-gray-100", "cursor-pointer my-1 select-none mr-2 px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"])}">${ssrInterpolate(item.name)}</button>`);
      });
      _push(`<!--]--></div><div class="flex flex-wrap mb-6"><h2 class="w-full font-semibold text-gray-900">\u8BF7\u9009\u62E9\u6E05\u6670\u5EA6\uFF1A</h2><!--[-->`);
      ssrRenderList(recordResolutionsList.value, (item, index) => {
        _push(`<button class="${ssrRenderClass([item.value == recordResolutions.value ? "bg-blue-600 text-white" : "bg-gray-100", "cursor-pointer my-1 select-none mr-2 px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"])}">${ssrInterpolate(item.name)}</button>`);
      });
      _push(`<!--]--></div><div class="flex flex-wrap mb-4"><button type="button" class="flex mr-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u5F00\u59CB\u5F55\u5236 </button><button type="button" class="flex mr-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u505C\u6B62 </button><button type="button" class="flex mr-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u4FDD\u5B58 </button></div></div></div></section><hr class="container mx-auto"><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({ "max-width": "none" })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u65E0\u9700\u4E0B\u8F7D\u5C31\u53EF\u4EE5\u5728\u7EBF\u5F55\u5C4F\u7684\u5DE5\u5177\uFF0C\u53EF\u9009\u62E9\u662F\u5426\u5F55\u5236\u9EA6\u514B\u98CE\u7684\u58F0\u97F3\uFF0C\u914D\u7F6E\u63A8\u8350\u4F7F\u7528\u9ED8\u8BA4\u914D\u7F6E\u3002 </p></blockquote><ul><li>Mac\u7528\u6237\u5EFA\u8BAE\u4F7F\u7528Safari\u6D4F\u89C8\u5668\uFF0C\u5B9E\u6D4BMac\u4E0BSafari\u5F55\u5236\u7684\u6E05\u6670\u5EA6\u66F4\u9AD8\u3002</li><li>Windows\u63A8\u8350\u4F7F\u7528Chrome\u6D4F\u89C8\u5668\u3002</li><li>\u624B\u673A\u7528\u6237\u6682\u4E0D\u652F\u6301\u4F7F\u7528\u3002</li><li>\u66F4\u591A\u529F\u80FD\u7B49\u5F85\u6DFB\u52A0\uFF1A</li><li>\u5F85\u5F00\u53D1\uFF1A\u6C34\u5370</li><li>\u5F85\u5F00\u53D1\uFF1A\u6587\u5B57\u8DD1\u9A6C\u706F</li></ul></article></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/ScreenRec.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=ScreenRec.5be4b58b.mjs.map
