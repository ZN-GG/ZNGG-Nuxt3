const WordToPDF_vue_vue_type_style_index_0_scoped_f3d2e81b_lang = ".convert-bg[data-v-f3d2e81b]{background:url(" + globalThis.__publicAssetsURL("img/office/office_banner.svg") + ") bottom no-repeat;height:130px}.convert-bg[data-v-f3d2e81b],.office-bg[data-v-f3d2e81b]{background-color:#f1f3fe}.in-upload-box[data-v-f3d2e81b]{left:50%;position:absolute;top:50%;transform:translate(-50%,-50%)}";

const WordToPDFStyles_775fec8e = [WordToPDF_vue_vue_type_style_index_0_scoped_f3d2e81b_lang];

export { WordToPDFStyles_775fec8e as default };
//# sourceMappingURL=WordToPDF-styles.775fec8e.mjs.map
