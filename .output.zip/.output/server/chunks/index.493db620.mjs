import { u as useHead, f as __nuxt_component_0$1 } from './server.mjs';
import { defineComponent, resolveComponent, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u7528\u6237\u4E2D\u5FC3",
      titleTemplate: (title) => `${title} - \u6301\u7EED\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "\u524D\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u540E\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u5728\u7EBF\u5C0F\u5DE5\u5177\uFF0C\u8BBE\u8BA1\u6280\u5DE7" },
        { name: "description", content: "ZNGG\u5728\u7EBF\u5DE5\u5177\u662F\u4E00\u4E2A\u6301\u7EED\u63D0\u4F9B\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA\u5E73\u53F0\uFF0C\u5E76\u5C06\u8F93\u51FA\u5185\u5BB9\u8F6C\u53D8\u4E3A\u6210\u679C\uFF0C\u63D0\u4F9B\u5404\u79CD\u5404\u6837\u7684\u5728\u7EBF\u5DE5\u5177\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UserLeftContents = __nuxt_component_0$1;
      const _component_NuxtChild = resolveComponent("NuxtChild");
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="flex container mx-auto my-6"><div class="w-2/12"><div class="w-full bg-white rounded p-4">`);
      _push(ssrRenderComponent(_component_UserLeftContents, null, null, _parent));
      _push(`</div></div><div class="w-8/12"><div class="w-full bg-white rounded mx-2 p-4">`);
      _push(ssrRenderComponent(_component_NuxtChild, null, null, _parent));
      _push(`</div></div><div class="w-2/12"><div class="w-full bg-white rounded mx-2"></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.493db620.mjs.map
