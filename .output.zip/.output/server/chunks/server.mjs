import { getCurrentInstance, inject, version, defineComponent, h, computed, unref, Transition, useSSRContext, ref, resolveComponent, shallowRef, reactive, createApp, toRef, isRef, effectScope, markRaw, watch, isReactive, toRaw, defineAsyncComponent, provide, onErrorCaptured, nextTick, onUnmounted, toRefs } from 'vue';
import { $fetch } from 'ofetch';
import { createHooks } from 'hookable';
import { getContext, executeAsync } from 'unctx';
import { hasProtocol, parseURL, joinURL, isEqual } from 'ufo';
import { createError as createError$1, sendRedirect } from 'h3';
import { useHead as useHead$1, createHead } from '@unhead/vue';
import { renderDOMHead, debouncedRenderDOMHead } from '@unhead/dom';
import { useRoute as useRoute$1, createMemoryHistory, createRouter } from 'vue-router';
import { ssrRenderComponent, ssrRenderSuspense } from 'vue/server-renderer';
import { a as useRuntimeConfig } from './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let __nuxt_component_0$1, useNuxtApp, appPageTransition, createError, _wrapIf, entry$1, appKeepalive, useRoute, defineStore, defineNuxtRouteMiddleware, navigateTo, useHead;
let __tla = (async () => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na, _oa, _pa, _qa, _ra, _sa, _ta, _ua, _va, _wa, _xa, _ya, _za;
  const appConfig = useRuntimeConfig().app;
  const baseURL = () => appConfig.baseURL;
  const nuxtAppCtx = getContext("nuxt-app");
  const NuxtPluginIndicator = "__nuxt_plugin";
  function createNuxtApp(options) {
    let hydratingCount = 0;
    const nuxtApp = {
      provide: void 0,
      globalName: "nuxt",
      payload: reactive({
        data: {},
        state: {},
        _errors: {},
        ...{
          serverRendered: true
        }
      }),
      static: {
        data: {}
      },
      isHydrating: false,
      deferHydration() {
        if (!nuxtApp.isHydrating) {
          return () => {
          };
        }
        hydratingCount++;
        let called = false;
        return () => {
          if (called) {
            return;
          }
          called = true;
          hydratingCount--;
          if (hydratingCount === 0) {
            nuxtApp.isHydrating = false;
            return nuxtApp.callHook("app:suspense:resolve");
          }
        };
      },
      _asyncDataPromises: {},
      _asyncData: {},
      ...options
    };
    nuxtApp.hooks = createHooks();
    nuxtApp.hook = nuxtApp.hooks.hook;
    nuxtApp.callHook = nuxtApp.hooks.callHook;
    nuxtApp.provide = (name, value) => {
      const $name = "$" + name;
      defineGetter(nuxtApp, $name, value);
      defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
    };
    defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
    defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
    {
      if (nuxtApp.ssrContext) {
        nuxtApp.ssrContext.nuxt = nuxtApp;
      }
      nuxtApp.ssrContext = nuxtApp.ssrContext || {};
      if (nuxtApp.ssrContext.payload) {
        Object.assign(nuxtApp.payload, nuxtApp.ssrContext.payload);
      }
      nuxtApp.ssrContext.payload = nuxtApp.payload;
      nuxtApp.payload.config = {
        public: options.ssrContext.runtimeConfig.public,
        app: options.ssrContext.runtimeConfig.app
      };
    }
    const runtimeConfig = options.ssrContext.runtimeConfig;
    const compatibilityConfig = new Proxy(runtimeConfig, {
      get(target, prop) {
        var _a2;
        if (prop === "public") {
          return target.public;
        }
        return (_a2 = target[prop]) != null ? _a2 : target.public[prop];
      },
      set(target, prop, value) {
        {
          return false;
        }
      }
    });
    nuxtApp.provide("config", compatibilityConfig);
    return nuxtApp;
  }
  async function applyPlugin(nuxtApp, plugin) {
    if (typeof plugin !== "function") {
      return;
    }
    const { provide: provide2 } = await callWithNuxt(nuxtApp, plugin, [
      nuxtApp
    ]) || {};
    if (provide2 && typeof provide2 === "object") {
      for (const key in provide2) {
        nuxtApp.provide(key, provide2[key]);
      }
    }
  }
  async function applyPlugins(nuxtApp, plugins2) {
    for (const plugin of plugins2) {
      await applyPlugin(nuxtApp, plugin);
    }
  }
  function normalizePlugins(_plugins2) {
    const plugins2 = _plugins2.map((plugin) => {
      if (typeof plugin !== "function") {
        return null;
      }
      if (plugin.length > 1) {
        return (nuxtApp) => plugin(nuxtApp, nuxtApp.provide);
      }
      return plugin;
    }).filter(Boolean);
    return plugins2;
  }
  function defineNuxtPlugin(plugin) {
    plugin[NuxtPluginIndicator] = true;
    return plugin;
  }
  function callWithNuxt(nuxt, setup, args) {
    const fn = () => args ? setup(...args) : setup();
    {
      return nuxtAppCtx.callAsync(nuxt, fn);
    }
  }
  useNuxtApp = function useNuxtApp2() {
    const nuxtAppInstance = nuxtAppCtx.tryUse();
    if (!nuxtAppInstance) {
      const vm = getCurrentInstance();
      if (!vm) {
        throw new Error("nuxt instance unavailable");
      }
      return vm.appContext.app.$nuxt;
    }
    return nuxtAppInstance;
  };
  function useRuntimeConfig$1() {
    return useNuxtApp().$config;
  }
  function defineGetter(obj, key, val) {
    Object.defineProperty(obj, key, {
      get: () => val
    });
  }
  const useError = () => toRef(useNuxtApp().payload, "error");
  const showError = (_err) => {
    const err = createError(_err);
    try {
      const nuxtApp = useNuxtApp();
      nuxtApp.callHook("app:error", err);
      const error = useError();
      error.value = error.value || err;
    } catch {
      throw err;
    }
    return err;
  };
  createError = (err) => {
    const _err = createError$1(err);
    _err.__nuxt_error = true;
    return _err;
  };
  function useState(...args) {
    const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
    if (typeof args[0] !== "string") {
      args.unshift(autoKey);
    }
    const [_key, init] = args;
    if (!_key || typeof _key !== "string") {
      throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
    }
    if (init !== void 0 && typeof init !== "function") {
      throw new Error("[nuxt] [useState] init must be a function: " + init);
    }
    const key = "$s" + _key;
    const nuxt = useNuxtApp();
    const state = toRef(nuxt.payload.state, key);
    if (state.value === void 0 && init) {
      const initialValue = init();
      if (isRef(initialValue)) {
        nuxt.payload.state[key] = initialValue;
        return initialValue;
      }
      state.value = initialValue;
    }
    return state;
  }
  const useRouter = () => {
    var _a2;
    return (_a2 = useNuxtApp()) == null ? void 0 : _a2.$router;
  };
  useRoute = () => {
    if (getCurrentInstance()) {
      return inject("_route", useNuxtApp()._route);
    }
    return useNuxtApp()._route;
  };
  defineNuxtRouteMiddleware = (middleware) => middleware;
  navigateTo = (to, options) => {
    if (!to) {
      to = "/";
    }
    const toPath = typeof to === "string" ? to : to.path || "/";
    const isExternal = hasProtocol(toPath, true);
    if (isExternal && !(options == null ? void 0 : options.external)) {
      throw new Error("Navigating to external URL is not allowed by default. Use `nagivateTo (url, { external: true })`.");
    }
    if (isExternal && parseURL(toPath).protocol === "script:") {
      throw new Error("Cannot navigate to an URL with script protocol.");
    }
    const router = useRouter();
    {
      const nuxtApp = useNuxtApp();
      if (nuxtApp.ssrContext && nuxtApp.ssrContext.event) {
        const redirectLocation = isExternal ? toPath : joinURL(useRuntimeConfig$1().app.baseURL, router.resolve(to).fullPath || "/");
        return nuxtApp.callHook("app:redirected").then(() => sendRedirect(nuxtApp.ssrContext.event, redirectLocation, (options == null ? void 0 : options.redirectCode) || 302));
      }
    }
    if (isExternal) {
      if (options == null ? void 0 : options.replace) {
        location.replace(toPath);
      } else {
        location.href = toPath;
      }
      return Promise.resolve();
    }
    return (options == null ? void 0 : options.replace) ? router.replace(to) : router.push(to);
  };
  useHead = function useHead2(input, options) {
    return useNuxtApp()._useHead(input, options);
  };
  const firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
  const DEFAULT_EXTERNAL_REL_ATTRIBUTE = "noopener noreferrer";
  function defineNuxtLink(options) {
    const componentName = options.componentName || "NuxtLink";
    return defineComponent({
      name: componentName,
      props: {
        to: {
          type: [
            String,
            Object
          ],
          default: void 0,
          required: false
        },
        href: {
          type: [
            String,
            Object
          ],
          default: void 0,
          required: false
        },
        target: {
          type: String,
          default: void 0,
          required: false
        },
        rel: {
          type: String,
          default: void 0,
          required: false
        },
        noRel: {
          type: Boolean,
          default: void 0,
          required: false
        },
        prefetch: {
          type: Boolean,
          default: void 0,
          required: false
        },
        noPrefetch: {
          type: Boolean,
          default: void 0,
          required: false
        },
        activeClass: {
          type: String,
          default: void 0,
          required: false
        },
        exactActiveClass: {
          type: String,
          default: void 0,
          required: false
        },
        prefetchedClass: {
          type: String,
          default: void 0,
          required: false
        },
        replace: {
          type: Boolean,
          default: void 0,
          required: false
        },
        ariaCurrentValue: {
          type: String,
          default: void 0,
          required: false
        },
        external: {
          type: Boolean,
          default: void 0,
          required: false
        },
        custom: {
          type: Boolean,
          default: void 0,
          required: false
        }
      },
      setup(props, { slots }) {
        const router = useRouter();
        const to = computed(() => {
          return props.to || props.href || "";
        });
        const isExternal = computed(() => {
          if (props.external) {
            return true;
          }
          if (props.target && props.target !== "_self") {
            return true;
          }
          if (typeof to.value === "object") {
            return false;
          }
          return to.value === "" || hasProtocol(to.value, true);
        });
        const prefetched = ref(false);
        const el = void 0;
        return () => {
          var _a2, _b2, _c2;
          if (!isExternal.value) {
            return h(resolveComponent("RouterLink"), {
              ref: void 0,
              to: to.value,
              ...prefetched.value && !props.custom ? {
                class: props.prefetchedClass || options.prefetchedClass
              } : {},
              activeClass: props.activeClass || options.activeClass,
              exactActiveClass: props.exactActiveClass || options.exactActiveClass,
              replace: props.replace,
              ariaCurrentValue: props.ariaCurrentValue,
              custom: props.custom
            }, slots.default);
          }
          const href = typeof to.value === "object" ? (_b2 = (_a2 = router.resolve(to.value)) == null ? void 0 : _a2.href) != null ? _b2 : null : to.value || null;
          const target = props.target || null;
          const rel = props.noRel ? null : firstNonUndefined(props.rel, options.externalRelAttribute, href ? DEFAULT_EXTERNAL_REL_ATTRIBUTE : "") || null;
          const navigate = () => navigateTo(href, {
            replace: props.replace
          });
          if (props.custom) {
            if (!slots.default) {
              return null;
            }
            return slots.default({
              href,
              navigate,
              route: router.resolve(href),
              rel,
              target,
              isExternal: isExternal.value,
              isActive: false,
              isExactActive: false
            });
          }
          return h("a", {
            ref: el,
            href,
            rel,
            target
          }, (_c2 = slots.default) == null ? void 0 : _c2.call(slots));
        };
      }
    });
  }
  __nuxt_component_0$1 = defineNuxtLink({
    componentName: "NuxtLink"
  });
  function isObject(value) {
    return value !== null && typeof value === "object";
  }
  function _defu(baseObject, defaults, namespace = ".", merger) {
    if (!isObject(defaults)) {
      return _defu(baseObject, {}, namespace, merger);
    }
    const object = Object.assign({}, defaults);
    for (const key in baseObject) {
      if (key === "__proto__" || key === "constructor") {
        continue;
      }
      const value = baseObject[key];
      if (value === null || value === void 0) {
        continue;
      }
      if (merger && merger(object, key, value, namespace)) {
        continue;
      }
      if (Array.isArray(value) && Array.isArray(object[key])) {
        object[key] = [
          ...value,
          ...object[key]
        ];
      } else if (isObject(value) && isObject(object[key])) {
        object[key] = _defu(value, object[key], (namespace ? `${namespace}.` : "") + key.toString(), merger);
      } else {
        object[key] = value;
      }
    }
    return object;
  }
  function createDefu(merger) {
    return (...arguments_) => arguments_.reduce((p, c) => _defu(p, c, "", merger), {});
  }
  const defuFn = createDefu((object, key, currentValue, _namespace) => {
    if (typeof object[key] !== "undefined" && typeof currentValue === "function") {
      object[key] = currentValue(object[key]);
      return true;
    }
  });
  const inlineConfig = {};
  defuFn(inlineConfig);
  const components = {};
  const _nuxt_components_plugin_mjs_KR1HBZs4kY = defineNuxtPlugin((nuxtApp) => {
    for (const name in components) {
      nuxtApp.vueApp.component(name, components[name]);
      nuxtApp.vueApp.component("Lazy" + name, components[name]);
    }
  });
  function createHead$1(initHeadObject) {
    const unhead = createHead();
    const legacyHead = {
      unhead,
      install(app) {
        if (app.config.globalProperties)
          app.config.globalProperties.$head = unhead;
        app.provide("usehead", unhead);
      },
      resolveTags() {
        return unhead.resolveTags();
      },
      headEntries() {
        return unhead.headEntries();
      },
      headTags() {
        return unhead.resolveTags();
      },
      push(input, options) {
        return unhead.push(input, options);
      },
      addEntry(input, options) {
        return unhead.push(input, options);
      },
      addHeadObjs(input, options) {
        return unhead.push(input, options);
      },
      addReactiveEntry(input, options) {
        const api = useHead$1(input, options);
        if (typeof api !== "undefined")
          return api.dispose;
        return () => {
        };
      },
      removeHeadObjs() {
      },
      updateDOM(document2, force) {
        if (force)
          renderDOMHead(unhead, {
            document: document2
          });
        else
          debouncedRenderDOMHead(unhead, {
            delayFn: (fn) => setTimeout(() => fn(), 50),
            document: document2
          });
      },
      internalHooks: unhead.hooks,
      hooks: {
        "before:dom": [],
        "resolved:tags": [],
        "resolved:entries": []
      }
    };
    unhead.addHeadObjs = legacyHead.addHeadObjs;
    unhead.updateDOM = legacyHead.updateDOM;
    unhead.hooks.hook("dom:beforeRender", (ctx) => {
      for (const hook of legacyHead.hooks["before:dom"]) {
        if (hook() === false)
          ctx.shouldRender = false;
      }
    });
    if (initHeadObject)
      legacyHead.addHeadObjs(initHeadObject);
    return legacyHead;
  }
  version.startsWith("2.");
  const appHead = {
    "meta": [
      {
        "name": "viewport",
        "content": "width=device-width, initial-scale=1, maximum-scale=1"
      },
      {
        "charset": "utf-8"
      }
    ],
    "link": [],
    "style": [],
    "script": [],
    "noscript": [],
    "viewport": "width=device-width, initial-scale=1, maximum-scale=1",
    "charset": "utf-8"
  };
  const appLayoutTransition = false;
  appPageTransition = false;
  appKeepalive = false;
  const node_modules_nuxt_dist_head_runtime_lib_vueuse_head_plugin_mjs_D7WGfuP1A0 = defineNuxtPlugin((nuxtApp) => {
    const head = createHead$1();
    head.push(appHead);
    nuxtApp.vueApp.use(head);
    nuxtApp._useHead = useHead$1;
    {
      nuxtApp.ssrContext.renderMeta = async () => {
        const { renderSSRHead } = await import('@unhead/ssr').then(async (m) => {
          await m.__tla;
          return m;
        });
        const meta = await renderSSRHead(head.unhead);
        return {
          ...meta,
          bodyScriptsPrepend: meta.bodyTagsOpen,
          bodyScripts: meta.bodyTags
        };
      };
    }
  });
  const __nuxt_page_meta$D = {
    title: "Some Page"
  };
  const __nuxt_page_meta$C = {};
  const __nuxt_page_meta$B = {};
  const __nuxt_page_meta$A = {};
  const __nuxt_page_meta$z = {};
  const __nuxt_page_meta$y = {};
  const __nuxt_page_meta$x = {};
  const __nuxt_page_meta$w = {};
  const __nuxt_page_meta$v = {};
  const __nuxt_page_meta$u = {};
  const __nuxt_page_meta$t = {};
  const __nuxt_page_meta$s = {};
  const __nuxt_page_meta$r = {};
  const __nuxt_page_meta$q = {};
  const __nuxt_page_meta$p = {};
  const __nuxt_page_meta$o = {};
  const __nuxt_page_meta$n = {};
  const __nuxt_page_meta$m = {};
  const __nuxt_page_meta$l = {};
  const __nuxt_page_meta$k = {};
  const __nuxt_page_meta$j = {};
  const __nuxt_page_meta$i = {};
  const __nuxt_page_meta$h = {};
  const __nuxt_page_meta$g = {};
  const __nuxt_page_meta$f = {};
  const __nuxt_page_meta$e = {
    layout: "empty"
  };
  const __nuxt_page_meta$d = {};
  const __nuxt_page_meta$c = {};
  const __nuxt_page_meta$b = {};
  const __nuxt_page_meta$a = {
    layout: "empty"
  };
  const __nuxt_page_meta$9 = {};
  const __nuxt_page_meta$8 = {};
  const __nuxt_page_meta$7 = {
    layout: "empty"
  };
  const __nuxt_page_meta$6 = {};
  const __nuxt_page_meta$5 = {
    layout: "default",
    middleware: [
      "auth"
    ]
  };
  const __nuxt_page_meta$4 = {};
  const __nuxt_page_meta$3 = {};
  const __nuxt_page_meta$2 = {};
  const __nuxt_page_meta$1 = {};
  const __nuxt_page_meta = {
    layout: "empty",
    middleware: [
      "auth"
    ]
  };
  const _routes = [
    {
      name: (_a = __nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.name) != null ? _a : "index",
      path: (_b = __nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.path) != null ? _b : "/",
      file: "F:/IdeaProject/ZNGG-Nuxt3/pages/index.vue",
      children: [],
      meta: __nuxt_page_meta$D,
      alias: (__nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.alias) || [],
      redirect: (__nuxt_page_meta$D == null ? void 0 : __nuxt_page_meta$D.redirect) || void 0,
      component: () => import('./index.86689e44.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    },
    {
      path: (_c = __nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.path) != null ? _c : "/link",
      file: "F:/IdeaProject/ZNGG-Nuxt3/pages/link.vue",
      children: [
        {
          name: (_d = __nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.name) != null ? _d : "link",
          path: (_e = __nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.path) != null ? _e : "",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/link/index.vue",
          children: [],
          meta: __nuxt_page_meta$B,
          alias: (__nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.alias) || [],
          redirect: (__nuxt_page_meta$B == null ? void 0 : __nuxt_page_meta$B.redirect) || void 0,
          component: () => import('./index.8c54c38a.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        }
      ],
      name: (_f = __nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.name) != null ? _f : void 0,
      meta: __nuxt_page_meta$C,
      alias: (__nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.alias) || [],
      redirect: (__nuxt_page_meta$C == null ? void 0 : __nuxt_page_meta$C.redirect) || void 0,
      component: () => import('./link.6aa350b3.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    },
    {
      path: (_g = __nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.path) != null ? _g : "/read",
      file: "F:/IdeaProject/ZNGG-Nuxt3/pages/read.vue",
      children: [
        {
          name: (_h = __nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.name) != null ? _h : "read",
          path: (_i = __nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.path) != null ? _i : "",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/read/index.vue",
          children: [],
          meta: __nuxt_page_meta$z,
          alias: (__nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.alias) || [],
          redirect: (__nuxt_page_meta$z == null ? void 0 : __nuxt_page_meta$z.redirect) || void 0,
          component: () => import('./index.2caa451e.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        },
        {
          name: (_j = __nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.name) != null ? _j : "read-post",
          path: (_k = __nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.path) != null ? _k : "post",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/read/post.vue",
          children: [
            {
              name: (_l = __nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.name) != null ? _l : "read-post-id",
              path: (_m = __nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.path) != null ? _m : ":id",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/read/post/[id].vue",
              children: [],
              meta: __nuxt_page_meta$x,
              alias: (__nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.alias) || [],
              redirect: (__nuxt_page_meta$x == null ? void 0 : __nuxt_page_meta$x.redirect) || void 0,
              component: () => import('./_id_.b207e71c.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            }
          ],
          meta: __nuxt_page_meta$y,
          alias: (__nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.alias) || [],
          redirect: (__nuxt_page_meta$y == null ? void 0 : __nuxt_page_meta$y.redirect) || void 0,
          component: () => import('./post.dfc87928.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        }
      ],
      name: (_n = __nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.name) != null ? _n : void 0,
      meta: __nuxt_page_meta$A,
      alias: (__nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.alias) || [],
      redirect: (__nuxt_page_meta$A == null ? void 0 : __nuxt_page_meta$A.redirect) || void 0,
      component: () => import('./read.8dcf2c12.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    },
    {
      path: (_o = __nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.path) != null ? _o : "/tool",
      file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool.vue",
      children: [
        {
          name: (_p = __nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.name) != null ? _p : "tool-detail",
          path: (_q = __nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.path) != null ? _q : "detail",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail.vue",
          children: [
            {
              name: (_r = __nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.name) != null ? _r : "tool-detail-Base64Convert",
              path: (_s = __nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.path) != null ? _s : "Base64Convert",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/Base64Convert.vue",
              children: [],
              meta: __nuxt_page_meta$u,
              alias: (__nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.alias) || [],
              redirect: (__nuxt_page_meta$u == null ? void 0 : __nuxt_page_meta$u.redirect) || void 0,
              component: () => import('./Base64Convert.e781af86.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_t = __nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.name) != null ? _t : "tool-detail-CSSGradient",
              path: (_u = __nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.path) != null ? _u : "CSSGradient",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/CSSGradient.vue",
              children: [],
              meta: __nuxt_page_meta$t,
              alias: (__nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.alias) || [],
              redirect: (__nuxt_page_meta$t == null ? void 0 : __nuxt_page_meta$t.redirect) || void 0,
              component: () => import('./CSSGradient.2176afc2.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_v = __nuxt_page_meta$s == null ? void 0 : __nuxt_page_meta$s.name) != null ? _v : "tool-detail-DownloadM3U8",
              path: (_w = __nuxt_page_meta$s == null ? void 0 : __nuxt_page_meta$s.path) != null ? _w : "DownloadM3U8",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/DownloadM3U8.vue",
              children: [],
              meta: __nuxt_page_meta$s,
              alias: (__nuxt_page_meta$s == null ? void 0 : __nuxt_page_meta$s.alias) || [],
              redirect: (__nuxt_page_meta$s == null ? void 0 : __nuxt_page_meta$s.redirect) || void 0,
              component: () => import('./DownloadM3U8.7933bf5a.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_x = __nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.name) != null ? _x : "tool-detail-EnglistConvert",
              path: (_y = __nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.path) != null ? _y : "EnglistConvert",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/EnglistConvert.vue",
              children: [],
              meta: __nuxt_page_meta$r,
              alias: (__nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.alias) || [],
              redirect: (__nuxt_page_meta$r == null ? void 0 : __nuxt_page_meta$r.redirect) || void 0,
              component: () => import('./EnglistConvert.5d659d00.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_z = __nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.name) != null ? _z : "tool-detail-FancyBorderRadius",
              path: (_A = __nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.path) != null ? _A : "FancyBorderRadius",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/FancyBorderRadius.vue",
              children: [],
              meta: __nuxt_page_meta$q,
              alias: (__nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.alias) || [],
              redirect: (__nuxt_page_meta$q == null ? void 0 : __nuxt_page_meta$q.redirect) || void 0,
              component: () => import('./FancyBorderRadius.ef72d9c9.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_B = __nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.name) != null ? _B : "tool-detail-FlvPlayer",
              path: (_C = __nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.path) != null ? _C : "FlvPlayer",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/FlvPlayer.vue",
              children: [],
              meta: __nuxt_page_meta$p,
              alias: (__nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.alias) || [],
              redirect: (__nuxt_page_meta$p == null ? void 0 : __nuxt_page_meta$p.redirect) || void 0,
              component: () => import('./FlvPlayer.038b2314.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_D = __nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.name) != null ? _D : "tool-detail-ImageToBase64",
              path: (_E = __nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.path) != null ? _E : "ImageToBase64",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/ImageToBase64.vue",
              children: [],
              meta: __nuxt_page_meta$o,
              alias: (__nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.alias) || [],
              redirect: (__nuxt_page_meta$o == null ? void 0 : __nuxt_page_meta$o.redirect) || void 0,
              component: () => import('./ImageToBase64.bedcc86d.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_F = __nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.name) != null ? _F : "tool-detail-M3U8V2Pro",
              path: (_G = __nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.path) != null ? _G : "M3U8V2Pro",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/M3U8V2Pro.vue",
              children: [],
              meta: __nuxt_page_meta$n,
              alias: (__nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.alias) || [],
              redirect: (__nuxt_page_meta$n == null ? void 0 : __nuxt_page_meta$n.redirect) || void 0,
              component: () => import('./M3U8V2Pro.6b2a231c.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_H = __nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.name) != null ? _H : "tool-detail-MakePhrase",
              path: (_I = __nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.path) != null ? _I : "MakePhrase",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/MakePhrase.vue",
              children: [],
              meta: __nuxt_page_meta$m,
              alias: (__nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.alias) || [],
              redirect: (__nuxt_page_meta$m == null ? void 0 : __nuxt_page_meta$m.redirect) || void 0,
              component: () => import('./MakePhrase.6fb03b9e.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_J = __nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.name) != null ? _J : "tool-detail-NPlayer",
              path: (_K = __nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.path) != null ? _K : "NPlayer",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/NPlayer.vue",
              children: [],
              meta: __nuxt_page_meta$l,
              alias: (__nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.alias) || [],
              redirect: (__nuxt_page_meta$l == null ? void 0 : __nuxt_page_meta$l.redirect) || void 0,
              component: () => import('./NPlayer.12a56fec.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_L = __nuxt_page_meta$k == null ? void 0 : __nuxt_page_meta$k.name) != null ? _L : "tool-detail-NationalDayAvatar",
              path: (_M = __nuxt_page_meta$k == null ? void 0 : __nuxt_page_meta$k.path) != null ? _M : "NationalDayAvatar",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/NationalDayAvatar.vue",
              children: [],
              meta: __nuxt_page_meta$k,
              alias: (__nuxt_page_meta$k == null ? void 0 : __nuxt_page_meta$k.alias) || [],
              redirect: (__nuxt_page_meta$k == null ? void 0 : __nuxt_page_meta$k.redirect) || void 0,
              component: () => import('./NationalDayAvatar.42019c15.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_N = __nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.name) != null ? _N : "tool-detail-PngToSVG",
              path: (_O = __nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.path) != null ? _O : "PngToSVG",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/PngToSVG.vue",
              children: [],
              meta: __nuxt_page_meta$j,
              alias: (__nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.alias) || [],
              redirect: (__nuxt_page_meta$j == null ? void 0 : __nuxt_page_meta$j.redirect) || void 0,
              component: () => import('./PngToSVG.53d5ff3b.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_P = __nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.name) != null ? _P : "tool-detail-ScreenRec",
              path: (_Q = __nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.path) != null ? _Q : "ScreenRec",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/ScreenRec.vue",
              children: [],
              meta: __nuxt_page_meta$i,
              alias: (__nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.alias) || [],
              redirect: (__nuxt_page_meta$i == null ? void 0 : __nuxt_page_meta$i.redirect) || void 0,
              component: () => import('./ScreenRec.8a458fb9.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_R = __nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.name) != null ? _R : "tool-detail-TextDistinct",
              path: (_S = __nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.path) != null ? _S : "TextDistinct",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/TextDistinct.vue",
              children: [],
              meta: __nuxt_page_meta$h,
              alias: (__nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.alias) || [],
              redirect: (__nuxt_page_meta$h == null ? void 0 : __nuxt_page_meta$h.redirect) || void 0,
              component: () => import('./TextDistinct.b29a6f38.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_T = __nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.name) != null ? _T : "tool-detail-TextSecret",
              path: (_U = __nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.path) != null ? _U : "TextSecret",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/TextSecret.vue",
              children: [],
              meta: __nuxt_page_meta$g,
              alias: (__nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.alias) || [],
              redirect: (__nuxt_page_meta$g == null ? void 0 : __nuxt_page_meta$g.redirect) || void 0,
              component: () => import('./TextSecret.739e52e3.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_V = __nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.name) != null ? _V : "tool-detail-Timestamp",
              path: (_W = __nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.path) != null ? _W : "Timestamp",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/Timestamp.vue",
              children: [],
              meta: __nuxt_page_meta$f,
              alias: (__nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.alias) || [],
              redirect: (__nuxt_page_meta$f == null ? void 0 : __nuxt_page_meta$f.redirect) || void 0,
              component: () => import('./Timestamp.b037abfb.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_X = __nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.name) != null ? _X : "tool-detail-TraceReplay",
              path: (_Y = __nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.path) != null ? _Y : "TraceReplay",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/TraceReplay.vue",
              children: [],
              meta: __nuxt_page_meta$e,
              alias: (__nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.alias) || [],
              redirect: (__nuxt_page_meta$e == null ? void 0 : __nuxt_page_meta$e.redirect) || void 0,
              component: () => import('./TraceReplay.6405e3b4.mjs').then((m) => m.default || m)
            },
            {
              name: (_Z = __nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.name) != null ? _Z : "tool-detail-UnicodeConvert",
              path: (__ = __nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.path) != null ? __ : "UnicodeConvert",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/UnicodeConvert.vue",
              children: [],
              meta: __nuxt_page_meta$d,
              alias: (__nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.alias) || [],
              redirect: (__nuxt_page_meta$d == null ? void 0 : __nuxt_page_meta$d.redirect) || void 0,
              component: () => import('./UnicodeConvert.9ac994c8.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_$ = __nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.name) != null ? _$ : "tool-detail-WeiBoGenerates",
              path: (_aa = __nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.path) != null ? _aa : "WeiBoGenerates",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/WeiBoGenerates.vue",
              children: [],
              meta: __nuxt_page_meta$c,
              alias: (__nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.alias) || [],
              redirect: (__nuxt_page_meta$c == null ? void 0 : __nuxt_page_meta$c.redirect) || void 0,
              component: () => import('./WeiBoGenerates.b8927e20.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_ba = __nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.name) != null ? _ba : "tool-detail-Whois",
              path: (_ca = __nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.path) != null ? _ca : "Whois",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/Whois.vue",
              children: [],
              meta: __nuxt_page_meta$b,
              alias: (__nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.alias) || [],
              redirect: (__nuxt_page_meta$b == null ? void 0 : __nuxt_page_meta$b.redirect) || void 0,
              component: () => import('./Whois.f05815ae.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_da = __nuxt_page_meta$a == null ? void 0 : __nuxt_page_meta$a.name) != null ? _da : "tool-detail-WordConvert",
              path: (_ea = __nuxt_page_meta$a == null ? void 0 : __nuxt_page_meta$a.path) != null ? _ea : "WordConvert",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/WordConvert.vue",
              children: [],
              meta: __nuxt_page_meta$a,
              alias: (__nuxt_page_meta$a == null ? void 0 : __nuxt_page_meta$a.alias) || [],
              redirect: (__nuxt_page_meta$a == null ? void 0 : __nuxt_page_meta$a.redirect) || void 0,
              component: () => import('./WordConvert.cfcee956.mjs').then((m) => m.default || m)
            },
            {
              name: (_fa = __nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.name) != null ? _fa : "tool-detail-WordToPDF",
              path: (_ga = __nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.path) != null ? _ga : "WordToPDF",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/WordToPDF.vue",
              children: [],
              meta: __nuxt_page_meta$9,
              alias: (__nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.alias) || [],
              redirect: (__nuxt_page_meta$9 == null ? void 0 : __nuxt_page_meta$9.redirect) || void 0,
              component: () => import('./WordToPDF.328e93d9.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_ha = __nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.name) != null ? _ha : "tool-detail-YinHeOSCode",
              path: (_ia = __nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.path) != null ? _ia : "YinHeOSCode",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/YinHeOSCode.vue",
              children: [],
              meta: __nuxt_page_meta$8,
              alias: (__nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.alias) || [],
              redirect: (__nuxt_page_meta$8 == null ? void 0 : __nuxt_page_meta$8.redirect) || void 0,
              component: () => import('./YinHeOSCode.1d769d06.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: (_ja = __nuxt_page_meta$7 == null ? void 0 : __nuxt_page_meta$7.name) != null ? _ja : "tool-detail-office-type",
              path: (_ka = __nuxt_page_meta$7 == null ? void 0 : __nuxt_page_meta$7.path) != null ? _ka : "office/:type",
              file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/detail/office/[type].vue",
              children: [],
              meta: __nuxt_page_meta$7,
              alias: (__nuxt_page_meta$7 == null ? void 0 : __nuxt_page_meta$7.alias) || [],
              redirect: (__nuxt_page_meta$7 == null ? void 0 : __nuxt_page_meta$7.redirect) || void 0,
              component: () => import('./_type_.73feb55a.mjs').then((m) => m.default || m)
            }
          ],
          meta: __nuxt_page_meta$v,
          alias: (__nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.alias) || [],
          redirect: (__nuxt_page_meta$v == null ? void 0 : __nuxt_page_meta$v.redirect) || void 0,
          component: () => import('./detail.f7896e95.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        },
        {
          name: (_la = __nuxt_page_meta$6 == null ? void 0 : __nuxt_page_meta$6.name) != null ? _la : "tool",
          path: (_ma = __nuxt_page_meta$6 == null ? void 0 : __nuxt_page_meta$6.path) != null ? _ma : "",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/tool/index.vue",
          children: [],
          meta: __nuxt_page_meta$6,
          alias: (__nuxt_page_meta$6 == null ? void 0 : __nuxt_page_meta$6.alias) || [],
          redirect: (__nuxt_page_meta$6 == null ? void 0 : __nuxt_page_meta$6.redirect) || void 0,
          component: () => import('./index.66ef2233.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        }
      ],
      name: (_na = __nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.name) != null ? _na : void 0,
      meta: __nuxt_page_meta$w,
      alias: (__nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.alias) || [],
      redirect: (__nuxt_page_meta$w == null ? void 0 : __nuxt_page_meta$w.redirect) || void 0,
      component: () => import('./tool.e15837f7.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    },
    {
      path: (_oa = __nuxt_page_meta$5 == null ? void 0 : __nuxt_page_meta$5.path) != null ? _oa : "/user",
      file: "F:/IdeaProject/ZNGG-Nuxt3/pages/user/index.vue",
      children: [
        {
          name: (_pa = __nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.name) != null ? _pa : "user-index-create",
          path: (_qa = __nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.path) != null ? _qa : "create",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/user/index/create.vue",
          children: [],
          meta: __nuxt_page_meta$4,
          alias: (__nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.alias) || [],
          redirect: (__nuxt_page_meta$4 == null ? void 0 : __nuxt_page_meta$4.redirect) || void 0,
          component: () => import('./create.2b539284.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        },
        {
          name: (_ra = __nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.name) != null ? _ra : "user-index",
          path: (_sa = __nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.path) != null ? _sa : "",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/user/index/index.vue",
          children: [],
          meta: __nuxt_page_meta$3,
          alias: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.alias) || [],
          redirect: (__nuxt_page_meta$3 == null ? void 0 : __nuxt_page_meta$3.redirect) || void 0,
          component: () => import('./index.8ef5dec1.mjs').then((m) => m.default || m)
        },
        {
          name: (_ta = __nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.name) != null ? _ta : "user-index-info",
          path: (_ua = __nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.path) != null ? _ua : "info",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/user/index/info.vue",
          children: [],
          meta: __nuxt_page_meta$2,
          alias: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.alias) || [],
          redirect: (__nuxt_page_meta$2 == null ? void 0 : __nuxt_page_meta$2.redirect) || void 0,
          component: () => import('./info.653f63d7.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        },
        {
          name: (_va = __nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.name) != null ? _va : "user-index-order",
          path: (_wa = __nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.path) != null ? _wa : "order",
          file: "F:/IdeaProject/ZNGG-Nuxt3/pages/user/index/order.vue",
          children: [],
          meta: __nuxt_page_meta$1,
          alias: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.alias) || [],
          redirect: (__nuxt_page_meta$1 == null ? void 0 : __nuxt_page_meta$1.redirect) || void 0,
          component: () => import('./order.b7c171d0.mjs').then((m) => m.default || m)
        }
      ],
      name: (_xa = __nuxt_page_meta$5 == null ? void 0 : __nuxt_page_meta$5.name) != null ? _xa : void 0,
      meta: __nuxt_page_meta$5,
      alias: (__nuxt_page_meta$5 == null ? void 0 : __nuxt_page_meta$5.alias) || [],
      redirect: (__nuxt_page_meta$5 == null ? void 0 : __nuxt_page_meta$5.redirect) || void 0,
      component: () => import('./index.cee8cc53.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    },
    {
      name: (_ya = __nuxt_page_meta == null ? void 0 : __nuxt_page_meta.name) != null ? _ya : "writer",
      path: (_za = __nuxt_page_meta == null ? void 0 : __nuxt_page_meta.path) != null ? _za : "/writer",
      file: "F:/IdeaProject/ZNGG-Nuxt3/pages/writer.vue",
      children: [],
      meta: __nuxt_page_meta,
      alias: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.alias) || [],
      redirect: (__nuxt_page_meta == null ? void 0 : __nuxt_page_meta.redirect) || void 0,
      component: () => import('./writer.788f8f2b.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    }
  ];
  const routerOptions0 = {
    scrollBehavior(to, from, savedPosition) {
      const nuxtApp = useNuxtApp();
      let position = savedPosition || void 0;
      if (!position && from && to && to.meta.scrollToTop !== false && _isDifferentRoute(from, to)) {
        position = {
          left: 0,
          top: 0
        };
      }
      if (to.path === from.path) {
        if (from.hash && !to.hash) {
          return {
            left: 0,
            top: 0
          };
        }
        if (to.hash) {
          return {
            el: to.hash,
            top: _getHashElementScrollMarginTop(to.hash)
          };
        }
      }
      const hasTransition = (route) => {
        var _a2;
        return !!((_a2 = route.meta.pageTransition) != null ? _a2 : appPageTransition);
      };
      const hookToWait = hasTransition(from) && hasTransition(to) ? "page:transition:finish" : "page:finish";
      return new Promise((resolve) => {
        nuxtApp.hooks.hookOnce(hookToWait, async () => {
          await nextTick();
          if (to.hash) {
            position = {
              el: to.hash,
              top: _getHashElementScrollMarginTop(to.hash)
            };
          }
          resolve(position);
        });
      });
    }
  };
  function _getHashElementScrollMarginTop(selector) {
    try {
      const elem = document.querySelector(selector);
      if (elem) {
        return parseFloat(getComputedStyle(elem).scrollMarginTop);
      }
    } catch {
    }
    return 0;
  }
  function _isDifferentRoute(a, b) {
    const samePageComponent = a.matched[0] === b.matched[0];
    if (!samePageComponent) {
      return true;
    }
    if (samePageComponent && JSON.stringify(a.params) !== JSON.stringify(b.params)) {
      return true;
    }
    return false;
  }
  const configRouterOptions = {};
  const routerOptions = {
    ...configRouterOptions,
    ...routerOptions0
  };
  const validate = defineNuxtRouteMiddleware(async (to) => {
    var _a2;
    let __temp, __restore;
    if (!((_a2 = to.meta) == null ? void 0 : _a2.validate)) {
      return;
    }
    const result = ([__temp, __restore] = executeAsync(() => Promise.resolve(to.meta.validate(to))), __temp = await __temp, __restore(), __temp);
    if (typeof result === "boolean") {
      return result;
    }
    return createError(result);
  });
  const globalMiddleware = [
    validate
  ];
  const namedMiddleware = {
    auth: () => import('./auth.df400583.mjs').then(async (m) => {
      await m.__tla;
      return m;
    })
  };
  const node_modules_nuxt_dist_pages_runtime_router_mjs_qNv5Ky2ZmB = defineNuxtPlugin(async (nuxtApp) => {
    var _a2, _b2, _c2, _d2;
    let __temp, __restore;
    let routerBase = useRuntimeConfig$1().app.baseURL;
    if (routerOptions.hashMode && !routerBase.includes("#")) {
      routerBase += "#";
    }
    const history = (_b2 = (_a2 = routerOptions.history) == null ? void 0 : _a2.call(routerOptions, routerBase)) != null ? _b2 : createMemoryHistory(routerBase);
    const routes = (_d2 = (_c2 = routerOptions.routes) == null ? void 0 : _c2.call(routerOptions, _routes)) != null ? _d2 : _routes;
    const initialURL = nuxtApp.ssrContext.url;
    const router = createRouter({
      ...routerOptions,
      history,
      routes
    });
    nuxtApp.vueApp.use(router);
    const previousRoute = shallowRef(router.currentRoute.value);
    router.afterEach((_to, from) => {
      previousRoute.value = from;
    });
    Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
      get: () => previousRoute.value
    });
    const _route = shallowRef(router.resolve(initialURL));
    const syncCurrentRoute = () => {
      _route.value = router.currentRoute.value;
    };
    nuxtApp.hook("page:finish", syncCurrentRoute);
    router.afterEach((to, from) => {
      var _a3, _b3, _c3, _d3;
      if (((_b3 = (_a3 = to.matched[0]) == null ? void 0 : _a3.components) == null ? void 0 : _b3.default) === ((_d3 = (_c3 = from.matched[0]) == null ? void 0 : _c3.components) == null ? void 0 : _d3.default)) {
        syncCurrentRoute();
      }
    });
    const route = {};
    for (const key in _route.value) {
      route[key] = computed(() => _route.value[key]);
    }
    nuxtApp._route = reactive(route);
    nuxtApp._middleware = nuxtApp._middleware || {
      global: [],
      named: {}
    };
    useError();
    try {
      if (true) {
        ;
        [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
        ;
      }
      ;
      [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
      ;
    } catch (error2) {
      callWithNuxt(nuxtApp, showError, [
        error2
      ]);
    }
    const initialLayout = useState("_layout");
    router.beforeEach(async (to, from) => {
      var _a3, _b3;
      to.meta = reactive(to.meta);
      if (nuxtApp.isHydrating) {
        to.meta.layout = (_a3 = initialLayout.value) != null ? _a3 : to.meta.layout;
      }
      nuxtApp._processingMiddleware = true;
      const middlewareEntries = /* @__PURE__ */ new Set([
        ...globalMiddleware,
        ...nuxtApp._middleware.global
      ]);
      for (const component of to.matched) {
        const componentMiddleware = component.meta.middleware;
        if (!componentMiddleware) {
          continue;
        }
        if (Array.isArray(componentMiddleware)) {
          for (const entry2 of componentMiddleware) {
            middlewareEntries.add(entry2);
          }
        } else {
          middlewareEntries.add(componentMiddleware);
        }
      }
      for (const entry2 of middlewareEntries) {
        const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_b3 = namedMiddleware[entry2]) == null ? void 0 : _b3.call(namedMiddleware).then((r) => r.default || r)) : entry2;
        if (!middleware) {
          throw new Error(`Unknown route middleware: '${entry2}'.`);
        }
        const result = await callWithNuxt(nuxtApp, middleware, [
          to,
          from
        ]);
        {
          if (result === false || result instanceof Error) {
            const error2 = result || createError$1({
              statusCode: 404,
              statusMessage: `Page Not Found: ${initialURL}`
            });
            await callWithNuxt(nuxtApp, showError, [
              error2
            ]);
            return false;
          }
        }
        if (result || result === false) {
          return result;
        }
      }
    });
    router.afterEach(async (to) => {
      delete nuxtApp._processingMiddleware;
      if (to.matched.length === 0) {
        callWithNuxt(nuxtApp, showError, [
          createError$1({
            statusCode: 404,
            fatal: false,
            statusMessage: `Page not found: ${to.fullPath}`
          })
        ]);
      } else {
        const currentURL = to.fullPath || "/";
        if (!isEqual(currentURL, initialURL)) {
          await callWithNuxt(nuxtApp, navigateTo, [
            currentURL
          ]);
        }
      }
    });
    nuxtApp.hooks.hookOnce("app:created", async () => {
      try {
        await router.replace({
          ...router.resolve(initialURL),
          name: void 0,
          force: true
        });
      } catch (error2) {
        callWithNuxt(nuxtApp, showError, [
          error2
        ]);
      }
    });
    return {
      provide: {
        router
      }
    };
  });
  const isVue2 = false;
  let activePinia;
  const setActivePinia = (pinia) => activePinia = pinia;
  const piniaSymbol = Symbol();
  function isPlainObject(o) {
    return o && typeof o === "object" && Object.prototype.toString.call(o) === "[object Object]" && typeof o.toJSON !== "function";
  }
  var MutationType;
  (function(MutationType2) {
    MutationType2["direct"] = "direct";
    MutationType2["patchObject"] = "patch object";
    MutationType2["patchFunction"] = "patch function";
  })(MutationType || (MutationType = {}));
  function createPinia() {
    const scope = effectScope(true);
    const state = scope.run(() => ref({}));
    let _p2 = [];
    let toBeInstalled = [];
    const pinia = markRaw({
      install(app) {
        setActivePinia(pinia);
        {
          pinia._a = app;
          app.provide(piniaSymbol, pinia);
          app.config.globalProperties.$pinia = pinia;
          toBeInstalled.forEach((plugin) => _p2.push(plugin));
          toBeInstalled = [];
        }
      },
      use(plugin) {
        if (!this._a && !isVue2) {
          toBeInstalled.push(plugin);
        } else {
          _p2.push(plugin);
        }
        return this;
      },
      _p: _p2,
      _a: null,
      _e: scope,
      _s: /* @__PURE__ */ new Map(),
      state
    });
    return pinia;
  }
  const noop = () => {
  };
  function addSubscription(subscriptions, callback, detached, onCleanup = noop) {
    subscriptions.push(callback);
    const removeSubscription = () => {
      const idx = subscriptions.indexOf(callback);
      if (idx > -1) {
        subscriptions.splice(idx, 1);
        onCleanup();
      }
    };
    if (!detached && getCurrentInstance()) {
      onUnmounted(removeSubscription);
    }
    return removeSubscription;
  }
  function triggerSubscriptions(subscriptions, ...args) {
    subscriptions.slice().forEach((callback) => {
      callback(...args);
    });
  }
  function mergeReactiveObjects(target, patchToApply) {
    if (target instanceof Map && patchToApply instanceof Map) {
      patchToApply.forEach((value, key) => target.set(key, value));
    }
    if (target instanceof Set && patchToApply instanceof Set) {
      patchToApply.forEach(target.add, target);
    }
    for (const key in patchToApply) {
      if (!patchToApply.hasOwnProperty(key))
        continue;
      const subPatch = patchToApply[key];
      const targetValue = target[key];
      if (isPlainObject(targetValue) && isPlainObject(subPatch) && target.hasOwnProperty(key) && !isRef(subPatch) && !isReactive(subPatch)) {
        target[key] = mergeReactiveObjects(targetValue, subPatch);
      } else {
        target[key] = subPatch;
      }
    }
    return target;
  }
  const skipHydrateSymbol = Symbol();
  function shouldHydrate(obj) {
    return !isPlainObject(obj) || !obj.hasOwnProperty(skipHydrateSymbol);
  }
  const { assign } = Object;
  function isComputed(o) {
    return !!(isRef(o) && o.effect);
  }
  function createOptionsStore(id, options, pinia, hot) {
    const { state, actions, getters } = options;
    const initialState = pinia.state.value[id];
    let store;
    function setup() {
      if (!initialState && (!("production" !== "production") )) {
        {
          pinia.state.value[id] = state ? state() : {};
        }
      }
      const localState = toRefs(pinia.state.value[id]);
      return assign(localState, actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
        computedGetters[name] = markRaw(computed(() => {
          setActivePinia(pinia);
          const store2 = pinia._s.get(id);
          return getters[name].call(store2, store2);
        }));
        return computedGetters;
      }, {}));
    }
    store = createSetupStore(id, setup, options, pinia, hot, true);
    store.$reset = function $reset() {
      const newState = state ? state() : {};
      this.$patch(($state) => {
        assign($state, newState);
      });
    };
    return store;
  }
  function createSetupStore($id, setup, options = {}, pinia, hot, isOptionsStore) {
    let scope;
    const optionsForPlugin = assign({
      actions: {}
    }, options);
    const $subscribeOptions = {
      deep: true
    };
    let isListening;
    let isSyncListening;
    let subscriptions = markRaw([]);
    let actionSubscriptions = markRaw([]);
    let debuggerEvents;
    const initialState = pinia.state.value[$id];
    if (!isOptionsStore && !initialState && (!("production" !== "production") )) {
      {
        pinia.state.value[$id] = {};
      }
    }
    const hotState = ref({});
    let activeListener;
    function $patch(partialStateOrMutator) {
      let subscriptionMutation;
      isListening = isSyncListening = false;
      if (typeof partialStateOrMutator === "function") {
        partialStateOrMutator(pinia.state.value[$id]);
        subscriptionMutation = {
          type: MutationType.patchFunction,
          storeId: $id,
          events: debuggerEvents
        };
      } else {
        mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
        subscriptionMutation = {
          type: MutationType.patchObject,
          payload: partialStateOrMutator,
          storeId: $id,
          events: debuggerEvents
        };
      }
      const myListenerId = activeListener = Symbol();
      nextTick().then(() => {
        if (activeListener === myListenerId) {
          isListening = true;
        }
      });
      isSyncListening = true;
      triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
    }
    const $reset = noop;
    function $dispose() {
      scope.stop();
      subscriptions = [];
      actionSubscriptions = [];
      pinia._s.delete($id);
    }
    function wrapAction(name, action) {
      return function() {
        setActivePinia(pinia);
        const args = Array.from(arguments);
        const afterCallbackList = [];
        const onErrorCallbackList = [];
        function after(callback) {
          afterCallbackList.push(callback);
        }
        function onError(callback) {
          onErrorCallbackList.push(callback);
        }
        triggerSubscriptions(actionSubscriptions, {
          args,
          name,
          store,
          after,
          onError
        });
        let ret;
        try {
          ret = action.apply(this && this.$id === $id ? this : store, args);
        } catch (error) {
          triggerSubscriptions(onErrorCallbackList, error);
          throw error;
        }
        if (ret instanceof Promise) {
          return ret.then((value) => {
            triggerSubscriptions(afterCallbackList, value);
            return value;
          }).catch((error) => {
            triggerSubscriptions(onErrorCallbackList, error);
            return Promise.reject(error);
          });
        }
        triggerSubscriptions(afterCallbackList, ret);
        return ret;
      };
    }
    markRaw({
      actions: {},
      getters: {},
      state: [],
      hotState
    });
    const partialStore = {
      _p: pinia,
      $id,
      $onAction: addSubscription.bind(null, actionSubscriptions),
      $patch,
      $reset,
      $subscribe(callback, options2 = {}) {
        const removeSubscription = addSubscription(subscriptions, callback, options2.detached, () => stopWatcher());
        const stopWatcher = scope.run(() => watch(() => pinia.state.value[$id], (state) => {
          if (options2.flush === "sync" ? isSyncListening : isListening) {
            callback({
              storeId: $id,
              type: MutationType.direct,
              events: debuggerEvents
            }, state);
          }
        }, assign({}, $subscribeOptions, options2)));
        return removeSubscription;
      },
      $dispose
    };
    const store = reactive(assign({}, partialStore));
    pinia._s.set($id, store);
    const setupStore = pinia._e.run(() => {
      scope = effectScope();
      return scope.run(() => setup());
    });
    for (const key in setupStore) {
      const prop = setupStore[key];
      if (isRef(prop) && !isComputed(prop) || isReactive(prop)) {
        if (!isOptionsStore) {
          if (initialState && shouldHydrate(prop)) {
            if (isRef(prop)) {
              prop.value = initialState[key];
            } else {
              mergeReactiveObjects(prop, initialState[key]);
            }
          }
          {
            pinia.state.value[$id][key] = prop;
          }
        }
      } else if (typeof prop === "function") {
        const actionValue = wrapAction(key, prop);
        {
          setupStore[key] = actionValue;
        }
        optionsForPlugin.actions[key] = prop;
      } else ;
    }
    {
      assign(store, setupStore);
      assign(toRaw(store), setupStore);
    }
    Object.defineProperty(store, "$state", {
      get: () => pinia.state.value[$id],
      set: (state) => {
        $patch(($state) => {
          assign($state, state);
        });
      }
    });
    pinia._p.forEach((extender) => {
      {
        assign(store, scope.run(() => extender({
          store,
          app: pinia._a,
          pinia,
          options: optionsForPlugin
        })));
      }
    });
    if (initialState && isOptionsStore && options.hydrate) {
      options.hydrate(store.$state, initialState);
    }
    isListening = true;
    isSyncListening = true;
    return store;
  }
  defineStore = function defineStore2(idOrOptions, setup, setupOptions) {
    let id;
    let options;
    const isSetupStore = typeof setup === "function";
    if (typeof idOrOptions === "string") {
      id = idOrOptions;
      options = isSetupStore ? setupOptions : setup;
    } else {
      options = idOrOptions;
      id = idOrOptions.id;
    }
    function useStore(pinia, hot) {
      const currentInstance = getCurrentInstance();
      pinia = (pinia) || currentInstance && inject(piniaSymbol);
      if (pinia)
        setActivePinia(pinia);
      pinia = activePinia;
      if (!pinia._s.has(id)) {
        if (isSetupStore) {
          createSetupStore(id, setup, options, pinia);
        } else {
          createOptionsStore(id, options, pinia);
        }
      }
      const store = pinia._s.get(id);
      return store;
    }
    useStore.$id = id;
    return useStore;
  };
  const node_modules__64pinia_nuxt_dist_runtime_plugin_vue3_mjs_A0OWXRrUgq = defineNuxtPlugin((nuxtApp) => {
    const pinia = createPinia();
    nuxtApp.vueApp.use(pinia);
    setActivePinia(pinia);
    {
      nuxtApp.payload.pinia = pinia.state.value;
    }
    return {
      provide: {
        pinia
      }
    };
  });
  const plugins_router_ts_WMnTGednOQ = defineNuxtPlugin((nuxtApp) => {
    nuxtApp.$router.options.scrollBehavior = () => {
      return {
        left: 0,
        top: 0
      };
    };
  });
  const _plugins = [
    _nuxt_components_plugin_mjs_KR1HBZs4kY,
    node_modules_nuxt_dist_head_runtime_lib_vueuse_head_plugin_mjs_D7WGfuP1A0,
    node_modules_nuxt_dist_pages_runtime_router_mjs_qNv5Ky2ZmB,
    node_modules__64pinia_nuxt_dist_runtime_plugin_vue3_mjs_A0OWXRrUgq,
    plugins_router_ts_WMnTGednOQ
  ];
  const Fragment = defineComponent({
    setup(_props, { slots }) {
      return () => {
        var _a2;
        return (_a2 = slots.default) == null ? void 0 : _a2.call(slots);
      };
    }
  });
  _wrapIf = (component, props, slots) => {
    return {
      default: () => props ? h(component, props === true ? {} : props, slots) : h(Fragment, {}, slots)
    };
  };
  const layouts = {
    default: () => import('./default.a6c690f6.mjs').then(async (m) => {
      await m.__tla;
      return m;
    }).then((m) => m.default || m),
    empty: () => import('./empty.678b21f4.mjs').then(async (m) => {
      await m.__tla;
      return m;
    }).then((m) => m.default || m)
  };
  const LayoutLoader = defineComponent({
    props: {
      name: String,
      ...{}
    },
    async setup(props, context) {
      const LayoutComponent = await layouts[props.name]().then((r) => r.default || r);
      return () => {
        return h(LayoutComponent, {}, context.slots);
      };
    }
  });
  const __nuxt_component_0 = defineComponent({
    props: {
      name: {
        type: [
          String,
          Boolean,
          Object
        ],
        default: null
      }
    },
    setup(props, context) {
      const injectedRoute = inject("_route");
      const route = injectedRoute === useRoute() ? useRoute$1() : injectedRoute;
      const layout = computed(() => {
        var _a2, _b2;
        return (_b2 = (_a2 = unref(props.name)) != null ? _a2 : route.meta.layout) != null ? _b2 : "default";
      });
      return () => {
        var _a2;
        const hasLayout = layout.value && layout.value in layouts;
        const transitionProps = (_a2 = route.meta.layoutTransition) != null ? _a2 : appLayoutTransition;
        return _wrapIf(Transition, hasLayout && transitionProps, {
          default: () => _wrapIf(LayoutLoader, hasLayout && {
            key: layout.value,
            name: layout.value,
            hasTransition: void 0
          }, context.slots).default()
        }).default();
      };
    }
  });
  const _sfc_main$1 = defineComponent({
    __name: "app",
    __ssrInlineRender: true,
    setup(__props) {
      useHead({});
      return (_ctx, _push, _parent, _attrs) => {
        const _component_NuxtLayout = __nuxt_component_0;
        _push(ssrRenderComponent(_component_NuxtLayout, _attrs, null, _parent));
      };
    }
  });
  const _sfc_setup$1 = _sfc_main$1.setup;
  _sfc_main$1.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
    return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
  };
  const _sfc_main = {
    __name: "nuxt-root",
    __ssrInlineRender: true,
    setup(__props) {
      const ErrorComponent = defineAsyncComponent(() => import('./error-component.8322468a.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((r) => r.default || r));
      const nuxtApp = useNuxtApp();
      nuxtApp.deferHydration();
      provide("_route", useRoute());
      nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
      const error = useError();
      onErrorCaptured((err, target, info) => {
        nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
        {
          callWithNuxt(nuxtApp, showError, [
            err
          ]);
        }
      });
      return (_ctx, _push, _parent, _attrs) => {
        ssrRenderSuspense(_push, {
          default: () => {
            if (unref(error)) {
              _push(ssrRenderComponent(unref(ErrorComponent), {
                error: unref(error)
              }, null, _parent));
            } else {
              _push(ssrRenderComponent(unref(_sfc_main$1), null, null, _parent));
            }
          },
          _: 1
        });
      };
    }
  };
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-root.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  if (!globalThis.$fetch) {
    globalThis.$fetch = $fetch.create({
      baseURL: baseURL()
    });
  }
  let entry;
  const plugins = normalizePlugins(_plugins);
  {
    entry = async function createNuxtAppServer(ssrContext) {
      const vueApp = createApp(_sfc_main);
      const nuxt = createNuxtApp({
        vueApp,
        ssrContext
      });
      try {
        await applyPlugins(nuxt, plugins);
        await nuxt.hooks.callHook("app:created", vueApp);
      } catch (err) {
        await nuxt.callHook("app:error", err);
        nuxt.payload.error = nuxt.payload.error || err;
      }
      return vueApp;
    };
  }
  entry$1 = (ctx) => entry(ctx);
})();

export { __nuxt_component_0$1 as _, __tla, useNuxtApp as a, appPageTransition as b, createError as c, _wrapIf as d, entry$1 as default, appKeepalive as e, useRoute as f, defineStore as g, defineNuxtRouteMiddleware as h, navigateTo as n, useHead as u };
//# sourceMappingURL=server.mjs.map
