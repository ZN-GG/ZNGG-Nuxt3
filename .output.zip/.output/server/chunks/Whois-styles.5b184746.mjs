const Whois_vue_vue_type_style_index_0_scoped_2293a361_lang = '.searchBtn[data-v-2293a361]:before{border:6px solid transparent;border-right-color:#000;content:"";position:absolute;right:100%;top:38%}';

const WhoisStyles_5b184746 = [Whois_vue_vue_type_style_index_0_scoped_2293a361_lang];

export { WhoisStyles_5b184746 as default };
//# sourceMappingURL=Whois-styles.5b184746.mjs.map
