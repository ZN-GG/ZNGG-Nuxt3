import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "UnicodeConvert",
    __ssrInlineRender: true,
    setup(__props) {
      const text = ref("");
      const result = ref("");
      const copyText = ref("\u4E00\u952E\u590D\u5236");
      useNuxtApp();
      useHead({
        title: "Unicode\u4E2D\u6587\u8F6C\u6362",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "Unicode\u8F6C\u4E2D\u6587,\u4E2D\u6587\u8F6CUnicode,Unicode\u4E0E\u4E2D\u6587\u4E92\u8F6C,\u5728\u7EBFUnicode\u8F6C\u6362\u5DE5\u5177"
          },
          {
            name: "description",
            content: "\u5728\u7EBF\u4E00\u952EUnicode\u8F6C\u4E2D\u6587\uFF0C\u4E00\u952E\u4E2D\u6587\u8F6CUnicode\uFF0C\u4E00\u952EUnicode\u4E0E\u4E2D\u6587\u4E92\u8F6C\uFF0C\u7A0B\u5E8F\u5458\u5FC5\u5907\u7684\u8F6C\u6362\u795E\u5668\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">Unicode\u4E2D\u6587\u8F6C\u6362</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12"><div class="w-full flex flex-wrap"><div class="relative w-full md:w-6/12 md:pr-2"><div class="relative"><textarea autofocus class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3" rows="8">${ssrInterpolate(unref(text))}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(unref(text).length)}</span></div></div><div class="relative w-full md:w-6/12 md:pl-2"><div class="relative"><textarea class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3" rows="8">${ssrInterpolate(unref(result))}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(unref(result).length)}</span></div></div></div><div class="flex flex-row flex-wrap"><button class="flex my-2 mr-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u8F6C\u4E2D\u6587 </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u8F6CUnicode </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none">${ssrInterpolate(unref(copyText))}</button><button class="flex md:m-2 my-2 py-2 px-4 font-medium tracking-widest text-white bg-red-800 shadow-lg focus:outline-none hover:bg-red-900 hover:shadow-none"> \u6E05\u7A7A </button></div></section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u5F00\u53D1\u8FC7\u7A0B\u4E2D\u6211\u4EEC\u96BE\u514D\u9047\u5230\u8F6C\u7801\u7684\u95EE\u9898\uFF0C\u6700\u4E3B\u8981\u7684\u5C31\u662F\u4E2D\u6587\u8FD9\u5757\uFF0C\u5F88\u591A\u7A0B\u5E8F\u5728\u7F16\u8BD1\u65F6\u4F1A\u628A\u4E2D\u6587\u8F6C\u6362\u6210Unicode\u7F16\u7801\uFF0C\u5176\u5178\u578B\u7279\u5F81\u5C31\u662F\u7F16\u7801\u5C31\u662F&quot;\\uxxxx&quot;,\u56E0\u6B64\u505A\u4E86\u8FD9\u4E2A\u5C0F\u5DE5\u5177\u3002</p></blockquote><ul><li>Unicode\u8F6C\u4E2D\u6587</li><li>\u4E2D\u6587\u8F6CUnicode\u3002</li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/UnicodeConvert.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=UnicodeConvert.bf7a3145.mjs.map
