import { defineComponent, h, Transition, Suspense, nextTick, computed, provide, reactive } from 'vue';
import { RouterView } from 'vue-router';
import { defu } from 'defu';
import { __tla as __tla$1, a as useNuxtApp, b as appPageTransition, d as _wrapIf, e as appKeepalive } from './server.mjs';

let __nuxt_component_0;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const interpolatePath = (route, match) => {
    return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
      var _a;
      return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
    });
  };
  const generateRouteKey = (override, routeProps) => {
    var _a;
    const matchedRoute = routeProps.route.matched.find((m) => {
      var _a2;
      return ((_a2 = m.components) == null ? void 0 : _a2.default) === routeProps.Component.type;
    });
    const source = (_a = override != null ? override : matchedRoute == null ? void 0 : matchedRoute.meta.key) != null ? _a : matchedRoute && interpolatePath(routeProps.route, matchedRoute);
    return typeof source === "function" ? source(routeProps.route) : source;
  };
  const wrapInKeepAlive = (props, children) => {
    return {
      default: () => children
    };
  };
  __nuxt_component_0 = defineComponent({
    name: "NuxtPage",
    inheritAttrs: false,
    props: {
      name: {
        type: String
      },
      transition: {
        type: [
          Boolean,
          Object
        ],
        default: void 0
      },
      keepalive: {
        type: [
          Boolean,
          Object
        ],
        default: void 0
      },
      route: {
        type: Object
      },
      pageKey: {
        type: [
          Function,
          String
        ],
        default: null
      }
    },
    setup(props, { attrs }) {
      const nuxtApp = useNuxtApp();
      return () => {
        return h(RouterView, {
          name: props.name,
          route: props.route,
          ...attrs
        }, {
          default: (routeProps) => {
            var _a, _b, _c, _d;
            if (!routeProps.Component) {
              return;
            }
            const key = generateRouteKey(props.pageKey, routeProps);
            const done = nuxtApp.deferHydration();
            const hasTransition = !!((_b = (_a = props.transition) != null ? _a : routeProps.route.meta.pageTransition) != null ? _b : appPageTransition);
            const transitionProps = hasTransition && _mergeTransitionProps([
              props.transition,
              routeProps.route.meta.pageTransition,
              appPageTransition,
              {
                onAfterLeave: () => {
                  nuxtApp.callHook("page:transition:finish", routeProps.Component);
                }
              }
            ].filter(Boolean));
            return _wrapIf(Transition, hasTransition && transitionProps, wrapInKeepAlive((_d = (_c = props.keepalive) != null ? _c : routeProps.route.meta.keepalive) != null ? _d : appKeepalive, h(Suspense, {
              onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
              onResolve: () => {
                nextTick(() => nuxtApp.callHook("page:finish", routeProps.Component).finally(done));
              }
            }, {
              default: () => h(Component, {
                key,
                routeProps,
                pageKey: key,
                hasTransition
              })
            }))).default();
          }
        });
      };
    }
  });
  function _toArray(val) {
    return Array.isArray(val) ? val : val ? [
      val
    ] : [];
  }
  function _mergeTransitionProps(routeProps) {
    const _props = routeProps.map((prop) => ({
      ...prop,
      onAfterLeave: _toArray(prop.onAfterLeave)
    }));
    return defu(..._props);
  }
  const Component = defineComponent({
    props: [
      "routeProps",
      "pageKey",
      "hasTransition"
    ],
    setup(props) {
      const previousKey = props.pageKey;
      const previousRoute = props.routeProps.route;
      const route = {};
      for (const key in props.routeProps.route) {
        route[key] = computed(() => previousKey === props.pageKey ? props.routeProps.route[key] : previousRoute[key]);
      }
      provide("_route", reactive(route));
      return () => {
        return h(props.routeProps.Component);
      };
    }
  });
});

export { __tla as _, __nuxt_component_0 as a };
//# sourceMappingURL=page.2cd64012.mjs.map
