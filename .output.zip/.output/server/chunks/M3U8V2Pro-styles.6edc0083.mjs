const M3U8V2Pro_vue_vue_type_style_index_0_scoped_ed6770f9_lang = ".item-box[data-v-ed6770f9]{max-height:24rem;min-height:8rem}.item-box[data-v-ed6770f9]::-webkit-scrollbar{height:10px;width:10px}.item-box[data-v-ed6770f9]::-webkit-scrollbar-thumb{background-color:#49b1f5;background-image:-webkit-linear-gradient(45deg,hsla(0,0%,100%,.4) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.4) 0,hsla(0,0%,100%,.4) 75%,transparent 0,transparent);border-radius:32px}.item-box[data-v-ed6770f9]::-webkit-scrollbar-track{background-color:#dbeffd;border-radius:32px}.btn-bg-save[data-v-ed6770f9]{background-color:#49b1f5;background-image:-webkit-linear-gradient(45deg,hsla(0,0%,100%,.4) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.4) 0,hsla(0,0%,100%,.4) 75%,transparent 0,transparent)}";

const M3U8V2ProStyles_6edc0083 = [M3U8V2Pro_vue_vue_type_style_index_0_scoped_ed6770f9_lang];

export { M3U8V2ProStyles_6edc0083 as default };
//# sourceMappingURL=M3U8V2Pro-styles.6edc0083.mjs.map
