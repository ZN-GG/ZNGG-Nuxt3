import { __tla as __tla$1, _ as __nuxt_component_0$1 } from './server.mjs';
import { useSSRContext, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let favorites;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main = {};
  function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
    const _component_NuxtLink = __nuxt_component_0$1;
    _push(`<div${ssrRenderAttrs(_attrs)}><div class="my-6 flex justify-between items-center"><p class="font-bold text-2xl">\u6211\u7684\u6536\u85CF</p>`);
    _push(ssrRenderComponent(_component_NuxtLink, {
      to: "/writer"
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`<button class="btn-normal"${_scopeId}>\u5199\u6587\u7AE0</button>`);
        } else {
          return [
            createVNode("button", {
              class: "btn-normal"
            }, "\u5199\u6587\u7AE0")
          ];
        }
      }),
      _: 1
    }, _parent));
    _push(`</div></div>`);
  }
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index/favorites.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  favorites = _export_sfc(_sfc_main, [
    [
      "ssrRender",
      _sfc_ssrRender
    ]
  ]);
});

export { __tla, favorites as default };
//# sourceMappingURL=favorites.b581f0a6.mjs.map
