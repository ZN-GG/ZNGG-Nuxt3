import { defineComponent, ref, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[type]",
  __ssrInlineRender: true,
  setup(__props) {
    let formatTable = {
      Text: [
        { name: "Hypertext Markup Language (html)", value: "html" },
        { name: "Extensible Hypertext Markup Language (xhtml)", value: "xhtml" },
        { name: "Portable Document Format (pdf)", value: "pdf" },
        { name: "OpenDocument Text (odt)", value: "odt" },
        { name: "OpenOffice.org 1.0 Text Document (sxw)", value: "sxw" },
        { name: "Microsoft Word 97-2003 (doc)", value: "doc" },
        { name: "Microsoft Word 2007-2013 (docx)", value: "docx" },
        { name: "Rich Text Format (rtf)", value: "rtf" },
        { name: "Plain Text (txt)", value: "txt" },
        { name: "Portable Network Graphics (png)", value: "png" }
      ],
      Spreadsheet: [
        { name: "Portable Document Format (pdf)", value: "pdf" },
        { name: "OpenDocument Spreadsheet (ods)", value: "ods" },
        { name: "OpenOffice.org 1.0 Spreadsheet (sxc)", value: "sxc" },
        { name: "Microsoft Excel 97-2003 (xls)", value: "xls" },
        { name: "Microsoft Excel 2007-2013 (xlsx)", value: "xlsx" },
        { name: "Comma-Separated Values (csv)", value: "csv" },
        { name: "Portable Network Graphics (png)", value: "png" }
      ],
      Presentation: [
        { name: "Portable Document Format (pdf)", value: "pdf" },
        { name: "Macromedia Flash (swf)", value: "swf" },
        { name: "OpenDocument Presentation (odp)", value: "odp" },
        { name: "OpenOffice.org 1.0 Presentation (sxi)", value: "sxi" },
        { name: "Microsoft PowerPoint 97-2003 (ppt)", value: "ppt" },
        { name: "Microsoft PowerPoint 2007-2013 (pptx)", value: "pptx" },
        { name: "Portable Network Graphics (png)", value: "png" }
      ],
      Drawing: [
        { name: "Portable Document Format (pdf)", value: "pdf" }
      ]
    };
    const fileName = ref("\u62D6\u62FD\u6587\u4EF6\u5230\u8FD9\u91CC\u6216\u8005\u70B9\u51FB\u9009\u62E9\u6587\u4EF6");
    ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><form class="overflow-hidden" action="" enctype="multipart/form-data" method="post"><div class="form-group"><div class="text-center relative py-12 mb-4 border-2 hover:bg-gray-100 custom-font-14 rounded" id="fileInput"><span>${ssrInterpolate(unref(fileName))}</span><input type="file" id="inputFile" name="inputFile" style="${ssrRenderStyle({ "opacity": "0", "position": "absolute", "cursor": "pointer", "width": "100%", "height": "100%", "left": "0", "top": "0" })}"></div></div><select id="outputFormat" name="outputFormat" required><!--[-->`);
      ssrRenderList(unref(formatTable).Text, (item, index) => {
        _push(`<option${ssrRenderAttr("value", item.value)}>${ssrInterpolate(item.name)}</option>`);
      });
      _push(`<!--]--></select></form></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/office/[type].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_type_.73feb55a.mjs.map
