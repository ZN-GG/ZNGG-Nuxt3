const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-06ac1f02.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-1318c9fe.mjs",
      "_dom-to-image-38bb6765.mjs",
      "_mpegts-ed5de2f4.mjs",
      "_pinyin-web-07a698a0.mjs",
      "_index.min-41c28b84.mjs",
      "_hls-c5686f37.mjs",
      "_RecordRTC-caa049a4.mjs",
      "_lodash-4f9bfa9d.mjs",
      "pages/index.vue",
      "pages/link/index.vue",
      "pages/link.vue",
      "pages/read/index.vue",
      "pages/read/post/[id].vue",
      "pages/read/post.vue",
      "pages/read.vue",
      "pages/tool/detail/CSSGradient.vue",
      "pages/tool/detail/EnglistConvert.vue",
      "pages/tool/detail/FancyBorderRadius.vue",
      "pages/tool/detail/FlvPlayer.vue",
      "pages/tool/detail/ImageToBase64.vue",
      "pages/tool/detail/MakePhrase.vue",
      "pages/tool/detail/NPlayer.vue",
      "pages/tool/detail/ScreenRec.vue",
      "pages/tool/detail/TextDistinct.vue",
      "pages/tool/detail/Timestamp.vue",
      "pages/tool/detail/WeiBoGenerates.vue",
      "pages/tool/detail.vue",
      "pages/tool/index.vue",
      "pages/tool.vue",
      "pages/user/index/create.vue",
      "pages/user/index/index.vue",
      "pages/user/index/order.vue",
      "pages/user/index.vue",
      "pages/writer.vue",
      "middleware/auth.ts",
      "layouts/default.vue",
      "layouts/empty.vue"
    ],
    "css": [
      "entry.ed582d36.css"
    ],
    "assets": [
      "iconfont.8c3eb7e7.woff2",
      "iconfont.c7a4bd31.woff",
      "iconfont.ec975a33.ttf"
    ]
  },
  "pages/index.vue": {
    "file": "index-32912fa0.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-679c4534.mjs",
      "_api-74dc2fca.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "_asyncData-679c4534.mjs": {
    "file": "asyncData-679c4534.mjs",
    "imports": [
      "_cookie-e4374aaa.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_api-74dc2fca.mjs": {
    "file": "api-74dc2fca.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "_cookie-e4374aaa.mjs": {
    "file": "cookie-e4374aaa.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link/index.vue": {
    "file": "index-93bba0cf.mjs",
    "src": "pages/link/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link.vue": {
    "file": "link-5b7f3be2.mjs",
    "src": "pages/link.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read/index.vue": {
    "file": "index-22b88ab2.mjs",
    "src": "pages/read/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-679c4534.mjs",
      "_api-74dc2fca.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "pages/read/post/[id].vue": {
    "file": "_id_-01345925.mjs",
    "src": "pages/read/post/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-679c4534.mjs",
      "_api-74dc2fca.mjs",
      "_theme-acdb2fb9.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "_theme-acdb2fb9.mjs": {
    "file": "theme-acdb2fb9.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js",
      "node_modules/medium-zoom/dist/medium-zoom.esm.js",
      "node_modules/mermaid/dist/mermaid.esm.min.mjs"
    ]
  },
  "pages/read/post.vue": {
    "file": "post-642a0f5a.mjs",
    "src": "pages/read/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read.vue": {
    "file": "read-a43ab711.mjs",
    "src": "pages/read.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/CSSGradient.vue": {
    "file": "CSSGradient-ca3a55fd.mjs",
    "src": "pages/tool/detail/CSSGradient.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-1318c9fe.mjs",
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail/EnglistConvert.vue": {
    "file": "EnglistConvert-a2cd9e3f.mjs",
    "src": "pages/tool/detail/EnglistConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FancyBorderRadius.vue": {
    "file": "FancyBorderRadius-077ece00.mjs",
    "src": "pages/tool/detail/FancyBorderRadius.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FlvPlayer.vue": {
    "file": "FlvPlayer-fcb8ed4c.mjs",
    "src": "pages/tool/detail/FlvPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_mpegts-ed5de2f4.mjs"
    ]
  },
  "pages/tool/detail/ImageToBase64.vue": {
    "file": "ImageToBase64-a3ad9003.mjs",
    "src": "pages/tool/detail/ImageToBase64.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/MakePhrase.vue": {
    "file": "MakePhrase-c3fb8ce4.mjs",
    "src": "pages/tool/detail/MakePhrase.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs",
      "_pinyin-web-07a698a0.mjs"
    ]
  },
  "pages/tool/detail/NPlayer.vue": {
    "file": "NPlayer-ecff4652.mjs",
    "src": "pages/tool/detail/NPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.min-41c28b84.mjs",
      "_hls-c5686f37.mjs"
    ]
  },
  "pages/tool/detail/ScreenRec.vue": {
    "file": "ScreenRec-598ca254.mjs",
    "src": "pages/tool/detail/ScreenRec.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_RecordRTC-caa049a4.mjs"
    ]
  },
  "pages/tool/detail/TextDistinct.vue": {
    "file": "TextDistinct-63643e95.mjs",
    "src": "pages/tool/detail/TextDistinct.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_lodash-4f9bfa9d.mjs"
    ]
  },
  "pages/tool/detail/Timestamp.vue": {
    "file": "Timestamp-40958714.mjs",
    "src": "pages/tool/detail/Timestamp.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api-74dc2fca.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "pages/tool/detail/WeiBoGenerates.vue": {
    "file": "WeiBoGenerates-c8ea030b.mjs",
    "src": "pages/tool/detail/WeiBoGenerates.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail.vue": {
    "file": "detail-fcb028f7.mjs",
    "src": "pages/tool/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/index.vue": {
    "file": "index-7991ec17.mjs",
    "src": "pages/tool/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-679c4534.mjs",
      "_api-74dc2fca.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "pages/tool.vue": {
    "file": "tool-9ccb1283.mjs",
    "src": "pages/tool.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/create.vue": {
    "file": "create-e141c244.mjs",
    "src": "pages/user/index/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/index.vue": {
    "file": "index-49b83a51.mjs",
    "src": "pages/user/index/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/order.vue": {
    "file": "order-46509acd.mjs",
    "src": "pages/user/index/order.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index.vue": {
    "file": "index-7ddf6345.mjs",
    "src": "pages/user/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "pages/writer.vue": {
    "file": "writer-80b18bf3.mjs",
    "src": "pages/writer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_theme-acdb2fb9.mjs",
      "_api-74dc2fca.mjs",
      "_cookie-e4374aaa.mjs"
    ]
  },
  "middleware/auth.ts": {
    "file": "auth-77f21f48.mjs",
    "src": "middleware/auth.ts",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-e4374aaa.mjs",
      "_api-74dc2fca.mjs"
    ]
  },
  "layouts/default.vue": {
    "file": "default-f8dc1038.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-e4374aaa.mjs",
      "_api-74dc2fca.mjs"
    ],
    "css": [
      "default.e0ef37d6.css"
    ]
  },
  "layouts/empty.vue": {
    "file": "empty-5e349cb8.mjs",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "utils/Drag.ts": {
    "file": "Drag-cac46c1e.mjs",
    "src": "utils/Drag.ts",
    "isDynamicEntry": true
  },
  "utils/color.ts": {
    "file": "color-c1be6728.mjs",
    "src": "utils/color.ts",
    "isDynamicEntry": true
  },
  "_interact.min-1318c9fe.mjs": {
    "file": "interact.min-1318c9fe.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_dom-to-image-38bb6765.mjs": {
    "file": "dom-to-image-38bb6765.mjs",
    "isDynamicEntry": true
  },
  "_mpegts-ed5de2f4.mjs": {
    "file": "mpegts-ed5de2f4.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_pinyin-web-07a698a0.mjs": {
    "file": "pinyin-web-07a698a0.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_index.min-41c28b84.mjs": {
    "file": "index.min-41c28b84.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_hls-c5686f37.mjs": {
    "file": "hls-c5686f37.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_RecordRTC-caa049a4.mjs": {
    "file": "RecordRTC-caa049a4.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_lodash-4f9bfa9d.mjs": {
    "file": "lodash-4f9bfa9d.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/highlight.js/es/index.js": {
    "file": "index-5d39d920.mjs",
    "src": "node_modules/highlight.js/es/index.js",
    "isDynamicEntry": true
  },
  "node_modules/medium-zoom/dist/medium-zoom.esm.js": {
    "file": "medium-zoom.esm-76784ffc.mjs",
    "src": "node_modules/medium-zoom/dist/medium-zoom.esm.js",
    "isDynamicEntry": true
  },
  "node_modules/mermaid/dist/mermaid.esm.min.mjs": {
    "file": "mermaid.esm.min-69e0ceb1.mjs",
    "src": "node_modules/mermaid/dist/mermaid.esm.min.mjs",
    "isDynamicEntry": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
