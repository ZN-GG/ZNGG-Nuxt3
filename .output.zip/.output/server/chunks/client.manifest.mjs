const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-d3288a86.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "_index-d96b7687.mjs",
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-806f62b3.mjs",
      "_dom-to-image-38bb6765.mjs",
      "_mpegts-335ba825.mjs",
      "_pinyin-web-6ec2b3c1.mjs",
      "_index.min-0fa75149.mjs",
      "_hls-58934b30.mjs",
      "_fabric-c1c35949.mjs",
      "_RecordRTC-3fcc8c3c.mjs",
      "_lodash-a041f857.mjs",
      "_index-ebba77f0.mjs",
      "pages/index.vue",
      "pages/link/index.vue",
      "pages/link.vue",
      "pages/read/index.vue",
      "pages/read/post/[id].vue",
      "pages/read/post.vue",
      "pages/read.vue",
      "pages/tool/detail/Base64Convert.vue",
      "pages/tool/detail/CSSGradient.vue",
      "pages/tool/detail/EnglistConvert.vue",
      "pages/tool/detail/FancyBorderRadius.vue",
      "pages/tool/detail/FlvPlayer.vue",
      "pages/tool/detail/ImageToBase64.vue",
      "pages/tool/detail/MakePhrase.vue",
      "pages/tool/detail/NPlayer.vue",
      "pages/tool/detail/NationalDayAvatar.vue",
      "pages/tool/detail/ScreenRec.vue",
      "pages/tool/detail/TextDistinct.vue",
      "pages/tool/detail/Timestamp.vue",
      "pages/tool/detail/TraceReplay.vue",
      "pages/tool/detail/UnicodeConvert.vue",
      "pages/tool/detail/WeiBoGenerates.vue",
      "pages/tool/detail.vue",
      "pages/tool/index.vue",
      "pages/tool.vue",
      "pages/user/index/create.vue",
      "pages/user/index/index.vue",
      "pages/user/index/order.vue",
      "pages/user/index.vue",
      "pages/writer.vue",
      "middleware/auth.ts",
      "layouts/default.vue",
      "layouts/empty.vue"
    ],
    "css": [
      "entry.978f841e.css"
    ],
    "assets": [
      "iconfont.8c3eb7e7.woff2",
      "iconfont.c7a4bd31.woff",
      "iconfont.ec975a33.ttf"
    ]
  },
  "pages/index.vue": {
    "file": "index-655121a4.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-b92a2a4b.mjs",
      "_api-a1090e24.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "_asyncData-b92a2a4b.mjs": {
    "file": "asyncData-b92a2a4b.mjs",
    "imports": [
      "_cookie-208964a7.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_api-a1090e24.mjs": {
    "file": "api-a1090e24.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "_cookie-208964a7.mjs": {
    "file": "cookie-208964a7.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link/index.vue": {
    "file": "index-b3781032.mjs",
    "src": "pages/link/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link.vue": {
    "file": "link-3ab123d8.mjs",
    "src": "pages/link.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read/index.vue": {
    "file": "index-b25ba1ae.mjs",
    "src": "pages/read/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-b92a2a4b.mjs",
      "_api-a1090e24.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "pages/read/post/[id].vue": {
    "file": "_id_-73d8856a.mjs",
    "src": "pages/read/post/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-b92a2a4b.mjs",
      "_api-a1090e24.mjs",
      "_theme-f9fd26f3.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "_theme-f9fd26f3.mjs": {
    "file": "theme-f9fd26f3.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js",
      "node_modules/medium-zoom/dist/medium-zoom.esm.js",
      "node_modules/mermaid/dist/mermaid.esm.min.mjs"
    ]
  },
  "pages/read/post.vue": {
    "file": "post-206c3883.mjs",
    "src": "pages/read/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read.vue": {
    "file": "read-2f4997f0.mjs",
    "src": "pages/read.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/Base64Convert.vue": {
    "file": "Base64Convert-4852ddf2.mjs",
    "src": "pages/tool/detail/Base64Convert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index-d96b7687.mjs"
    ]
  },
  "pages/tool/detail/CSSGradient.vue": {
    "file": "CSSGradient-48ee7ba4.mjs",
    "src": "pages/tool/detail/CSSGradient.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-806f62b3.mjs",
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail/EnglistConvert.vue": {
    "file": "EnglistConvert-e535e724.mjs",
    "src": "pages/tool/detail/EnglistConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FancyBorderRadius.vue": {
    "file": "FancyBorderRadius-67728380.mjs",
    "src": "pages/tool/detail/FancyBorderRadius.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FlvPlayer.vue": {
    "file": "FlvPlayer-30ec095b.mjs",
    "src": "pages/tool/detail/FlvPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_mpegts-335ba825.mjs"
    ]
  },
  "pages/tool/detail/ImageToBase64.vue": {
    "file": "ImageToBase64-d9d553af.mjs",
    "src": "pages/tool/detail/ImageToBase64.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index-d96b7687.mjs"
    ]
  },
  "pages/tool/detail/MakePhrase.vue": {
    "file": "MakePhrase-4c63b714.mjs",
    "src": "pages/tool/detail/MakePhrase.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs",
      "_pinyin-web-6ec2b3c1.mjs"
    ]
  },
  "pages/tool/detail/NPlayer.vue": {
    "file": "NPlayer-dd32a908.mjs",
    "src": "pages/tool/detail/NPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.min-0fa75149.mjs",
      "_hls-58934b30.mjs"
    ]
  },
  "pages/tool/detail/NationalDayAvatar.vue": {
    "file": "NationalDayAvatar-4ffd5785.mjs",
    "src": "pages/tool/detail/NationalDayAvatar.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_fabric-c1c35949.mjs"
    ]
  },
  "pages/tool/detail/ScreenRec.vue": {
    "file": "ScreenRec-e80917cb.mjs",
    "src": "pages/tool/detail/ScreenRec.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_RecordRTC-3fcc8c3c.mjs"
    ]
  },
  "pages/tool/detail/TextDistinct.vue": {
    "file": "TextDistinct-47a60e7c.mjs",
    "src": "pages/tool/detail/TextDistinct.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_lodash-a041f857.mjs"
    ]
  },
  "pages/tool/detail/Timestamp.vue": {
    "file": "Timestamp-a3de707e.mjs",
    "src": "pages/tool/detail/Timestamp.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api-a1090e24.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "pages/tool/detail/TraceReplay.vue": {
    "file": "TraceReplay-0b3876ed.mjs",
    "src": "pages/tool/detail/TraceReplay.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index-ebba77f0.mjs"
    ]
  },
  "pages/tool/detail/UnicodeConvert.vue": {
    "file": "UnicodeConvert-08c73f0e.mjs",
    "src": "pages/tool/detail/UnicodeConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/WeiBoGenerates.vue": {
    "file": "WeiBoGenerates-4b5e0cfd.mjs",
    "src": "pages/tool/detail/WeiBoGenerates.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail.vue": {
    "file": "detail-f9143f2b.mjs",
    "src": "pages/tool/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/index.vue": {
    "file": "index-b5afad9a.mjs",
    "src": "pages/tool/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-b92a2a4b.mjs",
      "_api-a1090e24.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "pages/tool.vue": {
    "file": "tool-c0686b05.mjs",
    "src": "pages/tool.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/create.vue": {
    "file": "create-1975a10d.mjs",
    "src": "pages/user/index/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/index.vue": {
    "file": "index-355e9fef.mjs",
    "src": "pages/user/index/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/order.vue": {
    "file": "order-2bfcc75a.mjs",
    "src": "pages/user/index/order.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index.vue": {
    "file": "index-7d7a27b5.mjs",
    "src": "pages/user/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "pages/writer.vue": {
    "file": "writer-98535fa3.mjs",
    "src": "pages/writer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_theme-f9fd26f3.mjs",
      "_api-a1090e24.mjs",
      "_cookie-208964a7.mjs"
    ]
  },
  "middleware/auth.ts": {
    "file": "auth-ac19af5b.mjs",
    "src": "middleware/auth.ts",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-208964a7.mjs",
      "_api-a1090e24.mjs"
    ]
  },
  "layouts/default.vue": {
    "file": "default-ecf82031.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-208964a7.mjs",
      "_api-a1090e24.mjs"
    ],
    "css": [
      "default.e0ef37d6.css"
    ]
  },
  "layouts/empty.vue": {
    "file": "empty-68596753.mjs",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_index-d96b7687.mjs": {
    "file": "index-d96b7687.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "__commonjsHelpers-f27416a5.mjs": {
    "file": "_commonjsHelpers-f27416a5.mjs"
  },
  "utils/Drag.ts": {
    "file": "Drag-cac46c1e.mjs",
    "src": "utils/Drag.ts",
    "isDynamicEntry": true
  },
  "utils/color.ts": {
    "file": "color-c1be6728.mjs",
    "src": "utils/color.ts",
    "isDynamicEntry": true
  },
  "_interact.min-806f62b3.mjs": {
    "file": "interact.min-806f62b3.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_dom-to-image-38bb6765.mjs": {
    "file": "dom-to-image-38bb6765.mjs",
    "isDynamicEntry": true
  },
  "_mpegts-335ba825.mjs": {
    "file": "mpegts-335ba825.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_pinyin-web-6ec2b3c1.mjs": {
    "file": "pinyin-web-6ec2b3c1.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_index.min-0fa75149.mjs": {
    "file": "index.min-0fa75149.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_hls-58934b30.mjs": {
    "file": "hls-58934b30.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_fabric-c1c35949.mjs": {
    "file": "fabric-c1c35949.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_RecordRTC-3fcc8c3c.mjs": {
    "file": "RecordRTC-3fcc8c3c.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_lodash-a041f857.mjs": {
    "file": "lodash-a041f857.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_index-ebba77f0.mjs": {
    "file": "index-ebba77f0.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "node_modules/highlight.js/es/index.js": {
    "file": "index-5d39d920.mjs",
    "src": "node_modules/highlight.js/es/index.js",
    "isDynamicEntry": true
  },
  "node_modules/medium-zoom/dist/medium-zoom.esm.js": {
    "file": "medium-zoom.esm-76784ffc.mjs",
    "src": "node_modules/medium-zoom/dist/medium-zoom.esm.js",
    "isDynamicEntry": true
  },
  "node_modules/mermaid/dist/mermaid.esm.min.mjs": {
    "file": "mermaid.esm.min-69e0ceb1.mjs",
    "src": "node_modules/mermaid/dist/mermaid.esm.min.mjs",
    "isDynamicEntry": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
