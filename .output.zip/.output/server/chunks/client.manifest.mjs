const client_manifest = {
  "assets/fonts/iconfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "iconfont.8c3eb7e7.woff2",
    "src": "assets/fonts/iconfont.woff2"
  },
  "utils/wasm/png-to-svg-wasm/png_to_svg_wasm_bg.wasm": {
    "file": "png_to_svg_wasm_bg.b6516f44.wasm",
    "src": "utils/wasm/png-to-svg-wasm/png_to_svg_wasm_bg.wasm"
  },
  "assets/fonts/iconfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "iconfont.c7a4bd31.woff",
    "src": "assets/fonts/iconfont.woff"
  },
  "assets/fonts/iconfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "iconfont.ec975a33.ttf",
    "src": "assets/fonts/iconfont.ttf"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.0e8b75ad.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "node_modules/@bytemd/vue-next/dist/index.mjs",
      "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
      "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
      "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
      "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
      "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
      "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
      "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
      "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
      "node_modules/marked/lib/marked.esm.js",
      "assets/theme.ts",
      "_index.1df7656a.js",
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min.3ac48332.js",
      "_dom-to-image.5044287b.js",
      "node_modules/@zackdk/m3u8tomp4/src/index.js",
      "_mpegts.e75d6339.js",
      "node_modules/pinyin-pro/lib/pinyin.ts",
      "_index.min.10aaf9f8.js",
      "_hls.2a7af7df.js",
      "_fabric.2646cadb.js",
      "utils/svgo.browser.mjs",
      "_index.efea0cb8.js",
      "_RecordRTC.d7a40e53.js",
      "_uniq.5ad30764.js",
      "_join.5e100562.js",
      "utils/ZWSP.ts",
      "_index.92c964f7.js",
      "middleware/auth.ts",
      "middleware/setSameOriginHeader.ts",
      "virtual:nuxt:F:/IdeaProject/ZNGG-Nuxt3/.nuxt/error-component.mjs",
      "layouts/default.vue",
      "layouts/empty.vue",
      "node_modules/nuxt/dist/app/entry.mjs-css"
    ],
    "css": [],
    "assets": [
      "png_to_svg_wasm_bg.b6516f44.wasm",
      "iconfont.8c3eb7e7.woff2",
      "iconfont.c7a4bd31.woff",
      "iconfont.ec975a33.ttf"
    ]
  },
  "entry.c86584e4.css": {
    "file": "entry.c86584e4.css",
    "resourceType": "style"
  },
  "png_to_svg_wasm_bg.b6516f44.wasm": {
    "file": "png_to_svg_wasm_bg.b6516f44.wasm"
  },
  "iconfont.8c3eb7e7.woff2": {
    "file": "iconfont.8c3eb7e7.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "iconfont.c7a4bd31.woff": {
    "file": "iconfont.c7a4bd31.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "iconfont.ec975a33.ttf": {
    "file": "iconfont.ec975a33.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "virtual:nuxt:F:/IdeaProject/ZNGG-Nuxt3/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.d1720a4b.js",
    "src": "virtual:nuxt:F:/IdeaProject/ZNGG-Nuxt3/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.3b6076df.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.e267810c.js",
      "_ScreenRecAD.16518c41.js",
      "_NplayerAD.f0b8259d.js",
      "_api.735b0804.js",
      "_cookie.91ef53df.js"
    ],
    "css": []
  },
  "index.06cc0c9c.css": {
    "file": "index.06cc0c9c.css",
    "resourceType": "style"
  },
  "_asyncData.e267810c.js": {
    "resourceType": "script",
    "module": true,
    "file": "asyncData.e267810c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_ScreenRecAD.16518c41.js": {
    "resourceType": "script",
    "module": true,
    "file": "ScreenRecAD.16518c41.js"
  },
  "_NplayerAD.f0b8259d.js": {
    "resourceType": "script",
    "module": true,
    "file": "NplayerAD.f0b8259d.js"
  },
  "_api.735b0804.js": {
    "resourceType": "script",
    "module": true,
    "file": "api.735b0804.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.91ef53df.js"
    ]
  },
  "_cookie.91ef53df.js": {
    "resourceType": "script",
    "module": true,
    "file": "cookie.91ef53df.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.56d7dcb3.js",
    "src": "pages/link/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link.vue": {
    "resourceType": "script",
    "module": true,
    "file": "link.2c7d1ed4.js",
    "src": "pages/link.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.4fbfa96e.js",
    "src": "pages/read/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.e267810c.js",
      "_ScreenRecAD.16518c41.js",
      "_NplayerAD.f0b8259d.js",
      "_api.735b0804.js",
      "_cookie.91ef53df.js"
    ],
    "css": []
  },
  "index.412ca2a9.css": {
    "file": "index.412ca2a9.css",
    "resourceType": "style"
  },
  "pages/read/post/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.8405b2f7.js",
    "src": "pages/read/post/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.e267810c.js",
      "_ScreenRecAD.16518c41.js",
      "_api.735b0804.js",
      "_cookie.91ef53df.js"
    ],
    "dynamicImports": [
      "node_modules/@bytemd/vue-next/dist/index.mjs",
      "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
      "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
      "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
      "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
      "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
      "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
      "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
      "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
      "node_modules/marked/lib/marked.esm.js",
      "assets/theme.ts"
    ],
    "css": []
  },
  "_id_.8465ac68.css": {
    "file": "_id_.8465ac68.css",
    "resourceType": "style"
  },
  "atom-one-dark.a80f81b9.css": {
    "file": "atom-one-dark.a80f81b9.css",
    "resourceType": "style"
  },
  "pages/read/post.vue": {
    "resourceType": "script",
    "module": true,
    "file": "post.55a1382f.js",
    "src": "pages/read/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read.vue": {
    "resourceType": "script",
    "module": true,
    "file": "read.1d155385.js",
    "src": "pages/read.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/Base64Convert.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Base64Convert.2376b413.js",
    "src": "pages/tool/detail/Base64Convert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.1df7656a.js"
    ]
  },
  "pages/tool/detail/CSSGradient.vue": {
    "resourceType": "script",
    "module": true,
    "file": "CSSGradient.f8143dab.js",
    "src": "pages/tool/detail/CSSGradient.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min.3ac48332.js",
      "_dom-to-image.5044287b.js"
    ]
  },
  "pages/tool/detail/DownloadM3U8.vue": {
    "resourceType": "script",
    "module": true,
    "file": "DownloadM3U8.82c836c5.js",
    "src": "pages/tool/detail/DownloadM3U8.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@zackdk/m3u8tomp4/src/index.js"
    ]
  },
  "pages/tool/detail/EnglistConvert.vue": {
    "resourceType": "script",
    "module": true,
    "file": "EnglistConvert.0501a238.js",
    "src": "pages/tool/detail/EnglistConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FancyBorderRadius.vue": {
    "resourceType": "script",
    "module": true,
    "file": "FancyBorderRadius.515e3349.js",
    "src": "pages/tool/detail/FancyBorderRadius.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "FancyBorderRadius.f62f7156.css": {
    "file": "FancyBorderRadius.f62f7156.css",
    "resourceType": "style"
  },
  "pages/tool/detail/FlvPlayer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "FlvPlayer.f25be302.js",
    "src": "pages/tool/detail/FlvPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_XGPlayer.fbdb72c2.js"
    ],
    "dynamicImports": [
      "_mpegts.e75d6339.js"
    ],
    "css": []
  },
  "FlvPlayer.4f97ec6b.css": {
    "file": "FlvPlayer.4f97ec6b.css",
    "resourceType": "style"
  },
  "_XGPlayer.fbdb72c2.js": {
    "resourceType": "script",
    "module": true,
    "file": "XGPlayer.fbdb72c2.js"
  },
  "pages/tool/detail/ImageToBase64.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ImageToBase64.2679ddb2.js",
    "src": "pages/tool/detail/ImageToBase64.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.1df7656a.js"
    ]
  },
  "pages/tool/detail/MakePhrase.vue": {
    "resourceType": "script",
    "module": true,
    "file": "MakePhrase.4481b7fd.js",
    "src": "pages/tool/detail/MakePhrase.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image.5044287b.js",
      "node_modules/pinyin-pro/lib/pinyin.ts"
    ],
    "css": []
  },
  "MakePhrase.de96d8ec.css": {
    "file": "MakePhrase.de96d8ec.css",
    "resourceType": "style"
  },
  "pages/tool/detail/NPlayer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "NPlayer.8674b298.js",
    "src": "pages/tool/detail/NPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_XGPlayer.fbdb72c2.js"
    ],
    "dynamicImports": [
      "_index.min.10aaf9f8.js",
      "_hls.2a7af7df.js"
    ],
    "css": []
  },
  "NPlayer.4f97ec6b.css": {
    "file": "NPlayer.4f97ec6b.css",
    "resourceType": "style"
  },
  "pages/tool/detail/NationalDayAvatar.vue": {
    "resourceType": "script",
    "module": true,
    "file": "NationalDayAvatar.e986b85b.js",
    "src": "pages/tool/detail/NationalDayAvatar.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_fabric.2646cadb.js"
    ],
    "css": []
  },
  "NationalDayAvatar.7bb32741.css": {
    "file": "NationalDayAvatar.7bb32741.css",
    "resourceType": "style"
  },
  "pages/tool/detail/PngToSVG.vue": {
    "resourceType": "script",
    "module": true,
    "file": "PngToSVG.4ecdf7b5.js",
    "src": "pages/tool/detail/PngToSVG.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/svgo.browser.mjs",
      "_index.efea0cb8.js"
    ]
  },
  "pages/tool/detail/ScreenRec.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ScreenRec.2f1e01da.js",
    "src": "pages/tool/detail/ScreenRec.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_RecordRTC.d7a40e53.js"
    ]
  },
  "pages/tool/detail/TextDistinct.vue": {
    "resourceType": "script",
    "module": true,
    "file": "TextDistinct.3e3867bb.js",
    "src": "pages/tool/detail/TextDistinct.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_uniq.5ad30764.js",
      "_join.5e100562.js"
    ]
  },
  "pages/tool/detail/TextSecret.vue": {
    "resourceType": "script",
    "module": true,
    "file": "TextSecret.a9ed78aa.js",
    "src": "pages/tool/detail/TextSecret.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/ZWSP.ts",
      "_index.efea0cb8.js"
    ],
    "css": []
  },
  "TextSecret.04f6e368.css": {
    "file": "TextSecret.04f6e368.css",
    "resourceType": "style"
  },
  "pages/tool/detail/Timestamp.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Timestamp.b51df3c7.js",
    "src": "pages/tool/detail/Timestamp.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api.735b0804.js",
      "_cookie.91ef53df.js"
    ]
  },
  "pages/tool/detail/TraceReplay.vue": {
    "resourceType": "script",
    "module": true,
    "file": "TraceReplay.332fc1ae.js",
    "src": "pages/tool/detail/TraceReplay.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.92c964f7.js"
    ]
  },
  "pages/tool/detail/UnicodeConvert.vue": {
    "resourceType": "script",
    "module": true,
    "file": "UnicodeConvert.6a11534e.js",
    "src": "pages/tool/detail/UnicodeConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/WeiBoGenerates.vue": {
    "resourceType": "script",
    "module": true,
    "file": "WeiBoGenerates.d3104ecc.js",
    "src": "pages/tool/detail/WeiBoGenerates.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image.5044287b.js"
    ],
    "css": []
  },
  "WeiBoGenerates.51f3a403.css": {
    "file": "WeiBoGenerates.51f3a403.css",
    "resourceType": "style"
  },
  "pages/tool/detail/Whois.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Whois.d93584c6.js",
    "src": "pages/tool/detail/Whois.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api.735b0804.js",
      "_cookie.91ef53df.js"
    ],
    "css": []
  },
  "Whois.5af28908.css": {
    "file": "Whois.5af28908.css",
    "resourceType": "style"
  },
  "pages/tool/detail.vue": {
    "resourceType": "script",
    "module": true,
    "file": "detail.824a19e1.js",
    "src": "pages/tool/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b20a93bc.js",
    "src": "pages/tool/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.e267810c.js",
      "_api.735b0804.js",
      "_cookie.91ef53df.js"
    ]
  },
  "pages/tool.vue": {
    "resourceType": "script",
    "module": true,
    "file": "tool.d977d8e4.js",
    "src": "pages/tool.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.6b4631c5.js",
    "src": "pages/user/index/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.c5ca6cac.js",
    "src": "pages/user/index/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/order.vue": {
    "resourceType": "script",
    "module": true,
    "file": "order.f3b4c32f.js",
    "src": "pages/user/index/order.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.1d98debf.js",
    "src": "pages/user/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.91ef53df.js"
    ]
  },
  "pages/writer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "writer.42c6e04e.js",
    "src": "pages/writer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api.735b0804.js",
      "_cookie.91ef53df.js"
    ],
    "dynamicImports": [
      "node_modules/@bytemd/vue-next/dist/index.mjs",
      "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
      "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
      "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
      "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
      "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
      "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
      "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
      "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
      "assets/theme.ts"
    ],
    "css": []
  },
  "writer.40077ed7.css": {
    "file": "writer.40077ed7.css",
    "resourceType": "style"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth.5b274609.js",
    "src": "middleware/auth.ts",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.91ef53df.js",
      "_api.735b0804.js"
    ]
  },
  "middleware/setSameOriginHeader.ts": {
    "resourceType": "script",
    "module": true,
    "file": "setSameOriginHeader.dd7680ee.js",
    "src": "middleware/setSameOriginHeader.ts",
    "isDynamicEntry": true
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.7f1294a7.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.91ef53df.js",
      "_api.735b0804.js"
    ],
    "css": [
      "default.13777b50.css"
    ]
  },
  "default.13777b50.css": {
    "file": "default.13777b50.css",
    "resourceType": "style"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "file": "empty.bef05a36.js",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@bytemd/vue-next/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.c9ebf9ec.js",
    "src": "node_modules/@bytemd/vue-next/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@bytemd/plugin-breaks/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.b7a1c1e0.js",
    "src": "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-gemoji/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.325e5bcb.js",
    "src": "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-gfm/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.e7f92d8d.js",
    "src": "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-highlight/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.e04dc61f.js",
    "src": "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js"
    ]
  },
  "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.2eab1e9a.js",
    "src": "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.52c1f5e9.js",
    "src": "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/medium-zoom/dist/medium-zoom.esm.js"
    ]
  },
  "node_modules/@bytemd/plugin-mermaid/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.50330dd7.js",
    "src": "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/mermaid/dist/mermaid.esm.min.mjs"
    ]
  },
  "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.18decebf.js",
    "src": "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/marked/lib/marked.esm.js": {
    "resourceType": "script",
    "module": true,
    "file": "marked.esm.551ebfac.js",
    "src": "node_modules/marked/lib/marked.esm.js",
    "isDynamicEntry": true
  },
  "assets/theme.ts": {
    "resourceType": "script",
    "module": true,
    "file": "theme.a19ed3dc.js",
    "src": "assets/theme.ts",
    "isDynamicEntry": true
  },
  "_index.1df7656a.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.1df7656a.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js",
      "____vite-browser-external_commonjs-proxy.b95c029b.js"
    ]
  },
  "__commonjsHelpers.a7148835.js": {
    "resourceType": "script",
    "module": true,
    "file": "_commonjsHelpers.a7148835.js"
  },
  "____vite-browser-external_commonjs-proxy.b95c029b.js": {
    "resourceType": "script",
    "module": true,
    "file": "___vite-browser-external_commonjs-proxy.b95c029b.js",
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "utils/Drag.ts": {
    "resourceType": "script",
    "module": true,
    "file": "Drag.fecf15e7.js",
    "src": "utils/Drag.ts",
    "isDynamicEntry": true
  },
  "utils/color.ts": {
    "resourceType": "script",
    "module": true,
    "file": "color.1a3a3075.js",
    "src": "utils/color.ts",
    "isDynamicEntry": true
  },
  "_interact.min.3ac48332.js": {
    "resourceType": "script",
    "module": true,
    "file": "interact.min.3ac48332.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_dom-to-image.5044287b.js": {
    "resourceType": "script",
    "module": true,
    "file": "dom-to-image.5044287b.js",
    "isDynamicEntry": true
  },
  "node_modules/@zackdk/m3u8tomp4/src/index.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.6810e914.js",
    "src": "node_modules/@zackdk/m3u8tomp4/src/index.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_mpegts.e75d6339.js": {
    "resourceType": "script",
    "module": true,
    "file": "mpegts.e75d6339.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "node_modules/pinyin-pro/lib/pinyin.ts": {
    "resourceType": "script",
    "module": true,
    "file": "pinyin.3f986354.js",
    "src": "node_modules/pinyin-pro/lib/pinyin.ts",
    "isDynamicEntry": true
  },
  "_index.min.10aaf9f8.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.min.10aaf9f8.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_hls.2a7af7df.js": {
    "resourceType": "script",
    "module": true,
    "file": "hls.2a7af7df.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_fabric.2646cadb.js": {
    "resourceType": "script",
    "module": true,
    "file": "fabric.2646cadb.js",
    "isDynamicEntry": true,
    "imports": [
      "____vite-browser-external_commonjs-proxy.b95c029b.js"
    ]
  },
  "utils/svgo.browser.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "svgo.browser.3113e892.js",
    "src": "utils/svgo.browser.mjs",
    "isDynamicEntry": true
  },
  "_index.efea0cb8.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.efea0cb8.js",
    "isDynamicEntry": true
  },
  "_RecordRTC.d7a40e53.js": {
    "resourceType": "script",
    "module": true,
    "file": "RecordRTC.d7a40e53.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_uniq.5ad30764.js": {
    "resourceType": "script",
    "module": true,
    "file": "uniq.5ad30764.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_join.5e100562.js": {
    "resourceType": "script",
    "module": true,
    "file": "join.5e100562.js",
    "isDynamicEntry": true
  },
  "utils/ZWSP.ts": {
    "resourceType": "script",
    "module": true,
    "file": "ZWSP.e88cbe23.js",
    "src": "utils/ZWSP.ts",
    "isDynamicEntry": true
  },
  "_index.92c964f7.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.92c964f7.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.1b80c24f.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-404.18ced855.css": {
    "file": "error-404.18ced855.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.ebbd068f.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-500.e60962de.css": {
    "file": "error-500.e60962de.css",
    "resourceType": "style"
  },
  "node_modules/highlight.js/es/index.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.5c5dd036.js",
    "src": "node_modules/highlight.js/es/index.js",
    "isDynamicEntry": true
  },
  "node_modules/medium-zoom/dist/medium-zoom.esm.js": {
    "resourceType": "script",
    "module": true,
    "file": "medium-zoom.esm.429efe94.js",
    "src": "node_modules/medium-zoom/dist/medium-zoom.esm.js",
    "isDynamicEntry": true
  },
  "node_modules/mermaid/dist/mermaid.esm.min.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "mermaid.esm.min.6d6fe547.js",
    "src": "node_modules/mermaid/dist/mermaid.esm.min.mjs",
    "isDynamicEntry": true
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.06cc0c9c.css",
    "src": "pages/index.css"
  },
  "pages/read/index.css": {
    "resourceType": "style",
    "file": "index.412ca2a9.css",
    "src": "pages/read/index.css"
  },
  "pages/tool/detail/FancyBorderRadius.css": {
    "resourceType": "style",
    "file": "FancyBorderRadius.f62f7156.css",
    "src": "pages/tool/detail/FancyBorderRadius.css"
  },
  "pages/tool/detail/TextSecret.css": {
    "resourceType": "style",
    "file": "TextSecret.04f6e368.css",
    "src": "pages/tool/detail/TextSecret.css"
  },
  "pages/tool/detail/MakePhrase.css": {
    "resourceType": "style",
    "file": "MakePhrase.de96d8ec.css",
    "src": "pages/tool/detail/MakePhrase.css"
  },
  "pages/read/post/[id].css": {
    "resourceType": "style",
    "file": "_id_.8465ac68.css",
    "src": "pages/read/post/[id].css"
  },
  "atom-one-dark.css": {
    "resourceType": "style",
    "file": "atom-one-dark.a80f81b9.css",
    "src": "atom-one-dark.css"
  },
  "pages/tool/detail/FlvPlayer.css": {
    "resourceType": "style",
    "file": "FlvPlayer.4f97ec6b.css",
    "src": "pages/tool/detail/FlvPlayer.css"
  },
  "pages/tool/detail/Whois.css": {
    "resourceType": "style",
    "file": "Whois.5af28908.css",
    "src": "pages/tool/detail/Whois.css"
  },
  "pages/writer.css": {
    "resourceType": "style",
    "file": "writer.40077ed7.css",
    "src": "pages/writer.css"
  },
  "pages/tool/detail/NationalDayAvatar.css": {
    "resourceType": "style",
    "file": "NationalDayAvatar.7bb32741.css",
    "src": "pages/tool/detail/NationalDayAvatar.css"
  },
  "pages/tool/detail/NPlayer.css": {
    "resourceType": "style",
    "file": "NPlayer.4f97ec6b.css",
    "src": "pages/tool/detail/NPlayer.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.e60962de.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "pages/tool/detail/WeiBoGenerates.css": {
    "resourceType": "style",
    "file": "WeiBoGenerates.51f3a403.css",
    "src": "pages/tool/detail/WeiBoGenerates.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.18ced855.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.13777b50.css",
    "src": "layouts/default.css"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.c86584e4.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs-css": {
    "file": "",
    "css": [
      "entry.c86584e4.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
