import { a as useNuxtApp, u as useHead } from './server.mjs';
import { defineComponent, ref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderList, ssrRenderClass, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CSSGradient",
  __ssrInlineRender: true,
  setup(__props) {
    useNuxtApp();
    const selectPointConfig = ref({
      index: 0
    });
    const appGradientPointList = ref([
      {
        "tranX": 0,
        "percent": 10,
        rgb: {
          r: 0,
          g: 201,
          b: 255
        },
        hsv: {
          h: 0.53,
          s: 1,
          v: 1
        },
        "hex": "#00c9ff",
        "a": 1,
        "isActive": true
      },
      {
        "tranX": 0,
        "percent": 90,
        rgb: {
          r: 146,
          g: 254,
          b: 157
        },
        hsv: {
          h: 0.35,
          s: 0.42,
          v: 0.99
        },
        "hex": "#92fe9e",
        "a": 1,
        "isActive": false
      }
    ]);
    ref({
      hue: null,
      alpha: null,
      bgAlpha: null,
      sv: null,
      svPointer: null
    });
    const styleConfig = ref({
      type: "linear"
    });
    const customDeg = ref(90);
    const customColor = ref(customDeg.value + "deg, rgb(0, 201, 255) 10%, rgb(146, 254, 157) 90%");
    const tempSortList = ref([]);
    useHead({
      title: "CSS\u6E10\u53D8\u80CC\u666F\u5DE5\u5177",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "CSSGradient\u6E10\u53D8\u80CC\u666F,css\u6E10\u53D8\u80CC\u666F\u5DE5\u5177,\u5728\u7EBF\u5236\u4F5Ccss\u6E10\u53D8\u80CC\u666F,\u6E10\u53D8\u5DE5\u5177\u5728\u7EBF\u7248,\u6E10\u53D8\u8272\u53D6\u6837,linear-gradient" },
        { name: "description", content: "\u4E00\u4E2A\u529F\u80FD\u5F3A\u5927\u7684css\u6E10\u53D8\u80CC\u666F\u5728\u7EBF\u751F\u6210\u5DE5\u5177\uFF0C\u5E2E\u52A9\u4F60\u5FEB\u901F\u8C03\u8BD5\u51FA\u6F02\u4EAE\u7684\u6E10\u53D8\u8272\u3002" }
      ],
      link: [
        { rel: "stylesheet", href: "/css/cssgradient.css" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><header class="page-header header-app"><div class="header-app__background-transparent"></div><div class="header-app__background-color js-header" style="${ssrRenderStyle("background-image: " + styleConfig.value.type + "-gradient(" + customColor.value + ");")}"></div></header><main class="js-body-content"><section class="panel-app"><section class="app-gradient"><div class="app-gradient__color"><div class="app-gradient__color-background js-background" style="${ssrRenderStyle("background-image: linear-gradient(" + customColor.value.replace(/[0-9]\d*deg/g, "90deg").replace("circle", "90deg") + ");")}"></div><div class="app-gradient__points js-drag"><!--[-->`);
      ssrRenderList(appGradientPointList.value, (item, index) => {
        _push(`<div class="${ssrRenderClass([item.isActive ? "is-active" : "", "js-draggable app-gradient__point"])}" touch-action="none"${ssrRenderAttr("data-x", item.tranX)}${ssrRenderAttr("index", index)} style="${ssrRenderStyle("transform: translateX(" + item.tranX + "px);")}"><div class="app-gradient__point-background"></div><div class="app-gradient__point-visual"></div><div class="app-gradient__point-color" style="${ssrRenderStyle("background-color: rgb(" + item.rgb.r + ", " + item.rgb.g + ", " + item.rgb.b + ", " + item.a + ");")}"></div><label class="app-gradient__point-label"><div class="app-gradient__point-label-bg"></div><input class="app-gradient__point-input" disabled${ssrRenderAttr("value", item.percent)}></label></div>`);
      });
      _push(`<!--]--></div></div></section><section class="app-color"><div class="row"><div class="col-xs-24 col-lg-8"><div class="colorPicker"></div></div><div class="col-xs-24 col-md-12 col-lg-8"><div class="app-color__inputs js-controls"><div class="controls-title">Color Code</div><div class="extras"><div class="hex"><input class="" type="text" maxlength="7"${ssrRenderAttr("value", appGradientPointList.value[selectPointConfig.value.index].hex)}><label class="">hex</label></div><div class="colorFields"><div class="color r"><input class="" type="text" maxlength="15"${ssrRenderAttr("value", appGradientPointList.value[selectPointConfig.value.index].rgb.r)}><label class="">r</label></div><div class="color g"><input class="" type="text" maxlength="15"${ssrRenderAttr("value", appGradientPointList.value[selectPointConfig.value.index].rgb.g)}><label class="">g</label></div><div class="color b"><input class="" type="text" maxlength="15"${ssrRenderAttr("value", appGradientPointList.value[selectPointConfig.value.index].rgb.b)}><label class="">b</label></div><div class="color a"><input class="" type="text" maxlength="15"${ssrRenderAttr("value", appGradientPointList.value[selectPointConfig.value.index].a)}><label class="">a</label></div></div></div></div></div><div class="col-xs-24 col-md-12 col-lg-8"><div class="app-color__stops"><div class="app-color__stops-title"><div class="app-color__stop-color"></div><div class="app-color__stop-hex"><h3>Hex</h3></div><div class="app-color__stop-position"><h3>Stop</h3></div><div class="app-color__stop-action"><h3>\u2295</h3></div></div><div class="js-stops"><!--[-->`);
      ssrRenderList(tempSortList.value, (item, index) => {
        _push(`<div class="${ssrRenderClass([item.isActive ? "is-active" : "", "app-color__stop"])}"><div class="app-color__stop-color"><div class="app-color__stop-color-bg"><div class="app-color__stop-color-tile" style="${ssrRenderStyle("background-color: rgb(" + item.rgb.r + ", " + item.rgb.g + ", " + item.rgb.b + ", " + item.a + ");")}"></div></div></div><div class="app-color__stop-hex"><input disabled${ssrRenderAttr("value", item.hex)}></div><div class="app-color__stop-position"><input disabled${ssrRenderAttr("value", item.percent)}></div><div class="app-color__stop-action"><button class="app-color__stop-action-button">\xD7</button></div></div>`);
      });
      _push(`<!--]--></div></div></div></div></section><section class="app-options"><div class="row"><div class="col-xs-24"><div class="app-options__content"><div class="app-option"><button class="${ssrRenderClass([styleConfig.value.type == "linear" ? "is-active" : "", "app-option__button app-option__button--linear js-button-linear"])}"><span class="app-option__button-icon"></span> Linear </button> <button class="${ssrRenderClass([styleConfig.value.type == "radial" ? "is-active" : "", "app-option__button app-option__button--radial js-button-radial"])}"><span class="app-option__button-icon"></span> Radial </button></div><div class="app-option" style="${ssrRenderStyle("display: " + (styleConfig.value.type == "linear" ? "block" : "none") + ";")}"><div class="app-option__angles"><div class="app-option__angle js-angle"><div class="app-option__angle-center js-pointer" style="${ssrRenderStyle("transform: translateZ(0px) rotate(" + customDeg.value + "deg);")}"><div class="app-option__angle-pointer"></div></div></div><input class="app-option__input js-angle-input"${ssrRenderAttr("value", customDeg.value + "\xB0")}></div></div><div class="app-option"><img class="input-file js-upload"> <label for="file"><svg width="16" height="16" xmlns="http://www.w3.org/2000/svg"><g stroke="#BBBFC5" stroke-width="2" fill="none" fill-rule="evenodd"><path d="M1 1h14v14H1z"></path><path d="M1 9l3-3 9 9"></path><path d="M8 10l3-3 4 4"></path></g></svg> Download </label></div><div class="app-option"><h1 class="">CSS\u6E10\u53D8\u80CC\u666F\u5DE5\u5177</h1></div></div></div></div></section></section><section class="panel-code"><div class="row"><div class="col-xs-24 col-md-24"><section class="code-editor"><div class="code-editor__column"><div class="code-editor__column-tabs"></div><div class="code-editor__column-numbers">1<br>2<br>3<br>4<br>5<br>6<br></div></div><div class="code-editor__block"><div class="code-editor__tabs"><div class="code-editor__tab is-active"> CSS </div><div class="code-editor__compat"><label><input type="checkbox" class="js-compat"><div class="compat__text"> Max Compatibility <span>(IE6+)</span></div><div class="compat__checkbox"></div></label></div></div><div class="code-editor__input"><code class="code-editor__input-code js-code" id="code"><span class="blue">background</span>: rgb(131,58,180);<br><span class="blue">background</span>: ${ssrInterpolate(styleConfig.value.type)}-gradient(${ssrInterpolate(customColor.value)});</code></div></div></section><section class="code-options"><button class="code-option__button js-copy"><div class="code-option__button-bg js-button-copy" style="${ssrRenderStyle("background-image: linear-gradient(" + customColor.value.replace(/[0-9]\d*deg/g, "90deg").replace("circle", "90deg") + ");")}"></div><svg class="code-option__button-svg" width="13" height="17" xmlns="http://www.w3.org/2000/svg"><g stroke="#ffffff" stroke-width="2" fill="none" fill-rule="evenodd"><path d="M5 5h7v11H5z"></path><path d="M1 15V1h10"></path></g></svg> <span>Copy to Clipboard</span></button></section></div></div></section></main></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/CSSGradient.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=CSSGradient.1376978a.mjs.map
