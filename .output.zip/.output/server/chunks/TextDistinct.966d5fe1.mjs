import { defineComponent, ref, withAsyncContext, watch, mergeProps, useSSRContext } from 'vue';
import { a as useNuxtApp, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TextDistinct",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const text = ref("");
    const result = ref("");
    const copyText = ref("\u4E00\u952E\u590D\u5236");
    useNuxtApp();
    const uniq = ([__temp, __restore] = withAsyncContext(() => import('lodash/uniq.js')), __temp = await __temp, __restore(), __temp).default;
    const join = ([__temp, __restore] = withAsyncContext(() => import('lodash/join.js')), __temp = await __temp, __restore(), __temp).default;
    watch(text, (count, prevCount) => {
      result.value = join(uniq(text.value.split("\n")), "\n");
    });
    useHead({
      title: "\u5728\u7EBF\u6587\u672C\u53BB\u91CD",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "\u6587\u672C\u53BB\u91CD\u5DE5\u5177,\u6279\u91CF\u53BB\u91CD,\u5728\u7EBF\u53BB\u9664\u91CD\u590D\u3002" },
        { name: "description", content: "\u5728\u7EBF\u6587\u672C\u53BB\u9664\u91CD\u590D\u5DE5\u5177\uFF0C\u5FEB\u901F\u6279\u91CF\u53BB\u91CD\uFF0C\u4F7F\u7528\u573A\u666F\u5E7F\u6CDB\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white" }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">\u6587\u672C\u53BB\u91CD</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12"><div class="relative"><p>\u539F\u6587\u672C\uFF1A</p><textarea placeholder="aaa
aaa
bbb" autofocus class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3" rows="8">${ssrInterpolate(text.value)}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(text.value.split("\n").length)} \u884C</span></div><div class="relative"><p>\u7ED3\u679C\uFF1A</p><textarea placeholder="aaa
bbb" class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3" rows="8">${ssrInterpolate(result.value)}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(result.value.split("\n").length)} \u884C</span></div><div class="flex flex-row flex-wrap"><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u6E05\u7A7A </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none">${ssrInterpolate(copyText.value)}</button></div></section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({ "max-width": "none" })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u6587\u672C\u53BB\u91CD\u5DE5\u5177\u5728\u65E5\u5E38\u751F\u6D3B\u4E2D\u771F\u7684\u5F88\u65B9\u4FBF\uFF0C\u8BB0\u5F55\u4EBA\u6570\u65F6\u56FE\u65B9\u4FBF\u8FDB\u6765\u4E00\u4E2A\u4EBA\u5199\u4E00\u4E2A\u4EBA\u7684\u540D\u5B57\uFF0C\u4F46\u662F\u6709\u4EBA\u591A\u6B21\u8FDB\u6765\uFF0C\u5C31\u5BFC\u81F4\u4E86\u4E00\u4E2A\u4EBA\u7684\u540D\u5B57\u5199\u4E86\u4E24\u6B21\uFF0C\u90A3\u4E48\u73B0\u5728\u53EA\u9700\u8981\u5C06\u8BB0\u5F55\u7684\u6240\u6709\u4EBA\u7684\u540D\u5B57\u90FD\u5199\u5165\u8FD9\u4E2A\u5DE5\u5177\uFF0C\u5219\u4F1A\u81EA\u52A8\u53BB\u91CD\uFF0C\u9632\u6B62\u591A\u6B21\u7EDF\u8BA1\u3002 </p></blockquote><ul><li>\u4F60\u53EA\u7BA1\u5F55\u5165\uFF0C\u5269\u4E0B\u7684\u4EA4\u7ED9\u5DE5\u5177\u3002</li><li>\u4F7F\u7528\u65B9\u4FBF\uFF0C\u6309\u884C\u7EDF\u8BA1\u3002</li><li>\u73ED\u7EA7\u7B7E\u5230\u3001\u805A\u4F1A\u4EBA\u6570\u7EDF\u8BA1\u7B49\u751F\u6D3B\u573A\u666F\u3002</li></ul></article></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/TextDistinct.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=TextDistinct.966d5fe1.mjs.map
