const FlvPlayer_vue_vue_type_style_index_0_lang = ".video-player-box{padding-bottom:70%;position:relative}";

const FlvPlayerStyles_77345c29 = [FlvPlayer_vue_vue_type_style_index_0_lang];

export { FlvPlayerStyles_77345c29 as default };
//# sourceMappingURL=FlvPlayer-styles.77345c29.mjs.map
