import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "YinHeOSCode",
    __ssrInlineRender: true,
    setup(__props) {
      const code = ref("");
      setInterval(function() {
        let date = new Date();
        let hour = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
        code.value = "#*" + (date.getMonth() + 11).toString() + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate().toString()) + (hour < 10 ? "0" + hour : hour);
      }, 100);
      useHead({
        title: "\u94F6\u6CB3OS\u52A8\u6001\u7801\u751F\u6210\u5DE5\u5177",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u94F6\u6CB3OS\u6253\u5F00ADB\u52A8\u6001\u7801,\u94F6\u6CB3OS\u5B89\u88C5\u7B2C\u4E09\u65B9\u8F6F\u4EF6,\u94F6\u6CB3\u8F66\u673A\u52A8\u6001\u7801\u5DE5\u5177"
          },
          {
            name: "description",
            content: "\u8FD9\u662F\u4E00\u4E2A\u81EA\u52A8\u751F\u6210\u5409\u5229\u94F6\u6CB3OS\u8FDB\u5165\u5F00\u53D1\u8005\u5DE5\u5177\u52A8\u6001\u7801\u7684\u5DE5\u5177\u3002"
          }
        ],
        script: [
          {
            async: "true",
            src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6667301035180632",
            crossorigin: "anonymous"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">\u94F6\u6CB3OS\u52A8\u6001\u7801</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12 h-96"> \u5F53\u524D\u52A8\u6001\u7801\uFF1A<span class="font-bold">${ssrInterpolate(unref(code))}</span><ins class="adsbygoogle" style="${ssrRenderStyle({
          "display": "block"
        })}" data-ad-client="ca-pub-6667301035180632" data-ad-slot="7555737332" data-ad-format="auto" data-full-width-responsive="true"></ins></section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u8FD9\u662F\u5409\u5229\u94F6\u6CB3OS\u8F66\u673A\u7CFB\u7EDF\u8FDB\u5165\u5F00\u53D1\u8005\u8C03\u8BD5\u5DE5\u5177\u7684\u52A8\u6001\u7801\u751F\u6210\u5668\uFF0C\u5728\u8F66\u673A\u5185\u6253\u5F00\u7535\u8BDD\uFF0C\u8F93\u5165\u8FD9\u6BB5\u4EE3\u7801\u5373\u53EF\u8FDB\u5165\u3002 </p></blockquote><ul><li>\u5409\u5229\u94F6\u6CB3OS\u5B89\u88C5\u7B2C\u4E09\u65B9APP\u5DE5\u5177</li><li>\u672C\u5DE5\u5177\u57FA\u4E8E\u7F51\u7EDC\u6D41\u4F20\u7684\u7B97\u6CD5</li><li>\u60A0\u7740\u70B9\uFF0C\u522B\u628A\u8F66\u673A\u641E\u6210\u7816\uFF01</li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/YinHeOSCode.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=YinHeOSCode.1d769d06.mjs.map
