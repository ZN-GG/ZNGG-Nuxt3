import { __tla as __tla$1, a as useNuxtApp, _ as __nuxt_component_0$1 } from './server.mjs';
import { defineComponent, ref, withAsyncContext, withCtx, createVNode, unref, toDisplayString, createTextVNode, useSSRContext } from 'vue';
import { _ as __tla$2, u as useAsyncData } from './asyncData.69ceb001.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import { _ as __tla$3, a as api } from './api.f18d44dd.mjs';
import { _ as __tla$4 } from './request.066d4a9e.mjs';
import { _ as __tla$5 } from './cookie.5566d94f.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "create",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      useNuxtApp();
      const page = ref(1);
      const articleList = ref([]);
      const totalPages = ref(0);
      const { data: articleData, pending: articlePending, refresh: ArticleRefresh, error: articleError } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("index_GetUserArticleList", () => api.article.getUserList(1, 10, ""))), __temp = await __temp, __restore(), __temp);
      if (articleData.value.success) {
        totalPages.value = articleData.value.data.totalPages;
        articleList.value = articleList.value.concat(articleData.value.data.content);
      }
      return (_ctx, _push, _parent, _attrs) => {
        const _component_NuxtLink = __nuxt_component_0$1;
        const _component_nuxt_link = __nuxt_component_0$1;
        _push(`<div${ssrRenderAttrs(_attrs)}><div class="my-6 flex justify-between items-center"><p class="font-bold text-2xl">\u521B\u4F5C</p>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/writer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="btn-normal"${_scopeId}>\u5199\u6587\u7AE0</button>`);
            } else {
              return [
                createVNode("button", {
                  class: "btn-normal"
                }, "\u5199\u6587\u7AE0")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div><ul><!--[-->`);
        ssrRenderList(unref(articleList), (item, index) => {
          _push(`<li class="mt-4 border-b pb-2"><div class="flex relative"><div class="flex-1 mr-2">`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            target: "_blank",
            to: "/read/post/" + item.id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<p class="font-semibold text-base h-8 leading-8 w-full overflow-y-hidden"${_scopeId}>${ssrInterpolate(item.title)}</p>`);
              } else {
                return [
                  createVNode("p", {
                    class: "font-semibold text-base h-8 leading-8 w-full overflow-y-hidden",
                    textContent: toDisplayString(item.title)
                  }, null, 8, [
                    "textContent"
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<p class="custom-font-14 leading-8 overflow-hidden h-6 text-gray-400 mb-2">${ssrInterpolate(item.summary)}</p></div>`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: "/writer?id=" + item.id,
            class: "font-bold text-xl"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`\u7F16\u8F91 `);
              } else {
                return [
                  createTextVNode("\u7F16\u8F91 ")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></li>`);
        });
        _push(`<!--]--></ul></div><div class="flex justify-center my-4"><button style="${ssrRenderStyle(unref(page) > 1 ? null : {
          display: "none"
        })}" class="btn-normal mx-2">\u4E0A\u4E00\u9875</button><button style="${ssrRenderStyle(unref(totalPages) > unref(page) ? null : {
          display: "none"
        })}" class="btn-normal mx-2">\u4E0B\u4E00\u9875</button></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index/create.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=create.6e3db41e.mjs.map
