const isEmpty = (data) => {
  return data === "" || data === null || data === void 0 || typeof data === "number" && isNaN(data);
};
const isRealEmpty = (data) => {
  return isEmpty(data) || Array.isArray(data) && !data.length || typeof data === "object" && !Object.keys(data).length;
};
const isUrl = (url) => {
  return /^https?:\/\/.+/.test(url);
};
const isEmail = (data) => {
  return /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/.test(data);
};
const isIdcard = (data) => {
  return /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/.test(data);
};
const isCarNumber = (data) => {
  if (typeof data !== "string") {
    return false;
  }
  const regExp = /^([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Za-z]{1}[A-Za-z]{1}(([0-9]{5}[DFdf])|([DFdf]([A-HJ-NP-Za-hj-np-z0-9])[0-9]{4})))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Za-z]{1}[A-Za-z]{1}[A-HJ-NP-Za-hj-np-z0-9]{4}[A-HJ-NP-Za-hj-np-z0-9挂学警港澳]{1})$/;
  return regExp.test(data);
};
const isPhoneNumber = (data) => {
  const regExp = /^[1]([3-9])[0-9]{9}$/;
  return regExp.test(data);
};
const isNumberLike = (data) => {
  return /^[\d]+$/g.test(data) && Number(data) < Number.MAX_SAFE_INTEGER;
};
const isJsonString = (data) => {
  if (typeof data !== "string") {
    return false;
  }
  try {
    if (typeof JSON.parse(data) === "object") {
      return true;
    }
  } catch (e) {
  }
  return false;
};

export { isCarNumber, isEmail, isEmpty, isIdcard, isJsonString, isNumberLike, isPhoneNumber, isRealEmpty, isUrl };
//# sourceMappingURL=validate.476b29a2.mjs.map
