import { defineComponent, ref, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "Base64Convert",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      const text = ref("");
      const result = ref("");
      const copyText = ref("\u4E00\u952E\u590D\u5236");
      useNuxtApp();
      [__temp, __restore] = withAsyncContext(() => import('crypto-js').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore();
      useHead({
        title: "Base64\u7F16\u7801\u89E3\u7801",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "Base64,Base64\u7F16\u7801,Base64\u89E3\u7801,Base64\u52A0\u5BC6,Base64\u89E3\u5BC6"
          },
          {
            name: "description",
            content: "\u5728\u7EBFBase64\u7F16\u7801\u89E3\u7801 \u5728\u7EBFBase64\u52A0\u5BC6\u89E3\u5BC6\u5DE5\u5177\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">Base64\u7F16\u7801\u89E3\u7801</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12"><div class="w-full flex flex-wrap"><div class="relative w-full md:w-6/12 md:pr-2"><div class="relative"><textarea autofocus class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3 h-full" rows="8">${ssrInterpolate(unref(text))}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(unref(text).length)}</span></div></div><div class="relative w-full md:w-6/12 md:pl-2"><div class="relative"><textarea class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3 h-full" rows="8">${ssrInterpolate(unref(result))}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(unref(result).length)}</span></div></div></div><div class="flex flex-row flex-wrap"><button class="flex my-2 mr-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u7F16\u7801 </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u89E3\u7801 </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none">${ssrInterpolate(unref(copyText))}</button><button class="flex md:m-2 my-2 py-2 px-4 font-medium tracking-widest text-white bg-red-800 shadow-lg focus:outline-none hover:bg-red-900 hover:shadow-none"> \u6E05\u7A7A </button></div></section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>Base64\u662F\u4E00\u79CD\u5E38\u89C1\u7684\u52A0\u5BC6\u65B9\u5F0F\uFF0C\u543E\u7231\u7834\u89E3\u8BBA\u575B\u5185\u67D0\u4E9B\u677F\u5757\u5728\u5E16\u5B50\u91CC\u7ECF\u5E38\u4F7F\u7528\u8FD9\u79CD\u52A0\u5BC6\u65B9\u5F0F\u6765\u52A0\u5BC6\u4E00\u4E9B\u5982\u8F6F\u4EF6\u540D\u3001\u7F51\u5740\u7B49\u654F\u611F\u4FE1\u606F\uFF0C\uFF08\u4E2A\u4EBA\u7406\u89E3\uFF09\u4E00\u822C\u770B\u5230\u4E00\u6BB5\u6CA1\u6709\u89C4\u5F8B\u7684\u82F1\u6587\uFF0C\u4E14\u6700\u540E\u662F==\u6216/xx\uFF0C\u90A3\u4E48\u5927\u6982\u7387\u662Fbase64\u52A0\u5BC6\uFF0C\u5C31\u4E0D\u59A8\u4F7F\u7528\u672C\u5DE5\u5177\u8BD5\u8BD5\u770B\u80FD\u5426\u89E3\u5BC6\u6210\u660E\u6587\u3002 </p></blockquote><ul><li>Base64\u52A0\u5BC6</li><li>Base64\u89E3\u5BC6</li><li>\u76F8\u5173\u5DE5\u5177\uFF1A<a href="ImageToBase64">Base64\u56FE\u7247\u8F6C\u6362</a></li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/Base64Convert.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=Base64Convert.08e0b8d7.mjs.map
