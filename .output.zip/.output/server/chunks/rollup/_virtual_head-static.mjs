const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">\n<script defer=\"\" crossorigin=\"anonymous\" src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6667301035180632\"></script>\n<script>if (!window.__abg_called){ (window.adsbygoogle = window.adsbygoogle || []); adsbygoogle.pauseAdRequests=0;\n            adsbygoogle.push({\n        google_ad_client: \"ca-pub-6667301035180632\",\n        overlays: {bottom: false},\n        \n      }); window.__abg_called = true;}</script>","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
