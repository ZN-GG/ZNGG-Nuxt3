import { defineComponent, withAsyncContext, ref, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderStyle, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let WeiBoGenerates;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main = defineComponent({
    __name: "WeiBoGenerates",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      ([__temp, __restore] = withAsyncContext(() => import('dom-to-image').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      ref();
      const vip = ref("icon_member7");
      const daren = ref(true);
      const renzheng = ref(true);
      const loading = ref(false);
      const vipList = ref({
        none: "\u65E0",
        icon_member1: "VIP1",
        icon_member2: "VIP2",
        icon_member3: "VIP3",
        icon_member4: "VIP4",
        icon_member5: "VIP5",
        icon_member6: "VIP6",
        icon_member7: "VIP7"
      });
      const img = ref("");
      ref("");
      ref("");
      ref("");
      const avatar = ref("/img/avatar.jpg");
      useNuxtApp();
      useHead({
        title: "\u5FAE\u535A\u56FE\u7247\u751F\u6210\u5668",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u5FAE\u535A\u56FE\u7247\u751F\u6210,\u540D\u4EBA\u5FAE\u535A\u56FE\u7247\u751F\u6210,\u751F\u6210\u5FAE\u535A\u56FE\u7247\u3002"
          },
          {
            name: "description",
            content: "\u53EF\u4EE5\u5728\u7EBF\u751F\u6210\u4EFB\u610F\u5FAE\u535A\u4FE1\u606F\uFF0C\u6076\u641E\u5FAE\u535A\u56FE\u7247\u751F\u6210\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))} data-v-3c73221d><section class="bg-gray-100" data-v-3c73221d><div class="container px-4 mx-auto" data-v-3c73221d><div class="md:flex md:-mx-4 md:items-center py-8" data-v-3c73221d><div class="md:w-1/2 px-4" data-v-3c73221d><h1 class="text-2xl text-black" data-v-3c73221d>\u5FAE\u535A\u56FE\u7247\u751F\u6210</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12" data-v-3c73221d><div class="weibo-container" data-v-3c73221d><div data-v-3c73221d><div class="flex flex-wrap mb-4" data-v-3c73221d><h2 class="w-full font-semibold text-gray-900" data-v-3c73221d>\u8BF7\u9009\u62E9VIP\u7B49\u7EA7\uFF1A</h2><!--[-->`);
        ssrRenderList(unref(vipList), (item, index) => {
          _push(`<button class="${ssrRenderClass([
            index == unref(vip) ? "bg-blue-600 text-white" : "bg-gray-100",
            "cursor-pointer my-1 select-none mr-2 px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"
          ])}" data-v-3c73221d>${ssrInterpolate(item)}</button>`);
        });
        _push(`<!--]--></div><h2 class="font-semibold text-gray-900" data-v-3c73221d>\u8BF7\u9009\u62E9\u5934\u50CF\uFF1A</h2><div class="form-group" data-v-3c73221d><div class="text-center relative pt-6 pb-6 mb-4 border-2 hover:bg-gray-100 custom-font-14 rounded" id="fileInput" data-v-3c73221d><span data-v-3c73221d>\u62D6\u62FD\u6587\u4EF6\u5230\u8FD9\u91CC\u6216\u8005\u70B9\u51FB\u9009\u62E9\u6587\u4EF6</span><input type="file" id="file" accept="image/*" style="${ssrRenderStyle({
          "opacity": "0",
          "position": "absolute",
          "cursor": "pointer",
          "width": "100%",
          "height": "100%",
          "left": "0",
          "top": "0"
        })}" data-v-3c73221d></div></div><div data-v-3c73221d><h2 class="mb-4 font-semibold text-gray-900" data-v-3c73221d>\u66F4\u591A\u8BBE\u7F6E\uFF1A</h2><ul class="items-center w-full text-sm font-medium text-gray-900 bg-white rounded-lg border border-gray-200 sm:flex" data-v-3c73221d><li class="w-full border-b border-gray-200 sm:border-b-0 sm:border-r" data-v-3c73221d><div class="flex items-center pl-3" data-v-3c73221d><input id="vue-checkbox-list" type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(renzheng)) ? ssrLooseContain(unref(renzheng), null) : unref(renzheng)) ? " checked" : ""} class="w-4 h-4 text-blue-600 bg-gray-100 rounded border-gray-300 focus:ring-blue-500 y-600" data-v-3c73221d><label for="vue-checkbox-list" class="py-3 ml-2 w-full text-sm font-medium text-gray-900" data-v-3c73221d>\u4E2A\u4EBA\u8BA4\u8BC1</label></div></li><li class="w-full border-b border-gray-200 sm:border-b-0 sm:border-r" data-v-3c73221d><div class="flex items-center pl-3" data-v-3c73221d><input id="react-checkbox-list" type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(daren)) ? ssrLooseContain(unref(daren), null) : unref(daren)) ? " checked" : ""} class="w-4 h-4 text-blue-600 bg-gray-100 rounded border-gray-300 focus:ring-blue-500 focus:ring-2" data-v-3c73221d><label for="react-checkbox-list" class="py-3 ml-2 w-full text-sm font-medium text-gray-900" data-v-3c73221d>\u5FAE\u535A\u8FBE\u4EBA</label></div></li></ul></div><div class="weibo-box" data-v-3c73221d><div class="c" data-v-3c73221d><div contenteditable="true" class="user-box" data-v-3c73221d><div class="header" data-v-3c73221d><img${ssrRenderAttr("src", unref(avatar))} class="avatar" data-v-3c73221d><div class="info" data-v-3c73221d><div class="info-header" data-v-3c73221d><span class="name" data-v-3c73221d> \u674E\u5B9D\u5B9D </span><i style="${ssrRenderStyle(unref(renzheng) ? null : {
          display: "none"
        })}" class="icon_approve_gold" data-v-3c73221d></i><i style="${ssrRenderStyle(unref(daren) ? null : {
          display: "none"
        })}" class="daren" data-v-3c73221d></i><i class="${ssrRenderClass([
          unref(vip),
          "icon_member"
        ])}" data-v-3c73221d></i></div><div class="line2" data-v-3c73221d> 7\u670813\u65E5 12:00 \u6765\u81EA iPhone 13 Pro Max </div><div class="content" data-v-3c73221d> \u70ED\u70C8\u5E86\u795DZNGG\u5728\u7EBF\u5DE5\u5177\u4E0A\u7EBF\u5FAE\u535A\u56FE\u7247\u751F\u6210\u5668\u5DE5\u5177\u3002 </div></div></div><div class="footer" data-v-3c73221d><div class="btn" data-v-3c73221d><em class="W_ficon ficon_favorite S_ficon" data-v-3c73221d> \xFB </em><span class="text" data-v-3c73221d> \u6536\u85CF </span></div><div class="btn" data-v-3c73221d><em class="W_ficon ficon_forward S_ficon" data-v-3c73221d> \uE607 </em><span class="text" data-v-3c73221d> 77841 </span></div><div class="btn" data-v-3c73221d><em class="W_ficon ficon_repeat S_ficon" data-v-3c73221d> \uE608 </em><span class="text" data-v-3c73221d> 26289 </span></div><div class="btn" data-v-3c73221d><em class="W_ficon ficon_praised S_txt2" data-v-3c73221d> \xF1 </em><span class="text" data-v-3c73221d> 46885 </span></div></div><i class="W_ficon ficon_arrow_down S_ficon" data-v-3c73221d> c </i></div></div></div><button type="button"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="flex mx-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none" data-v-3c73221d>${ssrInterpolate(unref(loading) ? "\u751F\u6210\u4E2D" : "\u5F00\u59CB\u751F\u6210")}</button></div><div class="my-4" data-v-3c73221d><img${ssrRenderAttr("src", unref(img))} class="img mx-auto md:ml-0" data-v-3c73221d></div></div></section><section class="bg-white w-full container mx-auto px-4 py-6" data-v-3c73221d><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}" data-v-3c73221d><h4 data-v-3c73221d>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote data-v-3c73221d><p data-v-3c73221d>\u56FE\u7247\u76F8\u5173\u4FE1\u606F\u5728\u70B9\u51FB\u914D\u7F6E\uFF0C\u6587\u672C\u76F8\u5173\u4FEE\u6539\u53EF\u4EE5\u76F4\u63A5\u5728\u539F\u6587\u4E0A\u4FEE\u6539\u3002 </p></blockquote><ul data-v-3c73221d><li data-v-3c73221d>\u6076\u641E\u5FAE\u535A\u751F\u6210\uFF0C\u4EC5\u7528\u4E8E\u5A31\u4E50\u4F7F\u7528\u3002</li><li data-v-3c73221d>\u672C\u5DE5\u5177\u4EC5\u9650\u4E8E\u6280\u672F\u5206\u4EAB\u5A31\u4E50\uFF0C\u4E25\u7981\u7528\u4E8E\u975E\u6CD5\u9014\u5F84\u3002</li><li data-v-3c73221d>\u4FDD\u5B58\uFF1A\u751F\u6210\u56FE\u7247\u4E4B\u540E\uFF0C\u7535\u8111\u7528\u6237\u53EF\u4EE5\u53F3\u952E\u4FDD\u5B58\u56FE\u7247\uFF0C\u624B\u673A\u7528\u6237\u957F\u6309\u53EF\u4EE5\u4FDD\u5B58\u56FE\u7247\u3002</li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/WeiBoGenerates.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  WeiBoGenerates = _export_sfc(_sfc_main, [
    [
      "__scopeId",
      "data-v-3c73221d"
    ]
  ]);
});

export { __tla, WeiBoGenerates as default };
//# sourceMappingURL=WeiBoGenerates.073ea33f.mjs.map
