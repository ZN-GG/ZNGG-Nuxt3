import { defineEventHandler, getQuery } from 'h3';

const whoiser = import('whoiser');
const whois_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  try {
    let domainWhois;
    if (query.domain != void 0 && query.domain.toString().indexOf(".") > 0) {
      domainWhois = (await whoiser).domain(query.domain.toString());
    } else if (query.domain != void 0 && query.domain.toString().indexOf(".") <= 0) {
      domainWhois = (await whoiser).tld(query.domain.toString());
    } else if (query.tld != void 0) {
      domainWhois = (await whoiser).tld(query.tld.toString());
    } else {
      throw new Error("\u53C2\u6570\u5F02\u5E38");
    }
    const result = {
      success: true,
      code: 200,
      message: "\u83B7\u53D6\u6210\u529F",
      data: await domainWhois
    };
    return result;
  } catch (e) {
    const result = {
      success: false,
      code: 201,
      message: "\u83B7\u53D6\u5931\u8D25",
      data: e.message
    };
    return result;
  }
});

export { whois_get as default };
//# sourceMappingURL=whois.get.mjs.map
