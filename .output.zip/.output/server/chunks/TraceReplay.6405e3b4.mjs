import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TraceReplay",
  __ssrInlineRender: true,
  setup(__props) {
    const data = ref("");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative" }, _attrs))}><div><div id="container" class="w-full h-screen overflow-hidden"></div></div><div class="fixed right-0 top-0 w-full px-12 py-24 md:w-auto h-screen"><div class="bg-white opacity-95 w-full h-full rounded px-4"><h1 class="pt-6 font-bold text-lg">\u8F68\u8FF9\u4F1A\u653E</h1><div><textarea class="bg-gray-200 outline-none w-full h-full px-2">${ssrInterpolate(unref(data))}</textarea></div><div class="flex w-full flex-wrap"><div class="bg-gray-100 cursor-pointer my-1 select-none mr-2 px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"> \u5F00\u59CB</div><div class="bg-gray-100 cursor-pointer my-1 select-none mr-2 px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"> \u6682\u505C</div><div class="bg-gray-100 cursor-pointer my-1 select-none mr-2 px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"> \u7EE7\u7EED</div><div class="bg-gray-100 cursor-pointer my-1 select-none px-3 md:px-5 rounded-md custom-font-14 leading-8 hover:bg-blue-600 hover:text-white"> \u505C\u6B62</div></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/TraceReplay.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=TraceReplay.6405e3b4.mjs.map
