import { __tla as __tla$1, a as useNuxtApp, _ as __nuxt_component_0$1 } from './server.mjs';
import { defineComponent, ref, withAsyncContext, withCtx, createVNode, unref, toDisplayString, createTextVNode, useSSRContext } from 'vue';
import { _ as __tla$2, u as useAsyncData } from './asyncData.34f60387.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as __tla$3, a as api } from './api.f10a16de.mjs';
import { _ as __tla$4 } from './request.59adbae7.mjs';
import { _ as __tla$5 } from './cookie.fa7850ad.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "create",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      useNuxtApp();
      const page = ref(1);
      const articleList = ref([]);
      const totalPages = ref(0);
      const { data: articleData, pending: articlePending, refresh: ArticleRefresh, error: articleError } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("index_GetUserArticleList", () => api.article.getUserList(1, 10, ""))), __temp = await __temp, __restore(), __temp);
      if (articleData.value.success) {
        totalPages.value = articleData.value.data.totalPages;
        articleList.value = articleList.value.concat(articleData.value.data.content);
        console.log(articleData.value);
      }
      function getState(params) {
        switch (params) {
          case "0":
            return "\u6B63\u5E38";
          case "1":
            return "\u8349\u7A3F";
          case "2":
            return "\u5220\u9664";
          default:
            return "\u672A\u77E5";
        }
      }
      return (_ctx, _push, _parent, _attrs) => {
        var _a;
        const _component_NuxtLink = __nuxt_component_0$1;
        const _component_nuxt_link = __nuxt_component_0$1;
        _push(`<div${ssrRenderAttrs(_attrs)}><div class="my-6 flex justify-between items-center"><p class="font-bold text-2xl">\u521B\u4F5C</p>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/writer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="btn-normal"${_scopeId}>\u5199\u6587\u7AE0</button>`);
            } else {
              return [
                createVNode("button", {
                  class: "btn-normal"
                }, "\u5199\u6587\u7AE0")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="relative overflow-x-auto shadow-md sm:rounded-lg"><div style="${ssrRenderStyle({
          "height": "560px"
        })}"><table class="w-full text-sm text-left text-gray-500 dark:text-gray-400"><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"><tr><th scope="col" class="px-6 py-3"> \u6587\u7AE0\u540D\u79F0 </th><th scope="col" class="px-6 py-3"> \u9605\u8BFB\u91CF </th><th scope="col" class="px-6 py-3"> \u72B6\u6001 </th><th scope="col" class="px-6 py-3"> \u64CD\u4F5C </th></tr></thead><tbody><!--[-->`);
        ssrRenderList(unref(articleList), (item, index) => {
          _push(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"><th scope="row" class="px-6 py-4 font-medium text-gray-900 dark:text-white" style="${ssrRenderStyle({
            "max-width": "400px"
          })}">`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            target: "_blank",
            to: "/read/post/" + item.id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<p class="whitespace-nowrap text-ellipsis overflow-hidden"${_scopeId}>${ssrInterpolate(item.title)}</p>`);
              } else {
                return [
                  createVNode("p", {
                    class: "whitespace-nowrap text-ellipsis overflow-hidden"
                  }, toDisplayString(item.title), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</th><td class="px-6 py-4">${ssrInterpolate(item.viewCount)}</td><td class="px-6 py-4">${ssrInterpolate(getState(item.state))}</td><td class="px-6 py-4">`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            target: "_blank",
            to: "/writer?id=" + item.id,
            class: "mr-2 font-medium text-blue-600 dark:text-blue-500 hover:underline"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`\u7F16\u8F91`);
              } else {
                return [
                  createTextVNode("\u7F16\u8F91")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<a href="#" class="mx-2 font-medium text-red-600 dark:text-blue-500 hover:underline">\u5220\u9664</a></td></tr>`);
        });
        _push(`<!--]--></tbody></table></div><nav class="flex items-center justify-between p-4" aria-label="Table navigation"><span class="text-sm font-normal text-gray-500 dark:text-gray-400">\u5171 <span class="font-semibold text-gray-900 dark:text-white">${ssrInterpolate((_a = unref(articleData)) == null ? void 0 : _a.data.totalElements)}</span> \u6761\u5185\u5BB9\uFF0C\u5F53\u524D${ssrInterpolate(unref(page))}\u9875\uFF0C\u5171${ssrInterpolate(unref(totalPages))}\u9875</span><ul class="inline-flex -space-x-px text-sm h-8"><li><div class="flex cursor-pointer items-center justify-center px-3 h-8 ml-0 leading-tight text-gray-500 bg-white border border-gray-300 rounded-l-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"> \u4E0A\u4E00\u9875</div></li><li><div class="flex cursor-pointer items-center justify-center px-3 h-8 leading-tight text-gray-500 bg-white border border-gray-300 rounded-r-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"> \u4E0B\u4E00\u9875</div></li></ul></nav></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index/create.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=create.7af66bed.mjs.map
