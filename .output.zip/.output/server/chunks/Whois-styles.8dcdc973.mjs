const Whois_vue_vue_type_style_index_0_scoped_6f92f1dd_lang = '.searchBtn[data-v-6f92f1dd]:before{border:6px solid transparent;border-right-color:#000;content:"";position:absolute;right:100%;top:38%}';

const WhoisStyles_8dcdc973 = [Whois_vue_vue_type_style_index_0_scoped_6f92f1dd_lang];

export { WhoisStyles_8dcdc973 as default };
//# sourceMappingURL=Whois-styles.8dcdc973.mjs.map
