const WordToPDF_vue_vue_type_style_index_0_scoped_8c7d5e60_lang = ".convert-bg[data-v-8c7d5e60]{background:url(" + globalThis.__publicAssetsURL("img/office/office_banner.svg") + ") bottom no-repeat;height:130px}.convert-bg[data-v-8c7d5e60],.office-bg[data-v-8c7d5e60]{background-color:#f1f3fe}.in-upload-box[data-v-8c7d5e60]{left:50%;position:absolute;top:50%;transform:translate(-50%,-50%)}";

const WordToPDFStyles_b8210d25 = [WordToPDF_vue_vue_type_style_index_0_scoped_8c7d5e60_lang];

export { WordToPDFStyles_b8210d25 as default };
//# sourceMappingURL=WordToPDF-styles.b8210d25.mjs.map
