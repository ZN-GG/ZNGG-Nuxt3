import { c as _export_sfc, h as userStore, a as useNuxtApp, b as useCookie, _ as __nuxt_component_0$2 } from './server.mjs';
import { useSSRContext, defineComponent, ref, watch, mergeProps, unref, withCtx, createTextVNode, toDisplayString, resolveComponent } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { nanoid } from 'nanoid';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _imports_0 = "" + globalThis.__publicAssetsURL("logo-black.png");
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Login",
  __ssrInlineRender: true,
  setup(__props) {
    const store = userStore();
    const isRegister = ref(false);
    const captchaUrl = ref("");
    const captchaUrlPic = ref("");
    const loginParams = ref({
      email: "",
      password: ""
    });
    const registerParams = {
      email: "",
      name: "",
      password: ""
    };
    const captcha = ref("");
    const captchaEmail = ref("");
    const captchaKey = ref("");
    const repassword = ref("");
    let uuid = nanoid(10);
    captchaKey.value = uuid;
    useNuxtApp();
    useCookie("token", {
      maxAge: 60 * 60 * 24 * 14
    });
    function refreshCaptcha() {
      captchaUrlPic.value = captchaUrl.value + captchaKey.value + "&t=" + new Date().getTime();
    }
    function toLogin() {
      isRegister.value = false;
      refreshCaptcha();
      clearData();
    }
    function clearData() {
      loginParams.value.email = "";
      loginParams.value.password = "";
      registerParams.email = "";
      registerParams.name = "";
      registerParams.password = "";
      captcha.value = "";
      captchaEmail.value = "";
    }
    watch(() => store.showLogin, (newStatus, oldStatus) => {
      if (newStatus) {
        captchaUrl.value = "https://api.zngg.net/user/user/captcha?captcha_uuid=";
        toLogin();
      } else {
        captchaUrl.value = "";
      }
    }, {
      deep: true
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        style: unref(store).showLogin ? null : { display: "none" },
        class: "modal-show flex items-center w-full h-full fixed top-0 left-0 z-40 bg-gray-500 opacity-100 justify-center"
      }, _attrs))} data-v-2723d8f5><div style="${ssrRenderStyle(!isRegister.value ? null : { display: "none" })}" class="modal-content bg-white w-80 pt-12 p-4 relative rounded-md" data-v-2723d8f5><span class="right-0 top-0 absolute m-2 w-5 h-5 iconfont icon-close" data-v-2723d8f5></span><img class="left-0 top-0 w-20 absolute m-2"${ssrRenderAttr("src", _imports_0)} alt="" data-v-2723d8f5><p class="text-2xl font-semibold my-2" data-v-2723d8f5>\u767B\u9646</p><input${ssrRenderAttr("value", loginParams.value.email)} type="text" placeholder="\u90AE\u7BB1\u5730\u5740" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full" data-v-2723d8f5><input${ssrRenderAttr("value", loginParams.value.password)} type="password" placeholder="\u5BC6\u7801" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full" data-v-2723d8f5><div class="flex items-center justify-around" data-v-2723d8f5><input${ssrRenderAttr("value", captcha.value)} type="text" placeholder="\u9A8C\u8BC1\u7801" class="bg-gray-100 w-3 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 mr-2 flex-1" data-v-2723d8f5><img class="h-9 flex-1"${ssrRenderAttr("src", captchaUrlPic.value)} alt="" data-v-2723d8f5></div><button class="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 my-2" data-v-2723d8f5> \u767B\u9646 </button><div class="mt-2 flex justify-between" data-v-2723d8f5><p class="custom-font-12" data-v-2723d8f5> \u8FD8\u6CA1\u6709\u8D26\u53F7\uFF1F <span class="text-blue-600 cursor-pointer font-medium" data-v-2723d8f5>\u7ACB\u5373\u6CE8\u518C</span></p><p class="custom-font-12" data-v-2723d8f5><a class="text-blue-600 cursor-pointer font-medium" data-v-2723d8f5>\u5FD8\u8BB0\u5BC6\u7801?</a></p></div></div><div style="${ssrRenderStyle(isRegister.value ? null : { display: "none" })}" class="modal-content bg-white w-80 pt-12 p-4 relative rounded-md" data-v-2723d8f5><span class="right-0 top-0 absolute m-2 w-5 h-5 iconfont icon-close" data-v-2723d8f5></span><img class="left-0 top-0 w-20 absolute m-2"${ssrRenderAttr("src", _imports_0)} alt="" data-v-2723d8f5><p class="text-2xl font-semibold my-2" data-v-2723d8f5>\u6CE8\u518C\u8D26\u53F7</p><input${ssrRenderAttr("value", registerParams.email)} type="text" placeholder="\u90AE\u7BB1\u5730\u5740" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full" data-v-2723d8f5><div class="flex" data-v-2723d8f5><input${ssrRenderAttr("value", captchaEmail.value)} type="text" placeholder="\u90AE\u7BB1\u9A8C\u8BC1\u7801" class="bg-gray-100 w-3 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 mr-2 flex-1" data-v-2723d8f5><button class="flex-1 bg-blue-500 text-white p-2 my-2 custom-font-14 hover:bg-blue-600" data-v-2723d8f5> \u53D1\u9001 </button></div><input${ssrRenderAttr("value", registerParams.name)} type="text" placeholder="\u7528\u6237\u540D" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full" data-v-2723d8f5><input${ssrRenderAttr("value", registerParams.password)} type="password" placeholder="\u5BC6\u7801" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full" data-v-2723d8f5><input${ssrRenderAttr("value", repassword.value)} type="password" placeholder="\u518D\u8F93\u4E00\u904D\u5BC6\u7801" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full" data-v-2723d8f5><div class="flex items-center justify-around" data-v-2723d8f5><input${ssrRenderAttr("value", captcha.value)} type="text" placeholder="\u9A8C\u8BC1\u7801" class="bg-gray-100 w-3 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 mr-2 flex-1" data-v-2723d8f5><img class="h-9 flex-1"${ssrRenderAttr("src", captchaUrlPic.value)} alt="" data-v-2723d8f5></div><button class="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 my-2" data-v-2723d8f5> \u6CE8\u518C </button><div class="mt-2 flex justify-between" data-v-2723d8f5><p class="custom-font-12" data-v-2723d8f5> \u5DF2\u6709\u8D26\u53F7\uFF1F <span class="text-blue-600 cursor-pointer font-medium" data-v-2723d8f5>\u7ACB\u5373\u767B\u9646</span></p><p class="custom-font-12" data-v-2723d8f5><a class="text-blue-600 cursor-pointer font-medium" data-v-2723d8f5>\u5FD8\u8BB0\u5BC6\u7801?</a></p></div></div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Login.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-2723d8f5"]]);
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Toolbar",
  __ssrInlineRender: true,
  setup(__props) {
    const token = useCookie("token");
    const store = userStore();
    const loginStatus = ref(false);
    if (typeof token.value != "undefined") {
      loginStatus.value = true;
    }
    watch(() => store.isLogin, (newStatus, oldStatus) => {
      loginStatus.value = newStatus;
    }, {
      deep: true
    });
    const dataList = ref([
      {
        link: "tool",
        name: "\u5DE5\u5177"
      },
      {
        link: "read",
        name: "\u6587\u7AE0"
      },
      {
        link: "link",
        name: "\u53CB\u94FE"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_nuxt_link = __nuxt_component_0$2;
      const _component_Login = __nuxt_component_1;
      _push(`<header${ssrRenderAttrs(mergeProps({
        class: ["shadow-xl", unref(store).showLogin ? "" : "sticky"]
      }, _attrs))} data-v-45bb422f><div class="flex px-1 md:px-6 py-4 justify-between items-center" data-v-45bb422f><div class="flex items-center" data-v-45bb422f><div class="font-black inline text-xl cursor-pointer" data-v-45bb422f><a href="/" data-v-45bb422f><img${ssrRenderAttr("src", _imports_0)} class="w-20 h-8" alt="" srcset="" data-v-45bb422f></a></div><ul class="menu ml-4 items-center hidden md:inline text-lg font-semibold pl-4" data-v-45bb422f><li class="inline mx-2 cursor-pointer select-none" data-v-45bb422f>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        exact: ""
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u9996\u9875`);
          } else {
            return [
              createTextVNode("\u9996\u9875")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><!--[-->`);
      ssrRenderList(dataList.value, (item, index) => {
        _push(`<li class="inline mx-2 cursor-pointer select-none" data-v-45bb422f>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: { name: item.link }
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(item.name)}`);
            } else {
              return [
                createTextVNode(toDisplayString(item.name), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div><div class="flex items-center" data-v-45bb422f><div class="login-group flex mx-2 lg:mx-4 custom-font-14 items-center leading-8" data-v-45bb422f><p style="${ssrRenderStyle(!loginStatus.value ? null : { display: "none" })}" class="cursor-pointer select-none mx-1 px-3 md:px-5 text-white bg-blue-500 rounded-md" data-v-45bb422f> \u767B\u5F55 </p>`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: "/user",
        style: loginStatus.value ? null : { display: "none" },
        class: "cursor-pointer select-none mx-1 px-3 md:px-5 bg-gray-100 rounded-md"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u6211\u7684 `);
          } else {
            return [
              createTextVNode(" \u6211\u7684 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
      _push(ssrRenderComponent(_component_Login, null, null, _parent));
      _push(`</header>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Toolbar.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-45bb422f"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Toolbar = __nuxt_component_0;
  const _component_NuxtChild = resolveComponent("NuxtChild");
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_Toolbar, null, null, _parent));
  _push(ssrRenderComponent(_component_NuxtChild, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default.5f6d8366.mjs.map
