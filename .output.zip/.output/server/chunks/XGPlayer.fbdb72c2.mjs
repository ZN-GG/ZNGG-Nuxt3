const _imports_0 = "" + globalThis.__publicAssetsURL("img/XGPlayer.png");

export { _imports_0 as _ };
//# sourceMappingURL=XGPlayer.fbdb72c2.mjs.map
