import { defineComponent, ref, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, u as useHead } from './server.mjs';
import { _ as __tla$2, u as useAsyncData } from './asyncData.34f60387.mjs';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __tla$3, a as api } from './api.f10a16de.mjs';
import { _ as __tla$4 } from './request.59adbae7.mjs';
import { _ as __tla$5 } from './cookie.fa7850ad.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "index",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      let categoryId = ref(0);
      const { data: navLinks, pending, refresh, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("web_NavLinks", () => api.web.getNavInfo())), __temp = await __temp, __restore(), __temp);
      if (navLinks.value.success) {
        console.log(navLinks.value);
      }
      useHead({
        title: "\u4F18\u8D28\u7F51\u5740\u5BFC\u822A",
        titleTemplate: (title) => `${title} - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u7F51\u5740\u5BFC\u822A"
          },
          {
            name: "description",
            content: "\u9AD8\u8D28\u91CF\u7F51\u5740\u5BFC\u822A"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        var _a, _b;
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "min-h-screen"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><p class="text-2xl text-black">\u4F18\u8D28\u7F51\u5740\u5BFC\u822A</p></div></div></div></section><section><div class="bg-white"><div class="container mx-auto px-4"><div class="flex py-3 space-x-4 flex-none overflow-auto"><!--[-->`);
        ssrRenderList((_a = unref(navLinks)) == null ? void 0 : _a.data, (item, index) => {
          _push(`<div class="${ssrRenderClass([
            unref(categoryId) == index ? "bg-blue-600 text-white" : "",
            "btn-2"
          ])}">${ssrInterpolate(item.name)}</div>`);
        });
        _push(`<!--]--></div></div></div><div class="container px-4 mx-auto"><div class="py-5"><ul class="w-full flex flex-wrap"><!--[-->`);
        ssrRenderList((_b = unref(navLinks)) == null ? void 0 : _b.data[unref(categoryId)].itemList, (item) => {
          _push(`<li class="w-full md:w-4/12"><div class="transition duration-300 ease-in-out p-2"><a${ssrRenderAttr("href", item.url)} target="_blank"><div class="bg-white rounded px-3 py-4 nav-item-anim"><div class="flex"><div class="w-2/12 flex items-center"><img class="w-8 h-8 mx-auto"${ssrRenderAttr("src", item.img)} alt="" srcset=""></div><div class="px-2"><div class="flex items-start"><div class="grow"><p class="text-gray-800 mb-1">${ssrInterpolate(item.title)}</p><p class="text-gray-400 text-xs">${ssrInterpolate(item.description)}</p></div></div></div></div></div></a></div></li>`);
        });
        _push(`<!--]--></ul></div></div></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/nav/index.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=index.732602f5.mjs.map
