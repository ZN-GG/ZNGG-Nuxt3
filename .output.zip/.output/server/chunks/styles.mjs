const interopDefault = r => r.default || r || [];
const styles = {
  "pages/index.vue": () => import('./index-styles.db5db422.mjs').then(interopDefault),
  "pages/read/index.vue": () => import('./index-styles.34e0185f.mjs').then(interopDefault),
  "pages/read/post/[id].vue": () => import('./_id_-styles.9082be73.mjs').then(interopDefault),
  "pages/tool/detail/FancyBorderRadius.vue": () => import('./FancyBorderRadius-styles.9f557d8d.mjs').then(interopDefault),
  "pages/tool/detail/M3U8V2Pro.vue": () => import('./M3U8V2Pro-styles.0de2770a.mjs').then(interopDefault),
  "pages/tool/detail/FlvPlayer.vue": () => import('./FlvPlayer-styles.77345c29.mjs').then(interopDefault),
  "pages/tool/detail/NationalDayAvatar.vue": () => import('./NationalDayAvatar-styles.67186513.mjs').then(interopDefault),
  "pages/tool/detail/MakePhrase.vue": () => import('./MakePhrase-styles.f5d5d445.mjs').then(interopDefault),
  "pages/tool/detail/NPlayer.vue": () => import('./NPlayer-styles.eceed04a.mjs').then(interopDefault),
  "pages/tool/detail/TextSecret.vue": () => import('./TextSecret-styles.def1b289.mjs').then(interopDefault),
  "pages/tool/detail/WordToPDF.vue": () => import('./WordToPDF-styles.775fec8e.mjs').then(interopDefault),
  "pages/tool/detail/Whois.vue": () => import('./Whois-styles.8dcdc973.mjs').then(interopDefault),
  "pages/tool/detail/office/[type].vue": () => import('./_type_-styles.173eea4a.mjs').then(interopDefault),
  "pages/tool/detail/WeiBoGenerates.vue": () => import('./WeiBoGenerates-styles.570bbd90.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./error-404-styles.43414ea3.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./error-500-styles.4087d4fb.mjs').then(interopDefault),
  "pages/writer.vue": () => import('./writer-styles.d0537891.mjs').then(interopDefault),
  "app.vue?vue&type=script&setup=true&lang.ts": () => import('./app.vue_vue_type_script_setup_true_lang-styles.b56b15b3.mjs').then(interopDefault),
  "pages/read/post/[id].vue?vue&type=script&setup=true&lang.ts": () => import('./_id_.vue_vue_type_script_setup_true_lang-styles.036c6780.mjs').then(interopDefault),
  "pages/writer.vue?vue&type=script&setup=true&lang.ts": () => import('./_id_.vue_vue_type_script_setup_true_lang-styles.036c6780.mjs').then(interopDefault),
  "components/user/LeftContents.vue": () => import('./LeftContents-styles.83af4ea7.mjs').then(interopDefault),
  "components/Toolbar.vue": () => import('./Toolbar-styles.a6fe5559.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
