const Login_vue_vue_type_style_index_0_scoped_d5e1abea_lang = ".modal-show[data-v-d5e1abea]{-webkit-backdrop-filter:saturate(180%) blur(25px);backdrop-filter:saturate(180%) blur(25px);background:rgba(0,0,0,.35)}";

const LoginStyles_bd62ca11 = [Login_vue_vue_type_style_index_0_scoped_d5e1abea_lang];

export { LoginStyles_bd62ca11 as default };
//# sourceMappingURL=Login-styles.bd62ca11.mjs.map
