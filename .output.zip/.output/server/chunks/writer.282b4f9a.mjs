import { __tla as __tla$1, g as useRoute, a as useNuxtApp, u as useHead } from './server.mjs';
import { defineComponent, withAsyncContext, ref, mergeProps, unref, useSSRContext } from 'vue';
import { _ as __tla$2, u as useAsyncData } from './asyncData.2f4be010.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as __tla$3, a as api } from './api.aab2ee7f.mjs';
import { _ as __tla$4 } from './request.9cdeab30.mjs';
import { _ as __tla$5 } from './cookie.20b5dbf0.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  const bold = "\u7C97\u4F53";
  const boldText = "\u7C97\u4F53\u6587\u672C";
  const cheatsheet = "Markdown \u8BED\u6CD5";
  const closeHelp = "\u5173\u95ED\u5E2E\u52A9";
  const closeToc = "\u5173\u95ED\u76EE\u5F55";
  const code = "\u4EE3\u7801";
  const codeBlock = "\u4EE3\u7801\u5757";
  const codeLang = "\u7F16\u7A0B\u8BED\u8A00";
  const codeText = "\u4EE3\u7801";
  const exitFullscreen = "\u9000\u51FA\u5168\u5C4F";
  const exitPreviewOnly = "\u6062\u590D\u9ED8\u8BA4";
  const exitWriteOnly = "\u6062\u590D\u9ED8\u8BA4";
  const fullscreen = "\u5168\u5C4F";
  const h1 = "\u4E00\u7EA7\u6807\u9898";
  const h2 = "\u4E8C\u7EA7\u6807\u9898";
  const h3 = "\u4E09\u7EA7\u6807\u9898";
  const h4 = "\u56DB\u7EA7\u6807\u9898";
  const h5 = "\u4E94\u7EA7\u6807\u9898";
  const h6 = "\u516D\u7EA7\u6807\u9898";
  const headingText = "\u6807\u9898";
  const help = "\u5E2E\u52A9";
  const hr = "\u5206\u5272\u7EBF";
  const image = "\u56FE\u7247";
  const imageAlt = "alt";
  const imageTitle = "\u56FE\u7247\u63CF\u8FF0";
  const italic = "\u659C\u4F53";
  const italicText = "\u659C\u4F53\u6587\u672C";
  const limited = "\u5DF2\u8FBE\u6700\u5927\u5B57\u7B26\u6570\u9650\u5236";
  const lines = "\u884C\u6570";
  const link = "\u94FE\u63A5";
  const linkText = "\u94FE\u63A5\u63CF\u8FF0";
  const ol = "\u6709\u5E8F\u5217\u8868";
  const olItem = "\u9879\u76EE";
  const preview = "\u9884\u89C8";
  const previewOnly = "\u4EC5\u9884\u89C8\u533A";
  const quote = "\u5F15\u7528";
  const quotedText = "\u5F15\u7528\u6587\u672C";
  const shortcuts = "\u5FEB\u6377\u952E";
  const source = "\u6E90\u4EE3\u7801";
  const sync = "\u540C\u6B65\u6EDA\u52A8";
  const toc = "\u76EE\u5F55";
  const top = "\u56DE\u5230\u9876\u90E8";
  const ul = "\u65E0\u5E8F\u5217\u8868";
  const ulItem = "\u9879\u76EE";
  const words = "\u5B57\u6570";
  const write = "\u7F16\u8F91";
  const writeOnly = "\u4EC5\u7F16\u8F91\u533A";
  const zhHans = {
    bold,
    boldText,
    cheatsheet,
    closeHelp,
    closeToc,
    code,
    codeBlock,
    codeLang,
    codeText,
    exitFullscreen,
    exitPreviewOnly,
    exitWriteOnly,
    fullscreen,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    headingText,
    help,
    hr,
    image,
    imageAlt,
    imageTitle,
    italic,
    italicText,
    limited,
    lines,
    link,
    linkText,
    ol,
    olItem,
    preview,
    previewOnly,
    quote,
    quotedText,
    shortcuts,
    source,
    sync,
    toc,
    top,
    ul,
    ulItem,
    words,
    write,
    writeOnly
  };
  _sfc_main = defineComponent({
    __name: "writer",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      const { Editor } = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/vue-next').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp);
      const breaks = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-breaks').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const gemoji = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-gemoji').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const gfm = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-gfm').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const highlight = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-highlight').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const math = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-math-ssr').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const medium = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-medium-zoom').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const mermaid = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-mermaid').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const frontmatter = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-frontmatter').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const themes = ([__temp, __restore] = withAsyncContext(() => import('./theme.a19ed3dc.mjs')), __temp = await __temp, __restore(), __temp).themes;
      const route = useRoute();
      useNuxtApp();
      const categoryList = ref([]);
      const article = ref({
        id: "",
        title: "",
        category_id: "",
        image: "",
        content: "",
        type: 1,
        summary: "",
        labels: ""
      });
      const edit = ref(false);
      const relaseCardShow = ref(false);
      const plugins = [
        breaks(),
        frontmatter(),
        {
          viewerEffect({ file }) {
            var _a, _b;
            if (typeof file.value != "string") {
              return;
            }
            const $style = document.createElement("style");
            try {
              $style.innerHTML = (_b = (_a = themes[file.frontmatter.theme]) == null ? void 0 : _a.style) != null ? _b : themes.juejin.style;
            } catch (e) {
              $style.innerHTML = themes.juejin.style;
            }
            document.head.appendChild($style);
            return () => {
              $style.remove();
            };
          }
        },
        gemoji(),
        gfm(),
        highlight(),
        math(),
        medium(),
        mermaid()
      ];
      if (route.query.id) {
        const { data: articleData, pending, refresh, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("editor_Detail", () => api.article.getDetail(route.query.id.toString()))), __temp = await __temp, __restore(), __temp);
        if (articleData.value.success) {
          article.value.id = articleData.value.data.id;
          article.value.title = articleData.value.data.title;
          article.value.category_id = articleData.value.data.category_id;
          article.value.image = articleData.value.data.image;
          article.value.content = articleData.value.data.content;
          article.value.type = articleData.value.data.type;
          article.value.summary = articleData.value.data.summary;
          article.value.labels = articleData.value.data.labels;
          edit.value = true;
        }
      } else {
        edit.value = false;
      }
      useHead({
        title: "\u5199\u4F5C",
        titleTemplate: (title) => `${title} - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u524D\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u540E\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u5728\u7EBF\u5C0F\u5DE5\u5177\uFF0C\u8BBE\u8BA1\u6280\u5DE7"
          },
          {
            name: "description",
            content: "ZNGG\u5728\u7EBF\u5DE5\u5177\u662F\u4E00\u4E2A\u6301\u7EED\u63D0\u4F9B\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA\u5E73\u53F0\uFF0C\u5E76\u5C06\u8F93\u51FA\u5185\u5BB9\u8F6C\u53D8\u4E3A\u6210\u679C\uFF0C\u63D0\u4F9B\u5404\u79CD\u5404\u6837\u7684\u5728\u7EBF\u5DE5\u5177\u3002"
          }
        ],
        link: [
          {
            rel: "stylesheet",
            href: "/fonts/katex.min.css"
          },
          {
            rel: "stylesheet",
            href: "/css/bytemd.css"
          }
        ],
        style: [
          {
            children: ".bytemd { height: calc(100vh - 4rem); }"
          }
        ]
      });
      let categoryResult = ([__temp, __restore] = withAsyncContext(() => api.article.getCategories()), __temp = await __temp, __restore(), __temp);
      categoryList.value = categoryResult.data;
      function handleChange(v) {
        article.value.content = v;
      }
      async function uploadImage(file) {
        const formData = new FormData();
        formData.append("file", file[0]);
        const result = await api.upload.uploadImage(formData);
        console.log(result);
        return [
          {
            title: result.message,
            url: "https://cdn.zngg.net/upload/image/" + result.message
          }
        ];
      }
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "w-full bg-slate-50 h-screen relative"
        }, _attrs))}><div style="${ssrRenderStyle(unref(relaseCardShow) ? null : {
          display: "none"
        })}" class="relaseCard w-screen h-screen fixed t-0 l-0 z-40"><div class="flex items-center h-screen"><div class="card bg-white mx-auto px-4 border-2"><div><p class="text-xl font-bold my-4">\u53D1\u5E03\u6587\u7AE0</p></div><hr><div class="flex my-4"><div class="w-20 text-right mr-3"><span class="text-red-500">*</span> \u5206\u7C7B: </div><ul class="flex-1"><!--[-->`);
        ssrRenderList(unref(categoryList), (item, index) => {
          _push(`<li class="${ssrRenderClass([
            item.id == unref(article).category_id ? "text-blue-500 bg-blue-100" : "",
            "inline-block mr-2 mb-3 px-2 bg-slate-100 text-gray-400 cursor-pointer w-24 h-7 text-center leading-7 custom-font-14 whitespace-nowrap"
          ])}">${ssrInterpolate(item.name)}</li>`);
        });
        _push(`<!--]--></ul></div><div class="flex my-4"><div class="w-20 text-right mr-3"> \u5C01\u9762: </div><div class="relative w-20 h-10 cursor-pointer overflow-hidden"><button class="w-20 h-10 bg-blue-400 text-white rounded">\u4E0A\u4F20\u56FE\u7247</button><input class="w-20 h-20 absolute cursor-pointer opacity-90 bottom-0 left-0" type="file" id="file" multiple></div><img class="w-32 h-16 mx-4" style="${ssrRenderStyle(unref(article).image.length > 0 ? null : {
          display: "none"
        })}"${ssrRenderAttr("src", unref(article).image)}></div><div class="flex my-4"><div class="w-20 text-right mr-3"><span class="text-red-500">*</span> \u6458\u8981: </div><textarea class="w-64 h-16 border-2 outline-none p-2">${ssrInterpolate(unref(article).summary)}</textarea></div><hr><div class="flex justify-end"><button class="mx-1 px-4 custom-text-14 py-1 my-4 border-2 border-blue-400 text-blue-400 rounded">\u53D6\u6D88</button><button class="mx-1 px-4 custom-text-14 py-1 my-4 bg-blue-400 text-white rounded">\u53D1\u5E03</button></div></div></div></div><div class="flex border-solid border-b-2 px-4 bg-white py-3 items-center h-16"><input${ssrRenderAttr("value", unref(article).title)} class="flex-1 border-none outline-none text-2xl py-2 px-6 font-bold" type="text" placeholder="\u8F93\u5165\u6587\u7AE0\u6807\u9898..."><button class="btn-normal bg-blue-500 px-5 mx-4 h-9">\u53D1\u5E03</button></div><div>`);
        _push(ssrRenderComponent(unref(Editor), {
          locale: unref(zhHans),
          uploadImages: uploadImage,
          value: unref(article).content,
          plugins,
          onChange: handleChange
        }, null, _parent));
        _push(`</div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/writer.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=writer.282b4f9a.mjs.map
