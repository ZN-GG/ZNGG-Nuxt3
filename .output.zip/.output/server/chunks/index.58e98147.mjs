import { __tla as __tla$1, u as useHead, _ as __nuxt_component_0$2 } from './server.mjs';
import { defineComponent, ref, withAsyncContext, onUnmounted, mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useAsyncData } from './asyncData.946db191.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderStyle, ssrRenderList, ssrInterpolate, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0 } from './ScreenRecAD.16518c41.mjs';
import { _ as _imports_1 } from './NplayerAD.f0b8259d.mjs';
import { a as api } from './api.63550e4b.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "index",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      let isShowCategory = ref(true);
      let rightFixedContainerWidth = ref("100%");
      let loading = ref(false);
      let empty = ref(false);
      let page = ref(2);
      ref(10);
      let categoryId = ref("");
      const articleParams = ref("");
      let articleList = ref([]);
      let categoryList = ref([]);
      let rightNormalContainer = ref(null);
      let rightFixedContainer = ref(null);
      let categoryResult = ([__temp, __restore] = withAsyncContext(() => api.article.getCategories()), __temp = await __temp, __restore(), __temp);
      categoryList.value = categoryResult.data;
      const { data: articleData, pending, refresh, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("read_GetList", () => api.article.getList(1, 10, articleParams.value))), __temp = await __temp, __restore(), __temp);
      if (articleData.value.success) {
        articleList.value = articleList.value.concat(articleData.value.data.content);
      }
      onUnmounted(() => {
        window.removeEventListener("scroll", handleScroll);
      });
      function setFloatContainer() {
        if (rightNormalContainer.value.getBoundingClientRect().bottom <= 0) {
          rightFixedContainer.value.style.position = "fixed";
          rightFixedContainer.value.style.top = "0.5rem";
          rightFixedContainerWidth.value = rightNormalContainer.value.offsetWidth + "px";
        } else if (rightNormalContainer.value.getBoundingClientRect().bottom > 0) {
          rightFixedContainerWidth.value = "100%";
          rightFixedContainer.value.style.top = "";
          rightFixedContainer.value.style.position = "absolute";
        }
      }
      function handleScroll() {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
        if (scrollTop > 20) {
          setFloatContainer();
        }
        let documentHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
        if (documentHeight - scrollTop - window.innerHeight < 60 && !empty.value) {
          loadMore();
        }
      }
      async function loadMore() {
        if (loading.value) {
          return;
        }
        loading.value = true;
        const result = await api.article.getList(page.value, 10, null);
        if (result.success) {
          if (result.data.content.length == 0) {
            empty.value = true;
          }
          articleList.value = articleList.value.concat(result.data.content);
          page.value = page.value + 1;
        }
        loading.value = false;
      }
      useHead({
        title: "\u6587\u7AE0",
        titleTemplate: (title) => `${title} - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        viewport: "width=device-width, initial-scale=1, maximum-scale=1",
        charset: "utf-8",
        meta: [
          {
            name: "Keywords",
            content: "ZNGG\u5728\u7EBF\u5DE5\u5177\u6587\u7AE0,IT\u6587\u7AE0\u5206\u4EAB,\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA,\u9AD8\u8D28\u91CF\u6587\u7AE0\u5206\u4EAB"
          },
          {
            name: "description",
            content: "ZNGG\u5728\u7EBF\u5DE5\u5177\u662F\u4E00\u4E2A\u6301\u7EED\u63D0\u4F9B\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA\u5E73\u53F0\uFF0C\u5E76\u5C06\u8F93\u51FA\u5185\u5BB9\u8F6C\u53D8\u4E3A\u6210\u679C\uFF0C\u63D0\u4F9B\u5404\u79CD\u5404\u6837\u7684\u5728\u7EBF\u5DE5\u5177\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        const _component_nuxt_link = __nuxt_component_0$2;
        _push(`<div${ssrRenderAttrs(mergeProps({
          ref: "html"
        }, _attrs))}><div class="mx-auto container my-8"><div class="flex flex-wrap relative"><div class="bg-white p-6 rounded-md mt-4 w-full lg:w-8/12"><div class="flex justify-between items-center"><div class="flex items-center"><p class="font-semibold text-2xl">\u6700\u65B0\u6587\u7AE0</p></div><div><div class="relative bg-gray-100 px-3 cursor-pointer rounded-md"><span class="custom-font-14 leading-8 relative inline select-none">\u5206\u7C7B <span class="${ssrRenderClass([
          unref(isShowCategory) ? "reverse" : "",
          "iconfont icon-arrow-down inline-block"
        ])}"></span></span></div></div></div><div style="${ssrRenderStyle(unref(isShowCategory) ? null : {
          display: "none"
        })}" class="${ssrRenderClass([
          unref(isShowCategory) ? "" : "hidden",
          "flex py-3 space-x-4 flex-none overflow-auto"
        ])}"><div class="${ssrRenderClass([
          unref(categoryId) == "" ? "bg-blue-600 text-white" : "",
          "btn-2"
        ])}">\u5168\u90E8</div><!--[-->`);
        ssrRenderList(unref(categoryList), (item, index) => {
          _push(`<div class="${ssrRenderClass([
            unref(categoryId) == item.id ? "bg-blue-600 text-white" : "",
            "btn-2"
          ])}">${ssrInterpolate(item.name)}</div>`);
        });
        _push(`<!--]--></div><ul><!--[-->`);
        ssrRenderList(unref(articleList), (item, index) => {
          _push(`<li class="mt-4"><div class="border-b pb-2"><div class="flex relative"><div class="flex-1 mr-2">`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            target: "_blank",
            to: "/read/post/" + item.id
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<p class="font-semibold text-base h-8 leading-8 w-full overflow-y-hidden"${_scopeId}>${ssrInterpolate(item.title)}</p>`);
              } else {
                return [
                  createVNode("p", {
                    class: "font-semibold text-base h-8 leading-8 w-full overflow-y-hidden",
                    textContent: toDisplayString(item.title)
                  }, null, 8, [
                    "textContent"
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<p class="custom-font-14 leading-8 overflow-hidden h-6 text-gray-400 mb-2">${ssrInterpolate(item.summary)}</p><ul class="flex items-center mt-6"><li class="flex items-center leading-4"><span class="flex items-center iconfont icon-browse"></span><span class="custom-font-12 ml-1">${ssrInterpolate(item.viewCount)}</span></li></ul></div>`);
          if (item.image != "") {
            _push(`<img class="w-32 h-24 right-0 object-contain"${ssrRenderAttr("src", item.image)} alt="" srcset="">`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div></li>`);
        });
        _push(`<!--]--><li style="${ssrRenderStyle(unref(empty) ? null : {
          display: "none"
        })}" class="mt-4 text-center"><p>\u5230\u5E95\u4E86</p></li><div style="${ssrRenderStyle(unref(loading) ? null : {
          display: "none"
        })}" class="w-full animate-pulse"><div class="flex items-center mb-6"><div class="w-8/12"><div class="w-10/12 h-6 bg-gray-200 my-3"></div><div class="w-10/12 h-6 bg-gray-200 my-3"></div></div><div class="flex-1 bg-gray-200 w-2/12 md:w-1/12 h-16"></div></div><div class="flex items-center mb-6"><div class="w-8/12"><div class="w-10/12 h-6 bg-gray-200 my-3"></div><div class="w-10/12 h-6 bg-gray-200 my-3"></div></div><div class="flex-1 bg-gray-200 w-2/12 md:w-1/12 h-16"></div></div></div></ul></div><div class="mt-4 hidden lg:block w-full lg:w-4/12 absolute right-0"><div class="pl-6 w-full">`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/tool/detail/ScreenRec"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="" srcset=""${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_0,
                  alt: "",
                  srcset: ""
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/tool/detail/Nplayer",
          class: "block mt-4"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_1)} alt="" srcset=""${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_1,
                  alt: "",
                  srcset: ""
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div style="${ssrRenderStyle({
          width: unref(rightFixedContainerWidth)
        })}" class="h-20 pl-6 my-4 hidden lg:block w-full"><div class="bg-white rounded-md p-6"><div class="flex justify-between items-center"><div class="flex items-center"><p class="font-semibold text-2xl">AD</p><p class="hidden lg:inline leading-8 mx-4 text-sm text-gray-400"> \u5E7F\u800C\u544A\u4E4B </p></div><div><div class="btn-1">\u66F4\u591A</div></div></div></div></div></div></div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/read/index.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=index.58e98147.mjs.map
