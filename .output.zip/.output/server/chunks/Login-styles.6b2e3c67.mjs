const Login_vue_vue_type_style_index_0_scoped_2723d8f5_lang = ".modal-show[data-v-2723d8f5]{-webkit-backdrop-filter:saturate(180%) blur(25px);backdrop-filter:saturate(180%) blur(25px);background:rgba(0,0,0,.35)}";

const LoginStyles_6b2e3c67 = [Login_vue_vue_type_style_index_0_scoped_2723d8f5_lang];

export { LoginStyles_6b2e3c67 as default };
//# sourceMappingURL=Login-styles.6b2e3c67.mjs.map
