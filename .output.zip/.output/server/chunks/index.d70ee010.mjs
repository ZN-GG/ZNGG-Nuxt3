import { __tla as __tla$1, u as useHead, _ as __nuxt_component_0$1 } from './server.mjs';
import { defineComponent, ref, withAsyncContext, mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { _ as __tla$2, u as useAsyncData } from './asyncData.d5c4eb01.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrRenderComponent, ssrRenderStyle } from 'vue/server-renderer';
import { _ as __tla$3, a as api } from './api.f68e58d2.mjs';
import { _ as __tla$4 } from './request.90647c95.mjs';
import { _ as __tla$5 } from './cookie.c979c833.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "index",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      let loading = ref(false);
      ref(false);
      ref(2);
      let categoryId = ref("");
      let toolCategoryList = ref([]);
      let toolCategoryResult = ([__temp, __restore] = withAsyncContext(() => api.tool.getCategories()), __temp = await __temp, __restore(), __temp);
      toolCategoryList.value = toolCategoryResult.data;
      const toolParams = ref("");
      const toolList = ref([]);
      const { data: toolData, pending: toolPending, refresh: ToolRefresh, error: toolError } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("tool_GetToolList", () => api.tool.getList(1, 24, toolParams.value))), __temp = await __temp, __restore(), __temp);
      if (toolData.value.success) {
        toolList.value = toolList.value.concat(toolData.value.data.content);
      }
      useHead({
        title: "\u5DE5\u5177",
        titleTemplate: (title) => `${title} - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "ZNGG\u5728\u7EBF\u5DE5\u5177,\u65F6\u95F4\u6233\u5DE5\u5177,\u5728\u7EBF\u8F6C\u6362\u5DE5\u5177,Json\u5728\u7EBF\u89E3\u6790\u683C\u5F0F\u5316"
          },
          {
            name: "description",
            content: "ZNGG\u5728\u7EBF\u5DE5\u5177\u662F\u4E00\u4E2A\u6301\u7EED\u63D0\u4F9B\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA\u5E73\u53F0\uFF0C\u5E76\u5C06\u8F93\u51FA\u5185\u5BB9\u8F6C\u53D8\u4E3A\u6210\u679C\uFF0C\u63D0\u4F9B\u5404\u79CD\u5404\u6837\u7684\u5728\u7EBF\u5DE5\u5177\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        const _component_NuxtLink = __nuxt_component_0$1;
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "mx-auto container px-4 my-8 min-h-screen mt-20"
        }, _attrs))}><div class="bg-white p-6 rounded-md mt-8 mb-4"><div class="flex justify-between items-center"><div class="flex items-center"><p class="font-semibold text-2xl">\u5728\u7EBF\u5DE5\u5177</p></div><div class="flex"><div class="hidden md:flex"><div class="${ssrRenderClass([
          unref(categoryId) == "" ? "bg-blue-600 text-white" : "",
          "btn-1"
        ])}"> \u5168\u90E8 </div><!--[-->`);
        ssrRenderList(unref(toolCategoryList), (item, index) => {
          _push(`<div class="${ssrRenderClass([
            unref(categoryId) == item.id ? "bg-blue-600 text-white" : "",
            "btn-1"
          ])}">${ssrInterpolate(item.name)}</div>`);
        });
        _push(`<!--]--></div></div></div></div><div class="w-full flex flex-wrap justify-between"><!--[-->`);
        ssrRenderList(unref(toolList), (item, index) => {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: "/tool/detail/" + item.content,
            key: index,
            target: "_blank",
            class: [
              "w-4/12 md:w-2/12 flex mb-4",
              [
                (index + 6) % 6 == 0 ? "md:pr-1 md:pl-0" : "",
                (index + 1) % 6 == 0 ? "md:pl-1 md:pr-0" : "",
                (index + 7) % 6 != 0 && (index + 1) % 6 != 0 ? "md:px-1" : "",
                (index + 2) % 3 == 0 ? "px-1" : "",
                (index + 3) % 3 == 0 ? "pr-2" : "",
                (index + 1) % 3 == 0 ? "pl-2" : ""
              ]
            ]
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="w-full relative tool-border"${_scopeId}><div class="tool-box absolute"${_scopeId}><div class="tool-icon" style="${ssrRenderStyle("background-image: url(/img/" + item.image + ");")}"${_scopeId}></div><p class="tool-title"${_scopeId}>${ssrInterpolate(item.title)}</p><p class="tool-des"${_scopeId}>${ssrInterpolate(item.summary)}</p></div></div>`);
              } else {
                return [
                  createVNode("div", {
                    class: "w-full relative tool-border"
                  }, [
                    createVNode("div", {
                      class: "tool-box absolute"
                    }, [
                      createVNode("div", {
                        class: "tool-icon",
                        style: "background-image: url(/img/" + item.image + ");"
                      }, null, 4),
                      createVNode("p", {
                        class: "tool-title",
                        textContent: toDisplayString(item.title)
                      }, null, 8, [
                        "textContent"
                      ]),
                      createVNode("p", {
                        class: "tool-des",
                        textContent: toDisplayString(item.summary)
                      }, null, 8, [
                        "textContent"
                      ])
                    ])
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
        });
        _push(`<!--]--><!--[-->`);
        ssrRenderList(11, (item) => {
          _push(`<div class="w-4/12 md:w-2/12"></div>`);
        });
        _push(`<!--]--></div><div style="${ssrRenderStyle(unref(loading) ? null : {
          display: "none"
        })}" class="w-full flex flex-wrap justify-between"><!--[-->`);
        ssrRenderList(4, (item, index) => {
          _push(`<div class="${ssrRenderClass([
            [
              (item + 5) % 6 == 0 ? "md:pr-1 md:pl-0" : "",
              item % 6 == 0 ? "md:pl-1 md:pr-0" : "",
              (item + 6) % 6 != 0 && item % 6 != 0 ? "md:px-1" : "",
              (item + 1) % 3 == 0 ? "px-1" : "",
              (item + 2) % 3 == 0 ? "pr-2" : "",
              item % 3 == 0 ? "pl-2" : ""
            ],
            "w-4/12 md:w-2/12 flex mb-4 animate-pulse"
          ])}"><div class="w-full relative tool-border"><div class="tool-box absolute"><div class="tool-icon bg-gray-200"></div><p class="tool-title bg-gray-200 h-4 w-6/12"></p><p class="tool-title bg-gray-200 h-4 w-6/12"></p></div></div></div>`);
        });
        _push(`<!--]--><!--[-->`);
        ssrRenderList(2, (item) => {
          _push(`<div class="w-4/12 md:w-2/12"></div>`);
        });
        _push(`<!--]--></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/index.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=index.d70ee010.mjs.map
