import { _ as __tla$1, a as _sfc_main } from './Adsbygoogle.337d5551.mjs';
import { __tla as __tla$2, a as useNuxtApp, u as useHead } from './server.mjs';
import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let CssGlassGenerates;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main$1 = defineComponent({
    __name: "CssGlassGenerates",
    __ssrInlineRender: true,
    setup(__props) {
      useNuxtApp();
      const BoxWidth = ref(420);
      const BoxAlpha = ref(0.2);
      const BoxRadius = ref(12);
      const BoxBlur = ref(6);
      ref();
      useHead({
        title: "CSS\u6BDB\u73BB\u7483\u6548\u679C",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u5728\u7EBF\u751F\u6210CSS\u6BDB\u73BB\u7483\u6548\u679C,\u5728\u7EBF\u751F\u6210CSS\u73BB\u7483\u5F62\u6001,\u82F9\u679C\u6BDB\u73BB\u7483\u6548\u679C\u5236\u4F5C"
          },
          {
            name: "description",
            content: "\u53EF\u4EE5\u5E2E\u52A9\u60A8\u8F7B\u677E\u751F\u6210\u5404\u79CDCSS\u6BDB\u73BB\u7483\u6548\u679C\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        const _component_adsbygoogle = _sfc_main;
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white min-h-screen"
        }, _attrs))} data-v-7260645e><section class="bg-gray-100" data-v-7260645e><div class="container px-4 mx-auto" data-v-7260645e><div class="md:flex md:-mx-4 md:items-center py-8" data-v-7260645e><div class="md:w-1/2 px-4" data-v-7260645e><h1 class="text-2xl text-black" data-v-7260645e>CSS\u6BDB\u73BB\u7483\u6548\u679C</h1></div></div></div></section><section class="my-4" data-v-7260645e><div class="w-full container px-4 mx-auto" data-v-7260645e><div class="w-full flex flex-wrap md:flex-nowrap" data-v-7260645e><div class="w-full md:w-64" data-v-7260645e><div class="px-4" data-v-7260645e><div class="my-4 md:my-12" data-v-7260645e><p data-v-7260645e>\u5BBD\u5EA6</p><input class="w-full" id="sub-size" type="range" min="260" max="500"${ssrRenderAttr("value", unref(BoxWidth))} step="10" data-v-7260645e></div><div class="my-4 md:my-12" data-v-7260645e><p data-v-7260645e>\u5706\u89D2</p><input class="w-full" id="sub-size" type="range" min="0" max="25"${ssrRenderAttr("value", unref(BoxRadius))} data-v-7260645e></div><div class="my-4 md:my-12" data-v-7260645e><p data-v-7260645e>\u6A21\u7CCA\u7A0B\u5EA6</p><input class="w-full" id="sub-size" type="range" min="0.0" max="30.0"${ssrRenderAttr("value", unref(BoxBlur))} step="0.5" data-v-7260645e></div><div class="my-4 md:my-12" data-v-7260645e><p data-v-7260645e>\u900F\u660E\u5EA6</p><input class="w-full" id="sub-size" type="range" min="0.05" max="0.60"${ssrRenderAttr("value", unref(BoxAlpha))} step="0.05" data-v-7260645e></div></div></div><div class="w-full h-auto flex justify-center items-center flex-row demo-bg mt-8 md:mt-0" data-v-7260645e><div id="circle-org" class="w-20 h-20 md:w-52 md:h-52 rounded-full" data-v-7260645e></div><div id="subject-div" class="glass glass-light" style="${ssrRenderStyle("height:120px; width:" + unref(BoxWidth) + "px;background-color: rgba(255, 255, 255, " + unref(BoxAlpha) + ");border-radius: " + unref(BoxRadius) + "px;backdrop-filter: blur(" + unref(BoxBlur) + "px);")}" data-v-7260645e></div><div id="circle-blue" data-v-7260645e></div></div></div></div></section><section class="w-full container px-4 mx-auto" data-v-7260645e><div class="panel-code" data-v-7260645e><div class="row" data-v-7260645e><div class="col-xs-24 col-md-24" data-v-7260645e><section class="code-editor" data-v-7260645e><div class="code-editor__column" data-v-7260645e><div class="code-editor__column-tabs" data-v-7260645e></div><div class="code-editor__column-numbers" data-v-7260645e>1<br data-v-7260645e>2<br data-v-7260645e>3<br data-v-7260645e>4<br data-v-7260645e>5<br data-v-7260645e>6<br data-v-7260645e></div></div><div class="code-editor__block" data-v-7260645e><div class="code-editor__tabs" data-v-7260645e><div class="code-editor__tab is-active" data-v-7260645e> CSS </div><div class="code-editor__compat" data-v-7260645e><label data-v-7260645e><input type="checkbox" class="js-compat" data-v-7260645e><div class="compat__text" data-v-7260645e> Max Compatibility <span data-v-7260645e>(IE6+)</span></div><div class="compat__checkbox" data-v-7260645e></div></label></div></div><div class="code-editor__input" data-v-7260645e><code class="code-editor__input-code js-code" id="code" data-v-7260645e><span class="blue" data-v-7260645e>backdrop-filter</span>: ${ssrInterpolate(unref(BoxRadius))}px;<br data-v-7260645e><span class="blue" data-v-7260645e>border-radius</span>: blur(${ssrInterpolate(unref(BoxBlur))}px);<br data-v-7260645e><span class="blue" data-v-7260645e>background-color</span>: rgba(255, 255, 255, ${ssrInterpolate(unref(BoxAlpha))});<br data-v-7260645e></code></div></div></section><section class="code-options" data-v-7260645e><button class="code-option__button js-copy" data-v-7260645e><div class="code-option__button-bg js-button-copy" style="${ssrRenderStyle({
          "background-image": "linear-gradient(135deg, #ffb566, #ff6677)"
        })}" data-v-7260645e></div><svg class="code-option__button-svg" width="13" height="17" xmlns="http://www.w3.org/2000/svg" data-v-7260645e><g stroke="#ffffff" stroke-width="2" fill="none" fill-rule="evenodd" data-v-7260645e><path d="M5 5h7v11H5z" data-v-7260645e></path><path d="M1 15V1h10" data-v-7260645e></path></g></svg> <span data-v-7260645e>Copy to Clipboard</span></button></section></div></div></div></section><section class="w-full container px-4 mx-auto mt-4" data-v-7260645e>`);
        _push(ssrRenderComponent(_component_adsbygoogle, null, null, _parent));
        _push(`</section><section class="bg-white w-full container mx-auto px-4 py-6" data-v-7260645e><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}" data-v-7260645e><h4 data-v-7260645e>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote data-v-7260645e><p data-v-7260645e>\u6B64\u5DE5\u5177\u7528\u4E8E\u65B9\u4FBF\u8C03\u8BD5CSS\u900F\u660E\u6A21\u7CCA\u80CC\u666F\u6548\u679C\uFF0C\u4E5F\u5C31\u662F\u4FD7\u79F0\u7684\u6BDB\u73BB\u7483\u6548\u679C\u3002</p></blockquote><ul data-v-7260645e><li data-v-7260645e>\u5DE5\u5177\u6709\u4E9B\u7B80\u5355\uFF0C\u8FD8\u4E0D\u591F\u5B8C\u5584...</li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main$1.setup;
  _sfc_main$1.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/CssGlassGenerates.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  CssGlassGenerates = _export_sfc(_sfc_main$1, [
    [
      "__scopeId",
      "data-v-7260645e"
    ]
  ]);
});

export { __tla, CssGlassGenerates as default };
//# sourceMappingURL=CssGlassGenerates.33d0f271.mjs.map
