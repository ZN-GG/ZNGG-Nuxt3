import { __tla as __tla$1 } from './server.mjs';
import { defineComponent, withAsyncContext, unref, useSSRContext } from 'vue';
import { _ as __tla$2, u as useAsyncData } from './asyncData.ab62c6e1.mjs';
import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __tla$3, a as api } from './api.931bc788.mjs';
import { _ as __tla$4 } from './request.c91d7a00.mjs';
import { _ as __tla$5 } from './cookie.bd9fc59c.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "info",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      const { data: userInfo, pending: infoPending, refresh: infoRefresh, error: infoError } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("info_GetUserInfo", () => api.user.getInfo())), __temp = await __temp, __restore(), __temp);
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(_attrs)}><div class="my-6 flex justify-between items-center"><p class="font-bold text-2xl">\u4E2A\u4EBA\u4FE1\u606F</p></div>`);
        if (unref(userInfo).success) {
          _push(`<div><img${ssrRenderAttr("src", unref(userInfo).data.avatar)} class="w-12 h-12 rounded-full border-spacing-1"></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index/info.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=info.495f449f.mjs.map
