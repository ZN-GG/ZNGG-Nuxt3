import { g as defineNuxtRouteMiddleware, b as useCookie, h as userStore, n as navigateTo } from './server.mjs';
import { a as api } from './api.c0ba017b.mjs';
import 'vue';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'vue/server-renderer';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const auth = defineNuxtRouteMiddleware((to, from) => {
  const token = useCookie("token");
  const store = userStore();
  if (typeof token.value == "undefined") {
    return navigateTo("/");
  }
  api.user.getInfo().then((info) => {
    if (!info.success) {
      store.$patch({
        isLogin: !store.isLogin
      });
      store.$patch({
        isLogin: false
      });
      token.value = void 0;
      store.$patch({
        showLogin: true
      });
      navigateTo("/");
    }
  });
});

export { auth as default };
//# sourceMappingURL=auth.bbaba7cd.mjs.map
