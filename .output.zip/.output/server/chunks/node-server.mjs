globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'http';
import { Server } from 'https';
import destr from 'destr';
import { defineEventHandler, handleCacheHeaders, createEvent, eventHandler, createError, createApp, createRouter, lazyEventHandler } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ohmyfetch';
import { createRouter as createRouter$1 } from 'radix3';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import { hash } from 'ohash';
import { createStorage } from 'unstorage';
import { withQuery, withLeadingSlash, withoutTrailingSlash, parseURL } from 'ufo';
import { promises } from 'fs';
import { resolve, dirname } from 'pathe';
import { fileURLToPath } from 'url';

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"routes":{},"envPrefix":"NUXT_"},"public":{}};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const getEnv = (key) => {
  const envKey = snakeCase(key).toUpperCase();
  return destr(process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]);
};
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
overrideConfig(_runtimeConfig);
const config = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => config;
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const globalTiming = globalThis.__timing__ || {
  start: () => 0,
  end: () => 0,
  metrics: []
};
function timingMiddleware(_req, res, next) {
  const start = globalTiming.start();
  const _end = res.end;
  res.end = (data, encoding, callback) => {
    const metrics = [["Generate", globalTiming.end(start)], ...globalTiming.metrics];
    const serverTiming = metrics.map((m) => `-;dur=${m[1]};desc="${encodeURIComponent(m[0])}"`).join(", ");
    if (!res.headersSent) {
      res.setHeader("Server-Timing", serverTiming);
    }
    _end.call(res, data, encoding, callback);
  };
  next();
}

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

const useStorage = () => storage;

storage.mount('/assets', assets$1);

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  async function get(key, resolver) {
    const cacheKey = [opts.base, group, name, key].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl;
    const _resolve = async () => {
      if (!pending[key]) {
        pending[key] = Promise.resolve(resolver());
      }
      entry.value = await pending[key];
      entry.mtime = Date.now();
      entry.integrity = integrity;
      delete pending[key];
      useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return Promise.resolve(entry);
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const key = (opts.getKey || getKey)(...args);
    const entry = await get(key, () => fn(...args));
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length ? hash(args, {}) : "";
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: (event) => {
      return event.req.originalUrl || event.req.url;
    },
    group: opts.group || "nitro/handlers",
    integrity: [
      opts.integrity,
      handler
    ]
  };
  const _cachedHandler = cachedFunction(async (incomingEvent) => {
    const reqProxy = cloneWithProxy(incomingEvent.req, { headers: {} });
    const resHeaders = {};
    const resProxy = cloneWithProxy(incomingEvent.res, {
      statusCode: 200,
      getHeader(name) {
        return resHeaders[name];
      },
      setHeader(name, value) {
        resHeaders[name] = value;
        return this;
      },
      getHeaderNames() {
        return Object.keys(resHeaders);
      },
      hasHeader(name) {
        return name in resHeaders;
      },
      removeHeader(name) {
        delete resHeaders[name];
      },
      getHeaders() {
        return resHeaders;
      }
    });
    const event = createEvent(reqProxy, resProxy);
    event.context = incomingEvent.context;
    const body = await handler(event);
    const headers = event.res.getHeaders();
    headers.Etag = `W/"${hash(body)}"`;
    headers["Last-Modified"] = new Date().toUTCString();
    const cacheControl = [];
    if (opts.swr) {
      if (opts.maxAge) {
        cacheControl.push(`s-maxage=${opts.maxAge}`);
      }
      if (opts.staleMaxAge) {
        cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
      } else {
        cacheControl.push("stale-while-revalidate");
      }
    } else if (opts.maxAge) {
      cacheControl.push(`max-age=${opts.maxAge}`);
    }
    if (cacheControl.length) {
      headers["Cache-Control"] = cacheControl.join(", ");
    }
    const cacheEntry = {
      code: event.res.statusCode,
      headers,
      body
    };
    return cacheEntry;
  }, _opts);
  return defineEventHandler(async (event) => {
    const response = await _cachedHandler(event);
    if (event.res.headersSent || event.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["Last-Modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.res.statusCode = response.code;
    for (const name in response.headers) {
      event.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const plugins = [
  
];

function hasReqHeader(req, header, includes) {
  const value = req.headers[header];
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event.req, "accept", "application/json") || hasReqHeader(event.req, "user-agent", "curl/") || hasReqHeader(event.req, "user-agent", "httpie/") || event.req.url?.endsWith(".json") || event.req.url?.includes("/api/");
}
function normalizeError(error) {
  const cwd = process.cwd();
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Route Not Found" : "Internal Server Error");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(_error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(_error);
  const errorObject = {
    url: event.req.url,
    statusCode,
    statusMessage,
    message,
    description: "",
    data: _error.data
  };
  event.res.statusCode = errorObject.statusCode;
  event.res.statusMessage = errorObject.statusMessage;
  if (errorObject.statusCode !== 404) {
    console.error("[nuxt] [request error]", errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    event.res.setHeader("Content-Type", "application/json");
    event.res.end(JSON.stringify(errorObject));
    return;
  }
  const url = withQuery("/__nuxt_error", errorObject);
  const html = await $fetch(url).catch((error) => {
    console.error("[nitro] Error while generating error response", error);
    return errorObject.statusMessage;
  });
  event.res.setHeader("Content-Type", "text/html;charset=UTF-8");
  event.res.end(html);
});

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"21bc-XwkmumvsWAWQvKTShmzlcL3xoys\"",
    "mtime": "2022-06-13T00:25:54.807Z",
    "path": "../public/favicon.ico"
  },
  "/img.webp": {
    "type": "image/webp",
    "etag": "\"1e6c-oIg/LP8CJN12q7jJqk3+6YiAAAE\"",
    "mtime": "2022-06-13T00:25:54.808Z",
    "path": "../public/img.webp"
  },
  "/logo-black.png": {
    "type": "image/png",
    "etag": "\"f8b-T8DaUF6cMVuOtlmcWFTPSg9vRVc\"",
    "mtime": "2022-06-13T00:25:54.819Z",
    "path": "../public/logo-black.png"
  },
  "/logo-white.png": {
    "type": "image/png",
    "etag": "\"12cd-7OgD0z7K6PlLKpDr28fqJyPhyDU\"",
    "mtime": "2022-06-13T00:25:54.820Z",
    "path": "../public/logo-white.png"
  },
  "/css/bytemd.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"37f2-BndiNIrYtZLJofBKANFx8BloKeg\"",
    "mtime": "2022-06-13T00:27:23.144Z",
    "path": "../public/css/bytemd.css"
  },
  "/fonts/katex.min.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"70ca-541ScM8siwMNw2ZcPRHRYu23Dr4\"",
    "mtime": "2022-07-13T01:28:50.565Z",
    "path": "../public/fonts/katex.min.css"
  },
  "/img/avatar.jpg": {
    "type": "image/jpeg",
    "etag": "\"939c-NrxYRAasNNTniegdscxu31iXb/M\"",
    "mtime": "2022-06-13T00:25:54.812Z",
    "path": "../public/img/avatar.jpg"
  },
  "/img/model-bg.png": {
    "type": "image/png",
    "etag": "\"4e19-jxswg8YFzrMFE2g0ZUeC9GQM8p8\"",
    "mtime": "2022-06-13T00:25:54.813Z",
    "path": "../public/img/model-bg.png"
  },
  "/img/tool-cover.webp": {
    "type": "image/webp",
    "etag": "\"47f8-oriNmSyXqXRq/e+EU5tie/3REWM\"",
    "mtime": "2022-06-13T00:25:54.815Z",
    "path": "../public/img/tool-cover.webp"
  },
  "/img/tool-e2E.svg": {
    "type": "image/svg+xml",
    "etag": "\"13b94-4zBMVvb6n2n8ycSBv8nPpE2p+Z8\"",
    "mtime": "2022-06-13T00:25:54.817Z",
    "path": "../public/img/tool-e2E.svg"
  },
  "/img/tool-FlvPlayer.svg": {
    "type": "image/svg+xml",
    "etag": "\"b80-yDFCKMqGg2DWl+NOAcQCHZ20fIY\"",
    "mtime": "2022-06-23T09:26:15.286Z",
    "path": "../public/img/tool-FlvPlayer.svg"
  },
  "/img/tool-ImageToBase64.svg": {
    "type": "image/svg+xml",
    "etag": "\"6e6-Hl0WH5O7T4fl1QtZC5TZ+gcwhdY\"",
    "mtime": "2022-06-23T00:26:47.857Z",
    "path": "../public/img/tool-ImageToBase64.svg"
  },
  "/img/tool-NPlayer.svg": {
    "type": "image/svg+xml",
    "etag": "\"f77-IH+ycoLEf3ZlghfOPzY4Ch4KC2g\"",
    "mtime": "2022-07-09T00:32:12.183Z",
    "path": "../public/img/tool-NPlayer.svg"
  },
  "/img/tool-timestamp.svg": {
    "type": "image/svg+xml",
    "etag": "\"99a-bYkNPTNqgRa5YpQl3L/Ho9rTsrU\"",
    "mtime": "2022-06-23T00:26:47.858Z",
    "path": "../public/img/tool-timestamp.svg"
  },
  "/img/XGPlayer.png": {
    "type": "image/png",
    "etag": "\"de2-/suJGH1La/EuOy9OWmjJpGY2JAA\"",
    "mtime": "2022-06-25T05:00:25.165Z",
    "path": "../public/img/XGPlayer.png"
  },
  "/_nuxt/api-f15ae6d5.mjs": {
    "type": "application/javascript",
    "etag": "\"56f-QY5dyNFOGFRvbKpM/bzq9340GAQ\"",
    "mtime": "2022-07-13T08:40:47.794Z",
    "path": "../public/_nuxt/api-f15ae6d5.mjs"
  },
  "/_nuxt/asyncData-9e800fd4.mjs": {
    "type": "application/javascript",
    "etag": "\"8db-miFV2pvRUKRrOITMHPOUfY0UZvw\"",
    "mtime": "2022-07-13T08:40:47.794Z",
    "path": "../public/_nuxt/asyncData-9e800fd4.mjs"
  },
  "/_nuxt/auth-357d358b.mjs": {
    "type": "application/javascript",
    "etag": "\"184-vydG6yWJBKz8c+R2fqfKjsL/t6M\"",
    "mtime": "2022-07-13T08:40:47.853Z",
    "path": "../public/_nuxt/auth-357d358b.mjs"
  },
  "/_nuxt/cookie-161ab64b.mjs": {
    "type": "application/javascript",
    "etag": "\"9ff-PALxSz11zBcsrA1R7p8gP6/miCI\"",
    "mtime": "2022-07-13T08:40:47.794Z",
    "path": "../public/_nuxt/cookie-161ab64b.mjs"
  },
  "/_nuxt/create-ada6c8cb.mjs": {
    "type": "application/javascript",
    "etag": "\"18f-l8Bif/pJCbo2RtuUIpriEqHsDRU\"",
    "mtime": "2022-07-13T08:40:47.797Z",
    "path": "../public/_nuxt/create-ada6c8cb.mjs"
  },
  "/_nuxt/default-b1b571d6.mjs": {
    "type": "application/javascript",
    "etag": "\"28c0-DD8lt2QtdRGkDK5Rf6baHY+zA9M\"",
    "mtime": "2022-07-13T08:40:47.797Z",
    "path": "../public/_nuxt/default-b1b571d6.mjs"
  },
  "/_nuxt/default.95449fef.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"17b-msklrzTgcnom7fDY/OhdJjOkC6U\"",
    "mtime": "2022-07-13T08:40:47.873Z",
    "path": "../public/_nuxt/default.95449fef.css"
  },
  "/_nuxt/detail-5848639d.mjs": {
    "type": "application/javascript",
    "etag": "\"c1-bTdXj0f308rkQex4X6z46mKFQy8\"",
    "mtime": "2022-07-13T08:40:47.797Z",
    "path": "../public/_nuxt/detail-5848639d.mjs"
  },
  "/_nuxt/empty-63f62191.mjs": {
    "type": "application/javascript",
    "etag": "\"c7-eVfgfm9qanHOfGtxwRwXGu8M9mM\"",
    "mtime": "2022-07-13T08:40:47.797Z",
    "path": "../public/_nuxt/empty-63f62191.mjs"
  },
  "/_nuxt/EnglistConvert-e5ec07ad.mjs": {
    "type": "application/javascript",
    "etag": "\"1238-5G2IICV75DloKYjTQ6MthY+RL7Q\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/EnglistConvert-e5ec07ad.mjs"
  },
  "/_nuxt/entry-7ec175ee.mjs": {
    "type": "application/javascript",
    "etag": "\"f7276-89y7DPfz7W9eijdqerOnDgHz1BE\"",
    "mtime": "2022-07-13T08:40:47.854Z",
    "path": "../public/_nuxt/entry-7ec175ee.mjs"
  },
  "/_nuxt/entry.072a5bcb.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b993-7oBYyZ9jD8snsmIJxOXnue2Rhlc\"",
    "mtime": "2022-07-13T08:40:47.853Z",
    "path": "../public/_nuxt/entry.072a5bcb.css"
  },
  "/_nuxt/FlvPlayer-789391d6.mjs": {
    "type": "application/javascript",
    "etag": "\"1352-Nwy34OgUyQFsrtCbWsGmpt9VOas\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/FlvPlayer-789391d6.mjs"
  },
  "/_nuxt/hls-71b01d54.mjs": {
    "type": "application/javascript",
    "etag": "\"56f11-i53VnteXVF5wt33YAeOnrCGQx9E\"",
    "mtime": "2022-07-13T08:40:47.853Z",
    "path": "../public/_nuxt/hls-71b01d54.mjs"
  },
  "/_nuxt/iconfont.8c3eb7e7.woff2": {
    "type": "font/woff2",
    "etag": "\"18cc-cQ3K8byt2wK0WEGTaxtTJvOlqng\"",
    "mtime": "2022-07-13T08:40:47.792Z",
    "path": "../public/_nuxt/iconfont.8c3eb7e7.woff2"
  },
  "/_nuxt/iconfont.c7a4bd31.woff": {
    "type": "font/woff",
    "etag": "\"1dac-wCBqDHFXLENY0KrJfIv0womRt+c\"",
    "mtime": "2022-07-13T08:40:47.792Z",
    "path": "../public/_nuxt/iconfont.c7a4bd31.woff"
  },
  "/_nuxt/iconfont.ec975a33.ttf": {
    "type": "font/ttf",
    "etag": "\"3288-48pK4y0dVuYOylcSl1XBM5vf0hQ\"",
    "mtime": "2022-07-13T08:40:47.792Z",
    "path": "../public/_nuxt/iconfont.ec975a33.ttf"
  },
  "/_nuxt/ImageToBase64-2682e8d1.mjs": {
    "type": "application/javascript",
    "etag": "\"e53-OGeWGTe0OiPyWNS99/ptQRvgKOg\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/ImageToBase64-2682e8d1.mjs"
  },
  "/_nuxt/index-5b27957a.mjs": {
    "type": "application/javascript",
    "etag": "\"1971-GSFzYhKalHkEX785ksXEP4rr+Lk\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/index-5b27957a.mjs"
  },
  "/_nuxt/index-5d39d920.mjs": {
    "type": "application/javascript",
    "etag": "\"fc50e-/F+aXLxU3owK++WJsJsLm1Zl4j0\"",
    "mtime": "2022-07-13T08:40:47.892Z",
    "path": "../public/_nuxt/index-5d39d920.mjs"
  },
  "/_nuxt/index-7060184a.mjs": {
    "type": "application/javascript",
    "etag": "\"2158-8cM2EYQ9tHyQ9P/Mqqlwn3a+F1o\"",
    "mtime": "2022-07-13T08:40:47.794Z",
    "path": "../public/_nuxt/index-7060184a.mjs"
  },
  "/_nuxt/index-72182e42.mjs": {
    "type": "application/javascript",
    "etag": "\"769-v8J+hEuVItY3VBkfhFP8334bk+Y\"",
    "mtime": "2022-07-13T08:40:47.797Z",
    "path": "../public/_nuxt/index-72182e42.mjs"
  },
  "/_nuxt/index-8768cdd1.mjs": {
    "type": "application/javascript",
    "etag": "\"12b5-oH+leiXccVOtr+7zdQc09PjVBE0\"",
    "mtime": "2022-07-13T08:40:47.796Z",
    "path": "../public/_nuxt/index-8768cdd1.mjs"
  },
  "/_nuxt/index-a6447800.mjs": {
    "type": "application/javascript",
    "etag": "\"913-bFni3DTn9Qyse5pPLmJ/KwDjNFA\"",
    "mtime": "2022-07-13T08:40:47.794Z",
    "path": "../public/_nuxt/index-a6447800.mjs"
  },
  "/_nuxt/index-f842967e.mjs": {
    "type": "application/javascript",
    "etag": "\"aa-xRwDa3VI3+z+FP84sfJQaCt9j4c\"",
    "mtime": "2022-07-13T08:40:47.797Z",
    "path": "../public/_nuxt/index-f842967e.mjs"
  },
  "/_nuxt/index.min-557d2fe9.mjs": {
    "type": "application/javascript",
    "etag": "\"1cd51-SS1mzxKrAXfohbtazO6u6BGonuM\"",
    "mtime": "2022-07-13T08:40:47.854Z",
    "path": "../public/_nuxt/index.min-557d2fe9.mjs"
  },
  "/_nuxt/link-4035608f.mjs": {
    "type": "application/javascript",
    "etag": "\"c1-LppZuDqyRa3uppOohKjmdo+vfkc\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/link-4035608f.mjs"
  },
  "/_nuxt/manifest.json": {
    "type": "application/json",
    "etag": "\"2123-HU6Uf6R3Gixo2qbbV2ZguTqu/Bw\"",
    "mtime": "2022-07-13T08:40:47.855Z",
    "path": "../public/_nuxt/manifest.json"
  },
  "/_nuxt/medium-zoom.esm-76784ffc.mjs": {
    "type": "application/javascript",
    "etag": "\"246a-wH3jHqfxLfHsVes+SY2ODbjn3NY\"",
    "mtime": "2022-07-13T08:40:47.853Z",
    "path": "../public/_nuxt/medium-zoom.esm-76784ffc.mjs"
  },
  "/_nuxt/mermaid.esm.min-69e0ceb1.mjs": {
    "type": "application/javascript",
    "etag": "\"1186b8-hF5SsVjCw5yhxkoYo/VWJ7gmcXo\"",
    "mtime": "2022-07-13T08:40:47.946Z",
    "path": "../public/_nuxt/mermaid.esm.min-69e0ceb1.mjs"
  },
  "/_nuxt/mpegts-6c0c230e.mjs": {
    "type": "application/javascript",
    "etag": "\"2a523-DasNRI15tFRrvKg2XYYVipcY80A\"",
    "mtime": "2022-07-13T08:40:47.853Z",
    "path": "../public/_nuxt/mpegts-6c0c230e.mjs"
  },
  "/_nuxt/NPlayer-595dd36b.mjs": {
    "type": "application/javascript",
    "etag": "\"1617-Uqn6pJQ150lJHwEoM+LDMutlnPc\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/NPlayer-595dd36b.mjs"
  },
  "/_nuxt/order-f6ac77ce.mjs": {
    "type": "application/javascript",
    "etag": "\"b2-+k2JKaNIsYGmgVhX+UQzSmMcSK4\"",
    "mtime": "2022-07-13T08:40:47.853Z",
    "path": "../public/_nuxt/order-f6ac77ce.mjs"
  },
  "/_nuxt/post-a64a9280.mjs": {
    "type": "application/javascript",
    "etag": "\"c6-I6oHNfxh8yZjrmuEZdamXWvdaws\"",
    "mtime": "2022-07-13T08:40:47.796Z",
    "path": "../public/_nuxt/post-a64a9280.mjs"
  },
  "/_nuxt/read-87fd18dd.mjs": {
    "type": "application/javascript",
    "etag": "\"c1-ImoOftas8WsS9OKRxPTwjo5rmC4\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/read-87fd18dd.mjs"
  },
  "/_nuxt/theme-3e2bc64d.mjs": {
    "type": "application/javascript",
    "etag": "\"bd7c9-iFd55gHODZe4FhgGOpEyUlo134M\"",
    "mtime": "2022-07-13T08:40:47.854Z",
    "path": "../public/_nuxt/theme-3e2bc64d.mjs"
  },
  "/_nuxt/Timestamp-7758b39d.mjs": {
    "type": "application/javascript",
    "etag": "\"1f99-mSsMRsonmh/5LHCXnt0Q5kK6B5Y\"",
    "mtime": "2022-07-13T08:40:47.795Z",
    "path": "../public/_nuxt/Timestamp-7758b39d.mjs"
  },
  "/_nuxt/tool-7f57148e.mjs": {
    "type": "application/javascript",
    "etag": "\"c6-j30uPcPsAQN9TOZYYMu0RnP/fqM\"",
    "mtime": "2022-07-13T08:40:47.796Z",
    "path": "../public/_nuxt/tool-7f57148e.mjs"
  },
  "/_nuxt/writer-a631b42c.mjs": {
    "type": "application/javascript",
    "etag": "\"1d02-ObjbvvqT1aDIWFnHXCfIqG8zuXg\"",
    "mtime": "2022-07-13T08:40:47.797Z",
    "path": "../public/_nuxt/writer-a631b42c.mjs"
  },
  "/_nuxt/_id_-7b7fe3d1.mjs": {
    "type": "application/javascript",
    "etag": "\"219d-Uri553KzhloebWyXIsTnrEijVbM\"",
    "mtime": "2022-07-13T08:40:47.794Z",
    "path": "../public/_nuxt/_id_-7b7fe3d1.mjs"
  },
  "/fonts/fonts/KaTeX_AMS-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"f890-Hf0O5uMPihwjmZ2dll24cAtany4\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_AMS-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_AMS-Regular.woff": {
    "type": "font/woff",
    "etag": "\"82ec-ma2i3jIA55UUPWOSMsNESwgBgjU\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_AMS-Regular.woff"
  },
  "/fonts/fonts/KaTeX_AMS-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"6dac-NElHQ3Nv2nVxl9FvzGpuGnkxfIY\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_AMS-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"3050-j6tziha6j7fnACoHXwNqRVpFxug\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Bold.woff": {
    "type": "font/woff",
    "etag": "\"1e24-3SOsD7CsRpsGJEhep41wD2NhQgM\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Bold.woff"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"1b00-W/pJysRs0derE1E4jTfBGvWbphU\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"3038-JvJqE+an0KabSPYqzTGoGWvOf24\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Regular.woff": {
    "type": "font/woff",
    "etag": "\"1de8-Gm85vXDJt0cTB431991hCPm604s\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Caligraphic-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"1afc-n4B34LOKKQzZt7E2sKwpyDdegaY\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Caligraphic-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Fraktur-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"4c80-TgjdADgxJOfNlpcMyw++NcnvqqM\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_Fraktur-Bold.woff": {
    "type": "font/woff",
    "etag": "\"33f0-W7r9UB8mIhlCavfyDBEDu0tzJZI\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Bold.woff"
  },
  "/fonts/fonts/KaTeX_Fraktur-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"2c54-+Y+JJy7KEa5BdnLFmg+qaoiAWok\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_Fraktur-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"4c74-F9tAiC3V8UBiXyjdlMQwReGJPpg\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Fraktur-Regular.woff": {
    "type": "font/woff",
    "etag": "\"3398-b3VjdjYPCBW0SGL1f3let8HNTbI\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Fraktur-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"2c34-pXZMbieE0CggwLkECJ8/rHmL5Po\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Fraktur-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Main-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"c888-QTqz3D/DpXUidbriyuZ+tY8rMvA\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_Main-Bold.woff": {
    "type": "font/woff",
    "etag": "\"74d8-9po2JQ6ubooCFzqZCapihCi6IGA\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Bold.woff"
  },
  "/fonts/fonts/KaTeX_Main-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"62ec-MQUKGxsSP7LFnK0fdLff+Q3rj84\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_Main-BoldItalic.ttf": {
    "type": "font/ttf",
    "etag": "\"80c8-umRk5EL9UK73Z4kkug8tlYHruwc\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-BoldItalic.ttf"
  },
  "/fonts/fonts/KaTeX_Main-BoldItalic.woff": {
    "type": "font/woff",
    "etag": "\"4bd4-A4u9yIh6lzCtlBR/xXxv9N+0hBE\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-BoldItalic.woff"
  },
  "/fonts/fonts/KaTeX_Main-BoldItalic.woff2": {
    "type": "font/woff2",
    "etag": "\"418c-pKSQW4sSb5/9VT0hpyoMJOlIA0U\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-BoldItalic.woff2"
  },
  "/fonts/fonts/KaTeX_Main-Italic.ttf": {
    "type": "font/ttf",
    "etag": "\"832c-HVZoorlK59vu/dfNaNmP6dWCXgc\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Italic.ttf"
  },
  "/fonts/fonts/KaTeX_Main-Italic.woff": {
    "type": "font/woff",
    "etag": "\"4cdc-fIWJITvHAD4sIzS1HKQVKFiYer0\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Italic.woff"
  },
  "/fonts/fonts/KaTeX_Main-Italic.woff2": {
    "type": "font/woff2",
    "etag": "\"425c-ybK1/9LyeqXGtvm6QaeytOZhAtM\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Italic.woff2"
  },
  "/fonts/fonts/KaTeX_Main-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"d14c-h0TbbvjDCePchfG76YBSCti3v9Q\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Main-Regular.woff": {
    "type": "font/woff",
    "etag": "\"7834-/crlS6HUY17oWlRizByX5SHP1RU\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Main-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"66a0-yIQIbCXOyFWBYLICb5Bu99o1cKw\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Main-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Math-BoldItalic.ttf": {
    "type": "font/ttf",
    "etag": "\"79dc-6AzEwjLSB192KlLUa+tP+9N6Xxo\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Math-BoldItalic.ttf"
  },
  "/fonts/fonts/KaTeX_Math-BoldItalic.woff": {
    "type": "font/woff",
    "etag": "\"48ec-1U5kgNbUBGxqVhmqODuqWXH7igw\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Math-BoldItalic.woff"
  },
  "/fonts/fonts/KaTeX_Math-BoldItalic.woff2": {
    "type": "font/woff2",
    "etag": "\"4010-j8udLeZaxxoMT92YYXPbcwWS7Yo\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Math-BoldItalic.woff2"
  },
  "/fonts/fonts/KaTeX_Math-Italic.ttf": {
    "type": "font/ttf",
    "etag": "\"7a4c-npoQ2Ppa2Iyez6SQKt3U2SWAsrw\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Math-Italic.ttf"
  },
  "/fonts/fonts/KaTeX_Math-Italic.woff": {
    "type": "font/woff",
    "etag": "\"493c-HBtIc54ctL4T3djAvCed3oUb26A\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Math-Italic.woff"
  },
  "/fonts/fonts/KaTeX_Math-Italic.woff2": {
    "type": "font/woff2",
    "etag": "\"4038-20iD0M/5XstcA0EOMoOnN8Ue1gQ\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Math-Italic.woff2"
  },
  "/fonts/fonts/KaTeX_SansSerif-Bold.ttf": {
    "type": "font/ttf",
    "etag": "\"5fb8-ILRfU0a2htUsRFdFOT0XB7uI7B0\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Bold.ttf"
  },
  "/fonts/fonts/KaTeX_SansSerif-Bold.woff": {
    "type": "font/woff",
    "etag": "\"3848-or7dyKPU0IAo1wd3btvU0k8uwPw\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Bold.woff"
  },
  "/fonts/fonts/KaTeX_SansSerif-Bold.woff2": {
    "type": "font/woff2",
    "etag": "\"2fb8-iG5heXpSXUqvzgqvV0FP366huHM\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Bold.woff2"
  },
  "/fonts/fonts/KaTeX_SansSerif-Italic.ttf": {
    "type": "font/ttf",
    "etag": "\"575c-mR+9wDFouxSkRHz6PlFfCabs/tw\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Italic.ttf"
  },
  "/fonts/fonts/KaTeX_SansSerif-Italic.woff": {
    "type": "font/woff",
    "etag": "\"3720-dWSjZrdv2DcEHCS+70xVgKWt1A4\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Italic.woff"
  },
  "/fonts/fonts/KaTeX_SansSerif-Italic.woff2": {
    "type": "font/woff2",
    "etag": "\"2efc-PV+jyzCfjYO03L3SdyXycPYPPus\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Italic.woff2"
  },
  "/fonts/fonts/KaTeX_SansSerif-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"4bec-So4XoMtYqCKN1EF/vRuJnkHasEU\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_SansSerif-Regular.woff": {
    "type": "font/woff",
    "etag": "\"301c-gEYQ9MsuLq2WlLjaLshOzo0Jw40\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Regular.woff"
  },
  "/fonts/fonts/KaTeX_SansSerif-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"2868-5F1fT0p/L/PcqfzMLxSOeB4j8pI\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_SansSerif-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Script-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"4108-xvZ12oGtKcvySyz3cPeVtNosZI4\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Script-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Script-Regular.woff": {
    "type": "font/woff",
    "etag": "\"295c-agXNyk8fcIXmB9w4vt71V1P4b9g\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Script-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Script-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"25ac-Y7gJWfH8Voma4hugy7zTmmywg5A\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Script-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size1-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"2fc4-MoC6y8sSRZcf4BAXtHTHbDN8EMk\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size1-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size1-Regular.woff": {
    "type": "font/woff",
    "etag": "\"1960-rv5mdKVlM2J8c5zXiWOY8USH4Bw\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size1-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size1-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"155c-V/pZmXShvAs31fDlzIYCMC8CtXM\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size1-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size2-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"2cf4-+vc/8+eVGE5UMWZv+v64qg4og00\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size2-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size2-Regular.woff": {
    "type": "font/woff",
    "etag": "\"182c-RmmP8YGb0ngm/V0txLpOH2PKzfQ\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size2-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size2-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"1458-7hhxNjSjvoyZcnaAhVKrGVpZj0M\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size2-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size3-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"1da4-MCphsuzfgtOeZ4D0K9B+5M5nuNU\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size3-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size3-Regular.woff": {
    "type": "font/woff",
    "etag": "\"1144-HaGQWm0dm8q5KwWd9ytSjepwi8s\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size3-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size3-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"e28-GafKrftmvSdXgQrkflx6DgBRAaE\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size3-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Size4-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"287c-PY2d1YoDt6RtSX9XYeYNi4RKUZk\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size4-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Size4-Regular.woff": {
    "type": "font/woff",
    "etag": "\"175c-j93bg1E+wiYjHr7gUHnsRfwBNXg\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size4-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Size4-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"1340-m+0X+5LyZQUB4imGLEDGQH4cVSg\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Size4-Regular.woff2"
  },
  "/fonts/fonts/KaTeX_Typewriter-Regular.ttf": {
    "type": "font/ttf",
    "etag": "\"6ba4-YpuZ+vGNl1KfIaGxAYCT5gvNBY8\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Typewriter-Regular.ttf"
  },
  "/fonts/fonts/KaTeX_Typewriter-Regular.woff": {
    "type": "font/woff",
    "etag": "\"3e9c-9ecp+k/0ZvwH4MerGXmtcMRfpdU\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Typewriter-Regular.woff"
  },
  "/fonts/fonts/KaTeX_Typewriter-Regular.woff2": {
    "type": "font/woff2",
    "etag": "\"3500-egiIP//GlYxxzAGnWguZzKPktHU\"",
    "mtime": "2022-06-13T00:27:22.305Z",
    "path": "../public/fonts/fonts/KaTeX_Typewriter-Regular.woff2"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = ["/_nuxt"];

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return
  }
  for (const base of publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = ["HEAD", "GET"];
const _152570 = eventHandler(async (event) => {
  if (event.req.method && !METHODS.includes(event.req.method)) {
    return;
  }
  let id = decodeURIComponent(withLeadingSlash(withoutTrailingSlash(parseURL(event.req.url).pathname)));
  let asset;
  for (const _id of [id, id + "/index.html"]) {
    const _asset = getAsset(_id);
    if (_asset) {
      asset = _asset;
      id = _id;
      break;
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.res.statusCode = 304;
    event.res.end("Not Modified (etag)");
    return;
  }
  const ifModifiedSinceH = event.req.headers["if-modified-since"];
  if (ifModifiedSinceH && asset.mtime) {
    if (new Date(ifModifiedSinceH) >= new Date(asset.mtime)) {
      event.res.statusCode = 304;
      event.res.end("Not Modified (mtime)");
      return;
    }
  }
  if (asset.type) {
    event.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag) {
    event.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime) {
    event.res.setHeader("Last-Modified", asset.mtime);
  }
  const contents = await readAsset(id);
  event.res.end(contents);
});

const _lazy_608310 = () => import('./renderer.mjs').then(function (n) { return n.a; });

const handlers = [
  { route: '', handler: _152570, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_608310, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_608310, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  h3App.use(config.app.baseURL, timingMiddleware);
  const router = createRouter();
  const routerOptions = createRouter$1({ routes: config.nitro.routes });
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    const referenceRoute = h.route.replace(/:\w+|\*\*/g, "_");
    const routeOptions = routerOptions.lookup(referenceRoute) || {};
    if (routeOptions.swr) {
      handler = cachedEventHandler(handler, {
        group: "nitro/routes"
      });
    }
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(/\/+/g, "/");
      h3App.use(middlewareBase, handler);
    } else {
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const localCall = createCall(h3App.nodeHandler);
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({ fetch: localFetch, Headers, defaults: { baseURL: config.app.baseURL } });
  globalThis.$fetch = $fetch;
  const app = {
    hooks,
    h3App,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, nitroApp.h3App.nodeHandler) : new Server$1(nitroApp.h3App.nodeHandler);
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const hostname = process.env.NITRO_HOST || process.env.HOST || "0.0.0.0";
server.listen(port, hostname, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  console.log(`Listening on ${protocol}://${hostname}:${port}${useRuntimeConfig().app.baseURL}`);
});
{
  process.on("unhandledRejection", (err) => console.error("[nitro] [dev] [unhandledRejection] " + err));
  process.on("uncaughtException", (err) => console.error("[nitro] [dev] [uncaughtException] " + err));
}
const nodeServer = {};

export { nodeServer as n, useRuntimeConfig as u };
//# sourceMappingURL=node-server.mjs.map
