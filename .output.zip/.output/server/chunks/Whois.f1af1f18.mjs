import { c as _export_sfc, a as useNuxtApp } from './server.mjs';
import { useSSRContext, defineComponent, ref, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Whois",
  __ssrInlineRender: true,
  setup(__props) {
    useNuxtApp();
    ref(null);
    const showInfo = ref(false);
    const result = ref("");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-gray-100" }, _attrs))} data-v-2293a361><section class="bg-gray-100" data-v-2293a361><div class="container px-4 mx-auto" data-v-2293a361><div class="md:flex md:-mx-4 md:items-center py-8" data-v-2293a361><div class="md:w-1/2 px-4" data-v-2293a361><h1 class="text-2xl text-black" data-v-2293a361>Whois\u67E5\u8BE2</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12 bg-white rounded-l mb-12" data-v-2293a361><div class="flex w-full text-xl md:text-2xl" data-v-2293a361><div class="bg-gray-100 py-2 w-full rounded" data-v-2293a361><input class="bg-gray-100 px-2 border-0 focus:outline-none w-full font-black" foucus type="text" placeholder="\u8BF7\u8F93\u5165\u8981\u67E5\u8BE2\u7684\u57DF\u540D" data-v-2293a361></div><div class="relative" data-v-2293a361><div class="searchBtn rounded-r whitespace-nowrap px-8 cursor-pointer hover:shadow-lg leading-7 md:leading-8 py-2 bg-black font-black text-white" data-v-2293a361> \u67E5\u8BE2</div></div></div><hr style="${ssrRenderStyle(showInfo.value ? null : { display: "none" })}" class="container mx-auto my-10" data-v-2293a361><div data-v-2293a361><p class="p-4 text-lg whitespace-pre-wrap" style="${ssrRenderStyle({ "white-space": "pre-wrap" })}" data-v-2293a361>${ssrInterpolate(result.value)}</p></div></section><section class="w-full container px-4 mx-auto py-12 bg-white rounded-l mb-12" data-v-2293a361><div class="text-xl md:text-2xl font-black my-3" data-v-2293a361>Q\uFF1A\u4EC0\u4E48\u662F <span class="inline-block bg-yellow-300" data-v-2293a361>Whois</span> \u67E5\u8BE2\uFF1F </div><div class="text-base md:text-xl mt-3 mb-12" data-v-2293a361>A\uFF1A\u7B80\u5355\u6765\u8BF4whois\u67E5\u8BE2\u5C31\u662F\u7528\u6765\u67E5\u770B\u57DF\u540D\u662F\u5426\u6CE8\u518C\uFF0C\u4EE5\u53CA\u5DF2\u6CE8\u518C\u57DF\u540D\u7684\u6240\u6709\u4EBA\u3001\u6CE8\u518C\u5546\u3001\u6CE8\u518C\u65E5\u671F\u548C\u8FC7\u671F\u65E5\u671F\u7B49\u4FE1\u606F\u3002 </div><div class="text-xl md:text-2xl font-black my-3" data-v-2293a361>Q\uFF1A<span class="inline-block bg-yellow-300" data-v-2293a361>Whois</span> \u67E5\u8BE2\u7684\u539F\u7406\u662F\u4EC0\u4E48\uFF1F </div><div class="text-base md:text-xl my-12" data-v-2293a361>A\uFF1A\u6839\u636E\u57DF\u540D\u540E\u7F00\u83B7\u53D6\u5230\u57DF\u540D\u670D\u52A1\u5668\uFF0C\u4E4B\u540E\u53BB\u4F7F\u7528TCP\u8FDE\u63A5\u5BF9\u5E94\u7684\u57DF\u540D\u670D\u52A1\u5668\uFF0C\u7AEF\u53E3\u4E3A34\uFF0C\u53D1\u9001\u547D\u4EE4\u5185\u5BB9\u4E3A\u57DF\u540D + \\r\\n\uFF0C\u63A5\u53D7\u5BF9\u5E94\u7684\u8FD4\u56DE\u4FE1\u606F\u4F5C\u4E3A\u57DF\u540D\u7684whois\u4FE1\u606F\u3002 </div></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/Whois.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Whois = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-2293a361"]]);

export { Whois as default };
//# sourceMappingURL=Whois.f1af1f18.mjs.map
