import { __tla as __tla$1, g as useRoute, u as useHead, _ as __nuxt_component_0$1 } from './server.mjs';
import { _ as __tla$2, a as _sfc_main } from './Adsbygoogle.47a8e0e3.mjs';
import { defineComponent, withAsyncContext, ref, onUnmounted, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { _ as __tla$3, u as useAsyncData } from './asyncData.b463f621.mjs';
import { _ as __tla$4, a as useRequestHeaders, u as useCookie } from './cookie.3a889f6e.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderClass, ssrInterpolate, ssrRenderAttr, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { _ as __tla$5, a as api } from './api.883a6098.mjs';
import { _ as __tla$6, r as request } from './request.785c1b89.mjs';
import { _ as __tla$7, u as userStore } from './user.da01cd42.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _id_;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$6;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$7;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main$1 = defineComponent({
    __name: "[id]",
    __ssrInlineRender: true,
    async setup(__props) {
      var _a;
      let __temp, __restore;
      const { Viewer } = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/vue-next').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp);
      const breaks = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-breaks').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const gemoji = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-gemoji').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const gfm = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-gfm').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const highlight = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-highlight').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const math = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-math-ssr').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const medium = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-medium-zoom').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const mermaid = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-mermaid').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const frontmatter = ([__temp, __restore] = withAsyncContext(() => import('@bytemd/plugin-frontmatter').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const { marked } = ([__temp, __restore] = withAsyncContext(() => import('marked').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp);
      const themes = ([__temp, __restore] = withAsyncContext(() => import('./theme.a19ed3dc.mjs')), __temp = await __temp, __restore(), __temp).themes;
      const isSuccess = ref(false);
      const isSuccessViewer = ref(false);
      const isRender = ref(false);
      ref(true);
      const rightFixedContainerWidth = ref("100%");
      const docMenu = ref([]);
      const tocActive = ref(0);
      const route = useRoute();
      let rightNormalContainer = ref();
      let rightFixedContainer = ref();
      let articleContents = ref();
      const isSpeader = ref(false);
      const headers = useRequestHeaders();
      const userAgent = (_a = headers == null ? void 0 : headers["user-agent"]) != null ? _a : navigator.userAgent;
      ([__temp, __restore] = withAsyncContext(() => import('dom-to-image').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      ref();
      let posterImage = ref("");
      const article = ref();
      const articleSimple = ref("");
      const isShowPoster = ref(false);
      const loginStatus = ref(false);
      const token = useCookie("token");
      userStore();
      if (typeof token.value != "undefined") {
        loginStatus.value = true;
      }
      const plugins = [
        breaks(),
        frontmatter(),
        {
          viewerEffect({ file }) {
            var _a2, _b;
            if (typeof file.value != "object") {
              return;
            }
            const $style = document.createElement("style");
            try {
              $style.innerHTML = (_b = (_a2 = themes[file.value.frontmatter.theme]) == null ? void 0 : _a2.style) != null ? _b : themes.juejin.style;
            } catch (e) {
              $style.innerHTML = themes.juejin.style;
            }
            document.head.appendChild($style);
            return () => {
              $style.remove();
            };
          }
        },
        gemoji(),
        gfm(),
        highlight(),
        math(),
        medium(),
        mermaid()
      ];
      const articleHtmlContent = ref();
      let mdHTMl = "";
      const userInteract = ref();
      const { data: articleData, pending, refresh, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData("read_Detail", () => api.article.getDetail(route.params.id.toString()))), __temp = await __temp, __restore(), __temp);
      if (articleData.value.success) {
        mdHTMl = marked.parse(articleData.value.data.content);
        article.value = articleData.value.data;
        articleSimple.value = article.value.content.substr(0, 240);
        isSuccess.value = true;
        if (userAgent.indexOf("Baiduspider") != -1) {
          isSpeader.value = true;
        }
      }
      onUnmounted(() => {
        window.removeEventListener("scroll", handleScroll);
      });
      function setFloatContainer() {
        if (rightNormalContainer.value.getBoundingClientRect().bottom <= 0) {
          rightFixedContainer.value.style.position = "fixed";
          rightFixedContainer.value.style.top = "5.5rem";
          rightFixedContainerWidth.value = rightNormalContainer.value.offsetWidth + "px";
        } else if (rightNormalContainer.value.getBoundingClientRect().bottom > 0) {
          rightFixedContainerWidth.value = "100%";
          rightFixedContainer.value.style.top = "";
          rightFixedContainer.value.style.position = "absolute";
        }
      }
      function handleScroll() {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
        if (scrollTop > 20) {
          setFloatContainer();
          setContentsActive();
        }
      }
      function handleChange(v) {
        articleHtmlContent.value = v;
      }
      function setContentsActive() {
        const titleNavList = document.querySelectorAll("#markdown-body h1,#markdown-body h2,#markdown-body h3,#markdown-body h4,#markdown-body h5,#markdown-body h6");
        const offsetTopList = [];
        titleNavList.forEach((item) => {
          offsetTopList.push(item.offsetTop);
        });
        const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        let navIndex = 0;
        for (let n = 0; n < offsetTopList.length; n++) {
          if (scrollTop >= offsetTopList[n]) {
            navIndex = n;
          }
        }
        tocActive.value = navIndex;
        let cateList = Array.prototype.slice.call(articleContents.value.querySelectorAll("li"));
        for (let i = 0; i < cateList.length; i++) {
          if (navIndex === i) {
            const top = getElementTop(cateList[i], articleContents.value);
            articleContents.value.scrollTop = top - articleContents.value.offsetHeight / 2;
          }
        }
      }
      function getElementTop(el, by) {
        let top = el.offsetTop;
        if (by) {
          top = top - by.offsetTop;
        }
        return top;
      }
      useHead({
        title: isSuccess.value ? article.value.title : "\u6587\u7AE0\u4E0D\u5B58\u5728",
        titleTemplate: (title) => `${title} - \u6587\u7AE0 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u524D\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u540E\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u5728\u7EBF\u5C0F\u5DE5\u5177\uFF0C\u8BBE\u8BA1\u6280\u5DE7"
          },
          {
            name: "description",
            content: isSuccess.value ? article.value.summary : "ZNGG\u5728\u7EBF\u5DE5\u5177\u662F\u4E00\u4E2A\u6301\u7EED\u63D0\u4F9B\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA\u5E73\u53F0\uFF0C\u5E76\u5C06\u8F93\u51FA\u5185\u5BB9\u8F6C\u53D8\u4E3A\u6210\u679C\uFF0C\u63D0\u4F9B\u5404\u79CD\u5404\u6837\u7684\u5728\u7EBF\u5DE5\u5177\u3002"
          }
        ],
        link: [
          {
            rel: "stylesheet",
            href: "/fonts/katex.min.css"
          },
          {
            rel: "stylesheet",
            href: "/css/bytemd.css"
          }
        ],
        script: []
      });
      return (_ctx, _push, _parent, _attrs) => {
        var _a2, _b, _c, _d;
        const _component_nuxt_link = __nuxt_component_0$1;
        const _component_adsbygoogle = _sfc_main;
        _push(`<div${ssrRenderAttrs(mergeProps({
          ref: "html"
        }, _attrs))} data-v-06399864><div class="mx-auto container my-8" data-v-06399864><div class="relative lg:block left-button-box" data-v-06399864><div class="absolute pt-10" style="${ssrRenderStyle({
          "left": "-62px",
          "top": "0"
        })}" data-v-06399864><div class="h-96 w-18 fixed" data-v-06399864><ul class="mx-auto" data-v-06399864><li class="${ssrRenderClass([
          ((_a2 = unref(userInteract)) == null ? void 0 : _a2.like) ? "text-blue-600" : "text-gray-500",
          "relative bg-white text-center rounded-full p-1 w-11 h-11 shadow-xl hover:text-blue-600"
        ])}" alt="\u70B9\u8D5E" data-v-06399864><i class="iconfont icon-Likevotethumbup mx-auto" data-v-06399864></i><p class="mt-2 text-sm" data-v-06399864>${ssrInterpolate((_b = unref(userInteract)) == null ? void 0 : _b.likeCount)}</p></li><li class="bg-white text-center rounded-full p-1 w-11 h-11 shadow-xl text-gray-500 hover:text-black" data-v-06399864><i class="iconfont icon-favorites-fill mx-auto" data-v-06399864></i><p class="mt-2 text-sm" data-v-06399864>${ssrInterpolate((_c = unref(userInteract)) == null ? void 0 : _c.collectCount)}</p></li></ul></div></div></div><div class="flex flex-wrap relative" data-v-06399864><div class="bg-white p-6 rounded-md mt-4 w-full lg:w-8/12" data-v-06399864>`);
        if (unref(isSuccess)) {
          _push(`<div class="" data-v-06399864><div class="" data-v-06399864><h1 class="font-semibold w-full text-xl lg:text-3xl" data-v-06399864>${ssrInterpolate(unref(article).title)}</h1><div class="flex py-4 w-fll justify-between items-center" data-v-06399864><div class="flex items-center" data-v-06399864><img${ssrRenderAttr("src", unref(article).user.avatar)} class="w-10 h-10 rounded-full" data-v-06399864><div class="ml-2" data-v-06399864><p class="custom-font-16" data-v-06399864>${ssrInterpolate(unref(article).user.name)}</p><p class="custom-font-14 text-gray-500" data-v-06399864>${ssrInterpolate(unref(article).updateTime)}\xA0\xA0\xA0\xA0<span class="block md:inline-block" data-v-06399864>\u9605\u8BFB\uFF1A${ssrInterpolate(unref(article).viewCount)}</span></p></div></div><div class="" data-v-06399864><a href="#" data-v-06399864><p class="btn-2 w-auto" data-v-06399864>${ssrInterpolate(unref(article).category.name)}</p></a></div></div><div style="${ssrRenderStyle(!unref(isSuccessViewer) && !unref(isSpeader) ? null : {
            display: "none"
          })}" class="block w-full animate-pulse" data-v-06399864><div class="flex mt-6 mb-2" data-v-06399864><div class="w-2/12" data-v-06399864></div><div class="w-10/12 h-6 bg-gray-200" data-v-06399864></div></div><div class="w-full h-6 bg-gray-200 my-6" data-v-06399864></div><div class="w-full h-64 bg-gray-200 my-6" data-v-06399864></div><div class="w-full h-6 bg-gray-200 my-6" data-v-06399864></div><div class="w-8/12 h-6 bg-gray-200 my-6" data-v-06399864></div></div>`);
          if (unref(isSpeader)) {
            _push(`<div is="&#39;style&#39;" data-v-06399864>${ssrInterpolate(unref(themes).juejin.style)}</div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<div style="${ssrRenderStyle(unref(isSpeader) ? null : {
            display: "none"
          })}" class="${ssrRenderClass([
            unref(isSpeader) ? "" : "opacity-0",
            "markdown-body overflow-auto"
          ])}" data-v-06399864>${unref(mdHTMl)}</div><div data-v-06399864>`);
          if (unref(isRender) && !unref(isSpeader)) {
            _push(ssrRenderComponent(unref(Viewer), {
              style: unref(isSuccessViewer) ? null : {
                display: "none"
              },
              id: "markdown-body",
              value: unref(articleHtmlContent),
              plugins,
              onChange: handleChange
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div></div>`);
        } else {
          _push(`<div class="h-80 relative" data-v-06399864><div class="absolute empty items-center text-2xl" data-v-06399864><span class="iconfont icon-cry" style="${ssrRenderStyle({
            "font-size": "24px"
          })}" data-v-06399864></span><p class="text-gray-700" data-v-06399864>\u6CA1\u6709\u627E\u5230\u8BE5\u6587\u7AE0\uFF01</p><p data-v-06399864><a href="/" class="text-blue-600 custom-font-14 my-4" data-v-06399864>\u8FD4\u56DE\u9996\u9875</a></p></div></div>`);
        }
        _push(`</div><div class="bg-white p-6 rounded-md mt-4 w-full lg:w-8/12" data-v-06399864>`);
        if (unref(isSuccess)) {
          _push(`<div class="" data-v-06399864><div class="" data-v-06399864><p class="font-bold text-xl my-2" data-v-06399864>\u8BC4\u8BBA</p><div class="flex w-fll justify-between items-center mt-4" data-v-06399864><div class="flex w-full" data-v-06399864><img${ssrRenderAttr("src", unref(article).user.avatar)} class="w-10 h-10 rounded-full" data-v-06399864><div class="w-full px-4" data-v-06399864><div contenteditable="true" class="w-full min-h-20 bg-gray-50 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2" data-v-06399864></div></div></div></div></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div class="mt-4 hidden lg:block w-full lg:w-4/12 absolute right-0" data-v-06399864><div class="pl-6 w-full" data-v-06399864><div class="w-full py-6 rounded text-center bg-gradient-to-r from-cyan-500 to-blue-500" data-v-06399864>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/nav"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="mx-auto" data-v-06399864${_scopeId}><p class="text-2xl font-bold text-white" data-v-06399864${_scopeId}>\u4F18\u8D28\u7F51\u5740\u5BFC\u822A</p></div>`);
            } else {
              return [
                createVNode("div", {
                  class: "mx-auto"
                }, [
                  createVNode("p", {
                    class: "text-2xl font-bold text-white"
                  }, "\u4F18\u8D28\u7F51\u5740\u5BFC\u822A")
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="w-full my-2 py-6 rounded text-center bg-gradient-to-r from-violet-500 to-fuchsia-500" data-v-06399864>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/tool/detail/FlvPlayer"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="mx-auto" data-v-06399864${_scopeId}><p class="text-2xl font-bold text-white" data-v-06399864${_scopeId}>FLV\u64AD\u653E\u5668</p></div>`);
            } else {
              return [
                createVNode("div", {
                  class: "mx-auto"
                }, [
                  createVNode("p", {
                    class: "text-2xl font-bold text-white"
                  }, "FLV\u64AD\u653E\u5668")
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="w-full my-2 py-6 rounded text-center bg-gradient-to-r from-orange-500 to-fuchsia-700" data-v-06399864>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/tool/detail/ScreenRec"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="mx-auto" data-v-06399864${_scopeId}><p class="text-2xl font-bold text-white" data-v-06399864${_scopeId}>PC\u5728\u7EBF\u5F55\u5C4F</p></div>`);
            } else {
              return [
                createVNode("div", {
                  class: "mx-auto"
                }, [
                  createVNode("p", {
                    class: "text-2xl font-bold text-white"
                  }, "PC\u5728\u7EBF\u5F55\u5C4F")
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="blick mt-4" data-v-06399864>`);
        _push(ssrRenderComponent(_component_adsbygoogle, null, null, _parent));
        _push(`</div></div><div style="${ssrRenderStyle({
          width: unref(rightFixedContainerWidth)
        })}" class="h-20 pl-6 my-4 hidden lg:block w-full" data-v-06399864><div style="${ssrRenderStyle(unref(docMenu).length > 0 ? null : {
          display: "none"
        })}" class="bg-white rounded-md" data-v-06399864><div class="flex justify-between items-center p-6" data-v-06399864><div class="flex items-center" data-v-06399864><p class="font-semibold text-2xl" data-v-06399864>\u76EE\u5F55</p><p class="hidden lg:inline leading-8 mx-4 text-sm text-gray-400" data-v-06399864> Contents </p></div></div><hr class="mx-6" data-v-06399864><div data-v-06399864><ul class="article-contents overflow-y-auto py-2 px-6" data-v-06399864><!--[-->`);
        ssrRenderList(unref(docMenu), (item, index) => {
          _push(`<li class="${ssrRenderClass([
            `level_${item.level}`,
            "leading-9 relative"
          ])}" data-v-06399864><a${ssrRenderAttr("href", "#" + item.id)} class="${ssrRenderClass({
            "text-blue-600 active": unref(tocActive) === index
          })}" data-v-06399864>${ssrInterpolate(item.text)}</a></li>`);
        });
        _push(`<!--]--></ul></div></div></div></div></div><div style="${ssrRenderStyle(unref(isShowPoster) ? null : {
          display: "none"
        })}" class="modal-show flex items-center w-full h-full fixed top-0 left-0 z-40 bg-gray-500 opacity-100 justify-center" data-v-06399864><div class="modal-content bg-white w-96 p-4 relative rounded-md" data-v-06399864><div data-v-06399864><span class="hover:cursor-pointer right-0 top-0 absolute m-2 w-5 h-5 iconfont icon-close" data-v-06399864></span></div><div class="relative mt-4" data-v-06399864><div class="overflow-hidden poster-content" data-v-06399864><div class="overflow-hidden h-80" data-v-06399864><img style="${ssrRenderStyle({
          "width": "100%"
        })}"${ssrRenderAttr("src", unref(posterImage))} data-v-06399864></div><div class="poster-content-mask" data-v-06399864></div><div class="absolute w-full" style="${ssrRenderStyle({
          "top": "320px"
        })}" data-v-06399864><hr class="mb-2" data-v-06399864><div class="flex" data-v-06399864><div data-v-06399864><img class="w-20"${ssrRenderAttr("src", unref(request).baseUrl + "/api/common/createQRCode?url=https://www.zngg.net/read/post/" + ((_d = unref(article)) == null ? void 0 : _d.id) + "&width=160&height=160")} + alt="" srcset="" data-v-06399864></div><div class="pl-4" data-v-06399864><p class="text-gray-500" data-v-06399864>\u626B\u63CF\u4E8C\u7EF4\u7801\u83B7\u53D6\u6587\u7AE0\u8BE6\u60C5</p><p class="text-gray-500 text-xs mt-3" data-v-06399864>\u66F4\u591A\u7CBE\u5F69\u5185\u5BB9\u5C3D\u5728\uFF1AWWW.ZNGG.NET</p></div></div></div></div></div></div></div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main$1.setup;
  _sfc_main$1.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/read/post/[id].vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  _id_ = _export_sfc(_sfc_main$1, [
    [
      "__scopeId",
      "data-v-06399864"
    ]
  ]);
});

export { __tla, _id_ as default };
//# sourceMappingURL=_id_.3ce694e6.mjs.map
