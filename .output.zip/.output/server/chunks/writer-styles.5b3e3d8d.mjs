const writer_vue_vue_type_style_index_0_lang = ".bytemd{height:calc(100vh - 4rem)}.relaseCard{background:rgba(0,0,0,.25)}.relaseCard .card{width:560px}";

const writerStyles_5b3e3d8d = [writer_vue_vue_type_style_index_0_lang];

export { writerStyles_5b3e3d8d as default };
//# sourceMappingURL=writer-styles.5b3e3d8d.mjs.map
