const Toolbar_vue_vue_type_style_index_0_scoped_45bb422f_lang = "header[data-v-45bb422f]{background:#fff}.menu>li[data-v-45bb422f]:hover,.router-link-active[data-v-45bb422f],.router-link-exact-active[data-v-45bb422f]{color:#3955f6;font-weight:900}.icon-category[data-v-45bb422f]{font-size:24px}";

const ToolbarStyles_61b9d4c2 = [Toolbar_vue_vue_type_style_index_0_scoped_45bb422f_lang];

export { ToolbarStyles_61b9d4c2 as default };
//# sourceMappingURL=Toolbar-styles.61b9d4c2.mjs.map
