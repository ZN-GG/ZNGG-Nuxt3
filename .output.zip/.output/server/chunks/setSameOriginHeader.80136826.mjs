function setSameOriginHeader(req, res, next) {
  res == null ? void 0 : res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
  res == null ? void 0 : res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  next();
}

export { setSameOriginHeader as default };
//# sourceMappingURL=setSameOriginHeader.80136826.mjs.map
