import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "EnglistConvert",
    __ssrInlineRender: true,
    setup(__props) {
      const text = ref("");
      const copyText = ref("\u4E00\u952E\u590D\u5236");
      useNuxtApp();
      useHead({
        title: "\u82F1\u6587\u5B57\u6BCD\u5927\u5C0F\u5199\u8F6C\u6362",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u82F1\u6587\u5B57\u6BCD\u5927\u5C0F\u5199\u8F6C\u6362\u5DE5\u5177,\u82F1\u6587\u5B57\u6BCD\u8F6C\u5927\u5199,\u82F1\u6587\u5B57\u6BCD\u8F6C\u5C0F\u5199,\u82F1\u6587\u9996\u5B57\u6BCD\u5927\u5199"
          },
          {
            name: "description",
            content: "\u8FD9\u662F\u4E00\u4E2A\u82F1\u6587\u5927\u5C0F\u5199\u8F6C\u6362\u7684\u5DE5\u5177\uFF0C\u53EF\u4EE5\u4E00\u952E\u5C06\u82F1\u6587\u53E5\u5B50\u6216\u6807\u9898\u7684\u5355\u8BCD\u9996\u5B57\u6BCD\u8F6C\u6362\u6210\u5927\u5199\uFF0C\u8DE8\u5883\u7535\u5546\u5546\u54C1\u540D\u5FC5\u5907\u5728\u7EBF\u5DE5\u5177\u4E4B\u4E00\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">\u82F1\u6587\u5927\u5C0F\u5199\u5728\u7EBF\u8F6C\u6362</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12"><div class="relative"><textarea autofocus class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3" rows="8">${ssrInterpolate(unref(text))}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(unref(text).length)}</span></div><div class="flex flex-row flex-wrap"><button class="flex my-2 mr-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u5355\u8BCD\u5927\u5199 </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u5355\u8BCD\u5C0F\u5199 </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u9996\u5B57\u6BCD\u5927\u5199 </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none">${ssrInterpolate(unref(copyText))}</button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-red-800 shadow-lg focus:outline-none hover:bg-red-900 hover:shadow-none"> \u6E05\u7A7A </button></div></section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u6709\u505A\u8DE8\u5883\u7535\u5546\u7684\u5C0F\u4F19\u4F34\u8BF4\u9700\u8981\u4E00\u6B3E\u82F1\u6587\u5927\u5C0F\u5199\u8F6C\u6362\u7684\u5DE5\u5177\uFF0C\u8BF4\u767D\u4E86\u5C31\u662F\u82F1\u6587\u9996\u5B57\u6BCD\u8F6C\u5927\u5199\uFF0C\u4E8E\u662F\u5C31\u5229\u7528JavaScript\u5199\u4E0B\u4E86\u8FD9\u4E2A\u5DE5\u5177\u3002</p></blockquote><ul><li>\u8F6C\u5927\u5199\uFF1A\u5168\u90E8\u5B57\u6BCD\u8F6C\u5927\u5199\u3002</li><li>\u8F6C\u5C0F\u5199\uFF1A\u5168\u90E8\u5B57\u6BCD\u8F6C\u5C0F\u5199\u3002</li><li>\u9996\u5B57\u6BCD\u5927\u5199\uFF1A\u82F1\u6587\u53E5\u5B50\u4E2D\u6BCF\u4E2A\u5355\u8BCD\u7684\u7B2C\u4E00\u4E2A\u5B57\u6BCD\u8F6C\u6210\u5927\u5199\uFF0C\u5176\u5B83\u5B57\u6BCD\u8F6C\u6210\u5C0F\u5199\u3002\u4F8B\u5982\uFF1Athis is my girl\u8F6C\u6362\u540E\u4E3A\uFF1AThis Is My Girl</li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/EnglistConvert.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=EnglistConvert.a560eda5.mjs.map
