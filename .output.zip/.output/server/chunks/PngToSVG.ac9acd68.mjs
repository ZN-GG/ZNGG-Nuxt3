import { defineComponent, withAsyncContext, ref, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrIncludeBooleanAttr, ssrLooseContain, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "PngToSVG",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      ([__temp, __restore] = withAsyncContext(() => import('./png_to_svg_wasm.368901b1.mjs')), __temp = await __temp, __restore(), __temp).default;
      ([__temp, __restore] = withAsyncContext(() => import('./png_to_svg_wasm.368901b1.mjs')), __temp = await __temp, __restore(), __temp).get_svg;
      ([__temp, __restore] = withAsyncContext(() => import('svgo').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      ([__temp, __restore] = withAsyncContext(() => import('copy-to-clipboard').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const isZip = ref(false);
      useNuxtApp();
      const emptyData = '<p style="line-height:18rem;text-align:center;">SVG\u5C55\u793A\u533A\u57DF</p>';
      const svgData = ref("");
      useHead({
        title: "Png\u8F6CSVG",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "Png\u8F6CSVG,\u5728\u7EBF\u5C06PNG\u8F6C\u6362\u6210SVG\u683C\u5F0F,\u514D\u8D39PNG\u8F6C\u6362\u6210SVG,Png to SVG,png conver to svg"
          },
          {
            name: "description",
            content: "\u4E00\u4E2A\u53EF\u4EE5\u5728\u7EBF\u5C06PNG\u56FE\u7247\u8F6C\u6362\u6210SVG\u683C\u5F0F\u7684\u5DE5\u5177\u3002A tool that can convert PNG images to SVG format online."
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white min-h-screen"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">Png\u8F6CSVG</h1></div></div></div></section><div class="container px-4 mx-auto py-6"><div class="form-group"><div class="text-center relative py-12 mb-4 border-2 hover:bg-gray-100 custom-font-14 rounded" id="fileInput"><span>\u62D6\u62FD\u6587\u4EF6\u5230\u8FD9\u91CC\u6216\u8005\u70B9\u51FB\u9009\u62E9\u6587\u4EF6</span><input type="file" id="file" accept="image/*" style="${ssrRenderStyle({
          "opacity": "0",
          "position": "absolute",
          "cursor": "pointer",
          "width": "100%",
          "height": "100%",
          "left": "0",
          "top": "0"
        })}"></div></div><div class="flex items-center pl-3"><input id="react-checkbox-list" type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(isZip)) ? ssrLooseContain(unref(isZip), null) : unref(isZip)) ? " checked" : ""} class="w-4 h-4 text-blue-600 bg-gray-100 rounded border-gray-300 focus:ring-blue-500 focus:ring-2"><label for="react-checkbox-list" class="py-3 ml-2 w-full text-sm font-medium text-gray-900">\u538B\u7F29SVG\uFF08\u5F00\u542F\u538B\u7F29\u540E\u8BF7\u52FF\u4E0A\u4F20\u8FC7\u5927\u7684Png\uFF0C\u4F1A\u5361\u6B7B\u3002\uFF09</label></div><div class="flex flex-wrap"><div class="w-full md:w-6/12 md:pr-2"><div class="w-full h-72 object-contain border-2">${unref(svgData) == "" ? emptyData : unref(svgData)}</div></div><div class="w-full md:w-6/12 md:pl-2 mt-4 md:mt-0"><textarea class="w-full bg-gray-100 outline-none p-2 h-72 text-gray-700 custom-font-14" name="" id="" cols="30" rows="10">${ssrInterpolate(unref(svgData))}</textarea></div></div><div class="flex flex-row flex-wrap justify-around"><div></div><div class="flex flex-row flex-wrap"><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none leading"> \u590D\u5236 </button></div></div><section class="w-full container px-4 mx-auto py-12 bg-white rounded-l mb-12"><div class="text-xl md:text-2xl font-black my-3">Q\uFF1A\u4E3A\u4EC0\u4E48\u8981\u505A\u4E00\u4E2APng\u8F6CSVG\u7684\u5DE5\u5177\uFF1F </div><div class="text-base md:text-xl mt-3 mb-12">A\uFF1A\u4E0D\u77E5\u9053\uFF0C\u505A\u5B8C\u624D\u53D1\u73B0<span class="inline-block bg-orange-400 px-1 mx-1">\u6CA1\u5565\u7528</span>\u3002 </div><div class="text-xl md:text-2xl font-black my-3">Q\uFF1A<span class="inline-block bg-yellow-300">\u4E0D\u8981</span> \u505A\u7684\u4E8B\u60C5\u6709\u54EA\u4E9B\uFF1F </div><div class="text-base md:text-xl my-12">A\uFF1A\u5343\u4E07\u522B\u8F6C\u6362\u592A\u5927\u7684png\u56FE\uFF0C\u5426\u5219\u5C31\u7B49\u7740\u5361\u6B7B\u5427\u3002\u8F6C\u6362\u4E00\u4E2A\u5C0F\u56FE\u6807\u5C31\u5F97\u4E86\u3002 </div></section></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/PngToSVG.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=PngToSVG.ac9acd68.mjs.map
