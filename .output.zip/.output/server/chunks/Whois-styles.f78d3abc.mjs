const Whois_vue_vue_type_style_index_0_scoped_a0695167_lang = '.searchBtn[data-v-a0695167]:before{border:6px solid transparent;border-right-color:#000;content:"";position:absolute;right:100%;top:38%}';

const WhoisStyles_f78d3abc = [Whois_vue_vue_type_style_index_0_scoped_a0695167_lang];

export { WhoisStyles_f78d3abc as default };
//# sourceMappingURL=Whois-styles.f78d3abc.mjs.map
