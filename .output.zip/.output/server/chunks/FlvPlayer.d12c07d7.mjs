import { u as useHead, _ as __nuxt_component_0$2 } from './server.mjs';
import { defineComponent, ref, mergeProps, withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_0 } from './XGPlayer.fbdb72c2.mjs';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FlvPlayer",
  __ssrInlineRender: true,
  setup(__props) {
    const videoUrl = ref("");
    ref(null);
    useHead({
      title: "Flv\u5728\u7EBF\u64AD\u653E\u5668",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "Flv\u5728\u7EBF\u64AD\u653E,flv\u76F4\u64AD\u64AD\u653E\u5668,flv\u76F4\u64AD\u6D4B\u8BD5,mp4\u64AD\u653E\u5668,mp4\u5728\u7EBF\u64AD\u653E,\u5728\u7EBF\u64AD\u653E\u5668" },
        { name: "description", content: "\u6D4B\u8BD5flv\u62C9\u6D41\u4E13\u7528\u7684\u64AD\u653E\u5668\uFF0Cflv\u76F4\u64AD\u662F\u4E00\u79CD\u7A33\u5B9A\u597D\u7528\u7684\u76F4\u64AD\u62C9\u6D41\u65B9\u6848\uFF0C\u6240\u4EE5\u4E13\u95E8\u505A\u4E86\u8FD9\u6837\u4E00\u4E2A\u64AD\u653E\u5668\u7528\u4E8E\u6D4B\u8BD5flv\u76F4\u64AD\u62C9\u6D41\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white" }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">Flv\u5728\u7EBF\u64AD\u653E\u5668</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12"><div class="flex w-full"><div class="w-full md:w-9/12"><div class="video-player-box w-full bg-black"><video class="absolute w-full h-full" controls autoplay></video></div></div><div class="hidden md:flex flex-wrap items-start md:w-3/12 bg-black"><div class="w-full"><p class="p-2 text-lg text-white font-bold hover:filter">\u66F4\u591A\u63A8\u8350\uFF1A</p><div class="px-2 py-4 cursor-pointer"><img${ssrRenderAttr("src", _imports_0)}></div><div class="px-2 py-4 cursor-pointer">`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/tool/detail/NPlayer" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p class="text-2xl text-white font-bold"${_scopeId}> NPlayer </p>`);
          } else {
            return [
              createVNode("p", { class: "text-2xl text-white font-bold" }, " NPlayer ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div><div class="flex flex-wrap justify-between my-2 items-center"><div class="w-full md:flex-1 md:pr-2"><input class="bg-gray-200 outline-none px-2 py-1 w-full" type="text" placeholder="\u8BF7\u8F93\u5165\u89C6\u9891\u5730\u5740"${ssrRenderAttr("value", videoUrl.value)}></div><div class="flex flex-wrap w-full md:w-auto my-2 md:my-0 justify-between"><div class="cursor-pointer py-1 px-4 bg-blue-500 text-gray-100 rounded md:ml-2">\u6E05\u7A7A </div><div class="cursor-pointer ml-2 py-1 px-4 bg-blue-500 text-gray-100 rounded">\u8F7D\u5165 </div><div class="cursor-pointer ml-2 py-1 px-4 bg-blue-500 text-gray-100 rounded">\u5F00\u59CB </div><div class="cursor-pointer ml-2 py-1 px-4 bg-blue-500 text-gray-100 rounded">\u6682\u505C </div><div class="cursor-pointer ml-2 py-1 px-4 bg-blue-500 text-gray-100 rounded">\u9500\u6BC1 </div></div></div></section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({ "max-width": "none" })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u4E13\u4E3AFlv\u76F4\u64AD\u62C9\u6D41\u6D4B\u8BD5\u800C\u6253\u9020\u7684\u64AD\u653E\u5668\uFF0C\u540C\u65F6\u652F\u6301mp4\u7B49\u89C6\u9891\u683C\u5F0F\u7684\u64AD\u653E\u3002\uFF08\u4E0D\u652F\u6301m3u8\uFF09</p></blockquote><ul><li>\u652F\u6301\u683C\u5F0F\uFF1A&#39;mse&#39;, &#39;mpegts&#39;, &#39;m2ts&#39;, &#39;flv&#39; \u548C &#39;mp4&#39;</li><li>\u4E0D\u652F\u6301m3u8!!!</li><li>m3u8\u64AD\u653E\u5668\u6B63\u51C6\u5907\u5F00\u53D1...</li><li>\u57FA\u4E8Empegts\uFF1A<a href="https://github.com/xqq/mpegts.js" target="_blank">https://github.com/xqq/mpegts.js</a></li></ul></article></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/FlvPlayer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=FlvPlayer.d12c07d7.mjs.map
