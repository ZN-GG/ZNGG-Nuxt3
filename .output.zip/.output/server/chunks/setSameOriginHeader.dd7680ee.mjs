function setSameOriginHeader(req, res, next) {
  const uList = [
    "/tool/detail/DownloadM3U8"
  ];
  if (uList.indexOf(req.url) > -1) {
    res == null ? void 0 : res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
    res == null ? void 0 : res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
    res == null ? void 0 : res.setHeader("cross-origin-resource-policy", "cross-origin");
  }
  next();
}

export { setSameOriginHeader as default };
//# sourceMappingURL=setSameOriginHeader.dd7680ee.mjs.map
