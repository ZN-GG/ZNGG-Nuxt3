import { __tla as __tla$1, h as defineStore } from './server.mjs';

let userStore;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  userStore = defineStore("user", {
    state() {
      return {
        showLogin: false,
        isLogin: false
      };
    }
  });
});

export { __tla as _, userStore as u };
//# sourceMappingURL=user.75451490.mjs.map
