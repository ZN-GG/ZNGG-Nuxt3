import { _ as __tla$1, r as request } from './request.066d4a9e.mjs';

let api;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const article = {
    getDetail(id) {
      return request.get("/portal/article/" + id);
    },
    getList(page, size, category) {
      let c = category ? category + "/" : "";
      return request.get("/portal/article/" + c + page + "/" + size);
    },
    getCategories() {
      return request.get("/portal/article_category");
    },
    postArticle(params) {
      return request.post("/user/article", params);
    },
    updateArticle(params) {
      return request.put("/user/article", params);
    },
    getUserList(page, size, category) {
      let c = category ? category + "/" : "";
      return request.get("/user/article/list/" + c + page + "/" + size);
    }
  };
  const user = {
    login(params, captcha, captcha_key) {
      return request.post("/user/user/" + captcha + "/" + captcha_key, params);
    },
    getInfo() {
      return request.get("/user/user/info");
    },
    register(params, email_code, captcha_code, captcha_key) {
      return request.post("/user/user?email_code=" + email_code + "&captcha_code=" + captcha_code + "&captcha_uuid=" + captcha_key, params);
    },
    sendEmailCaptcha(email) {
      return request.get("/user/user/email_verify_code?type=register&email=" + email);
    }
  };
  const upload = {
    uploadImage(params) {
      return request.post("/user/image", params);
    },
    uploadImageCover(params) {
      return request.post("/user/image/cover", params);
    }
  };
  const fun = {
    stringToTimestamp(str) {
      return request.get("/api/common/stringToTimestamp/v1", {
        str
      });
    },
    getWhois(domain) {
      return request.get("/api/common/whois/" + domain);
    },
    wordConvert(domain) {
      return request.post("/api/common//office/wordConvert");
    }
  };
  const tool = {
    getCategories() {
      return request.get("/portal/tool_category");
    },
    getList(page, size, category) {
      let c = category ? category + "/" : "";
      return request.get("/portal/tool/" + c + page + "/" + size);
    }
  };
  const web = {
    getFriendLinks() {
      return request.get("/portal/web/friendlyLinks");
    }
  };
  api = {
    article,
    user,
    upload,
    fun,
    tool,
    web
  };
});

export { __tla as _, api as a };
//# sourceMappingURL=api.f18d44dd.mjs.map
