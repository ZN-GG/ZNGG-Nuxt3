const LeftContents_vue_vue_type_style_index_0_scoped_b89894fa_lang = ".left-ul>li>a[data-v-b89894fa]{align-items:center;cursor:pointer;display:flex;font-weight:700;line-height:2.5rem;padding-left:.75rem;padding-right:.75rem}.left-ul>li[data-v-b89894fa]:hover{--tw-bg-opacity:1;background-color:#e5e7eb;background-color:rgb(229 231 235/var(--tw-bg-opacity));border-radius:.25rem}.left-ul>li.active>a[data-v-b89894fa]{--tw-text-opacity:1;color:#2563eb;color:rgb(37 99 235/var(--tw-text-opacity))}";

const LeftContentsStyles_83af4ea7 = [LeftContents_vue_vue_type_style_index_0_scoped_b89894fa_lang];

export { LeftContentsStyles_83af4ea7 as default };
//# sourceMappingURL=LeftContents-styles.83af4ea7.mjs.map
