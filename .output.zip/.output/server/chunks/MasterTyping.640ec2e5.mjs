import { __tla as __tla$1, u as useHead } from './server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { useSSRContext } from 'vue';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let MasterTyping;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  useHead({
    title: "\u6253\u5B57\u7EC3\u4E60\u5DE5\u5177",
    titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
    meta: [
      {
        name: "Keywords",
        content: "\u6253\u5B57\u7EC3\u4E60\u5668,\u5728\u7EBF\u6253\u5B57\u7EC3\u4E60"
      },
      {
        name: "description",
        content: "\u4E00\u4E2A\u514D\u8D39\u7684\u5728\u7EBF\u6253\u5B57\u7EC3\u4E60\u5DE5\u5177"
      }
    ]
  });
  const _sfc_main = {};
  function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
    _push(`<div${ssrRenderAttrs(_attrs)}><div><div class="main-content"><div class="heading"><span>\u{1F579}\uFE0F\xA0</span><span>G</span><span>A</span><span>M</span><span>E</span><span>Z</span><span>O</span><span>N</span><span>E</span></div><div class="search-container"><input type="text" class="search-input" placeholder="Search" onkeyup="search_game()" id="searchbar"><div class="search-btn"><i class="fa fa-search" aria-hidden="true"></i></div></div><br><ul class="project-list"></ul><div class="pagination"><button id="prev-page-tile" onclick="goToPreviousPage()">Previous</button><div class="pagination_section"></div><button id="next-page-tile" onclick="goToNextPage()">Next</button></div></div></div><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"></div>`);
  }
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/MasterTyping.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  MasterTyping = _export_sfc(_sfc_main, [
    [
      "ssrRender",
      _sfc_ssrRender
    ]
  ]);
});

export { __tla, MasterTyping as default };
//# sourceMappingURL=MasterTyping.640ec2e5.mjs.map
