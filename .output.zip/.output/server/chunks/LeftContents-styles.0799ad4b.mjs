const LeftContents_vue_vue_type_style_index_0_scoped_6a242011_lang = ".left-ul>li>a[data-v-6a242011]{align-items:center;cursor:pointer;display:flex;font-weight:700;line-height:2.5rem;padding-left:.75rem;padding-right:.75rem}.left-ul>li[data-v-6a242011]:hover{--tw-bg-opacity:1;background-color:#e5e7eb;background-color:rgb(229 231 235/var(--tw-bg-opacity));border-radius:.25rem}.left-ul>li.active>a[data-v-6a242011]{--tw-text-opacity:1;color:#2563eb;color:rgb(37 99 235/var(--tw-text-opacity))}";

const LeftContentsStyles_0799ad4b = [LeftContents_vue_vue_type_style_index_0_scoped_6a242011_lang];

export { LeftContentsStyles_0799ad4b as default };
//# sourceMappingURL=LeftContents-styles.0799ad4b.mjs.map
