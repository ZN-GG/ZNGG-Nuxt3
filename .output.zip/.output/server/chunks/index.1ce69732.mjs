import { u as useHead } from './server.mjs';
import { defineComponent, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "\u53CB\u94FE",
      titleTemplate: (title) => `${title} - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "\u53CB\u60C5\u94FE\u63A5\uFF0C\u4F18\u8D28\u7F51\u7AD9\u63A8\u8350" },
        { name: "description", content: "\u53CB\u60C5\u94FE\u63A5\u9875\u9762\uFF0C\u9AD8\u8D28\u91CF\u7F51\u7AD9\u63A8\u8350\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white min-h-screen" }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><p class="text-2xl text-black">\u53CB\u60C5\u94FE\u63A5</p></div></div></div></section><section><div class="container px-4 mx-auto"><div class="py-5"><div class="grid md:grid-cols-3 gap-6"><ul class="w-full"><li class="hover:bg-gray-100 hover:text-gray-700 transition duration-300 ease-in-out p-3"><a href="https://www.qingqingblog.com/" target="_blank"><div class="flex items-start"><div class="grow"><p class="text-gray-800 font-bold mb-1">\u6768\u9752\u9752\u535A\u5BA2</p><p class="text-gray-500"> \u4F18\u79C0\u5973\u7AD9\u957F\uFF0C\u9AD8\u8D28\u91CF\u5E1D\u56FD\u6A21\u677F\u521B\u9020\u8005\u3002 </p></div></div></a></li><li class="hover:bg-gray-100 hover:text-gray-700 transition duration-300 ease-in-out p-3"><a href="https://www.usuuu.com/" target="_blank"><div class="flex items-start"><div class="grow"><p class="text-gray-800 font-bold mb-1">\u60A0\u60A0\u535A\u5BA2</p><p class="text-gray-500"> \u8BB0\u5F55\u4E00\u4E2A\u6587\u827A\u5973\u9752\u5E74\u7684IT\u4E4B\u8DEF\u3002 </p></div></div></a></li></ul><ul class="w-full"><li class="hover:bg-gray-100 hover:text-gray-700 transition duration-300 ease-in-out p-3"><a href="https://www.aqwdzy.com/" target="_blank"><div class="flex items-start"><div class="grow"><p class="text-gray-800 font-bold mb-1">\u901A\u5929\u6280\u672F\u7F51</p><p class="text-gray-500"> \u805A\u7126\u524D\u6CBF\u6280\u672F\uFF0C\u63A2\u7D22\u884C\u4E1A\u672A\u6765\u3002 </p></div></div></a></li></ul><ul class="w-full"><li class="hover:bg-gray-100 hover:text-gray-700 transition duration-300 ease-in-out p-3"><a href="https://hu60.cn" target="_blank"><div class="flex items-start"><div class="grow"><p class="text-gray-800 font-bold mb-1">\u864E\u7EFF\u6797</p><p class="text-gray-500"> \u864E\u7EFF\u6797 \u7F16\u7A0B\u5B66\u9662\u3002 </p></div></div></a></li></ul></div></div></div></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/link/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.1ce69732.mjs.map
