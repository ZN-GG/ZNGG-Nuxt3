const Whois_vue_vue_type_style_index_0_scoped_eba7db56_lang = '.searchBtn[data-v-eba7db56]:before{border:6px solid transparent;border-right-color:#000;content:"";position:absolute;right:100%;top:38%}';

const WhoisStyles_5dd2b585 = [Whois_vue_vue_type_style_index_0_scoped_eba7db56_lang];

export { WhoisStyles_5dd2b585 as default };
//# sourceMappingURL=Whois-styles.5dd2b585.mjs.map
