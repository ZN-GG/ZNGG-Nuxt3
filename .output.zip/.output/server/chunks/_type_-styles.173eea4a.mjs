const _type__vue_vue_type_style_index_0_lang = "";

const _type_Styles_173eea4a = [_type__vue_vue_type_style_index_0_lang];

export { _type_Styles_173eea4a as default };
//# sourceMappingURL=_type_-styles.173eea4a.mjs.map
