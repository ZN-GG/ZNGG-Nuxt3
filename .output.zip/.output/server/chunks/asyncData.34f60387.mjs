import { ref, onServerPrefetch, unref } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, c as createError } from './server.mjs';

let useAsyncData;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const getDefault = () => null;
  useAsyncData = function useAsyncData2(...args) {
    var _a, _b, _c, _d, _e, _f, _g;
    const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
    if (typeof args[0] !== "string") {
      args.unshift(autoKey);
    }
    let [key, handler, options = {}] = args;
    if (typeof key !== "string") {
      throw new TypeError("[nuxt] [asyncData] key must be a string.");
    }
    if (typeof handler !== "function") {
      throw new TypeError("[nuxt] [asyncData] handler must be a function.");
    }
    options.server = (_a = options.server) != null ? _a : true;
    options.default = (_b = options.default) != null ? _b : getDefault;
    options.lazy = (_c = options.lazy) != null ? _c : false;
    options.immediate = (_d = options.immediate) != null ? _d : true;
    const nuxt = useNuxtApp();
    const getCachedData = () => nuxt.isHydrating ? nuxt.payload.data[key] : nuxt.static.data[key];
    const hasCachedData = () => getCachedData() !== void 0;
    if (!nuxt._asyncData[key]) {
      nuxt._asyncData[key] = {
        data: ref((_g = (_f = getCachedData()) != null ? _f : (_e = options.default) == null ? void 0 : _e.call(options)) != null ? _g : null),
        pending: ref(!hasCachedData()),
        error: ref(nuxt.payload._errors[key] ? createError(nuxt.payload._errors[key]) : null)
      };
    }
    const asyncData = {
      ...nuxt._asyncData[key]
    };
    asyncData.refresh = asyncData.execute = (opts = {}) => {
      if (nuxt._asyncDataPromises[key]) {
        if (opts.dedupe === false) {
          return nuxt._asyncDataPromises[key];
        }
        nuxt._asyncDataPromises[key].cancelled = true;
      }
      if (opts._initial && hasCachedData()) {
        return getCachedData();
      }
      asyncData.pending.value = true;
      const promise = new Promise((resolve, reject) => {
        try {
          resolve(handler(nuxt));
        } catch (err) {
          reject(err);
        }
      }).then((result) => {
        if (promise.cancelled) {
          return nuxt._asyncDataPromises[key];
        }
        if (options.transform) {
          result = options.transform(result);
        }
        if (options.pick) {
          result = pick(result, options.pick);
        }
        asyncData.data.value = result;
        asyncData.error.value = null;
      }).catch((error) => {
        var _a2, _b2;
        if (promise.cancelled) {
          return nuxt._asyncDataPromises[key];
        }
        asyncData.error.value = error;
        asyncData.data.value = unref((_b2 = (_a2 = options.default) == null ? void 0 : _a2.call(options)) != null ? _b2 : null);
      }).finally(() => {
        if (promise.cancelled) {
          return;
        }
        asyncData.pending.value = false;
        nuxt.payload.data[key] = asyncData.data.value;
        if (asyncData.error.value) {
          nuxt.payload._errors[key] = createError(asyncData.error.value);
        }
        delete nuxt._asyncDataPromises[key];
      });
      nuxt._asyncDataPromises[key] = promise;
      return nuxt._asyncDataPromises[key];
    };
    const initialFetch = () => asyncData.refresh({
      _initial: true
    });
    const fetchOnServer = options.server !== false && nuxt.payload.serverRendered;
    if (fetchOnServer && options.immediate) {
      const promise = initialFetch();
      onServerPrefetch(() => promise);
    }
    const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
    Object.assign(asyncDataPromise, asyncData);
    return asyncDataPromise;
  };
  function pick(obj, keys) {
    const newObj = {};
    for (const key of keys) {
      newObj[key] = obj[key];
    }
    return newObj;
  }
});

export { __tla as _, useAsyncData as u };
//# sourceMappingURL=asyncData.34f60387.mjs.map
