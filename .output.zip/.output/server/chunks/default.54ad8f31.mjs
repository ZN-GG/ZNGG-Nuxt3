import { __tla as __tla$1, a as useNuxtApp, _ as __nuxt_component_0$1 } from './server.mjs';
import { defineComponent, ref, watch, mergeProps, unref, useSSRContext, withCtx, createTextVNode, toDisplayString, createVNode, h, computed } from 'vue';
import { _ as __tla$2, u as useCookie } from './cookie.fa7850ad.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { _ as __tla$3, r as request } from './request.59adbae7.mjs';
import { nanoid } from 'nanoid';
import { _ as __tla$4, u as userStore } from './user.8b90e898.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import { _ as __tla$5, a as __nuxt_component_0 } from './page.8271591f.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _default;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$5;
    } catch {
    }
  })()
]).then(async () => {
  const _imports_0 = "" + globalThis.__publicAssetsURL("logo-black.png");
  const _sfc_main$2 = defineComponent({
    __name: "Login",
    __ssrInlineRender: true,
    setup(__props) {
      const store = userStore();
      const isRegister = ref(false);
      const captchaUrl = ref("");
      const captchaUrlPic = ref("");
      const loginParams = ref({
        email: "",
        password: ""
      });
      const registerParams = {
        email: "",
        name: "",
        password: ""
      };
      const captcha = ref("");
      const captchaEmail = ref("");
      const captchaKey = ref("");
      const repassword = ref("");
      let uuid = nanoid(10);
      captchaKey.value = uuid;
      useNuxtApp();
      useCookie("token", {
        maxAge: 60 * 60 * 24 * 14
      });
      function refreshCaptcha() {
        captchaUrlPic.value = captchaUrl.value + captchaKey.value + "&t=" + new Date().getTime();
      }
      function toLogin() {
        isRegister.value = false;
        refreshCaptcha();
        clearData();
      }
      function clearData() {
        loginParams.value.email = "";
        loginParams.value.password = "";
        registerParams.email = "";
        registerParams.name = "";
        registerParams.password = "";
        captcha.value = "";
        captchaEmail.value = "";
      }
      watch(() => store.showLogin, (newStatus, oldStatus) => {
        if (newStatus) {
          captchaUrl.value = request.baseUrl + "/user/user/captcha?captcha_uuid=";
          toLogin();
        } else {
          captchaUrl.value = "";
        }
      }, {
        deep: true
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          style: unref(store).showLogin ? null : {
            display: "none"
          },
          class: "modal-show flex items-center w-full h-full fixed top-0 left-0 z-40 bg-gray-500 opacity-100 justify-center"
        }, _attrs))}><div style="${ssrRenderStyle(!unref(isRegister) ? null : {
          display: "none"
        })}" class="modal-content bg-white w-80 pt-12 p-4 relative rounded-md"><span class="right-0 top-0 absolute m-2 w-5 h-5 iconfont icon-close"></span><img class="left-0 top-0 w-20 absolute m-2"${ssrRenderAttr("src", _imports_0)} alt=""><p class="text-2xl font-semibold my-2">\u767B\u9646</p><input${ssrRenderAttr("value", unref(loginParams).email)} type="text" placeholder="\u90AE\u7BB1\u5730\u5740" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full"><input${ssrRenderAttr("value", unref(loginParams).password)} type="password" placeholder="\u5BC6\u7801" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full"><div class="flex items-center justify-around"><input${ssrRenderAttr("value", unref(captcha))} type="text" placeholder="\u9A8C\u8BC1\u7801" class="bg-gray-100 w-3 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 mr-2 flex-1"><img class="h-9 flex-1"${ssrRenderAttr("src", unref(captchaUrlPic))} crossorigin="anonymous"></div><button class="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 my-2"> \u767B\u9646 </button><div class="mt-2 flex justify-between"><p class="custom-font-12"> \u8FD8\u6CA1\u6709\u8D26\u53F7\uFF1F <span class="text-blue-600 cursor-pointer font-medium">\u7ACB\u5373\u6CE8\u518C</span></p><p class="custom-font-12"><a class="text-blue-600 cursor-pointer font-medium">\u5FD8\u8BB0\u5BC6\u7801?</a></p></div></div><div style="${ssrRenderStyle(unref(isRegister) ? null : {
          display: "none"
        })}" class="modal-content bg-white w-80 pt-12 p-4 relative rounded-md"><span class="right-0 top-0 absolute m-2 w-5 h-5 iconfont icon-close"></span><img class="left-0 top-0 w-20 absolute m-2"${ssrRenderAttr("src", _imports_0)} alt=""><p class="text-2xl font-semibold my-2">\u6CE8\u518C\u8D26\u53F7</p><input${ssrRenderAttr("value", registerParams.email)} type="text" placeholder="\u90AE\u7BB1\u5730\u5740" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full"><div class="flex"><input${ssrRenderAttr("value", unref(captchaEmail))} type="text" placeholder="\u90AE\u7BB1\u9A8C\u8BC1\u7801" class="bg-gray-100 w-3 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 mr-2 flex-1"><button class="flex-1 bg-blue-500 text-white p-2 my-2 custom-font-14 hover:bg-blue-600"> \u53D1\u9001 </button></div><input${ssrRenderAttr("value", registerParams.name)} type="text" placeholder="\u7528\u6237\u540D" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full"><input${ssrRenderAttr("value", registerParams.password)} type="password" placeholder="\u5BC6\u7801" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full"><input${ssrRenderAttr("value", unref(repassword))} type="password" placeholder="\u518D\u8F93\u4E00\u904D\u5BC6\u7801" class="bg-gray-100 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 w-full"><div class="flex items-center justify-around"><input${ssrRenderAttr("value", unref(captcha))} type="text" placeholder="\u9A8C\u8BC1\u7801" class="bg-gray-100 w-3 border-0 border-transparent focus:outline-none custom-font-14 text-gray-600 p-2 my-2 mr-2 flex-1"><img class="h-9 flex-1"${ssrRenderAttr("src", unref(captchaUrlPic))} crossorigin="anonymous"></div><button class="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 my-2"> \u6CE8\u518C </button><div class="mt-2 flex justify-between"><p class="custom-font-12"> \u5DF2\u6709\u8D26\u53F7\uFF1F <span class="text-blue-600 cursor-pointer font-medium">\u7ACB\u5373\u767B\u9646</span></p><p class="custom-font-12"><a class="text-blue-600 cursor-pointer font-medium">\u5FD8\u8BB0\u5BC6\u7801?</a></p></div></div></div>`);
      };
    }
  });
  const _sfc_setup$2 = _sfc_main$2.setup;
  _sfc_main$2.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Login.vue");
    return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
  };
  const _sfc_main$1 = defineComponent({
    __name: "Toolbar",
    __ssrInlineRender: true,
    setup(__props) {
      const token = useCookie("token");
      const store = userStore();
      const loginStatus = ref(false);
      const mobileMenuStatus = ref(false);
      if (typeof token.value != "undefined") {
        loginStatus.value = true;
      }
      watch(() => store.isLogin, (newStatus, oldStatus) => {
        loginStatus.value = newStatus;
      }, {
        deep: true
      });
      const dataList = ref([
        {
          link: "tool",
          name: "\u5DE5\u5177"
        },
        {
          link: "read",
          name: "\u6587\u7AE0"
        },
        {
          link: "nav",
          name: "\u5BFC\u822A"
        },
        {
          link: "link",
          name: "\u53CB\u94FE"
        }
      ]);
      function toggleMobileMenu() {
        mobileMenuStatus.value = !mobileMenuStatus.value;
      }
      return (_ctx, _push, _parent, _attrs) => {
        const _component_NuxtLink = __nuxt_component_0$1;
        const _component_nuxt_link = __nuxt_component_0$1;
        const _component_Login = _sfc_main$2;
        _push(`<header${ssrRenderAttrs(mergeProps({
          class: "shadow-md fixed top-0 w-full z-20"
        }, _attrs))} data-v-fb8cedea><div class="flex px-1 md:px-6 py-4 justify-between items-center" data-v-fb8cedea><div class="flex items-center" data-v-fb8cedea><div class="font-black inline text-xl cursor-pointer" data-v-fb8cedea><a href="/" data-v-fb8cedea><img${ssrRenderAttr("src", _imports_0)} class="w-20 h-8" alt="" srcset="" data-v-fb8cedea></a></div><ul class="menu ml-4 items-center hidden md:inline text-lg font-semibold pl-4" data-v-fb8cedea><li class="inline mx-2 cursor-pointer select-none" data-v-fb8cedea>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/",
          exact: ""
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u9996\u9875`);
            } else {
              return [
                createTextVNode("\u9996\u9875")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li><!--[-->`);
        ssrRenderList(dataList.value, (item, index) => {
          _push(`<li class="inline mx-2 cursor-pointer select-none" data-v-fb8cedea>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: {
              name: item.link
            }
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate(item.name)}`);
              } else {
                return [
                  createTextVNode(toDisplayString(item.name), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div><div class="flex items-center" data-v-fb8cedea><div class="login-group flex mx-2 lg:mx-4 custom-font-14 items-center leading-8" data-v-fb8cedea><i class="md:hidden cursor-pointer select-none mx-1 px-3 md:px-5 iconfont icon-ego-menu rounded-md" data-v-fb8cedea></i><p style="${ssrRenderStyle(!loginStatus.value ? null : {
          display: "none"
        })}" class="cursor-pointer select-none mx-1 px-3 md:px-5 text-white bg-blue-500 rounded-md" data-v-fb8cedea> \u767B\u5F55 </p>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/user",
          style: loginStatus.value ? null : {
            display: "none"
          },
          class: "cursor-pointer select-none mx-1 px-3 md:px-5 bg-gray-100 rounded-md"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` \u6211\u7684 `);
            } else {
              return [
                createTextVNode(" \u6211\u7684 ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
        _push(ssrRenderComponent(_component_Login, null, null, _parent));
        _push(`<div class="${ssrRenderClass([
          mobileMenuStatus.value ? " animation-mobile-bg-show" : "animation-mobile-bg-hidden pointer-events-none",
          "fixed modal-show z-30 w-full h-full border-t-2"
        ])}" data-v-fb8cedea><div class="${ssrRenderClass([
          mobileMenuStatus.value ? "animation-mobile-show" : "animation-mobile-hidden",
          "w-9/12 bg-white h-full right-0 absolute"
        ])}" data-v-fb8cedea><ul class="text-lg font-semibold" data-v-fb8cedea><li class="cursor-pointer select-none" data-v-fb8cedea>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          onClick: ($event) => toggleMobileMenu(),
          to: "/"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="m-2 p-2 mx-2 bg-gray-100" data-v-fb8cedea${_scopeId}>\u9996\u9875</div>`);
            } else {
              return [
                createVNode("div", {
                  class: "m-2 p-2 mx-2 bg-gray-100"
                }, "\u9996\u9875")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</li><!--[-->`);
        ssrRenderList(dataList.value, (item, index) => {
          _push(`<li class="cursor-pointer select-none" data-v-fb8cedea>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            onClick: ($event) => toggleMobileMenu(),
            to: {
              name: item.link
            }
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="m-2 p-2 mx-2 bg-gray-100" data-v-fb8cedea${_scopeId}>${ssrInterpolate(item.name)}</div>`);
              } else {
                return [
                  createVNode("div", {
                    class: "m-2 p-2 mx-2 bg-gray-100"
                  }, toDisplayString(item.name), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div><div class="w-3/12 h-full" data-v-fb8cedea></div></div></header>`);
      };
    }
  });
  const _sfc_setup$1 = _sfc_main$1.setup;
  _sfc_main$1.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Toolbar.vue");
    return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
  };
  const __nuxt_component_0$2 = _export_sfc(_sfc_main$1, [
    [
      "__scopeId",
      "data-v-fb8cedea"
    ]
  ]);
  const __nuxt_component_1 = defineComponent({
    name: "NuxtLoadingIndicator",
    props: {
      throttle: {
        type: Number,
        default: 200
      },
      duration: {
        type: Number,
        default: 2e3
      },
      height: {
        type: Number,
        default: 3
      },
      color: {
        type: String,
        default: "repeating-linear-gradient(to right,#00dc82 0%,#34cdfe 50%,#0047e1 100%)"
      }
    },
    setup(props, { slots }) {
      const indicator = useLoadingIndicator({
        duration: props.duration,
        throttle: props.throttle
      });
      const nuxtApp = useNuxtApp();
      nuxtApp.hook("page:start", indicator.start);
      nuxtApp.hook("page:finish", indicator.finish);
      return () => h("div", {
        class: "nuxt-loading-indicator",
        style: {
          position: "fixed",
          top: 0,
          right: 0,
          left: 0,
          pointerEvents: "none",
          width: `${indicator.progress.value}%`,
          height: `${props.height}px`,
          opacity: indicator.isLoading.value ? 1 : 0,
          background: props.color,
          backgroundSize: `${100 / indicator.progress.value * 100}% auto`,
          transition: "width 0.1s, height 0.4s, opacity 0.4s",
          zIndex: 999999
        }
      }, slots);
    }
  });
  function useLoadingIndicator(opts) {
    const progress = ref(0);
    const isLoading = ref(false);
    computed(() => 1e4 / opts.duration);
    let _timer = null;
    let _throttle = null;
    function start() {
      clear();
      progress.value = 0;
      isLoading.value = true;
      if (opts.throttle)
        ;
    }
    function finish() {
      progress.value = 100;
      _hide();
    }
    function clear() {
      clearInterval(_timer);
      clearTimeout(_throttle);
      _timer = null;
      _throttle = null;
    }
    function _hide() {
      clear();
    }
    return {
      progress,
      isLoading,
      start,
      finish,
      clear
    };
  }
  const _sfc_main = {};
  function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
    const _component_Toolbar = __nuxt_component_0$2;
    const _component_NuxtLoadingIndicator = __nuxt_component_1;
    const _component_NuxtPage = __nuxt_component_0;
    _push(`<div${ssrRenderAttrs(_attrs)}>`);
    _push(ssrRenderComponent(_component_Toolbar, null, null, _parent));
    _push(ssrRenderComponent(_component_NuxtLoadingIndicator, null, null, _parent));
    _push(ssrRenderComponent(_component_NuxtPage, {
      class: "mt-16"
    }, null, _parent));
    _push(`</div>`);
  }
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  _default = _export_sfc(_sfc_main, [
    [
      "ssrRender",
      _sfc_ssrRender
    ]
  ]);
});

export { __tla, _default as default };
//# sourceMappingURL=default.54ad8f31.mjs.map
