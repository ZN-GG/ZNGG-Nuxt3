const M3U8V2Pro_vue_vue_type_style_index_0_scoped_452e3b48_lang = ".item-box[data-v-452e3b48]{max-height:24rem;min-height:8rem}.item-box[data-v-452e3b48]::-webkit-scrollbar{height:10px;width:10px}.item-box[data-v-452e3b48]::-webkit-scrollbar-thumb{background-color:#49b1f5;background-image:-webkit-linear-gradient(45deg,hsla(0,0%,100%,.4) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.4) 0,hsla(0,0%,100%,.4) 75%,transparent 0,transparent);border-radius:32px}.item-box[data-v-452e3b48]::-webkit-scrollbar-track{background-color:#dbeffd;border-radius:32px}.btn-bg-save[data-v-452e3b48]{background-color:#49b1f5;background-image:-webkit-linear-gradient(45deg,hsla(0,0%,100%,.4) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.4) 0,hsla(0,0%,100%,.4) 75%,transparent 0,transparent)}";

const M3U8V2ProStyles_487f5754 = [M3U8V2Pro_vue_vue_type_style_index_0_scoped_452e3b48_lang];

export { M3U8V2ProStyles_487f5754 as default };
//# sourceMappingURL=M3U8V2Pro-styles.487f5754.mjs.map
