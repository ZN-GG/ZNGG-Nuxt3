import { defineComponent, withAsyncContext, ref, watch, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderStyle, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let TextSecret;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main = defineComponent({
    __name: "TextSecret",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      const ZWSP = ([__temp, __restore] = withAsyncContext(() => import('./ZWSP.e88cbe23.mjs')), __temp = await __temp, __restore(), __temp).default;
      const show = ref(true);
      const data = ref({
        "textShow": "",
        "textHidden": "",
        "result": ""
      });
      ref("\u590D\u5236\u7ED3\u679C");
      useNuxtApp();
      ([__temp, __restore] = withAsyncContext(() => import('copy-to-clipboard').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      watch(() => data.value.result, (o, n) => {
        if (show.value) {
          data.value.textHidden = ZWSP.decode(data.value.result);
        }
      });
      useHead({
        title: "\u6587\u5B57\u91CC\u7684\u79D8\u5BC6",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u6587\u5B57\u91CC\u7684\u79D8\u5BC6,\u6587\u5B57\u9690\u5199\u672F,\u9690\u85CF\u6587\u5B57,\u9690\u85CF\u5B57\u7B26,\u628A\u7231\u60C5\u85CF\u8FDB\u6587\u5B57,\u96F6\u5BBD\u5B57\u7B26,\u5C5E\u4E8E\u4E24\u4E2A\u4EBA\u7684\u79D8\u5BC6"
          },
          {
            name: "description",
            content: "\u4E00\u4E2A\u80FD\u591F\u628A\u4E00\u6BB5\u6587\u5B57\u9690\u85CF\u4E8E\u53E6\u4E00\u7AEF\u6587\u5B57\u7684\u5DE5\u5177\uFF0C\u57FA\u4E8E\u96F6\u5BBD\u5B57\u7B26\u7684\u539F\u7406\uFF0C\u53EF\u4EE5\u628A\u4E00\u4E9B\u5C0F\u79D8\u5BC6\u85CF\u8D77\u6765\u53D1\u9001\u7ED9\u597D\u53CB\uFF0C\u8BA9ta\u6765\u672C\u7AD9\u89E3\u5BC6\u63ED\u6653\u7B54\u6848\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))} data-v-96532113><section class="bg-gray-100" data-v-96532113><div class="container px-4 mx-auto" data-v-96532113><div class="md:flex md:-mx-4 md:items-center py-8" data-v-96532113><div class="md:w-1/2 px-4" data-v-96532113><h1 class="text-2xl text-black" data-v-96532113>\u6587\u5B57\u91CC\u7684\u79D8\u5BC6</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12" data-v-96532113><div data-v-96532113><div class="text-xl md:text-2xl font-black my-6" data-v-96532113><span class="${ssrRenderClass([
          unref(show) ? "bg-yellow-300" : "",
          "inline-block p-2 cursor-pointer"
        ])}" data-v-96532113>\u663E\u793A\u79D8\u5BC6</span><span class="${ssrRenderClass([
          unref(show) ? "" : "bg-yellow-300",
          "inline-block mx-2 p-2 cursor-pointer"
        ])}" data-v-96532113>\u9690\u85CF\u79D8\u5BC6</span></div></div><div style="${ssrRenderStyle(unref(show) ? null : {
          display: "none"
        })}" data-v-96532113><div class="flex-container" data-v-96532113><div class="flex-item-lg" data-v-96532113><div class="textarea-container" data-v-96532113><textarea placeholder="\u8BF7\u7C98\u8D34\u5F85\u52A0\u5BC6\u7684\u6587\u672C" data-v-96532113>${ssrInterpolate(unref(data).result)}</textarea></div></div><div class="flex-item-sm" data-v-96532113><div class="blue-bar relative" data-v-96532113></div></div><div class="flex-item-lg" data-v-96532113><div class="textarea-container" data-v-96532113><textarea placeholder="\u8FD9\u91CC\u662F\u5C0F\u79D8\u5BC6\u54E6\uFF01 (\u{1F606})" readonly class="readonly" data-v-96532113>${ssrInterpolate(unref(data).textHidden)}</textarea></div></div></div></div><div style="${ssrRenderStyle(!unref(show) ? null : {
          display: "none"
        })}" data-v-96532113><div class="flex-container" data-v-96532113><div class="flex-item-lg" data-v-96532113><div class="textarea-container" data-v-96532113><textarea placeholder="\u8F93\u5165\u8981\u663E\u793A\u7684\u6587\u5B57" data-v-96532113>${ssrInterpolate(unref(data).textShow)}</textarea></div><div class="textarea-container" data-v-96532113><textarea placeholder="\u8F93\u5165\u8981\u9690\u85CF\u7684\u6587\u5B57 (\u{1F606})" data-v-96532113>${ssrInterpolate(unref(data).textHidden)}</textarea></div></div><div class="flex-item-sm" data-v-96532113><div class="blue-bar relative" data-v-96532113></div><div class="blue-bar relative" data-v-96532113></div></div><div class="flex-item-lg" data-v-96532113><div class="textarea-container" data-v-96532113><textarea readonly placeholder="\u7ED3\u679C" class="readonly" data-v-96532113>${ssrInterpolate(unref(data).result)}</textarea></div></div></div><div class="flex flex-row flex-wrap" data-v-96532113><button class="flex my-2 mr-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none" data-v-96532113> \u4E00\u952E\u9690\u85CF </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-red-800 shadow-lg focus:outline-none hover:bg-red-900 hover:shadow-none" data-v-96532113> \u6E05\u7A7A </button></div></div></section><section class="bg-white w-full container mx-auto px-4 py-6" data-v-96532113><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}" data-v-96532113><h4 data-v-96532113>\u4E0D\u80FD\u8BF4\u7684 <span class="text-xl md:text-2xl font-black bg-green-400 px-2" data-v-96532113>\u79D8\u5BC6</span> \uFF1A</h4><blockquote data-v-96532113><p data-v-96532113>\u8FD9\u662F\u4E00\u4E2A\u80FD\u591F\u628A\u6587\u5B57\u9690\u85CF\u5728\u6587\u5B57\u4E2D\u7684\u6709\u8DA3\u5C0F\u5DE5\u5177\uFF0C\u60A8\u53EF\u4EE5\u8F93\u5165\u8981\u5B9E\u73B0\u51FA\u6765\u7684\u6587\u5B57\uFF0C\u7136\u540E\u8F93\u5165\u8981\u9690\u85CF\u7684\u6587\u5B57\uFF0C\u70B9\u51FB\u4E00\u952E\u9690\u85CF\u540E\u4F1A\u628A\u751F\u6210\u597D\u7684\u79D8\u5BC6\u6587\u5B57\u590D\u5236\u4E0B\u6765\uFF0C\u60A8\u53EF\u4EE5\u5728\u5176\u4ED6\u793E\u4EA4\u8F6F\u4EF6\u7684\u804A\u5929\u6846\u4E2D\u7C98\u8D34\u5E76\u53D1\u9001\u7ED9\u597D\u53CB\uFF0C\u8BA9ta\u6765\u672C\u7AD9\u89E3\u5BC6\u5427\u3002 </p></blockquote><ul data-v-96532113><li data-v-96532113>\u70B9\u51FB\u9690\u85CF\u79D8\u5BC6\u5373\u53EF\u8FDB\u5165\u9690\u85CF\u6A21\u5F0F</li><li data-v-96532113>\u70B9\u51FB\u663E\u793A\u79D8\u5BC6\u5373\u53EF\u8FDB\u5165\u89E3\u5BC6\u6A21\u5F0F\uFF08\u9ED8\u8BA4\uFF09</li><li data-v-96532113>\u4E3E\u4F8B\uFF1A\u70B9\u51FB&quot;\u9690\u85CF\u79D8\u5BC6&quot;\u540E\uFF0C\u663E\u793A\u6587\u5B57\u8F93\u5165\u6C88\u4F73\u5B9C\uFF0C\u9690\u85CF\u6587\u5B57\u8F93\u5165\u6211\u7231\u4F60\uFF0C\u70B9\u51FB\u4E00\u952E\u9690\u85CF\u540E\u7C98\u8D34\u53D1\u9001\u7ED9\u597D\u53CB\uFF0C\u8BA9ta\u6765\u89E3\u5BC6\u67E5\u770B\u5C5E\u4E8E\u4F60\u4EEC\u7684\u5C0F\u79D8\u5BC6\u5427\u3002</li><li data-v-96532113>\u672C\u5DE5\u5177\u4EC5\u9650\u5A31\u4E50\uFF0C\u5207\u52FF\u7528\u4F5C\u975E\u6CD5\u7528\u9014\uFF01</li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/TextSecret.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  TextSecret = _export_sfc(_sfc_main, [
    [
      "__scopeId",
      "data-v-96532113"
    ]
  ]);
});

export { __tla, TextSecret as default };
//# sourceMappingURL=TextSecret.228810d9.mjs.map
