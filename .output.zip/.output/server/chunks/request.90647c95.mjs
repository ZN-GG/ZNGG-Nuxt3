import { __tla as __tla$1 } from './server.mjs';
import { _ as __tla$2, u as useCookie } from './cookie.c979c833.mjs';

let request;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })()
]).then(async () => {
  const baseUrl = "https://api.zngg.net";
  const version = "19";
  const errorResponse = {
    success: false,
    code: 0,
    message: "",
    data: null
  };
  const get = async (url, params = {}) => {
    try {
      const token = useCookie("token");
      const res = await $fetch(baseUrl + url, {
        headers: {
          "Authorization": token.value,
          "version": version
        },
        method: "GET",
        params
      });
      return res;
    } catch (error) {
      errorResponse.message = error;
      return errorResponse;
    }
  };
  const post = async (url, params = {}) => {
    try {
      const token = useCookie("token");
      const res = await $fetch(baseUrl + url, {
        headers: {
          "Authorization": token.value
        },
        method: "POST",
        body: params
      });
      return res;
    } catch (error) {
      errorResponse.message = "" + error;
      return errorResponse;
    }
  };
  const put = async (url, params = {}) => {
    try {
      const token = useCookie("token");
      const res = await $fetch(baseUrl + url, {
        headers: {
          "Authorization": token.value
        },
        method: "PUT",
        body: params
      });
      return res;
    } catch (error) {
      errorResponse.message = error;
      return errorResponse;
    }
  };
  request = {
    get,
    post,
    put,
    baseUrl
  };
});

export { __tla as _, request as r };
//# sourceMappingURL=request.90647c95.mjs.map
