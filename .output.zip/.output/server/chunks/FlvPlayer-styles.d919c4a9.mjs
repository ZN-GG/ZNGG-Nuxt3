const FlvPlayer_vue_vue_type_style_index_0_lang = ".video-player-box{padding-bottom:66.666666%;position:relative}";

const FlvPlayerStyles_d919c4a9 = [FlvPlayer_vue_vue_type_style_index_0_lang];

export { FlvPlayerStyles_d919c4a9 as default };
//# sourceMappingURL=FlvPlayer-styles.d919c4a9.mjs.map
