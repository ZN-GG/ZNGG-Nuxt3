const NPlayer_vue_vue_type_style_index_0_lang = ".video-player-box{padding-bottom:66.666666%;position:relative}";

const NPlayerStyles_eceed04a = [NPlayer_vue_vue_type_style_index_0_lang];

export { NPlayerStyles_eceed04a as default };
//# sourceMappingURL=NPlayer-styles.eceed04a.mjs.map
