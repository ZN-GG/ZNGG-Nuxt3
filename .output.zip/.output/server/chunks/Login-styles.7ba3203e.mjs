const Login_vue_vue_type_style_index_0_scoped_6517a4a9_lang = ".modal-show[data-v-6517a4a9]{-webkit-backdrop-filter:saturate(180%) blur(25px);backdrop-filter:saturate(180%) blur(25px);background:rgba(0,0,0,.35)}";

const LoginStyles_7ba3203e = [Login_vue_vue_type_style_index_0_scoped_6517a4a9_lang];

export { LoginStyles_7ba3203e as default };
//# sourceMappingURL=Login-styles.7ba3203e.mjs.map
