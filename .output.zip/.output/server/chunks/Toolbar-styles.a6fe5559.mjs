const Toolbar_vue_vue_type_style_index_0_scoped_fb8cedea_lang = "header[data-v-fb8cedea]{background:#fff}.menu>li[data-v-fb8cedea]:hover,.router-link-active[data-v-fb8cedea],.router-link-exact-active[data-v-fb8cedea]{color:#3955f6;font-weight:900}.icon-category[data-v-fb8cedea]{font-size:24px}";

const ToolbarStyles_a6fe5559 = [Toolbar_vue_vue_type_style_index_0_scoped_fb8cedea_lang];

export { ToolbarStyles_a6fe5559 as default };
//# sourceMappingURL=Toolbar-styles.a6fe5559.mjs.map
