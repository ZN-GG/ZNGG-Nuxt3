import { useSSRContext, defineComponent, ref, mergeProps, unref } from 'vue';
import { c as _export_sfc, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _imports_0 = "" + globalThis.__publicAssetsURL("img/NationalDayAvatar/tool-logo.png");
const _imports_1 = "" + globalThis.__publicAssetsURL("img/NationalDayAvatar/message.png");
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "NationalDayAvatar",
  __ssrInlineRender: true,
  setup(__props) {
    const sum = 15;
    ref(null);
    ref(null);
    let activeIndex = ref(1);
    let uploaded = ref(false);
    let isShowResult = ref(false);
    let resultData = ref("");
    useHead({
      title: "\u56FD\u5E86\u5934\u50CF\u751F\u6210\u5668",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "\u56FD\u5E86\u5934\u50CF\u751F\u6210\u5668,\u5728\u7EBF\u751F\u6210\u56FD\u5E86\u5934\u50CF,\u4E00\u952E\u5FAE\u4FE1\u56FD\u5E86\u5934\u50CF\u751F\u6210,\u5FAE\u4FE1\u5934\u50CF\u52A0\u4E94\u661F\u7EA2\u65D7,\u56FD\u5E86\u5FAE\u4FE1\u5934\u50CF" },
        { name: "description", content: "\u8FD9\u662F\u4E00\u4E2A\u4E00\u952E\u751F\u6210\u56FD\u5E86\u5934\u50CF\u7684\u5C0F\u7A0B\u5E8F\uFF0C\u4E0A\u4F20\u81EA\u5DF1\u5934\u50CF\u540E\u53EF\u4EE5\u9009\u62E9\u5408\u9002\u7684\u56FD\u5E86\u5934\u50CF\u6837\u5F0F\uFF0C\u968F\u540E\u4FDD\u5B58\u5934\u50CF\u5373\u53EF\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "main" }, _attrs))} data-v-dd38a14d><div class="container mx-auto" data-v-dd38a14d><img class="mx-auto mt-12 md:mt-28 tool-logo"${ssrRenderAttr("src", _imports_0)} alt="" data-v-dd38a14d></div><div class="mx-auto mt-8" data-v-dd38a14d><div class="flex items-center justify-center" data-v-dd38a14d><a class="prev" data-v-dd38a14d></a><div class="canvasAvatarBoxBorder p-1 relative" data-v-dd38a14d><div class="canvasAvatarBox" data-v-dd38a14d><canvas class="canvasAvatar" id="canvasAvatar" data-v-dd38a14d></canvas></div><img style="${ssrRenderStyle([
        unref(isShowResult) ? null : { display: "none" },
        { "width": "9.6rem", "height": "9.6rem", "top": "0.25rem", "left": "0.25rem", "position": "absolute" }
      ])}"${ssrRenderAttr("src", unref(resultData))} data-v-dd38a14d></div><a class="next" data-v-dd38a14d></a></div></div><div data-v-dd38a14d><div class="container mt-6 mx-auto" data-v-dd38a14d><div class="text-center relative pt-6 pb-6 mb-4 custom-font-14 rounded w-44 mx-auto" style="${ssrRenderStyle({ "background": "url(/img/NationalDayAvatar/upload-btn.png)", "background-size": "11rem" })}" id="fileInput" alt="\u4E0A\u4F20\u5934\u50CF" data-v-dd38a14d><input type="file" id="file" accept="image/*" style="${ssrRenderStyle({ "opacity": "0", "position": "absolute", "cursor": "pointer", "width": "100%", "height": "100%", "left": "0", "top": "0" })}" data-v-dd38a14d></div><div style="${ssrRenderStyle([
        unref(uploaded) ? null : { display: "none" },
        { "background": "url(/img/NationalDayAvatar/save-btn.png)", "background-size": "11rem" }
      ])}" class="text-center relative pt-6 pb-6 mb-4 custom-font-14 rounded w-44 mx-auto" alt="\u4FDD\u5B58\u5934\u50CF" data-v-dd38a14d></div><div class="w-full text-center" data-v-dd38a14d><p class="text-yellow-300" data-v-dd38a14d>\u624B\u673A\u7528\u6237\u8BF7\u70B9\u51FB\u4FDD\u5B58\u5934\u50CF\u540E\u957F\u6309\u5934\u50CF\u8FDB\u884C\u4E0B\u8F7D</p></div></div><div style="${ssrRenderStyle({ "display": "none" })}" data-v-dd38a14d><!--[-->`);
      ssrRenderList(sum, (index) => {
        _push(`<img${ssrRenderAttr("id", "avatar-" + index)}${ssrRenderAttr("src", "/img/NationalDayAvatar/avatar-" + index + ".png")} style="${ssrRenderStyle({ "display": "none" })}" data-v-dd38a14d>`);
      });
      _push(`<!--]--></div><div class="container flex flex-wrap mx-auto justify-around" data-v-dd38a14d><!--[-->`);
      ssrRenderList(sum, (index) => {
        _push(`<div class="${ssrRenderClass([index == unref(activeIndex) ? "active" : "", "w-16 md:w-20 m-3 md:m-4 canvasAvatarBoxBorder"])}" data-v-dd38a14d><img${ssrRenderAttr("src", "/img/NationalDayAvatar/avatar-" + index + ".png")} data-v-dd38a14d></div>`);
      });
      _push(`<!--]--><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-dd38a14d></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-dd38a14d></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-dd38a14d></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-dd38a14d></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-dd38a14d></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-dd38a14d></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-dd38a14d></div></div><div class="container mx-auto" data-v-dd38a14d><img${ssrRenderAttr("src", _imports_1)} alt="" data-v-dd38a14d></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/NationalDayAvatar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const NationalDayAvatar = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-dd38a14d"]]);

export { NationalDayAvatar as default };
//# sourceMappingURL=NationalDayAvatar.4317f561.mjs.map
