const Login_vue_vue_type_style_index_0_scoped_4d869e21_lang = ".modal-show[data-v-4d869e21]{-webkit-backdrop-filter:saturate(180%) blur(25px);backdrop-filter:saturate(180%) blur(25px);background:rgba(0,0,0,.35)}";

const LoginStyles_2f93e838 = [Login_vue_vue_type_style_index_0_scoped_4d869e21_lang];

export { LoginStyles_2f93e838 as default };
//# sourceMappingURL=Login-styles.2f93e838.mjs.map
