const Toolbar_vue_vue_type_style_index_0_scoped_b38cc781_lang = "header[data-v-b38cc781]{background:#fff}.menu>li[data-v-b38cc781]:hover,.router-link-active[data-v-b38cc781],.router-link-exact-active[data-v-b38cc781]{color:#3955f6;font-weight:900}.icon-category[data-v-b38cc781]{font-size:24px}";

const ToolbarStyles_a59ae2da = [Toolbar_vue_vue_type_style_index_0_scoped_b38cc781_lang];

export { ToolbarStyles_a59ae2da as default };
//# sourceMappingURL=Toolbar-styles.a59ae2da.mjs.map
