const _imports_0 = "" + globalThis.__publicAssetsURL("ad/ScreenRecAD.jpg");

export { _imports_0 as _ };
//# sourceMappingURL=ScreenRecAD.16518c41.mjs.map
