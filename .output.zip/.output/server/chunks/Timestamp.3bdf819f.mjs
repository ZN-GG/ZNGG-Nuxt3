import { a as useNuxtApp, u as useHead } from './server.mjs';
import { defineComponent, ref, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Timestamp",
  __ssrInlineRender: true,
  setup(__props) {
    useNuxtApp();
    const nowStamp = ref(Date.parse(new Date().toString()) / 1e3);
    const isRunning = ref(true);
    const inputStr = ref("");
    const strToTimestampResult = ref("");
    const inputTimestamp = ref(Date.parse(new Date().toString()) / 1e3);
    const timestampToStrResult = ref("");
    const showTypeTimestampFlag = ref(false);
    const typeTimestamp = ref(1);
    const showTypeS2TFlag = ref(false);
    const typeS2T = ref(1);
    const showTypeT2SFlag = ref(false);
    const typeT2S = ref(1);
    const dateFormat = (date, format = "YYYY-MM-DD HH:mm:ss") => {
      const config = {
        YYYY: date.getFullYear(),
        MM: date.getMonth() < 9 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1,
        DD: date.getDate() < 10 ? "0" + date.getDate() : date.getDate(),
        HH: date.getHours() < 10 ? "0" + date.getHours() : date.getHours(),
        mm: date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes(),
        ss: date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds()
      };
      for (const key in config) {
        format = format.replace(key, config[key]);
      }
      return format;
    };
    inputStr.value = dateFormat(new Date());
    setInterval(function() {
      if (isRunning.value) {
        if (typeTimestamp.value == 1) {
          nowStamp.value = Date.parse(new Date().toString()) / 1e3;
        } else {
          nowStamp.value = Date.now();
        }
      }
    }, 1e3);
    useHead({
      title: "\u65F6\u95F4\u6233\u5728\u7EBF\u8F6C\u6362\u5DE5\u5177",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "\u65F6\u95F4\u6233\u5DE5\u5177,\u65F6\u95F4\u8F6C\u6362,\u65F6\u95F4\u6233\u8F6C\u6362,\u65F6\u95F4\u6233\u5728\u7EBF\u8F6C\u6362\u5DE5\u5177" },
        { name: "description", content: "\u4E00\u4E2A\u65F6\u95F4\u6233\u8F6C\u6362\u5DE5\u5177\uFF0C\u7528\u4E8E\u5C06\u65F6\u95F4\u6233\u8F6C\u6362\u6210\u65F6\u95F4\u6216\u8005\u5C06\u65F6\u95F4\u8F6C\u6362\u6210\u65F6\u95F4\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white min-h-screen" }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">\u65F6\u95F4\u6233\u5728\u7EBF\u8F6C\u6362</h1></div></div></div></section><div class="container px-4 mx-auto py-6"><div class="flex items-center flex-wrap border-b py-2"><p class="mr-2 my-1">\u73B0\u5728\u7684Unix\u65F6\u95F4\u6233(Unix timestamp)\u662F:</p> <input${ssrRenderAttr("value", nowStamp.value)} class="bg-gray-100 outline-none px-2 py-1 mr-2 my-1 text-red-700" disabled type="text"><div><div class="relative bg-gray-100 px-3 mr-2 cursor-pointer rounded-md"><span class="custom-font-14 leading-8 relative inline select-none">${ssrInterpolate(typeTimestamp.value == 1 ? "\u79D2" : "\u6BEB\u79D2")} <span class="${ssrRenderClass([showTypeTimestampFlag.value ? "reverse" : "", "iconfont icon-arrow-down inline-block"])}"></span></span></div><div style="${ssrRenderStyle(showTypeTimestampFlag.value ? null : { display: "none" })}" class="${ssrRenderClass([showTypeTimestampFlag.value ? "" : "hidden", "flex flex-wrap w-20 items-center overflow-auto absolute"])}"><div class="btn-2 bg-gray-200 w-16 text-center my-1"> \u79D2 </div><div class="btn-2 bg-gray-200 w-16 text-center"> \u6BEB\u79D2 </div></div></div><div class="flex"><div class="my-2 mr-2 py-1 cursor-pointer rounded px-4 bg-blue-700 text-gray-100 select-none hover:bg-blue-900"> \u5F00\u59CB</div><div class="m-2 py-1 cursor-pointer rounded px-4 bg-blue-700 text-gray-100 select-none hover:bg-blue-900"> \u6682\u505C</div><div class="m-2 py-1 cursor-pointer rounded px-4 bg-blue-700 text-gray-100 select-none hover:bg-blue-900"> \u590D\u5236</div></div></div><div class="flex items-center flex-wrap border-b py-6"><p class="mr-2 my-1">\u65E5\u671F\u8F6C\u65F6\u95F4\u6233:</p><input${ssrRenderAttr("value", inputStr.value)} class="bg-gray-100 outline-none px-2 py-1 mr-2 my-1 w-60" type="text"><div><div class="relative bg-gray-100 px-3 mr-2 cursor-pointer rounded-md"><span class="custom-font-14 leading-8 relative inline select-none">${ssrInterpolate(typeT2S.value == 1 ? "\u79D2" : "\u6BEB\u79D2")} <span class="${ssrRenderClass([showTypeT2SFlag.value ? "reverse" : "", "iconfont icon-arrow-down inline-block"])}"></span></span></div><div style="${ssrRenderStyle(showTypeT2SFlag.value ? null : { display: "none" })}" class="${ssrRenderClass([showTypeT2SFlag.value ? "" : "hidden", "flex flex-wrap w-20 items-center overflow-auto absolute"])}"><div class="btn-2 bg-gray-200 w-16 text-center my-1"> \u79D2 </div><div class="btn-2 bg-gray-200 w-16 text-center"> \u6BEB\u79D2 </div></div></div><div class="my-2 mr-3 py-1 cursor-pointer rounded px-4 bg-blue-700 text-gray-100 select-none hover:bg-blue-900"> \u5F00\u59CB\u8F6C\u6362</div><input${ssrRenderAttr("value", strToTimestampResult.value)} class="bg-gray-100 outline-none px-2 py-1 mr-2 my-1" disabled type="text"><div class="my-2 mr-2 py-1 cursor-pointer rounded px-4 bg-blue-700 text-gray-100 select-none hover:bg-blue-900"> \u590D\u5236</div></div><div class="flex items-center flex-wrap border-b py-6"><p class="mr-2 my-1">\u65F6\u95F4\u6233\u8F6C\u65E5\u671F:</p><input${ssrRenderAttr("value", inputTimestamp.value)} class="bg-gray-100 outline-none px-2 py-1 mr-2 my-1" type="text"><div><div class="relative bg-gray-100 px-3 mr-2 cursor-pointer rounded-md"><span class="custom-font-14 leading-8 relative inline select-none">${ssrInterpolate(typeS2T.value == 1 ? "\u79D2" : "\u6BEB\u79D2")} <span class="${ssrRenderClass([showTypeS2TFlag.value ? "reverse" : "", "iconfont icon-arrow-down inline-block"])}"></span></span></div><div style="${ssrRenderStyle(showTypeS2TFlag.value ? null : { display: "none" })}" class="${ssrRenderClass([showTypeS2TFlag.value ? "" : "hidden", "flex flex-wrap w-20 items-center overflow-auto absolute"])}"><div class="btn-2 bg-gray-200 w-16 text-center my-1"> \u79D2 </div><div class="btn-2 bg-gray-200 w-16 text-center"> \u6BEB\u79D2 </div></div></div><div class="my-2 mr-3 py-1 cursor-pointer rounded px-4 bg-blue-700 text-gray-100 select-none hover:bg-blue-900"> \u5F00\u59CB\u8F6C\u6362</div><input${ssrRenderAttr("value", timestampToStrResult.value)} class="bg-gray-100 outline-none px-2 py-1 mr-2 my-1" disabled type="text"><div class="my-2 mr-2 py-1 cursor-pointer rounded px-4 bg-blue-700 text-gray-100 select-none hover:bg-blue-900"> \u590D\u5236</div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/Timestamp.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Timestamp.3bdf819f.mjs.map
