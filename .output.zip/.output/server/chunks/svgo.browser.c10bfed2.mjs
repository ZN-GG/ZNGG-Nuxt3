var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getAugmentedNamespace(n) {
  var f = n.default;
  if (typeof f == "function") {
    var a = function() {
      return f.apply(this, arguments);
    };
    a.prototype = f.prototype;
  } else
    a = {};
  Object.defineProperty(a, "__esModule", { value: true });
  Object.keys(n).forEach(function(k) {
    var d = Object.getOwnPropertyDescriptor(n, k);
    Object.defineProperty(a, k, d.get ? d : {
      enumerable: true,
      get: function() {
        return n[k];
      }
    });
  });
  return a;
}
var svgo = {};
var config$3 = {};
var builtin$1 = {};
var plugins = {};
var xast = {};
var lib$6 = {};
var lib$5 = {};
var stringify$1 = {};
var lib$4 = {};
var lib$3 = {};
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.Doctype = exports.CDATA = exports.Tag = exports.Style = exports.Script = exports.Comment = exports.Directive = exports.Text = exports.Root = exports.isTag = exports.ElementType = void 0;
  var ElementType2;
  (function(ElementType3) {
    ElementType3["Root"] = "root";
    ElementType3["Text"] = "text";
    ElementType3["Directive"] = "directive";
    ElementType3["Comment"] = "comment";
    ElementType3["Script"] = "script";
    ElementType3["Style"] = "style";
    ElementType3["Tag"] = "tag";
    ElementType3["CDATA"] = "cdata";
    ElementType3["Doctype"] = "doctype";
  })(ElementType2 = exports.ElementType || (exports.ElementType = {}));
  function isTag2(elem) {
    return elem.type === ElementType2.Tag || elem.type === ElementType2.Script || elem.type === ElementType2.Style;
  }
  exports.isTag = isTag2;
  exports.Root = ElementType2.Root;
  exports.Text = ElementType2.Text;
  exports.Directive = ElementType2.Directive;
  exports.Comment = ElementType2.Comment;
  exports.Script = ElementType2.Script;
  exports.Style = ElementType2.Style;
  exports.Tag = ElementType2.Tag;
  exports.CDATA = ElementType2.CDATA;
  exports.Doctype = ElementType2.Doctype;
})(lib$3);
var node$1 = {};
var __extends = commonjsGlobal && commonjsGlobal.__extends || function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2)
        if (Object.prototype.hasOwnProperty.call(b2, p))
          d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __assign$1 = commonjsGlobal && commonjsGlobal.__assign || function() {
  __assign$1 = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign$1.apply(this, arguments);
};
Object.defineProperty(node$1, "__esModule", { value: true });
node$1.cloneNode = node$1.hasChildren = node$1.isDocument = node$1.isDirective = node$1.isComment = node$1.isText = node$1.isCDATA = node$1.isTag = node$1.Element = node$1.Document = node$1.CDATA = node$1.NodeWithChildren = node$1.ProcessingInstruction = node$1.Comment = node$1.Text = node$1.DataNode = node$1.Node = void 0;
var domelementtype_1$1 = lib$3;
var Node = function() {
  function Node2() {
    this.parent = null;
    this.prev = null;
    this.next = null;
    this.startIndex = null;
    this.endIndex = null;
  }
  Object.defineProperty(Node2.prototype, "parentNode", {
    get: function() {
      return this.parent;
    },
    set: function(parent) {
      this.parent = parent;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(Node2.prototype, "previousSibling", {
    get: function() {
      return this.prev;
    },
    set: function(prev) {
      this.prev = prev;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(Node2.prototype, "nextSibling", {
    get: function() {
      return this.next;
    },
    set: function(next) {
      this.next = next;
    },
    enumerable: false,
    configurable: true
  });
  Node2.prototype.cloneNode = function(recursive) {
    if (recursive === void 0) {
      recursive = false;
    }
    return cloneNode(this, recursive);
  };
  return Node2;
}();
node$1.Node = Node;
var DataNode = function(_super) {
  __extends(DataNode2, _super);
  function DataNode2(data2) {
    var _this = _super.call(this) || this;
    _this.data = data2;
    return _this;
  }
  Object.defineProperty(DataNode2.prototype, "nodeValue", {
    get: function() {
      return this.data;
    },
    set: function(data2) {
      this.data = data2;
    },
    enumerable: false,
    configurable: true
  });
  return DataNode2;
}(Node);
node$1.DataNode = DataNode;
var Text = function(_super) {
  __extends(Text2, _super);
  function Text2() {
    var _this = _super !== null && _super.apply(this, arguments) || this;
    _this.type = domelementtype_1$1.ElementType.Text;
    return _this;
  }
  Object.defineProperty(Text2.prototype, "nodeType", {
    get: function() {
      return 3;
    },
    enumerable: false,
    configurable: true
  });
  return Text2;
}(DataNode);
node$1.Text = Text;
var Comment$6 = function(_super) {
  __extends(Comment2, _super);
  function Comment2() {
    var _this = _super !== null && _super.apply(this, arguments) || this;
    _this.type = domelementtype_1$1.ElementType.Comment;
    return _this;
  }
  Object.defineProperty(Comment2.prototype, "nodeType", {
    get: function() {
      return 8;
    },
    enumerable: false,
    configurable: true
  });
  return Comment2;
}(DataNode);
node$1.Comment = Comment$6;
var ProcessingInstruction = function(_super) {
  __extends(ProcessingInstruction2, _super);
  function ProcessingInstruction2(name2, data2) {
    var _this = _super.call(this, data2) || this;
    _this.name = name2;
    _this.type = domelementtype_1$1.ElementType.Directive;
    return _this;
  }
  Object.defineProperty(ProcessingInstruction2.prototype, "nodeType", {
    get: function() {
      return 1;
    },
    enumerable: false,
    configurable: true
  });
  return ProcessingInstruction2;
}(DataNode);
node$1.ProcessingInstruction = ProcessingInstruction;
var NodeWithChildren = function(_super) {
  __extends(NodeWithChildren2, _super);
  function NodeWithChildren2(children) {
    var _this = _super.call(this) || this;
    _this.children = children;
    return _this;
  }
  Object.defineProperty(NodeWithChildren2.prototype, "firstChild", {
    get: function() {
      var _a;
      return (_a = this.children[0]) !== null && _a !== void 0 ? _a : null;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(NodeWithChildren2.prototype, "lastChild", {
    get: function() {
      return this.children.length > 0 ? this.children[this.children.length - 1] : null;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(NodeWithChildren2.prototype, "childNodes", {
    get: function() {
      return this.children;
    },
    set: function(children) {
      this.children = children;
    },
    enumerable: false,
    configurable: true
  });
  return NodeWithChildren2;
}(Node);
node$1.NodeWithChildren = NodeWithChildren;
var CDATA = function(_super) {
  __extends(CDATA2, _super);
  function CDATA2() {
    var _this = _super !== null && _super.apply(this, arguments) || this;
    _this.type = domelementtype_1$1.ElementType.CDATA;
    return _this;
  }
  Object.defineProperty(CDATA2.prototype, "nodeType", {
    get: function() {
      return 4;
    },
    enumerable: false,
    configurable: true
  });
  return CDATA2;
}(NodeWithChildren);
node$1.CDATA = CDATA;
var Document = function(_super) {
  __extends(Document2, _super);
  function Document2() {
    var _this = _super !== null && _super.apply(this, arguments) || this;
    _this.type = domelementtype_1$1.ElementType.Root;
    return _this;
  }
  Object.defineProperty(Document2.prototype, "nodeType", {
    get: function() {
      return 9;
    },
    enumerable: false,
    configurable: true
  });
  return Document2;
}(NodeWithChildren);
node$1.Document = Document;
var Element = function(_super) {
  __extends(Element2, _super);
  function Element2(name2, attribs, children, type) {
    if (children === void 0) {
      children = [];
    }
    if (type === void 0) {
      type = name2 === "script" ? domelementtype_1$1.ElementType.Script : name2 === "style" ? domelementtype_1$1.ElementType.Style : domelementtype_1$1.ElementType.Tag;
    }
    var _this = _super.call(this, children) || this;
    _this.name = name2;
    _this.attribs = attribs;
    _this.type = type;
    return _this;
  }
  Object.defineProperty(Element2.prototype, "nodeType", {
    get: function() {
      return 1;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(Element2.prototype, "tagName", {
    get: function() {
      return this.name;
    },
    set: function(name2) {
      this.name = name2;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(Element2.prototype, "attributes", {
    get: function() {
      var _this = this;
      return Object.keys(this.attribs).map(function(name2) {
        var _a, _b;
        return {
          name: name2,
          value: _this.attribs[name2],
          namespace: (_a = _this["x-attribsNamespace"]) === null || _a === void 0 ? void 0 : _a[name2],
          prefix: (_b = _this["x-attribsPrefix"]) === null || _b === void 0 ? void 0 : _b[name2]
        };
      });
    },
    enumerable: false,
    configurable: true
  });
  return Element2;
}(NodeWithChildren);
node$1.Element = Element;
function isTag$1(node2) {
  return (0, domelementtype_1$1.isTag)(node2);
}
node$1.isTag = isTag$1;
function isCDATA(node2) {
  return node2.type === domelementtype_1$1.ElementType.CDATA;
}
node$1.isCDATA = isCDATA;
function isText(node2) {
  return node2.type === domelementtype_1$1.ElementType.Text;
}
node$1.isText = isText;
function isComment(node2) {
  return node2.type === domelementtype_1$1.ElementType.Comment;
}
node$1.isComment = isComment;
function isDirective(node2) {
  return node2.type === domelementtype_1$1.ElementType.Directive;
}
node$1.isDirective = isDirective;
function isDocument(node2) {
  return node2.type === domelementtype_1$1.ElementType.Root;
}
node$1.isDocument = isDocument;
function hasChildren(node2) {
  return Object.prototype.hasOwnProperty.call(node2, "children");
}
node$1.hasChildren = hasChildren;
function cloneNode(node2, recursive) {
  if (recursive === void 0) {
    recursive = false;
  }
  var result;
  if (isText(node2)) {
    result = new Text(node2.data);
  } else if (isComment(node2)) {
    result = new Comment$6(node2.data);
  } else if (isTag$1(node2)) {
    var children = recursive ? cloneChildren(node2.children) : [];
    var clone_1 = new Element(node2.name, __assign$1({}, node2.attribs), children);
    children.forEach(function(child) {
      return child.parent = clone_1;
    });
    if (node2.namespace != null) {
      clone_1.namespace = node2.namespace;
    }
    if (node2["x-attribsNamespace"]) {
      clone_1["x-attribsNamespace"] = __assign$1({}, node2["x-attribsNamespace"]);
    }
    if (node2["x-attribsPrefix"]) {
      clone_1["x-attribsPrefix"] = __assign$1({}, node2["x-attribsPrefix"]);
    }
    result = clone_1;
  } else if (isCDATA(node2)) {
    var children = recursive ? cloneChildren(node2.children) : [];
    var clone_2 = new CDATA(children);
    children.forEach(function(child) {
      return child.parent = clone_2;
    });
    result = clone_2;
  } else if (isDocument(node2)) {
    var children = recursive ? cloneChildren(node2.children) : [];
    var clone_3 = new Document(children);
    children.forEach(function(child) {
      return child.parent = clone_3;
    });
    if (node2["x-mode"]) {
      clone_3["x-mode"] = node2["x-mode"];
    }
    result = clone_3;
  } else if (isDirective(node2)) {
    var instruction = new ProcessingInstruction(node2.name, node2.data);
    if (node2["x-name"] != null) {
      instruction["x-name"] = node2["x-name"];
      instruction["x-publicId"] = node2["x-publicId"];
      instruction["x-systemId"] = node2["x-systemId"];
    }
    result = instruction;
  } else {
    throw new Error("Not implemented yet: ".concat(node2.type));
  }
  result.startIndex = node2.startIndex;
  result.endIndex = node2.endIndex;
  if (node2.sourceCodeLocation != null) {
    result.sourceCodeLocation = node2.sourceCodeLocation;
  }
  return result;
}
node$1.cloneNode = cloneNode;
function cloneChildren(childs) {
  var children = childs.map(function(child) {
    return cloneNode(child, true);
  });
  for (var i = 1; i < children.length; i++) {
    children[i].prev = children[i - 1];
    children[i - 1].next = children[i];
  }
  return children;
}
(function(exports) {
  var __createBinding2 = commonjsGlobal && commonjsGlobal.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() {
        return m[k];
      } };
    }
    Object.defineProperty(o, k2, desc);
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = commonjsGlobal && commonjsGlobal.__exportStar || function(m, exports2) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p))
        __createBinding2(exports2, m, p);
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.DomHandler = void 0;
  var domelementtype_12 = lib$3;
  var node_js_1 = node$1;
  __exportStar(node$1, exports);
  var defaultOpts = {
    withStartIndices: false,
    withEndIndices: false,
    xmlMode: false
  };
  var DomHandler = function() {
    function DomHandler2(callback, options, elementCB) {
      this.dom = [];
      this.root = new node_js_1.Document(this.dom);
      this.done = false;
      this.tagStack = [this.root];
      this.lastNode = null;
      this.parser = null;
      if (typeof options === "function") {
        elementCB = options;
        options = defaultOpts;
      }
      if (typeof callback === "object") {
        options = callback;
        callback = void 0;
      }
      this.callback = callback !== null && callback !== void 0 ? callback : null;
      this.options = options !== null && options !== void 0 ? options : defaultOpts;
      this.elementCB = elementCB !== null && elementCB !== void 0 ? elementCB : null;
    }
    DomHandler2.prototype.onparserinit = function(parser2) {
      this.parser = parser2;
    };
    DomHandler2.prototype.onreset = function() {
      this.dom = [];
      this.root = new node_js_1.Document(this.dom);
      this.done = false;
      this.tagStack = [this.root];
      this.lastNode = null;
      this.parser = null;
    };
    DomHandler2.prototype.onend = function() {
      if (this.done)
        return;
      this.done = true;
      this.parser = null;
      this.handleCallback(null);
    };
    DomHandler2.prototype.onerror = function(error2) {
      this.handleCallback(error2);
    };
    DomHandler2.prototype.onclosetag = function() {
      this.lastNode = null;
      var elem = this.tagStack.pop();
      if (this.options.withEndIndices) {
        elem.endIndex = this.parser.endIndex;
      }
      if (this.elementCB)
        this.elementCB(elem);
    };
    DomHandler2.prototype.onopentag = function(name2, attribs) {
      var type = this.options.xmlMode ? domelementtype_12.ElementType.Tag : void 0;
      var element = new node_js_1.Element(name2, attribs, void 0, type);
      this.addNode(element);
      this.tagStack.push(element);
    };
    DomHandler2.prototype.ontext = function(data2) {
      var lastNode = this.lastNode;
      if (lastNode && lastNode.type === domelementtype_12.ElementType.Text) {
        lastNode.data += data2;
        if (this.options.withEndIndices) {
          lastNode.endIndex = this.parser.endIndex;
        }
      } else {
        var node2 = new node_js_1.Text(data2);
        this.addNode(node2);
        this.lastNode = node2;
      }
    };
    DomHandler2.prototype.oncomment = function(data2) {
      if (this.lastNode && this.lastNode.type === domelementtype_12.ElementType.Comment) {
        this.lastNode.data += data2;
        return;
      }
      var node2 = new node_js_1.Comment(data2);
      this.addNode(node2);
      this.lastNode = node2;
    };
    DomHandler2.prototype.oncommentend = function() {
      this.lastNode = null;
    };
    DomHandler2.prototype.oncdatastart = function() {
      var text = new node_js_1.Text("");
      var node2 = new node_js_1.CDATA([text]);
      this.addNode(node2);
      text.parent = node2;
      this.lastNode = text;
    };
    DomHandler2.prototype.oncdataend = function() {
      this.lastNode = null;
    };
    DomHandler2.prototype.onprocessinginstruction = function(name2, data2) {
      var node2 = new node_js_1.ProcessingInstruction(name2, data2);
      this.addNode(node2);
    };
    DomHandler2.prototype.handleCallback = function(error2) {
      if (typeof this.callback === "function") {
        this.callback(error2, this.dom);
      } else if (error2) {
        throw error2;
      }
    };
    DomHandler2.prototype.addNode = function(node2) {
      var parent = this.tagStack[this.tagStack.length - 1];
      var previousSibling = parent.children[parent.children.length - 1];
      if (this.options.withStartIndices) {
        node2.startIndex = this.parser.startIndex;
      }
      if (this.options.withEndIndices) {
        node2.endIndex = this.parser.endIndex;
      }
      parent.children.push(node2);
      if (previousSibling) {
        node2.prev = previousSibling;
        previousSibling.next = node2;
      }
      node2.parent = parent;
      this.lastNode = null;
    };
    return DomHandler2;
  }();
  exports.DomHandler = DomHandler;
  exports.default = DomHandler;
})(lib$4);
var lib$2 = {};
var lib$1 = {};
var decode$3 = {};
var decodeDataHtml = {};
Object.defineProperty(decodeDataHtml, "__esModule", { value: true });
decodeDataHtml.default = new Uint16Array(
  '\u1D41<\xD5\u0131\u028A\u049D\u057B\u05D0\u0675\u06DE\u07A2\u07D6\u080F\u0A4A\u0A91\u0DA1\u0E6D\u0F09\u0F26\u10CA\u1228\u12E1\u1415\u149D\u14C3\u14DF\u1525\0\0\0\0\0\0\u156B\u16CD\u198D\u1C12\u1DDD\u1F7E\u2060\u21B0\u228D\u23C0\u23FB\u2442\u2824\u2912\u2D08\u2E48\u2FCE\u3016\u32BA\u3639\u37AC\u38FE\u3A28\u3A71\u3AE0\u3B2E\u0800EMabcfglmnoprstu\\bfms\x7F\x84\x8B\x90\x95\x98\xA6\xB3\xB9\xC8\xCFlig\u803B\xC6\u40C6P\u803B&\u4026cute\u803B\xC1\u40C1reve;\u4102\u0100iyx}rc\u803B\xC2\u40C2;\u4410r;\uC000\u{1D504}rave\u803B\xC0\u40C0pha;\u4391acr;\u4100d;\u6A53\u0100gp\x9D\xA1on;\u4104f;\uC000\u{1D538}plyFunction;\u6061ing\u803B\xC5\u40C5\u0100cs\xBE\xC3r;\uC000\u{1D49C}ign;\u6254ilde\u803B\xC3\u40C3ml\u803B\xC4\u40C4\u0400aceforsu\xE5\xFB\xFE\u0117\u011C\u0122\u0127\u012A\u0100cr\xEA\xF2kslash;\u6216\u0176\xF6\xF8;\u6AE7ed;\u6306y;\u4411\u0180crt\u0105\u010B\u0114ause;\u6235noullis;\u612Ca;\u4392r;\uC000\u{1D505}pf;\uC000\u{1D539}eve;\u42D8c\xF2\u0113mpeq;\u624E\u0700HOacdefhilorsu\u014D\u0151\u0156\u0180\u019E\u01A2\u01B5\u01B7\u01BA\u01DC\u0215\u0273\u0278\u027Ecy;\u4427PY\u803B\xA9\u40A9\u0180cpy\u015D\u0162\u017Aute;\u4106\u0100;i\u0167\u0168\u62D2talDifferentialD;\u6145leys;\u612D\u0200aeio\u0189\u018E\u0194\u0198ron;\u410Cdil\u803B\xC7\u40C7rc;\u4108nint;\u6230ot;\u410A\u0100dn\u01A7\u01ADilla;\u40B8terDot;\u40B7\xF2\u017Fi;\u43A7rcle\u0200DMPT\u01C7\u01CB\u01D1\u01D6ot;\u6299inus;\u6296lus;\u6295imes;\u6297o\u0100cs\u01E2\u01F8kwiseContourIntegral;\u6232eCurly\u0100DQ\u0203\u020FoubleQuote;\u601Duote;\u6019\u0200lnpu\u021E\u0228\u0247\u0255on\u0100;e\u0225\u0226\u6237;\u6A74\u0180git\u022F\u0236\u023Aruent;\u6261nt;\u622FourIntegral;\u622E\u0100fr\u024C\u024E;\u6102oduct;\u6210nterClockwiseContourIntegral;\u6233oss;\u6A2Fcr;\uC000\u{1D49E}p\u0100;C\u0284\u0285\u62D3ap;\u624D\u0580DJSZacefios\u02A0\u02AC\u02B0\u02B4\u02B8\u02CB\u02D7\u02E1\u02E6\u0333\u048D\u0100;o\u0179\u02A5trahd;\u6911cy;\u4402cy;\u4405cy;\u440F\u0180grs\u02BF\u02C4\u02C7ger;\u6021r;\u61A1hv;\u6AE4\u0100ay\u02D0\u02D5ron;\u410E;\u4414l\u0100;t\u02DD\u02DE\u6207a;\u4394r;\uC000\u{1D507}\u0100af\u02EB\u0327\u0100cm\u02F0\u0322ritical\u0200ADGT\u0300\u0306\u0316\u031Ccute;\u40B4o\u0174\u030B\u030D;\u42D9bleAcute;\u42DDrave;\u4060ilde;\u42DCond;\u62C4ferentialD;\u6146\u0470\u033D\0\0\0\u0342\u0354\0\u0405f;\uC000\u{1D53B}\u0180;DE\u0348\u0349\u034D\u40A8ot;\u60DCqual;\u6250ble\u0300CDLRUV\u0363\u0372\u0382\u03CF\u03E2\u03F8ontourIntegra\xEC\u0239o\u0274\u0379\0\0\u037B\xBB\u0349nArrow;\u61D3\u0100eo\u0387\u03A4ft\u0180ART\u0390\u0396\u03A1rrow;\u61D0ightArrow;\u61D4e\xE5\u02CAng\u0100LR\u03AB\u03C4eft\u0100AR\u03B3\u03B9rrow;\u67F8ightArrow;\u67FAightArrow;\u67F9ight\u0100AT\u03D8\u03DErrow;\u61D2ee;\u62A8p\u0241\u03E9\0\0\u03EFrrow;\u61D1ownArrow;\u61D5erticalBar;\u6225n\u0300ABLRTa\u0412\u042A\u0430\u045E\u047F\u037Crrow\u0180;BU\u041D\u041E\u0422\u6193ar;\u6913pArrow;\u61F5reve;\u4311eft\u02D2\u043A\0\u0446\0\u0450ightVector;\u6950eeVector;\u695Eector\u0100;B\u0459\u045A\u61BDar;\u6956ight\u01D4\u0467\0\u0471eeVector;\u695Fector\u0100;B\u047A\u047B\u61C1ar;\u6957ee\u0100;A\u0486\u0487\u62A4rrow;\u61A7\u0100ct\u0492\u0497r;\uC000\u{1D49F}rok;\u4110\u0800NTacdfglmopqstux\u04BD\u04C0\u04C4\u04CB\u04DE\u04E2\u04E7\u04EE\u04F5\u0521\u052F\u0536\u0552\u055D\u0560\u0565G;\u414AH\u803B\xD0\u40D0cute\u803B\xC9\u40C9\u0180aiy\u04D2\u04D7\u04DCron;\u411Arc\u803B\xCA\u40CA;\u442Dot;\u4116r;\uC000\u{1D508}rave\u803B\xC8\u40C8ement;\u6208\u0100ap\u04FA\u04FEcr;\u4112ty\u0253\u0506\0\0\u0512mallSquare;\u65FBerySmallSquare;\u65AB\u0100gp\u0526\u052Aon;\u4118f;\uC000\u{1D53C}silon;\u4395u\u0100ai\u053C\u0549l\u0100;T\u0542\u0543\u6A75ilde;\u6242librium;\u61CC\u0100ci\u0557\u055Ar;\u6130m;\u6A73a;\u4397ml\u803B\xCB\u40CB\u0100ip\u056A\u056Fsts;\u6203onentialE;\u6147\u0280cfios\u0585\u0588\u058D\u05B2\u05CCy;\u4424r;\uC000\u{1D509}lled\u0253\u0597\0\0\u05A3mallSquare;\u65FCerySmallSquare;\u65AA\u0370\u05BA\0\u05BF\0\0\u05C4f;\uC000\u{1D53D}All;\u6200riertrf;\u6131c\xF2\u05CB\u0600JTabcdfgorst\u05E8\u05EC\u05EF\u05FA\u0600\u0612\u0616\u061B\u061D\u0623\u066C\u0672cy;\u4403\u803B>\u403Emma\u0100;d\u05F7\u05F8\u4393;\u43DCreve;\u411E\u0180eiy\u0607\u060C\u0610dil;\u4122rc;\u411C;\u4413ot;\u4120r;\uC000\u{1D50A};\u62D9pf;\uC000\u{1D53E}eater\u0300EFGLST\u0635\u0644\u064E\u0656\u065B\u0666qual\u0100;L\u063E\u063F\u6265ess;\u62DBullEqual;\u6267reater;\u6AA2ess;\u6277lantEqual;\u6A7Eilde;\u6273cr;\uC000\u{1D4A2};\u626B\u0400Aacfiosu\u0685\u068B\u0696\u069B\u069E\u06AA\u06BE\u06CARDcy;\u442A\u0100ct\u0690\u0694ek;\u42C7;\u405Eirc;\u4124r;\u610ClbertSpace;\u610B\u01F0\u06AF\0\u06B2f;\u610DizontalLine;\u6500\u0100ct\u06C3\u06C5\xF2\u06A9rok;\u4126mp\u0144\u06D0\u06D8ownHum\xF0\u012Fqual;\u624F\u0700EJOacdfgmnostu\u06FA\u06FE\u0703\u0707\u070E\u071A\u071E\u0721\u0728\u0744\u0778\u078B\u078F\u0795cy;\u4415lig;\u4132cy;\u4401cute\u803B\xCD\u40CD\u0100iy\u0713\u0718rc\u803B\xCE\u40CE;\u4418ot;\u4130r;\u6111rave\u803B\xCC\u40CC\u0180;ap\u0720\u072F\u073F\u0100cg\u0734\u0737r;\u412AinaryI;\u6148lie\xF3\u03DD\u01F4\u0749\0\u0762\u0100;e\u074D\u074E\u622C\u0100gr\u0753\u0758ral;\u622Bsection;\u62C2isible\u0100CT\u076C\u0772omma;\u6063imes;\u6062\u0180gpt\u077F\u0783\u0788on;\u412Ef;\uC000\u{1D540}a;\u4399cr;\u6110ilde;\u4128\u01EB\u079A\0\u079Ecy;\u4406l\u803B\xCF\u40CF\u0280cfosu\u07AC\u07B7\u07BC\u07C2\u07D0\u0100iy\u07B1\u07B5rc;\u4134;\u4419r;\uC000\u{1D50D}pf;\uC000\u{1D541}\u01E3\u07C7\0\u07CCr;\uC000\u{1D4A5}rcy;\u4408kcy;\u4404\u0380HJacfos\u07E4\u07E8\u07EC\u07F1\u07FD\u0802\u0808cy;\u4425cy;\u440Cppa;\u439A\u0100ey\u07F6\u07FBdil;\u4136;\u441Ar;\uC000\u{1D50E}pf;\uC000\u{1D542}cr;\uC000\u{1D4A6}\u0580JTaceflmost\u0825\u0829\u082C\u0850\u0863\u09B3\u09B8\u09C7\u09CD\u0A37\u0A47cy;\u4409\u803B<\u403C\u0280cmnpr\u0837\u083C\u0841\u0844\u084Dute;\u4139bda;\u439Bg;\u67EAlacetrf;\u6112r;\u619E\u0180aey\u0857\u085C\u0861ron;\u413Ddil;\u413B;\u441B\u0100fs\u0868\u0970t\u0500ACDFRTUVar\u087E\u08A9\u08B1\u08E0\u08E6\u08FC\u092F\u095B\u0390\u096A\u0100nr\u0883\u088FgleBracket;\u67E8row\u0180;BR\u0899\u089A\u089E\u6190ar;\u61E4ightArrow;\u61C6eiling;\u6308o\u01F5\u08B7\0\u08C3bleBracket;\u67E6n\u01D4\u08C8\0\u08D2eeVector;\u6961ector\u0100;B\u08DB\u08DC\u61C3ar;\u6959loor;\u630Aight\u0100AV\u08EF\u08F5rrow;\u6194ector;\u694E\u0100er\u0901\u0917e\u0180;AV\u0909\u090A\u0910\u62A3rrow;\u61A4ector;\u695Aiangle\u0180;BE\u0924\u0925\u0929\u62B2ar;\u69CFqual;\u62B4p\u0180DTV\u0937\u0942\u094CownVector;\u6951eeVector;\u6960ector\u0100;B\u0956\u0957\u61BFar;\u6958ector\u0100;B\u0965\u0966\u61BCar;\u6952ight\xE1\u039Cs\u0300EFGLST\u097E\u098B\u0995\u099D\u09A2\u09ADqualGreater;\u62DAullEqual;\u6266reater;\u6276ess;\u6AA1lantEqual;\u6A7Dilde;\u6272r;\uC000\u{1D50F}\u0100;e\u09BD\u09BE\u62D8ftarrow;\u61DAidot;\u413F\u0180npw\u09D4\u0A16\u0A1Bg\u0200LRlr\u09DE\u09F7\u0A02\u0A10eft\u0100AR\u09E6\u09ECrrow;\u67F5ightArrow;\u67F7ightArrow;\u67F6eft\u0100ar\u03B3\u0A0Aight\xE1\u03BFight\xE1\u03CAf;\uC000\u{1D543}er\u0100LR\u0A22\u0A2CeftArrow;\u6199ightArrow;\u6198\u0180cht\u0A3E\u0A40\u0A42\xF2\u084C;\u61B0rok;\u4141;\u626A\u0400acefiosu\u0A5A\u0A5D\u0A60\u0A77\u0A7C\u0A85\u0A8B\u0A8Ep;\u6905y;\u441C\u0100dl\u0A65\u0A6FiumSpace;\u605Flintrf;\u6133r;\uC000\u{1D510}nusPlus;\u6213pf;\uC000\u{1D544}c\xF2\u0A76;\u439C\u0480Jacefostu\u0AA3\u0AA7\u0AAD\u0AC0\u0B14\u0B19\u0D91\u0D97\u0D9Ecy;\u440Acute;\u4143\u0180aey\u0AB4\u0AB9\u0ABEron;\u4147dil;\u4145;\u441D\u0180gsw\u0AC7\u0AF0\u0B0Eative\u0180MTV\u0AD3\u0ADF\u0AE8ediumSpace;\u600Bhi\u0100cn\u0AE6\u0AD8\xEB\u0AD9eryThi\xEE\u0AD9ted\u0100GL\u0AF8\u0B06reaterGreate\xF2\u0673essLes\xF3\u0A48Line;\u400Ar;\uC000\u{1D511}\u0200Bnpt\u0B22\u0B28\u0B37\u0B3Areak;\u6060BreakingSpace;\u40A0f;\u6115\u0680;CDEGHLNPRSTV\u0B55\u0B56\u0B6A\u0B7C\u0BA1\u0BEB\u0C04\u0C5E\u0C84\u0CA6\u0CD8\u0D61\u0D85\u6AEC\u0100ou\u0B5B\u0B64ngruent;\u6262pCap;\u626DoubleVerticalBar;\u6226\u0180lqx\u0B83\u0B8A\u0B9Bement;\u6209ual\u0100;T\u0B92\u0B93\u6260ilde;\uC000\u2242\u0338ists;\u6204reater\u0380;EFGLST\u0BB6\u0BB7\u0BBD\u0BC9\u0BD3\u0BD8\u0BE5\u626Fqual;\u6271ullEqual;\uC000\u2267\u0338reater;\uC000\u226B\u0338ess;\u6279lantEqual;\uC000\u2A7E\u0338ilde;\u6275ump\u0144\u0BF2\u0BFDownHump;\uC000\u224E\u0338qual;\uC000\u224F\u0338e\u0100fs\u0C0A\u0C27tTriangle\u0180;BE\u0C1A\u0C1B\u0C21\u62EAar;\uC000\u29CF\u0338qual;\u62ECs\u0300;EGLST\u0C35\u0C36\u0C3C\u0C44\u0C4B\u0C58\u626Equal;\u6270reater;\u6278ess;\uC000\u226A\u0338lantEqual;\uC000\u2A7D\u0338ilde;\u6274ested\u0100GL\u0C68\u0C79reaterGreater;\uC000\u2AA2\u0338essLess;\uC000\u2AA1\u0338recedes\u0180;ES\u0C92\u0C93\u0C9B\u6280qual;\uC000\u2AAF\u0338lantEqual;\u62E0\u0100ei\u0CAB\u0CB9verseElement;\u620CghtTriangle\u0180;BE\u0CCB\u0CCC\u0CD2\u62EBar;\uC000\u29D0\u0338qual;\u62ED\u0100qu\u0CDD\u0D0CuareSu\u0100bp\u0CE8\u0CF9set\u0100;E\u0CF0\u0CF3\uC000\u228F\u0338qual;\u62E2erset\u0100;E\u0D03\u0D06\uC000\u2290\u0338qual;\u62E3\u0180bcp\u0D13\u0D24\u0D4Eset\u0100;E\u0D1B\u0D1E\uC000\u2282\u20D2qual;\u6288ceeds\u0200;EST\u0D32\u0D33\u0D3B\u0D46\u6281qual;\uC000\u2AB0\u0338lantEqual;\u62E1ilde;\uC000\u227F\u0338erset\u0100;E\u0D58\u0D5B\uC000\u2283\u20D2qual;\u6289ilde\u0200;EFT\u0D6E\u0D6F\u0D75\u0D7F\u6241qual;\u6244ullEqual;\u6247ilde;\u6249erticalBar;\u6224cr;\uC000\u{1D4A9}ilde\u803B\xD1\u40D1;\u439D\u0700Eacdfgmoprstuv\u0DBD\u0DC2\u0DC9\u0DD5\u0DDB\u0DE0\u0DE7\u0DFC\u0E02\u0E20\u0E22\u0E32\u0E3F\u0E44lig;\u4152cute\u803B\xD3\u40D3\u0100iy\u0DCE\u0DD3rc\u803B\xD4\u40D4;\u441Eblac;\u4150r;\uC000\u{1D512}rave\u803B\xD2\u40D2\u0180aei\u0DEE\u0DF2\u0DF6cr;\u414Cga;\u43A9cron;\u439Fpf;\uC000\u{1D546}enCurly\u0100DQ\u0E0E\u0E1AoubleQuote;\u601Cuote;\u6018;\u6A54\u0100cl\u0E27\u0E2Cr;\uC000\u{1D4AA}ash\u803B\xD8\u40D8i\u016C\u0E37\u0E3Cde\u803B\xD5\u40D5es;\u6A37ml\u803B\xD6\u40D6er\u0100BP\u0E4B\u0E60\u0100ar\u0E50\u0E53r;\u603Eac\u0100ek\u0E5A\u0E5C;\u63DEet;\u63B4arenthesis;\u63DC\u0480acfhilors\u0E7F\u0E87\u0E8A\u0E8F\u0E92\u0E94\u0E9D\u0EB0\u0EFCrtialD;\u6202y;\u441Fr;\uC000\u{1D513}i;\u43A6;\u43A0usMinus;\u40B1\u0100ip\u0EA2\u0EADncareplan\xE5\u069Df;\u6119\u0200;eio\u0EB9\u0EBA\u0EE0\u0EE4\u6ABBcedes\u0200;EST\u0EC8\u0EC9\u0ECF\u0EDA\u627Aqual;\u6AAFlantEqual;\u627Cilde;\u627Eme;\u6033\u0100dp\u0EE9\u0EEEuct;\u620Fortion\u0100;a\u0225\u0EF9l;\u621D\u0100ci\u0F01\u0F06r;\uC000\u{1D4AB};\u43A8\u0200Ufos\u0F11\u0F16\u0F1B\u0F1FOT\u803B"\u4022r;\uC000\u{1D514}pf;\u611Acr;\uC000\u{1D4AC}\u0600BEacefhiorsu\u0F3E\u0F43\u0F47\u0F60\u0F73\u0FA7\u0FAA\u0FAD\u1096\u10A9\u10B4\u10BEarr;\u6910G\u803B\xAE\u40AE\u0180cnr\u0F4E\u0F53\u0F56ute;\u4154g;\u67EBr\u0100;t\u0F5C\u0F5D\u61A0l;\u6916\u0180aey\u0F67\u0F6C\u0F71ron;\u4158dil;\u4156;\u4420\u0100;v\u0F78\u0F79\u611Cerse\u0100EU\u0F82\u0F99\u0100lq\u0F87\u0F8Eement;\u620Builibrium;\u61CBpEquilibrium;\u696Fr\xBB\u0F79o;\u43A1ght\u0400ACDFTUVa\u0FC1\u0FEB\u0FF3\u1022\u1028\u105B\u1087\u03D8\u0100nr\u0FC6\u0FD2gleBracket;\u67E9row\u0180;BL\u0FDC\u0FDD\u0FE1\u6192ar;\u61E5eftArrow;\u61C4eiling;\u6309o\u01F5\u0FF9\0\u1005bleBracket;\u67E7n\u01D4\u100A\0\u1014eeVector;\u695Dector\u0100;B\u101D\u101E\u61C2ar;\u6955loor;\u630B\u0100er\u102D\u1043e\u0180;AV\u1035\u1036\u103C\u62A2rrow;\u61A6ector;\u695Biangle\u0180;BE\u1050\u1051\u1055\u62B3ar;\u69D0qual;\u62B5p\u0180DTV\u1063\u106E\u1078ownVector;\u694FeeVector;\u695Cector\u0100;B\u1082\u1083\u61BEar;\u6954ector\u0100;B\u1091\u1092\u61C0ar;\u6953\u0100pu\u109B\u109Ef;\u611DndImplies;\u6970ightarrow;\u61DB\u0100ch\u10B9\u10BCr;\u611B;\u61B1leDelayed;\u69F4\u0680HOacfhimoqstu\u10E4\u10F1\u10F7\u10FD\u1119\u111E\u1151\u1156\u1161\u1167\u11B5\u11BB\u11BF\u0100Cc\u10E9\u10EEHcy;\u4429y;\u4428FTcy;\u442Ccute;\u415A\u0280;aeiy\u1108\u1109\u110E\u1113\u1117\u6ABCron;\u4160dil;\u415Erc;\u415C;\u4421r;\uC000\u{1D516}ort\u0200DLRU\u112A\u1134\u113E\u1149ownArrow\xBB\u041EeftArrow\xBB\u089AightArrow\xBB\u0FDDpArrow;\u6191gma;\u43A3allCircle;\u6218pf;\uC000\u{1D54A}\u0272\u116D\0\0\u1170t;\u621Aare\u0200;ISU\u117B\u117C\u1189\u11AF\u65A1ntersection;\u6293u\u0100bp\u118F\u119Eset\u0100;E\u1197\u1198\u628Fqual;\u6291erset\u0100;E\u11A8\u11A9\u6290qual;\u6292nion;\u6294cr;\uC000\u{1D4AE}ar;\u62C6\u0200bcmp\u11C8\u11DB\u1209\u120B\u0100;s\u11CD\u11CE\u62D0et\u0100;E\u11CD\u11D5qual;\u6286\u0100ch\u11E0\u1205eeds\u0200;EST\u11ED\u11EE\u11F4\u11FF\u627Bqual;\u6AB0lantEqual;\u627Dilde;\u627FTh\xE1\u0F8C;\u6211\u0180;es\u1212\u1213\u1223\u62D1rset\u0100;E\u121C\u121D\u6283qual;\u6287et\xBB\u1213\u0580HRSacfhiors\u123E\u1244\u1249\u1255\u125E\u1271\u1276\u129F\u12C2\u12C8\u12D1ORN\u803B\xDE\u40DEADE;\u6122\u0100Hc\u124E\u1252cy;\u440By;\u4426\u0100bu\u125A\u125C;\u4009;\u43A4\u0180aey\u1265\u126A\u126Fron;\u4164dil;\u4162;\u4422r;\uC000\u{1D517}\u0100ei\u127B\u1289\u01F2\u1280\0\u1287efore;\u6234a;\u4398\u0100cn\u128E\u1298kSpace;\uC000\u205F\u200ASpace;\u6009lde\u0200;EFT\u12AB\u12AC\u12B2\u12BC\u623Cqual;\u6243ullEqual;\u6245ilde;\u6248pf;\uC000\u{1D54B}ipleDot;\u60DB\u0100ct\u12D6\u12DBr;\uC000\u{1D4AF}rok;\u4166\u0AE1\u12F7\u130E\u131A\u1326\0\u132C\u1331\0\0\0\0\0\u1338\u133D\u1377\u1385\0\u13FF\u1404\u140A\u1410\u0100cr\u12FB\u1301ute\u803B\xDA\u40DAr\u0100;o\u1307\u1308\u619Fcir;\u6949r\u01E3\u1313\0\u1316y;\u440Eve;\u416C\u0100iy\u131E\u1323rc\u803B\xDB\u40DB;\u4423blac;\u4170r;\uC000\u{1D518}rave\u803B\xD9\u40D9acr;\u416A\u0100di\u1341\u1369er\u0100BP\u1348\u135D\u0100ar\u134D\u1350r;\u405Fac\u0100ek\u1357\u1359;\u63DFet;\u63B5arenthesis;\u63DDon\u0100;P\u1370\u1371\u62C3lus;\u628E\u0100gp\u137B\u137Fon;\u4172f;\uC000\u{1D54C}\u0400ADETadps\u1395\u13AE\u13B8\u13C4\u03E8\u13D2\u13D7\u13F3rrow\u0180;BD\u1150\u13A0\u13A4ar;\u6912ownArrow;\u61C5ownArrow;\u6195quilibrium;\u696Eee\u0100;A\u13CB\u13CC\u62A5rrow;\u61A5own\xE1\u03F3er\u0100LR\u13DE\u13E8eftArrow;\u6196ightArrow;\u6197i\u0100;l\u13F9\u13FA\u43D2on;\u43A5ing;\u416Ecr;\uC000\u{1D4B0}ilde;\u4168ml\u803B\xDC\u40DC\u0480Dbcdefosv\u1427\u142C\u1430\u1433\u143E\u1485\u148A\u1490\u1496ash;\u62ABar;\u6AEBy;\u4412ash\u0100;l\u143B\u143C\u62A9;\u6AE6\u0100er\u1443\u1445;\u62C1\u0180bty\u144C\u1450\u147Aar;\u6016\u0100;i\u144F\u1455cal\u0200BLST\u1461\u1465\u146A\u1474ar;\u6223ine;\u407Ceparator;\u6758ilde;\u6240ThinSpace;\u600Ar;\uC000\u{1D519}pf;\uC000\u{1D54D}cr;\uC000\u{1D4B1}dash;\u62AA\u0280cefos\u14A7\u14AC\u14B1\u14B6\u14BCirc;\u4174dge;\u62C0r;\uC000\u{1D51A}pf;\uC000\u{1D54E}cr;\uC000\u{1D4B2}\u0200fios\u14CB\u14D0\u14D2\u14D8r;\uC000\u{1D51B};\u439Epf;\uC000\u{1D54F}cr;\uC000\u{1D4B3}\u0480AIUacfosu\u14F1\u14F5\u14F9\u14FD\u1504\u150F\u1514\u151A\u1520cy;\u442Fcy;\u4407cy;\u442Ecute\u803B\xDD\u40DD\u0100iy\u1509\u150Drc;\u4176;\u442Br;\uC000\u{1D51C}pf;\uC000\u{1D550}cr;\uC000\u{1D4B4}ml;\u4178\u0400Hacdefos\u1535\u1539\u153F\u154B\u154F\u155D\u1560\u1564cy;\u4416cute;\u4179\u0100ay\u1544\u1549ron;\u417D;\u4417ot;\u417B\u01F2\u1554\0\u155BoWidt\xE8\u0AD9a;\u4396r;\u6128pf;\u6124cr;\uC000\u{1D4B5}\u0BE1\u1583\u158A\u1590\0\u15B0\u15B6\u15BF\0\0\0\0\u15C6\u15DB\u15EB\u165F\u166D\0\u1695\u169B\u16B2\u16B9\0\u16BEcute\u803B\xE1\u40E1reve;\u4103\u0300;Ediuy\u159C\u159D\u15A1\u15A3\u15A8\u15AD\u623E;\uC000\u223E\u0333;\u623Frc\u803B\xE2\u40E2te\u80BB\xB4\u0306;\u4430lig\u803B\xE6\u40E6\u0100;r\xB2\u15BA;\uC000\u{1D51E}rave\u803B\xE0\u40E0\u0100ep\u15CA\u15D6\u0100fp\u15CF\u15D4sym;\u6135\xE8\u15D3ha;\u43B1\u0100ap\u15DFc\u0100cl\u15E4\u15E7r;\u4101g;\u6A3F\u0264\u15F0\0\0\u160A\u0280;adsv\u15FA\u15FB\u15FF\u1601\u1607\u6227nd;\u6A55;\u6A5Clope;\u6A58;\u6A5A\u0380;elmrsz\u1618\u1619\u161B\u161E\u163F\u164F\u1659\u6220;\u69A4e\xBB\u1619sd\u0100;a\u1625\u1626\u6221\u0461\u1630\u1632\u1634\u1636\u1638\u163A\u163C\u163E;\u69A8;\u69A9;\u69AA;\u69AB;\u69AC;\u69AD;\u69AE;\u69AFt\u0100;v\u1645\u1646\u621Fb\u0100;d\u164C\u164D\u62BE;\u699D\u0100pt\u1654\u1657h;\u6222\xBB\xB9arr;\u637C\u0100gp\u1663\u1667on;\u4105f;\uC000\u{1D552}\u0380;Eaeiop\u12C1\u167B\u167D\u1682\u1684\u1687\u168A;\u6A70cir;\u6A6F;\u624Ad;\u624Bs;\u4027rox\u0100;e\u12C1\u1692\xF1\u1683ing\u803B\xE5\u40E5\u0180cty\u16A1\u16A6\u16A8r;\uC000\u{1D4B6};\u402Amp\u0100;e\u12C1\u16AF\xF1\u0288ilde\u803B\xE3\u40E3ml\u803B\xE4\u40E4\u0100ci\u16C2\u16C8onin\xF4\u0272nt;\u6A11\u0800Nabcdefiklnoprsu\u16ED\u16F1\u1730\u173C\u1743\u1748\u1778\u177D\u17E0\u17E6\u1839\u1850\u170D\u193D\u1948\u1970ot;\u6AED\u0100cr\u16F6\u171Ek\u0200ceps\u1700\u1705\u170D\u1713ong;\u624Cpsilon;\u43F6rime;\u6035im\u0100;e\u171A\u171B\u623Dq;\u62CD\u0176\u1722\u1726ee;\u62BDed\u0100;g\u172C\u172D\u6305e\xBB\u172Drk\u0100;t\u135C\u1737brk;\u63B6\u0100oy\u1701\u1741;\u4431quo;\u601E\u0280cmprt\u1753\u175B\u1761\u1764\u1768aus\u0100;e\u010A\u0109ptyv;\u69B0s\xE9\u170Cno\xF5\u0113\u0180ahw\u176F\u1771\u1773;\u43B2;\u6136een;\u626Cr;\uC000\u{1D51F}g\u0380costuvw\u178D\u179D\u17B3\u17C1\u17D5\u17DB\u17DE\u0180aiu\u1794\u1796\u179A\xF0\u0760rc;\u65EFp\xBB\u1371\u0180dpt\u17A4\u17A8\u17ADot;\u6A00lus;\u6A01imes;\u6A02\u0271\u17B9\0\0\u17BEcup;\u6A06ar;\u6605riangle\u0100du\u17CD\u17D2own;\u65BDp;\u65B3plus;\u6A04e\xE5\u1444\xE5\u14ADarow;\u690D\u0180ako\u17ED\u1826\u1835\u0100cn\u17F2\u1823k\u0180lst\u17FA\u05AB\u1802ozenge;\u69EBriangle\u0200;dlr\u1812\u1813\u1818\u181D\u65B4own;\u65BEeft;\u65C2ight;\u65B8k;\u6423\u01B1\u182B\0\u1833\u01B2\u182F\0\u1831;\u6592;\u65914;\u6593ck;\u6588\u0100eo\u183E\u184D\u0100;q\u1843\u1846\uC000=\u20E5uiv;\uC000\u2261\u20E5t;\u6310\u0200ptwx\u1859\u185E\u1867\u186Cf;\uC000\u{1D553}\u0100;t\u13CB\u1863om\xBB\u13CCtie;\u62C8\u0600DHUVbdhmptuv\u1885\u1896\u18AA\u18BB\u18D7\u18DB\u18EC\u18FF\u1905\u190A\u1910\u1921\u0200LRlr\u188E\u1890\u1892\u1894;\u6557;\u6554;\u6556;\u6553\u0280;DUdu\u18A1\u18A2\u18A4\u18A6\u18A8\u6550;\u6566;\u6569;\u6564;\u6567\u0200LRlr\u18B3\u18B5\u18B7\u18B9;\u655D;\u655A;\u655C;\u6559\u0380;HLRhlr\u18CA\u18CB\u18CD\u18CF\u18D1\u18D3\u18D5\u6551;\u656C;\u6563;\u6560;\u656B;\u6562;\u655Fox;\u69C9\u0200LRlr\u18E4\u18E6\u18E8\u18EA;\u6555;\u6552;\u6510;\u650C\u0280;DUdu\u06BD\u18F7\u18F9\u18FB\u18FD;\u6565;\u6568;\u652C;\u6534inus;\u629Flus;\u629Eimes;\u62A0\u0200LRlr\u1919\u191B\u191D\u191F;\u655B;\u6558;\u6518;\u6514\u0380;HLRhlr\u1930\u1931\u1933\u1935\u1937\u1939\u193B\u6502;\u656A;\u6561;\u655E;\u653C;\u6524;\u651C\u0100ev\u0123\u1942bar\u803B\xA6\u40A6\u0200ceio\u1951\u1956\u195A\u1960r;\uC000\u{1D4B7}mi;\u604Fm\u0100;e\u171A\u171Cl\u0180;bh\u1968\u1969\u196B\u405C;\u69C5sub;\u67C8\u016C\u1974\u197El\u0100;e\u1979\u197A\u6022t\xBB\u197Ap\u0180;Ee\u012F\u1985\u1987;\u6AAE\u0100;q\u06DC\u06DB\u0CE1\u19A7\0\u19E8\u1A11\u1A15\u1A32\0\u1A37\u1A50\0\0\u1AB4\0\0\u1AC1\0\0\u1B21\u1B2E\u1B4D\u1B52\0\u1BFD\0\u1C0C\u0180cpr\u19AD\u19B2\u19DDute;\u4107\u0300;abcds\u19BF\u19C0\u19C4\u19CA\u19D5\u19D9\u6229nd;\u6A44rcup;\u6A49\u0100au\u19CF\u19D2p;\u6A4Bp;\u6A47ot;\u6A40;\uC000\u2229\uFE00\u0100eo\u19E2\u19E5t;\u6041\xEE\u0693\u0200aeiu\u19F0\u19FB\u1A01\u1A05\u01F0\u19F5\0\u19F8s;\u6A4Don;\u410Ddil\u803B\xE7\u40E7rc;\u4109ps\u0100;s\u1A0C\u1A0D\u6A4Cm;\u6A50ot;\u410B\u0180dmn\u1A1B\u1A20\u1A26il\u80BB\xB8\u01ADptyv;\u69B2t\u8100\xA2;e\u1A2D\u1A2E\u40A2r\xE4\u01B2r;\uC000\u{1D520}\u0180cei\u1A3D\u1A40\u1A4Dy;\u4447ck\u0100;m\u1A47\u1A48\u6713ark\xBB\u1A48;\u43C7r\u0380;Ecefms\u1A5F\u1A60\u1A62\u1A6B\u1AA4\u1AAA\u1AAE\u65CB;\u69C3\u0180;el\u1A69\u1A6A\u1A6D\u42C6q;\u6257e\u0261\u1A74\0\0\u1A88rrow\u0100lr\u1A7C\u1A81eft;\u61BAight;\u61BB\u0280RSacd\u1A92\u1A94\u1A96\u1A9A\u1A9F\xBB\u0F47;\u64C8st;\u629Birc;\u629Aash;\u629Dnint;\u6A10id;\u6AEFcir;\u69C2ubs\u0100;u\u1ABB\u1ABC\u6663it\xBB\u1ABC\u02EC\u1AC7\u1AD4\u1AFA\0\u1B0Aon\u0100;e\u1ACD\u1ACE\u403A\u0100;q\xC7\xC6\u026D\u1AD9\0\0\u1AE2a\u0100;t\u1ADE\u1ADF\u402C;\u4040\u0180;fl\u1AE8\u1AE9\u1AEB\u6201\xEE\u1160e\u0100mx\u1AF1\u1AF6ent\xBB\u1AE9e\xF3\u024D\u01E7\u1AFE\0\u1B07\u0100;d\u12BB\u1B02ot;\u6A6Dn\xF4\u0246\u0180fry\u1B10\u1B14\u1B17;\uC000\u{1D554}o\xE4\u0254\u8100\xA9;s\u0155\u1B1Dr;\u6117\u0100ao\u1B25\u1B29rr;\u61B5ss;\u6717\u0100cu\u1B32\u1B37r;\uC000\u{1D4B8}\u0100bp\u1B3C\u1B44\u0100;e\u1B41\u1B42\u6ACF;\u6AD1\u0100;e\u1B49\u1B4A\u6AD0;\u6AD2dot;\u62EF\u0380delprvw\u1B60\u1B6C\u1B77\u1B82\u1BAC\u1BD4\u1BF9arr\u0100lr\u1B68\u1B6A;\u6938;\u6935\u0270\u1B72\0\0\u1B75r;\u62DEc;\u62DFarr\u0100;p\u1B7F\u1B80\u61B6;\u693D\u0300;bcdos\u1B8F\u1B90\u1B96\u1BA1\u1BA5\u1BA8\u622Arcap;\u6A48\u0100au\u1B9B\u1B9Ep;\u6A46p;\u6A4Aot;\u628Dr;\u6A45;\uC000\u222A\uFE00\u0200alrv\u1BB5\u1BBF\u1BDE\u1BE3rr\u0100;m\u1BBC\u1BBD\u61B7;\u693Cy\u0180evw\u1BC7\u1BD4\u1BD8q\u0270\u1BCE\0\0\u1BD2re\xE3\u1B73u\xE3\u1B75ee;\u62CEedge;\u62CFen\u803B\xA4\u40A4earrow\u0100lr\u1BEE\u1BF3eft\xBB\u1B80ight\xBB\u1BBDe\xE4\u1BDD\u0100ci\u1C01\u1C07onin\xF4\u01F7nt;\u6231lcty;\u632D\u0980AHabcdefhijlorstuwz\u1C38\u1C3B\u1C3F\u1C5D\u1C69\u1C75\u1C8A\u1C9E\u1CAC\u1CB7\u1CFB\u1CFF\u1D0D\u1D7B\u1D91\u1DAB\u1DBB\u1DC6\u1DCDr\xF2\u0381ar;\u6965\u0200glrs\u1C48\u1C4D\u1C52\u1C54ger;\u6020eth;\u6138\xF2\u1133h\u0100;v\u1C5A\u1C5B\u6010\xBB\u090A\u016B\u1C61\u1C67arow;\u690Fa\xE3\u0315\u0100ay\u1C6E\u1C73ron;\u410F;\u4434\u0180;ao\u0332\u1C7C\u1C84\u0100gr\u02BF\u1C81r;\u61CAtseq;\u6A77\u0180glm\u1C91\u1C94\u1C98\u803B\xB0\u40B0ta;\u43B4ptyv;\u69B1\u0100ir\u1CA3\u1CA8sht;\u697F;\uC000\u{1D521}ar\u0100lr\u1CB3\u1CB5\xBB\u08DC\xBB\u101E\u0280aegsv\u1CC2\u0378\u1CD6\u1CDC\u1CE0m\u0180;os\u0326\u1CCA\u1CD4nd\u0100;s\u0326\u1CD1uit;\u6666amma;\u43DDin;\u62F2\u0180;io\u1CE7\u1CE8\u1CF8\u40F7de\u8100\xF7;o\u1CE7\u1CF0ntimes;\u62C7n\xF8\u1CF7cy;\u4452c\u026F\u1D06\0\0\u1D0Arn;\u631Eop;\u630D\u0280lptuw\u1D18\u1D1D\u1D22\u1D49\u1D55lar;\u4024f;\uC000\u{1D555}\u0280;emps\u030B\u1D2D\u1D37\u1D3D\u1D42q\u0100;d\u0352\u1D33ot;\u6251inus;\u6238lus;\u6214quare;\u62A1blebarwedg\xE5\xFAn\u0180adh\u112E\u1D5D\u1D67ownarrow\xF3\u1C83arpoon\u0100lr\u1D72\u1D76ef\xF4\u1CB4igh\xF4\u1CB6\u0162\u1D7F\u1D85karo\xF7\u0F42\u026F\u1D8A\0\0\u1D8Ern;\u631Fop;\u630C\u0180cot\u1D98\u1DA3\u1DA6\u0100ry\u1D9D\u1DA1;\uC000\u{1D4B9};\u4455l;\u69F6rok;\u4111\u0100dr\u1DB0\u1DB4ot;\u62F1i\u0100;f\u1DBA\u1816\u65BF\u0100ah\u1DC0\u1DC3r\xF2\u0429a\xF2\u0FA6angle;\u69A6\u0100ci\u1DD2\u1DD5y;\u445Fgrarr;\u67FF\u0900Dacdefglmnopqrstux\u1E01\u1E09\u1E19\u1E38\u0578\u1E3C\u1E49\u1E61\u1E7E\u1EA5\u1EAF\u1EBD\u1EE1\u1F2A\u1F37\u1F44\u1F4E\u1F5A\u0100Do\u1E06\u1D34o\xF4\u1C89\u0100cs\u1E0E\u1E14ute\u803B\xE9\u40E9ter;\u6A6E\u0200aioy\u1E22\u1E27\u1E31\u1E36ron;\u411Br\u0100;c\u1E2D\u1E2E\u6256\u803B\xEA\u40EAlon;\u6255;\u444Dot;\u4117\u0100Dr\u1E41\u1E45ot;\u6252;\uC000\u{1D522}\u0180;rs\u1E50\u1E51\u1E57\u6A9Aave\u803B\xE8\u40E8\u0100;d\u1E5C\u1E5D\u6A96ot;\u6A98\u0200;ils\u1E6A\u1E6B\u1E72\u1E74\u6A99nters;\u63E7;\u6113\u0100;d\u1E79\u1E7A\u6A95ot;\u6A97\u0180aps\u1E85\u1E89\u1E97cr;\u4113ty\u0180;sv\u1E92\u1E93\u1E95\u6205et\xBB\u1E93p\u01001;\u1E9D\u1EA4\u0133\u1EA1\u1EA3;\u6004;\u6005\u6003\u0100gs\u1EAA\u1EAC;\u414Bp;\u6002\u0100gp\u1EB4\u1EB8on;\u4119f;\uC000\u{1D556}\u0180als\u1EC4\u1ECE\u1ED2r\u0100;s\u1ECA\u1ECB\u62D5l;\u69E3us;\u6A71i\u0180;lv\u1EDA\u1EDB\u1EDF\u43B5on\xBB\u1EDB;\u43F5\u0200csuv\u1EEA\u1EF3\u1F0B\u1F23\u0100io\u1EEF\u1E31rc\xBB\u1E2E\u0269\u1EF9\0\0\u1EFB\xED\u0548ant\u0100gl\u1F02\u1F06tr\xBB\u1E5Dess\xBB\u1E7A\u0180aei\u1F12\u1F16\u1F1Als;\u403Dst;\u625Fv\u0100;D\u0235\u1F20D;\u6A78parsl;\u69E5\u0100Da\u1F2F\u1F33ot;\u6253rr;\u6971\u0180cdi\u1F3E\u1F41\u1EF8r;\u612Fo\xF4\u0352\u0100ah\u1F49\u1F4B;\u43B7\u803B\xF0\u40F0\u0100mr\u1F53\u1F57l\u803B\xEB\u40EBo;\u60AC\u0180cip\u1F61\u1F64\u1F67l;\u4021s\xF4\u056E\u0100eo\u1F6C\u1F74ctatio\xEE\u0559nential\xE5\u0579\u09E1\u1F92\0\u1F9E\0\u1FA1\u1FA7\0\0\u1FC6\u1FCC\0\u1FD3\0\u1FE6\u1FEA\u2000\0\u2008\u205Allingdotse\xF1\u1E44y;\u4444male;\u6640\u0180ilr\u1FAD\u1FB3\u1FC1lig;\u8000\uFB03\u0269\u1FB9\0\0\u1FBDg;\u8000\uFB00ig;\u8000\uFB04;\uC000\u{1D523}lig;\u8000\uFB01lig;\uC000fj\u0180alt\u1FD9\u1FDC\u1FE1t;\u666Dig;\u8000\uFB02ns;\u65B1of;\u4192\u01F0\u1FEE\0\u1FF3f;\uC000\u{1D557}\u0100ak\u05BF\u1FF7\u0100;v\u1FFC\u1FFD\u62D4;\u6AD9artint;\u6A0D\u0100ao\u200C\u2055\u0100cs\u2011\u2052\u03B1\u201A\u2030\u2038\u2045\u2048\0\u2050\u03B2\u2022\u2025\u2027\u202A\u202C\0\u202E\u803B\xBD\u40BD;\u6153\u803B\xBC\u40BC;\u6155;\u6159;\u615B\u01B3\u2034\0\u2036;\u6154;\u6156\u02B4\u203E\u2041\0\0\u2043\u803B\xBE\u40BE;\u6157;\u615C5;\u6158\u01B6\u204C\0\u204E;\u615A;\u615D8;\u615El;\u6044wn;\u6322cr;\uC000\u{1D4BB}\u0880Eabcdefgijlnorstv\u2082\u2089\u209F\u20A5\u20B0\u20B4\u20F0\u20F5\u20FA\u20FF\u2103\u2112\u2138\u0317\u213E\u2152\u219E\u0100;l\u064D\u2087;\u6A8C\u0180cmp\u2090\u2095\u209Dute;\u41F5ma\u0100;d\u209C\u1CDA\u43B3;\u6A86reve;\u411F\u0100iy\u20AA\u20AErc;\u411D;\u4433ot;\u4121\u0200;lqs\u063E\u0642\u20BD\u20C9\u0180;qs\u063E\u064C\u20C4lan\xF4\u0665\u0200;cdl\u0665\u20D2\u20D5\u20E5c;\u6AA9ot\u0100;o\u20DC\u20DD\u6A80\u0100;l\u20E2\u20E3\u6A82;\u6A84\u0100;e\u20EA\u20ED\uC000\u22DB\uFE00s;\u6A94r;\uC000\u{1D524}\u0100;g\u0673\u061Bmel;\u6137cy;\u4453\u0200;Eaj\u065A\u210C\u210E\u2110;\u6A92;\u6AA5;\u6AA4\u0200Eaes\u211B\u211D\u2129\u2134;\u6269p\u0100;p\u2123\u2124\u6A8Arox\xBB\u2124\u0100;q\u212E\u212F\u6A88\u0100;q\u212E\u211Bim;\u62E7pf;\uC000\u{1D558}\u0100ci\u2143\u2146r;\u610Am\u0180;el\u066B\u214E\u2150;\u6A8E;\u6A90\u8300>;cdlqr\u05EE\u2160\u216A\u216E\u2173\u2179\u0100ci\u2165\u2167;\u6AA7r;\u6A7Aot;\u62D7Par;\u6995uest;\u6A7C\u0280adels\u2184\u216A\u2190\u0656\u219B\u01F0\u2189\0\u218Epro\xF8\u209Er;\u6978q\u0100lq\u063F\u2196les\xF3\u2088i\xED\u066B\u0100en\u21A3\u21ADrtneqq;\uC000\u2269\uFE00\xC5\u21AA\u0500Aabcefkosy\u21C4\u21C7\u21F1\u21F5\u21FA\u2218\u221D\u222F\u2268\u227Dr\xF2\u03A0\u0200ilmr\u21D0\u21D4\u21D7\u21DBrs\xF0\u1484f\xBB\u2024il\xF4\u06A9\u0100dr\u21E0\u21E4cy;\u444A\u0180;cw\u08F4\u21EB\u21EFir;\u6948;\u61ADar;\u610Firc;\u4125\u0180alr\u2201\u220E\u2213rts\u0100;u\u2209\u220A\u6665it\xBB\u220Alip;\u6026con;\u62B9r;\uC000\u{1D525}s\u0100ew\u2223\u2229arow;\u6925arow;\u6926\u0280amopr\u223A\u223E\u2243\u225E\u2263rr;\u61FFtht;\u623Bk\u0100lr\u2249\u2253eftarrow;\u61A9ightarrow;\u61AAf;\uC000\u{1D559}bar;\u6015\u0180clt\u226F\u2274\u2278r;\uC000\u{1D4BD}as\xE8\u21F4rok;\u4127\u0100bp\u2282\u2287ull;\u6043hen\xBB\u1C5B\u0AE1\u22A3\0\u22AA\0\u22B8\u22C5\u22CE\0\u22D5\u22F3\0\0\u22F8\u2322\u2367\u2362\u237F\0\u2386\u23AA\u23B4cute\u803B\xED\u40ED\u0180;iy\u0771\u22B0\u22B5rc\u803B\xEE\u40EE;\u4438\u0100cx\u22BC\u22BFy;\u4435cl\u803B\xA1\u40A1\u0100fr\u039F\u22C9;\uC000\u{1D526}rave\u803B\xEC\u40EC\u0200;ino\u073E\u22DD\u22E9\u22EE\u0100in\u22E2\u22E6nt;\u6A0Ct;\u622Dfin;\u69DCta;\u6129lig;\u4133\u0180aop\u22FE\u231A\u231D\u0180cgt\u2305\u2308\u2317r;\u412B\u0180elp\u071F\u230F\u2313in\xE5\u078Ear\xF4\u0720h;\u4131f;\u62B7ed;\u41B5\u0280;cfot\u04F4\u232C\u2331\u233D\u2341are;\u6105in\u0100;t\u2338\u2339\u621Eie;\u69DDdo\xF4\u2319\u0280;celp\u0757\u234C\u2350\u235B\u2361al;\u62BA\u0100gr\u2355\u2359er\xF3\u1563\xE3\u234Darhk;\u6A17rod;\u6A3C\u0200cgpt\u236F\u2372\u2376\u237By;\u4451on;\u412Ff;\uC000\u{1D55A}a;\u43B9uest\u803B\xBF\u40BF\u0100ci\u238A\u238Fr;\uC000\u{1D4BE}n\u0280;Edsv\u04F4\u239B\u239D\u23A1\u04F3;\u62F9ot;\u62F5\u0100;v\u23A6\u23A7\u62F4;\u62F3\u0100;i\u0777\u23AElde;\u4129\u01EB\u23B8\0\u23BCcy;\u4456l\u803B\xEF\u40EF\u0300cfmosu\u23CC\u23D7\u23DC\u23E1\u23E7\u23F5\u0100iy\u23D1\u23D5rc;\u4135;\u4439r;\uC000\u{1D527}ath;\u4237pf;\uC000\u{1D55B}\u01E3\u23EC\0\u23F1r;\uC000\u{1D4BF}rcy;\u4458kcy;\u4454\u0400acfghjos\u240B\u2416\u2422\u2427\u242D\u2431\u2435\u243Bppa\u0100;v\u2413\u2414\u43BA;\u43F0\u0100ey\u241B\u2420dil;\u4137;\u443Ar;\uC000\u{1D528}reen;\u4138cy;\u4445cy;\u445Cpf;\uC000\u{1D55C}cr;\uC000\u{1D4C0}\u0B80ABEHabcdefghjlmnoprstuv\u2470\u2481\u2486\u248D\u2491\u250E\u253D\u255A\u2580\u264E\u265E\u2665\u2679\u267D\u269A\u26B2\u26D8\u275D\u2768\u278B\u27C0\u2801\u2812\u0180art\u2477\u247A\u247Cr\xF2\u09C6\xF2\u0395ail;\u691Barr;\u690E\u0100;g\u0994\u248B;\u6A8Bar;\u6962\u0963\u24A5\0\u24AA\0\u24B1\0\0\0\0\0\u24B5\u24BA\0\u24C6\u24C8\u24CD\0\u24F9ute;\u413Amptyv;\u69B4ra\xEE\u084Cbda;\u43BBg\u0180;dl\u088E\u24C1\u24C3;\u6991\xE5\u088E;\u6A85uo\u803B\xAB\u40ABr\u0400;bfhlpst\u0899\u24DE\u24E6\u24E9\u24EB\u24EE\u24F1\u24F5\u0100;f\u089D\u24E3s;\u691Fs;\u691D\xEB\u2252p;\u61ABl;\u6939im;\u6973l;\u61A2\u0180;ae\u24FF\u2500\u2504\u6AABil;\u6919\u0100;s\u2509\u250A\u6AAD;\uC000\u2AAD\uFE00\u0180abr\u2515\u2519\u251Drr;\u690Crk;\u6772\u0100ak\u2522\u252Cc\u0100ek\u2528\u252A;\u407B;\u405B\u0100es\u2531\u2533;\u698Bl\u0100du\u2539\u253B;\u698F;\u698D\u0200aeuy\u2546\u254B\u2556\u2558ron;\u413E\u0100di\u2550\u2554il;\u413C\xEC\u08B0\xE2\u2529;\u443B\u0200cqrs\u2563\u2566\u256D\u257Da;\u6936uo\u0100;r\u0E19\u1746\u0100du\u2572\u2577har;\u6967shar;\u694Bh;\u61B2\u0280;fgqs\u258B\u258C\u0989\u25F3\u25FF\u6264t\u0280ahlrt\u2598\u25A4\u25B7\u25C2\u25E8rrow\u0100;t\u0899\u25A1a\xE9\u24F6arpoon\u0100du\u25AF\u25B4own\xBB\u045Ap\xBB\u0966eftarrows;\u61C7ight\u0180ahs\u25CD\u25D6\u25DErrow\u0100;s\u08F4\u08A7arpoon\xF3\u0F98quigarro\xF7\u21F0hreetimes;\u62CB\u0180;qs\u258B\u0993\u25FAlan\xF4\u09AC\u0280;cdgs\u09AC\u260A\u260D\u261D\u2628c;\u6AA8ot\u0100;o\u2614\u2615\u6A7F\u0100;r\u261A\u261B\u6A81;\u6A83\u0100;e\u2622\u2625\uC000\u22DA\uFE00s;\u6A93\u0280adegs\u2633\u2639\u263D\u2649\u264Bppro\xF8\u24C6ot;\u62D6q\u0100gq\u2643\u2645\xF4\u0989gt\xF2\u248C\xF4\u099Bi\xED\u09B2\u0180ilr\u2655\u08E1\u265Asht;\u697C;\uC000\u{1D529}\u0100;E\u099C\u2663;\u6A91\u0161\u2669\u2676r\u0100du\u25B2\u266E\u0100;l\u0965\u2673;\u696Alk;\u6584cy;\u4459\u0280;acht\u0A48\u2688\u268B\u2691\u2696r\xF2\u25C1orne\xF2\u1D08ard;\u696Bri;\u65FA\u0100io\u269F\u26A4dot;\u4140ust\u0100;a\u26AC\u26AD\u63B0che\xBB\u26AD\u0200Eaes\u26BB\u26BD\u26C9\u26D4;\u6268p\u0100;p\u26C3\u26C4\u6A89rox\xBB\u26C4\u0100;q\u26CE\u26CF\u6A87\u0100;q\u26CE\u26BBim;\u62E6\u0400abnoptwz\u26E9\u26F4\u26F7\u271A\u272F\u2741\u2747\u2750\u0100nr\u26EE\u26F1g;\u67ECr;\u61FDr\xEB\u08C1g\u0180lmr\u26FF\u270D\u2714eft\u0100ar\u09E6\u2707ight\xE1\u09F2apsto;\u67FCight\xE1\u09FDparrow\u0100lr\u2725\u2729ef\xF4\u24EDight;\u61AC\u0180afl\u2736\u2739\u273Dr;\u6985;\uC000\u{1D55D}us;\u6A2Dimes;\u6A34\u0161\u274B\u274Fst;\u6217\xE1\u134E\u0180;ef\u2757\u2758\u1800\u65CAnge\xBB\u2758ar\u0100;l\u2764\u2765\u4028t;\u6993\u0280achmt\u2773\u2776\u277C\u2785\u2787r\xF2\u08A8orne\xF2\u1D8Car\u0100;d\u0F98\u2783;\u696D;\u600Eri;\u62BF\u0300achiqt\u2798\u279D\u0A40\u27A2\u27AE\u27BBquo;\u6039r;\uC000\u{1D4C1}m\u0180;eg\u09B2\u27AA\u27AC;\u6A8D;\u6A8F\u0100bu\u252A\u27B3o\u0100;r\u0E1F\u27B9;\u601Arok;\u4142\u8400<;cdhilqr\u082B\u27D2\u2639\u27DC\u27E0\u27E5\u27EA\u27F0\u0100ci\u27D7\u27D9;\u6AA6r;\u6A79re\xE5\u25F2mes;\u62C9arr;\u6976uest;\u6A7B\u0100Pi\u27F5\u27F9ar;\u6996\u0180;ef\u2800\u092D\u181B\u65C3r\u0100du\u2807\u280Dshar;\u694Ahar;\u6966\u0100en\u2817\u2821rtneqq;\uC000\u2268\uFE00\xC5\u281E\u0700Dacdefhilnopsu\u2840\u2845\u2882\u288E\u2893\u28A0\u28A5\u28A8\u28DA\u28E2\u28E4\u0A83\u28F3\u2902Dot;\u623A\u0200clpr\u284E\u2852\u2863\u287Dr\u803B\xAF\u40AF\u0100et\u2857\u2859;\u6642\u0100;e\u285E\u285F\u6720se\xBB\u285F\u0100;s\u103B\u2868to\u0200;dlu\u103B\u2873\u2877\u287Bow\xEE\u048Cef\xF4\u090F\xF0\u13D1ker;\u65AE\u0100oy\u2887\u288Cmma;\u6A29;\u443Cash;\u6014asuredangle\xBB\u1626r;\uC000\u{1D52A}o;\u6127\u0180cdn\u28AF\u28B4\u28C9ro\u803B\xB5\u40B5\u0200;acd\u1464\u28BD\u28C0\u28C4s\xF4\u16A7ir;\u6AF0ot\u80BB\xB7\u01B5us\u0180;bd\u28D2\u1903\u28D3\u6212\u0100;u\u1D3C\u28D8;\u6A2A\u0163\u28DE\u28E1p;\u6ADB\xF2\u2212\xF0\u0A81\u0100dp\u28E9\u28EEels;\u62A7f;\uC000\u{1D55E}\u0100ct\u28F8\u28FDr;\uC000\u{1D4C2}pos\xBB\u159D\u0180;lm\u2909\u290A\u290D\u43BCtimap;\u62B8\u0C00GLRVabcdefghijlmoprstuvw\u2942\u2953\u297E\u2989\u2998\u29DA\u29E9\u2A15\u2A1A\u2A58\u2A5D\u2A83\u2A95\u2AA4\u2AA8\u2B04\u2B07\u2B44\u2B7F\u2BAE\u2C34\u2C67\u2C7C\u2CE9\u0100gt\u2947\u294B;\uC000\u22D9\u0338\u0100;v\u2950\u0BCF\uC000\u226B\u20D2\u0180elt\u295A\u2972\u2976ft\u0100ar\u2961\u2967rrow;\u61CDightarrow;\u61CE;\uC000\u22D8\u0338\u0100;v\u297B\u0C47\uC000\u226A\u20D2ightarrow;\u61CF\u0100Dd\u298E\u2993ash;\u62AFash;\u62AE\u0280bcnpt\u29A3\u29A7\u29AC\u29B1\u29CCla\xBB\u02DEute;\u4144g;\uC000\u2220\u20D2\u0280;Eiop\u0D84\u29BC\u29C0\u29C5\u29C8;\uC000\u2A70\u0338d;\uC000\u224B\u0338s;\u4149ro\xF8\u0D84ur\u0100;a\u29D3\u29D4\u666El\u0100;s\u29D3\u0B38\u01F3\u29DF\0\u29E3p\u80BB\xA0\u0B37mp\u0100;e\u0BF9\u0C00\u0280aeouy\u29F4\u29FE\u2A03\u2A10\u2A13\u01F0\u29F9\0\u29FB;\u6A43on;\u4148dil;\u4146ng\u0100;d\u0D7E\u2A0Aot;\uC000\u2A6D\u0338p;\u6A42;\u443Dash;\u6013\u0380;Aadqsx\u0B92\u2A29\u2A2D\u2A3B\u2A41\u2A45\u2A50rr;\u61D7r\u0100hr\u2A33\u2A36k;\u6924\u0100;o\u13F2\u13F0ot;\uC000\u2250\u0338ui\xF6\u0B63\u0100ei\u2A4A\u2A4Ear;\u6928\xED\u0B98ist\u0100;s\u0BA0\u0B9Fr;\uC000\u{1D52B}\u0200Eest\u0BC5\u2A66\u2A79\u2A7C\u0180;qs\u0BBC\u2A6D\u0BE1\u0180;qs\u0BBC\u0BC5\u2A74lan\xF4\u0BE2i\xED\u0BEA\u0100;r\u0BB6\u2A81\xBB\u0BB7\u0180Aap\u2A8A\u2A8D\u2A91r\xF2\u2971rr;\u61AEar;\u6AF2\u0180;sv\u0F8D\u2A9C\u0F8C\u0100;d\u2AA1\u2AA2\u62FC;\u62FAcy;\u445A\u0380AEadest\u2AB7\u2ABA\u2ABE\u2AC2\u2AC5\u2AF6\u2AF9r\xF2\u2966;\uC000\u2266\u0338rr;\u619Ar;\u6025\u0200;fqs\u0C3B\u2ACE\u2AE3\u2AEFt\u0100ar\u2AD4\u2AD9rro\xF7\u2AC1ightarro\xF7\u2A90\u0180;qs\u0C3B\u2ABA\u2AEAlan\xF4\u0C55\u0100;s\u0C55\u2AF4\xBB\u0C36i\xED\u0C5D\u0100;r\u0C35\u2AFEi\u0100;e\u0C1A\u0C25i\xE4\u0D90\u0100pt\u2B0C\u2B11f;\uC000\u{1D55F}\u8180\xAC;in\u2B19\u2B1A\u2B36\u40ACn\u0200;Edv\u0B89\u2B24\u2B28\u2B2E;\uC000\u22F9\u0338ot;\uC000\u22F5\u0338\u01E1\u0B89\u2B33\u2B35;\u62F7;\u62F6i\u0100;v\u0CB8\u2B3C\u01E1\u0CB8\u2B41\u2B43;\u62FE;\u62FD\u0180aor\u2B4B\u2B63\u2B69r\u0200;ast\u0B7B\u2B55\u2B5A\u2B5Flle\xEC\u0B7Bl;\uC000\u2AFD\u20E5;\uC000\u2202\u0338lint;\u6A14\u0180;ce\u0C92\u2B70\u2B73u\xE5\u0CA5\u0100;c\u0C98\u2B78\u0100;e\u0C92\u2B7D\xF1\u0C98\u0200Aait\u2B88\u2B8B\u2B9D\u2BA7r\xF2\u2988rr\u0180;cw\u2B94\u2B95\u2B99\u619B;\uC000\u2933\u0338;\uC000\u219D\u0338ghtarrow\xBB\u2B95ri\u0100;e\u0CCB\u0CD6\u0380chimpqu\u2BBD\u2BCD\u2BD9\u2B04\u0B78\u2BE4\u2BEF\u0200;cer\u0D32\u2BC6\u0D37\u2BC9u\xE5\u0D45;\uC000\u{1D4C3}ort\u026D\u2B05\0\0\u2BD6ar\xE1\u2B56m\u0100;e\u0D6E\u2BDF\u0100;q\u0D74\u0D73su\u0100bp\u2BEB\u2BED\xE5\u0CF8\xE5\u0D0B\u0180bcp\u2BF6\u2C11\u2C19\u0200;Ees\u2BFF\u2C00\u0D22\u2C04\u6284;\uC000\u2AC5\u0338et\u0100;e\u0D1B\u2C0Bq\u0100;q\u0D23\u2C00c\u0100;e\u0D32\u2C17\xF1\u0D38\u0200;Ees\u2C22\u2C23\u0D5F\u2C27\u6285;\uC000\u2AC6\u0338et\u0100;e\u0D58\u2C2Eq\u0100;q\u0D60\u2C23\u0200gilr\u2C3D\u2C3F\u2C45\u2C47\xEC\u0BD7lde\u803B\xF1\u40F1\xE7\u0C43iangle\u0100lr\u2C52\u2C5Ceft\u0100;e\u0C1A\u2C5A\xF1\u0C26ight\u0100;e\u0CCB\u2C65\xF1\u0CD7\u0100;m\u2C6C\u2C6D\u43BD\u0180;es\u2C74\u2C75\u2C79\u4023ro;\u6116p;\u6007\u0480DHadgilrs\u2C8F\u2C94\u2C99\u2C9E\u2CA3\u2CB0\u2CB6\u2CD3\u2CE3ash;\u62ADarr;\u6904p;\uC000\u224D\u20D2ash;\u62AC\u0100et\u2CA8\u2CAC;\uC000\u2265\u20D2;\uC000>\u20D2nfin;\u69DE\u0180Aet\u2CBD\u2CC1\u2CC5rr;\u6902;\uC000\u2264\u20D2\u0100;r\u2CCA\u2CCD\uC000<\u20D2ie;\uC000\u22B4\u20D2\u0100At\u2CD8\u2CDCrr;\u6903rie;\uC000\u22B5\u20D2im;\uC000\u223C\u20D2\u0180Aan\u2CF0\u2CF4\u2D02rr;\u61D6r\u0100hr\u2CFA\u2CFDk;\u6923\u0100;o\u13E7\u13E5ear;\u6927\u1253\u1A95\0\0\0\0\0\0\0\0\0\0\0\0\0\u2D2D\0\u2D38\u2D48\u2D60\u2D65\u2D72\u2D84\u1B07\0\0\u2D8D\u2DAB\0\u2DC8\u2DCE\0\u2DDC\u2E19\u2E2B\u2E3E\u2E43\u0100cs\u2D31\u1A97ute\u803B\xF3\u40F3\u0100iy\u2D3C\u2D45r\u0100;c\u1A9E\u2D42\u803B\xF4\u40F4;\u443E\u0280abios\u1AA0\u2D52\u2D57\u01C8\u2D5Alac;\u4151v;\u6A38old;\u69BClig;\u4153\u0100cr\u2D69\u2D6Dir;\u69BF;\uC000\u{1D52C}\u036F\u2D79\0\0\u2D7C\0\u2D82n;\u42DBave\u803B\xF2\u40F2;\u69C1\u0100bm\u2D88\u0DF4ar;\u69B5\u0200acit\u2D95\u2D98\u2DA5\u2DA8r\xF2\u1A80\u0100ir\u2D9D\u2DA0r;\u69BEoss;\u69BBn\xE5\u0E52;\u69C0\u0180aei\u2DB1\u2DB5\u2DB9cr;\u414Dga;\u43C9\u0180cdn\u2DC0\u2DC5\u01CDron;\u43BF;\u69B6pf;\uC000\u{1D560}\u0180ael\u2DD4\u2DD7\u01D2r;\u69B7rp;\u69B9\u0380;adiosv\u2DEA\u2DEB\u2DEE\u2E08\u2E0D\u2E10\u2E16\u6228r\xF2\u1A86\u0200;efm\u2DF7\u2DF8\u2E02\u2E05\u6A5Dr\u0100;o\u2DFE\u2DFF\u6134f\xBB\u2DFF\u803B\xAA\u40AA\u803B\xBA\u40BAgof;\u62B6r;\u6A56lope;\u6A57;\u6A5B\u0180clo\u2E1F\u2E21\u2E27\xF2\u2E01ash\u803B\xF8\u40F8l;\u6298i\u016C\u2E2F\u2E34de\u803B\xF5\u40F5es\u0100;a\u01DB\u2E3As;\u6A36ml\u803B\xF6\u40F6bar;\u633D\u0AE1\u2E5E\0\u2E7D\0\u2E80\u2E9D\0\u2EA2\u2EB9\0\0\u2ECB\u0E9C\0\u2F13\0\0\u2F2B\u2FBC\0\u2FC8r\u0200;ast\u0403\u2E67\u2E72\u0E85\u8100\xB6;l\u2E6D\u2E6E\u40B6le\xEC\u0403\u0269\u2E78\0\0\u2E7Bm;\u6AF3;\u6AFDy;\u443Fr\u0280cimpt\u2E8B\u2E8F\u2E93\u1865\u2E97nt;\u4025od;\u402Eil;\u6030enk;\u6031r;\uC000\u{1D52D}\u0180imo\u2EA8\u2EB0\u2EB4\u0100;v\u2EAD\u2EAE\u43C6;\u43D5ma\xF4\u0A76ne;\u660E\u0180;tv\u2EBF\u2EC0\u2EC8\u43C0chfork\xBB\u1FFD;\u43D6\u0100au\u2ECF\u2EDFn\u0100ck\u2ED5\u2EDDk\u0100;h\u21F4\u2EDB;\u610E\xF6\u21F4s\u0480;abcdemst\u2EF3\u2EF4\u1908\u2EF9\u2EFD\u2F04\u2F06\u2F0A\u2F0E\u402Bcir;\u6A23ir;\u6A22\u0100ou\u1D40\u2F02;\u6A25;\u6A72n\u80BB\xB1\u0E9Dim;\u6A26wo;\u6A27\u0180ipu\u2F19\u2F20\u2F25ntint;\u6A15f;\uC000\u{1D561}nd\u803B\xA3\u40A3\u0500;Eaceinosu\u0EC8\u2F3F\u2F41\u2F44\u2F47\u2F81\u2F89\u2F92\u2F7E\u2FB6;\u6AB3p;\u6AB7u\xE5\u0ED9\u0100;c\u0ECE\u2F4C\u0300;acens\u0EC8\u2F59\u2F5F\u2F66\u2F68\u2F7Eppro\xF8\u2F43urlye\xF1\u0ED9\xF1\u0ECE\u0180aes\u2F6F\u2F76\u2F7Approx;\u6AB9qq;\u6AB5im;\u62E8i\xED\u0EDFme\u0100;s\u2F88\u0EAE\u6032\u0180Eas\u2F78\u2F90\u2F7A\xF0\u2F75\u0180dfp\u0EEC\u2F99\u2FAF\u0180als\u2FA0\u2FA5\u2FAAlar;\u632Eine;\u6312urf;\u6313\u0100;t\u0EFB\u2FB4\xEF\u0EFBrel;\u62B0\u0100ci\u2FC0\u2FC5r;\uC000\u{1D4C5};\u43C8ncsp;\u6008\u0300fiopsu\u2FDA\u22E2\u2FDF\u2FE5\u2FEB\u2FF1r;\uC000\u{1D52E}pf;\uC000\u{1D562}rime;\u6057cr;\uC000\u{1D4C6}\u0180aeo\u2FF8\u3009\u3013t\u0100ei\u2FFE\u3005rnion\xF3\u06B0nt;\u6A16st\u0100;e\u3010\u3011\u403F\xF1\u1F19\xF4\u0F14\u0A80ABHabcdefhilmnoprstux\u3040\u3051\u3055\u3059\u30E0\u310E\u312B\u3147\u3162\u3172\u318E\u3206\u3215\u3224\u3229\u3258\u326E\u3272\u3290\u32B0\u32B7\u0180art\u3047\u304A\u304Cr\xF2\u10B3\xF2\u03DDail;\u691Car\xF2\u1C65ar;\u6964\u0380cdenqrt\u3068\u3075\u3078\u307F\u308F\u3094\u30CC\u0100eu\u306D\u3071;\uC000\u223D\u0331te;\u4155i\xE3\u116Emptyv;\u69B3g\u0200;del\u0FD1\u3089\u308B\u308D;\u6992;\u69A5\xE5\u0FD1uo\u803B\xBB\u40BBr\u0580;abcfhlpstw\u0FDC\u30AC\u30AF\u30B7\u30B9\u30BC\u30BE\u30C0\u30C3\u30C7\u30CAp;\u6975\u0100;f\u0FE0\u30B4s;\u6920;\u6933s;\u691E\xEB\u225D\xF0\u272El;\u6945im;\u6974l;\u61A3;\u619D\u0100ai\u30D1\u30D5il;\u691Ao\u0100;n\u30DB\u30DC\u6236al\xF3\u0F1E\u0180abr\u30E7\u30EA\u30EEr\xF2\u17E5rk;\u6773\u0100ak\u30F3\u30FDc\u0100ek\u30F9\u30FB;\u407D;\u405D\u0100es\u3102\u3104;\u698Cl\u0100du\u310A\u310C;\u698E;\u6990\u0200aeuy\u3117\u311C\u3127\u3129ron;\u4159\u0100di\u3121\u3125il;\u4157\xEC\u0FF2\xE2\u30FA;\u4440\u0200clqs\u3134\u3137\u313D\u3144a;\u6937dhar;\u6969uo\u0100;r\u020E\u020Dh;\u61B3\u0180acg\u314E\u315F\u0F44l\u0200;ips\u0F78\u3158\u315B\u109Cn\xE5\u10BBar\xF4\u0FA9t;\u65AD\u0180ilr\u3169\u1023\u316Esht;\u697D;\uC000\u{1D52F}\u0100ao\u3177\u3186r\u0100du\u317D\u317F\xBB\u047B\u0100;l\u1091\u3184;\u696C\u0100;v\u318B\u318C\u43C1;\u43F1\u0180gns\u3195\u31F9\u31FCht\u0300ahlrst\u31A4\u31B0\u31C2\u31D8\u31E4\u31EErrow\u0100;t\u0FDC\u31ADa\xE9\u30C8arpoon\u0100du\u31BB\u31BFow\xEE\u317Ep\xBB\u1092eft\u0100ah\u31CA\u31D0rrow\xF3\u0FEAarpoon\xF3\u0551ightarrows;\u61C9quigarro\xF7\u30CBhreetimes;\u62CCg;\u42DAingdotse\xF1\u1F32\u0180ahm\u320D\u3210\u3213r\xF2\u0FEAa\xF2\u0551;\u600Foust\u0100;a\u321E\u321F\u63B1che\xBB\u321Fmid;\u6AEE\u0200abpt\u3232\u323D\u3240\u3252\u0100nr\u3237\u323Ag;\u67EDr;\u61FEr\xEB\u1003\u0180afl\u3247\u324A\u324Er;\u6986;\uC000\u{1D563}us;\u6A2Eimes;\u6A35\u0100ap\u325D\u3267r\u0100;g\u3263\u3264\u4029t;\u6994olint;\u6A12ar\xF2\u31E3\u0200achq\u327B\u3280\u10BC\u3285quo;\u603Ar;\uC000\u{1D4C7}\u0100bu\u30FB\u328Ao\u0100;r\u0214\u0213\u0180hir\u3297\u329B\u32A0re\xE5\u31F8mes;\u62CAi\u0200;efl\u32AA\u1059\u1821\u32AB\u65B9tri;\u69CEluhar;\u6968;\u611E\u0D61\u32D5\u32DB\u32DF\u332C\u3338\u3371\0\u337A\u33A4\0\0\u33EC\u33F0\0\u3428\u3448\u345A\u34AD\u34B1\u34CA\u34F1\0\u3616\0\0\u3633cute;\u415Bqu\xEF\u27BA\u0500;Eaceinpsy\u11ED\u32F3\u32F5\u32FF\u3302\u330B\u330F\u331F\u3326\u3329;\u6AB4\u01F0\u32FA\0\u32FC;\u6AB8on;\u4161u\xE5\u11FE\u0100;d\u11F3\u3307il;\u415Frc;\u415D\u0180Eas\u3316\u3318\u331B;\u6AB6p;\u6ABAim;\u62E9olint;\u6A13i\xED\u1204;\u4441ot\u0180;be\u3334\u1D47\u3335\u62C5;\u6A66\u0380Aacmstx\u3346\u334A\u3357\u335B\u335E\u3363\u336Drr;\u61D8r\u0100hr\u3350\u3352\xEB\u2228\u0100;o\u0A36\u0A34t\u803B\xA7\u40A7i;\u403Bwar;\u6929m\u0100in\u3369\xF0nu\xF3\xF1t;\u6736r\u0100;o\u3376\u2055\uC000\u{1D530}\u0200acoy\u3382\u3386\u3391\u33A0rp;\u666F\u0100hy\u338B\u338Fcy;\u4449;\u4448rt\u026D\u3399\0\0\u339Ci\xE4\u1464ara\xEC\u2E6F\u803B\xAD\u40AD\u0100gm\u33A8\u33B4ma\u0180;fv\u33B1\u33B2\u33B2\u43C3;\u43C2\u0400;deglnpr\u12AB\u33C5\u33C9\u33CE\u33D6\u33DE\u33E1\u33E6ot;\u6A6A\u0100;q\u12B1\u12B0\u0100;E\u33D3\u33D4\u6A9E;\u6AA0\u0100;E\u33DB\u33DC\u6A9D;\u6A9Fe;\u6246lus;\u6A24arr;\u6972ar\xF2\u113D\u0200aeit\u33F8\u3408\u340F\u3417\u0100ls\u33FD\u3404lsetm\xE9\u336Ahp;\u6A33parsl;\u69E4\u0100dl\u1463\u3414e;\u6323\u0100;e\u341C\u341D\u6AAA\u0100;s\u3422\u3423\u6AAC;\uC000\u2AAC\uFE00\u0180flp\u342E\u3433\u3442tcy;\u444C\u0100;b\u3438\u3439\u402F\u0100;a\u343E\u343F\u69C4r;\u633Ff;\uC000\u{1D564}a\u0100dr\u344D\u0402es\u0100;u\u3454\u3455\u6660it\xBB\u3455\u0180csu\u3460\u3479\u349F\u0100au\u3465\u346Fp\u0100;s\u1188\u346B;\uC000\u2293\uFE00p\u0100;s\u11B4\u3475;\uC000\u2294\uFE00u\u0100bp\u347F\u348F\u0180;es\u1197\u119C\u3486et\u0100;e\u1197\u348D\xF1\u119D\u0180;es\u11A8\u11AD\u3496et\u0100;e\u11A8\u349D\xF1\u11AE\u0180;af\u117B\u34A6\u05B0r\u0165\u34AB\u05B1\xBB\u117Car\xF2\u1148\u0200cemt\u34B9\u34BE\u34C2\u34C5r;\uC000\u{1D4C8}tm\xEE\xF1i\xEC\u3415ar\xE6\u11BE\u0100ar\u34CE\u34D5r\u0100;f\u34D4\u17BF\u6606\u0100an\u34DA\u34EDight\u0100ep\u34E3\u34EApsilo\xEE\u1EE0h\xE9\u2EAFs\xBB\u2852\u0280bcmnp\u34FB\u355E\u1209\u358B\u358E\u0480;Edemnprs\u350E\u350F\u3511\u3515\u351E\u3523\u352C\u3531\u3536\u6282;\u6AC5ot;\u6ABD\u0100;d\u11DA\u351Aot;\u6AC3ult;\u6AC1\u0100Ee\u3528\u352A;\u6ACB;\u628Alus;\u6ABFarr;\u6979\u0180eiu\u353D\u3552\u3555t\u0180;en\u350E\u3545\u354Bq\u0100;q\u11DA\u350Feq\u0100;q\u352B\u3528m;\u6AC7\u0100bp\u355A\u355C;\u6AD5;\u6AD3c\u0300;acens\u11ED\u356C\u3572\u3579\u357B\u3326ppro\xF8\u32FAurlye\xF1\u11FE\xF1\u11F3\u0180aes\u3582\u3588\u331Bppro\xF8\u331Aq\xF1\u3317g;\u666A\u0680123;Edehlmnps\u35A9\u35AC\u35AF\u121C\u35B2\u35B4\u35C0\u35C9\u35D5\u35DA\u35DF\u35E8\u35ED\u803B\xB9\u40B9\u803B\xB2\u40B2\u803B\xB3\u40B3;\u6AC6\u0100os\u35B9\u35BCt;\u6ABEub;\u6AD8\u0100;d\u1222\u35C5ot;\u6AC4s\u0100ou\u35CF\u35D2l;\u67C9b;\u6AD7arr;\u697Bult;\u6AC2\u0100Ee\u35E4\u35E6;\u6ACC;\u628Blus;\u6AC0\u0180eiu\u35F4\u3609\u360Ct\u0180;en\u121C\u35FC\u3602q\u0100;q\u1222\u35B2eq\u0100;q\u35E7\u35E4m;\u6AC8\u0100bp\u3611\u3613;\u6AD4;\u6AD6\u0180Aan\u361C\u3620\u362Drr;\u61D9r\u0100hr\u3626\u3628\xEB\u222E\u0100;o\u0A2B\u0A29war;\u692Alig\u803B\xDF\u40DF\u0BE1\u3651\u365D\u3660\u12CE\u3673\u3679\0\u367E\u36C2\0\0\0\0\0\u36DB\u3703\0\u3709\u376C\0\0\0\u3787\u0272\u3656\0\0\u365Bget;\u6316;\u43C4r\xEB\u0E5F\u0180aey\u3666\u366B\u3670ron;\u4165dil;\u4163;\u4442lrec;\u6315r;\uC000\u{1D531}\u0200eiko\u3686\u369D\u36B5\u36BC\u01F2\u368B\0\u3691e\u01004f\u1284\u1281a\u0180;sv\u3698\u3699\u369B\u43B8ym;\u43D1\u0100cn\u36A2\u36B2k\u0100as\u36A8\u36AEppro\xF8\u12C1im\xBB\u12ACs\xF0\u129E\u0100as\u36BA\u36AE\xF0\u12C1rn\u803B\xFE\u40FE\u01EC\u031F\u36C6\u22E7es\u8180\xD7;bd\u36CF\u36D0\u36D8\u40D7\u0100;a\u190F\u36D5r;\u6A31;\u6A30\u0180eps\u36E1\u36E3\u3700\xE1\u2A4D\u0200;bcf\u0486\u36EC\u36F0\u36F4ot;\u6336ir;\u6AF1\u0100;o\u36F9\u36FC\uC000\u{1D565}rk;\u6ADA\xE1\u3362rime;\u6034\u0180aip\u370F\u3712\u3764d\xE5\u1248\u0380adempst\u3721\u374D\u3740\u3751\u3757\u375C\u375Fngle\u0280;dlqr\u3730\u3731\u3736\u3740\u3742\u65B5own\xBB\u1DBBeft\u0100;e\u2800\u373E\xF1\u092E;\u625Cight\u0100;e\u32AA\u374B\xF1\u105Aot;\u65ECinus;\u6A3Alus;\u6A39b;\u69CDime;\u6A3Bezium;\u63E2\u0180cht\u3772\u377D\u3781\u0100ry\u3777\u377B;\uC000\u{1D4C9};\u4446cy;\u445Brok;\u4167\u0100io\u378B\u378Ex\xF4\u1777head\u0100lr\u3797\u37A0eftarro\xF7\u084Fightarrow\xBB\u0F5D\u0900AHabcdfghlmoprstuw\u37D0\u37D3\u37D7\u37E4\u37F0\u37FC\u380E\u381C\u3823\u3834\u3851\u385D\u386B\u38A9\u38CC\u38D2\u38EA\u38F6r\xF2\u03EDar;\u6963\u0100cr\u37DC\u37E2ute\u803B\xFA\u40FA\xF2\u1150r\u01E3\u37EA\0\u37EDy;\u445Eve;\u416D\u0100iy\u37F5\u37FArc\u803B\xFB\u40FB;\u4443\u0180abh\u3803\u3806\u380Br\xF2\u13ADlac;\u4171a\xF2\u13C3\u0100ir\u3813\u3818sht;\u697E;\uC000\u{1D532}rave\u803B\xF9\u40F9\u0161\u3827\u3831r\u0100lr\u382C\u382E\xBB\u0957\xBB\u1083lk;\u6580\u0100ct\u3839\u384D\u026F\u383F\0\0\u384Arn\u0100;e\u3845\u3846\u631Cr\xBB\u3846op;\u630Fri;\u65F8\u0100al\u3856\u385Acr;\u416B\u80BB\xA8\u0349\u0100gp\u3862\u3866on;\u4173f;\uC000\u{1D566}\u0300adhlsu\u114B\u3878\u387D\u1372\u3891\u38A0own\xE1\u13B3arpoon\u0100lr\u3888\u388Cef\xF4\u382Digh\xF4\u382Fi\u0180;hl\u3899\u389A\u389C\u43C5\xBB\u13FAon\xBB\u389Aparrows;\u61C8\u0180cit\u38B0\u38C4\u38C8\u026F\u38B6\0\0\u38C1rn\u0100;e\u38BC\u38BD\u631Dr\xBB\u38BDop;\u630Eng;\u416Fri;\u65F9cr;\uC000\u{1D4CA}\u0180dir\u38D9\u38DD\u38E2ot;\u62F0lde;\u4169i\u0100;f\u3730\u38E8\xBB\u1813\u0100am\u38EF\u38F2r\xF2\u38A8l\u803B\xFC\u40FCangle;\u69A7\u0780ABDacdeflnoprsz\u391C\u391F\u3929\u392D\u39B5\u39B8\u39BD\u39DF\u39E4\u39E8\u39F3\u39F9\u39FD\u3A01\u3A20r\xF2\u03F7ar\u0100;v\u3926\u3927\u6AE8;\u6AE9as\xE8\u03E1\u0100nr\u3932\u3937grt;\u699C\u0380eknprst\u34E3\u3946\u394B\u3952\u395D\u3964\u3996app\xE1\u2415othin\xE7\u1E96\u0180hir\u34EB\u2EC8\u3959op\xF4\u2FB5\u0100;h\u13B7\u3962\xEF\u318D\u0100iu\u3969\u396Dgm\xE1\u33B3\u0100bp\u3972\u3984setneq\u0100;q\u397D\u3980\uC000\u228A\uFE00;\uC000\u2ACB\uFE00setneq\u0100;q\u398F\u3992\uC000\u228B\uFE00;\uC000\u2ACC\uFE00\u0100hr\u399B\u399Fet\xE1\u369Ciangle\u0100lr\u39AA\u39AFeft\xBB\u0925ight\xBB\u1051y;\u4432ash\xBB\u1036\u0180elr\u39C4\u39D2\u39D7\u0180;be\u2DEA\u39CB\u39CFar;\u62BBq;\u625Alip;\u62EE\u0100bt\u39DC\u1468a\xF2\u1469r;\uC000\u{1D533}tr\xE9\u39AEsu\u0100bp\u39EF\u39F1\xBB\u0D1C\xBB\u0D59pf;\uC000\u{1D567}ro\xF0\u0EFBtr\xE9\u39B4\u0100cu\u3A06\u3A0Br;\uC000\u{1D4CB}\u0100bp\u3A10\u3A18n\u0100Ee\u3980\u3A16\xBB\u397En\u0100Ee\u3992\u3A1E\xBB\u3990igzag;\u699A\u0380cefoprs\u3A36\u3A3B\u3A56\u3A5B\u3A54\u3A61\u3A6Airc;\u4175\u0100di\u3A40\u3A51\u0100bg\u3A45\u3A49ar;\u6A5Fe\u0100;q\u15FA\u3A4F;\u6259erp;\u6118r;\uC000\u{1D534}pf;\uC000\u{1D568}\u0100;e\u1479\u3A66at\xE8\u1479cr;\uC000\u{1D4CC}\u0AE3\u178E\u3A87\0\u3A8B\0\u3A90\u3A9B\0\0\u3A9D\u3AA8\u3AAB\u3AAF\0\0\u3AC3\u3ACE\0\u3AD8\u17DC\u17DFtr\xE9\u17D1r;\uC000\u{1D535}\u0100Aa\u3A94\u3A97r\xF2\u03C3r\xF2\u09F6;\u43BE\u0100Aa\u3AA1\u3AA4r\xF2\u03B8r\xF2\u09EBa\xF0\u2713is;\u62FB\u0180dpt\u17A4\u3AB5\u3ABE\u0100fl\u3ABA\u17A9;\uC000\u{1D569}im\xE5\u17B2\u0100Aa\u3AC7\u3ACAr\xF2\u03CEr\xF2\u0A01\u0100cq\u3AD2\u17B8r;\uC000\u{1D4CD}\u0100pt\u17D6\u3ADCr\xE9\u17D4\u0400acefiosu\u3AF0\u3AFD\u3B08\u3B0C\u3B11\u3B15\u3B1B\u3B21c\u0100uy\u3AF6\u3AFBte\u803B\xFD\u40FD;\u444F\u0100iy\u3B02\u3B06rc;\u4177;\u444Bn\u803B\xA5\u40A5r;\uC000\u{1D536}cy;\u4457pf;\uC000\u{1D56A}cr;\uC000\u{1D4CE}\u0100cm\u3B26\u3B29y;\u444El\u803B\xFF\u40FF\u0500acdefhiosw\u3B42\u3B48\u3B54\u3B58\u3B64\u3B69\u3B6D\u3B74\u3B7A\u3B80cute;\u417A\u0100ay\u3B4D\u3B52ron;\u417E;\u4437ot;\u417C\u0100et\u3B5D\u3B61tr\xE6\u155Fa;\u43B6r;\uC000\u{1D537}cy;\u4436grarr;\u61DDpf;\uC000\u{1D56B}cr;\uC000\u{1D4CF}\u0100jn\u3B85\u3B87;\u600Dj;\u600C'.split("").map(function(c) {
    return c.charCodeAt(0);
  })
);
var decodeDataXml = {};
Object.defineProperty(decodeDataXml, "__esModule", { value: true });
decodeDataXml.default = new Uint16Array(
  "\u0200aglq	\x1B\u026D\0\0p;\u4026os;\u4027t;\u403Et;\u403Cuot;\u4022".split("").map(function(c) {
    return c.charCodeAt(0);
  })
);
var decode_codepoint = {};
(function(exports) {
  var _a;
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.replaceCodePoint = exports.fromCodePoint = void 0;
  var decodeMap = /* @__PURE__ */ new Map([
    [0, 65533],
    [128, 8364],
    [130, 8218],
    [131, 402],
    [132, 8222],
    [133, 8230],
    [134, 8224],
    [135, 8225],
    [136, 710],
    [137, 8240],
    [138, 352],
    [139, 8249],
    [140, 338],
    [142, 381],
    [145, 8216],
    [146, 8217],
    [147, 8220],
    [148, 8221],
    [149, 8226],
    [150, 8211],
    [151, 8212],
    [152, 732],
    [153, 8482],
    [154, 353],
    [155, 8250],
    [156, 339],
    [158, 382],
    [159, 376]
  ]);
  exports.fromCodePoint = (_a = String.fromCodePoint) !== null && _a !== void 0 ? _a : function(codePoint) {
    var output = "";
    if (codePoint > 65535) {
      codePoint -= 65536;
      output += String.fromCharCode(codePoint >>> 10 & 1023 | 55296);
      codePoint = 56320 | codePoint & 1023;
    }
    output += String.fromCharCode(codePoint);
    return output;
  };
  function replaceCodePoint(codePoint) {
    var _a2;
    if (codePoint >= 55296 && codePoint <= 57343 || codePoint > 1114111) {
      return 65533;
    }
    return (_a2 = decodeMap.get(codePoint)) !== null && _a2 !== void 0 ? _a2 : codePoint;
  }
  exports.replaceCodePoint = replaceCodePoint;
  function decodeCodePoint(codePoint) {
    return (0, exports.fromCodePoint)(replaceCodePoint(codePoint));
  }
  exports.default = decodeCodePoint;
})(decode_codepoint);
(function(exports) {
  var __importDefault2 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.decodeXML = exports.decodeHTMLStrict = exports.decodeHTML = exports.determineBranch = exports.BinTrieFlags = exports.fromCodePoint = exports.replaceCodePoint = exports.decodeCodePoint = exports.xmlDecodeTree = exports.htmlDecodeTree = void 0;
  var decode_data_html_js_1 = __importDefault2(decodeDataHtml);
  exports.htmlDecodeTree = decode_data_html_js_1.default;
  var decode_data_xml_js_1 = __importDefault2(decodeDataXml);
  exports.xmlDecodeTree = decode_data_xml_js_1.default;
  var decode_codepoint_js_1 = __importDefault2(decode_codepoint);
  exports.decodeCodePoint = decode_codepoint_js_1.default;
  var decode_codepoint_js_2 = decode_codepoint;
  Object.defineProperty(exports, "replaceCodePoint", { enumerable: true, get: function() {
    return decode_codepoint_js_2.replaceCodePoint;
  } });
  Object.defineProperty(exports, "fromCodePoint", { enumerable: true, get: function() {
    return decode_codepoint_js_2.fromCodePoint;
  } });
  var CharCodes;
  (function(CharCodes2) {
    CharCodes2[CharCodes2["NUM"] = 35] = "NUM";
    CharCodes2[CharCodes2["SEMI"] = 59] = "SEMI";
    CharCodes2[CharCodes2["ZERO"] = 48] = "ZERO";
    CharCodes2[CharCodes2["NINE"] = 57] = "NINE";
    CharCodes2[CharCodes2["LOWER_A"] = 97] = "LOWER_A";
    CharCodes2[CharCodes2["LOWER_F"] = 102] = "LOWER_F";
    CharCodes2[CharCodes2["LOWER_X"] = 120] = "LOWER_X";
    CharCodes2[CharCodes2["To_LOWER_BIT"] = 32] = "To_LOWER_BIT";
  })(CharCodes || (CharCodes = {}));
  var BinTrieFlags;
  (function(BinTrieFlags2) {
    BinTrieFlags2[BinTrieFlags2["VALUE_LENGTH"] = 49152] = "VALUE_LENGTH";
    BinTrieFlags2[BinTrieFlags2["BRANCH_LENGTH"] = 16256] = "BRANCH_LENGTH";
    BinTrieFlags2[BinTrieFlags2["JUMP_TABLE"] = 127] = "JUMP_TABLE";
  })(BinTrieFlags = exports.BinTrieFlags || (exports.BinTrieFlags = {}));
  function getDecoder(decodeTree) {
    return function decodeHTMLBinary(str, strict) {
      var ret = "";
      var lastIdx = 0;
      var strIdx = 0;
      while ((strIdx = str.indexOf("&", strIdx)) >= 0) {
        ret += str.slice(lastIdx, strIdx);
        lastIdx = strIdx;
        strIdx += 1;
        if (str.charCodeAt(strIdx) === CharCodes.NUM) {
          var start = strIdx + 1;
          var base = 10;
          var cp = str.charCodeAt(start);
          if ((cp | CharCodes.To_LOWER_BIT) === CharCodes.LOWER_X) {
            base = 16;
            strIdx += 1;
            start += 1;
          }
          do
            cp = str.charCodeAt(++strIdx);
          while (cp >= CharCodes.ZERO && cp <= CharCodes.NINE || base === 16 && (cp | CharCodes.To_LOWER_BIT) >= CharCodes.LOWER_A && (cp | CharCodes.To_LOWER_BIT) <= CharCodes.LOWER_F);
          if (start !== strIdx) {
            var entity = str.substring(start, strIdx);
            var parsed = parseInt(entity, base);
            if (str.charCodeAt(strIdx) === CharCodes.SEMI) {
              strIdx += 1;
            } else if (strict) {
              continue;
            }
            ret += (0, decode_codepoint_js_1.default)(parsed);
            lastIdx = strIdx;
          }
          continue;
        }
        var resultIdx = 0;
        var excess = 1;
        var treeIdx = 0;
        var current = decodeTree[treeIdx];
        for (; strIdx < str.length; strIdx++, excess++) {
          treeIdx = determineBranch(decodeTree, current, treeIdx + 1, str.charCodeAt(strIdx));
          if (treeIdx < 0)
            break;
          current = decodeTree[treeIdx];
          var masked = current & BinTrieFlags.VALUE_LENGTH;
          if (masked) {
            if (!strict || str.charCodeAt(strIdx) === CharCodes.SEMI) {
              resultIdx = treeIdx;
              excess = 0;
            }
            var valueLength = (masked >> 14) - 1;
            if (valueLength === 0)
              break;
            treeIdx += valueLength;
          }
        }
        if (resultIdx !== 0) {
          var valueLength = (decodeTree[resultIdx] & BinTrieFlags.VALUE_LENGTH) >> 14;
          ret += valueLength === 1 ? String.fromCharCode(decodeTree[resultIdx] & ~BinTrieFlags.VALUE_LENGTH) : valueLength === 2 ? String.fromCharCode(decodeTree[resultIdx + 1]) : String.fromCharCode(decodeTree[resultIdx + 1], decodeTree[resultIdx + 2]);
          lastIdx = strIdx - excess + 1;
        }
      }
      return ret + str.slice(lastIdx);
    };
  }
  function determineBranch(decodeTree, current, nodeIdx, char) {
    var branchCount = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
    var jumpOffset = current & BinTrieFlags.JUMP_TABLE;
    if (branchCount === 0) {
      return jumpOffset !== 0 && char === jumpOffset ? nodeIdx : -1;
    }
    if (jumpOffset) {
      var value2 = char - jumpOffset;
      return value2 < 0 || value2 >= branchCount ? -1 : decodeTree[nodeIdx + value2] - 1;
    }
    var lo = nodeIdx;
    var hi = lo + branchCount - 1;
    while (lo <= hi) {
      var mid = lo + hi >>> 1;
      var midVal = decodeTree[mid];
      if (midVal < char) {
        lo = mid + 1;
      } else if (midVal > char) {
        hi = mid - 1;
      } else {
        return decodeTree[mid + branchCount];
      }
    }
    return -1;
  }
  exports.determineBranch = determineBranch;
  var htmlDecoder = getDecoder(decode_data_html_js_1.default);
  var xmlDecoder = getDecoder(decode_data_xml_js_1.default);
  function decodeHTML(str) {
    return htmlDecoder(str, false);
  }
  exports.decodeHTML = decodeHTML;
  function decodeHTMLStrict(str) {
    return htmlDecoder(str, true);
  }
  exports.decodeHTMLStrict = decodeHTMLStrict;
  function decodeXML(str) {
    return xmlDecoder(str, true);
  }
  exports.decodeXML = decodeXML;
})(decode$3);
var encode$3 = {};
var encodeHtml = {};
Object.defineProperty(encodeHtml, "__esModule", { value: true });
function restoreDiff(arr) {
  for (var i = 1; i < arr.length; i++) {
    arr[i][0] += arr[i - 1][0] + 1;
  }
  return arr;
}
encodeHtml.default = new Map(/* @__PURE__ */ restoreDiff([[9, "&Tab;"], [0, "&NewLine;"], [22, "&excl;"], [0, "&quot;"], [0, "&num;"], [0, "&dollar;"], [0, "&percnt;"], [0, "&amp;"], [0, "&apos;"], [0, "&lpar;"], [0, "&rpar;"], [0, "&ast;"], [0, "&plus;"], [0, "&comma;"], [1, "&period;"], [0, "&sol;"], [10, "&colon;"], [0, "&semi;"], [0, { v: "&lt;", n: 8402, o: "&nvlt;" }], [0, { v: "&equals;", n: 8421, o: "&bne;" }], [0, { v: "&gt;", n: 8402, o: "&nvgt;" }], [0, "&quest;"], [0, "&commat;"], [26, "&lbrack;"], [0, "&bsol;"], [0, "&rbrack;"], [0, "&Hat;"], [0, "&lowbar;"], [0, "&DiacriticalGrave;"], [5, { n: 106, o: "&fjlig;" }], [20, "&lbrace;"], [0, "&verbar;"], [0, "&rbrace;"], [34, "&nbsp;"], [0, "&iexcl;"], [0, "&cent;"], [0, "&pound;"], [0, "&curren;"], [0, "&yen;"], [0, "&brvbar;"], [0, "&sect;"], [0, "&die;"], [0, "&copy;"], [0, "&ordf;"], [0, "&laquo;"], [0, "&not;"], [0, "&shy;"], [0, "&circledR;"], [0, "&macr;"], [0, "&deg;"], [0, "&PlusMinus;"], [0, "&sup2;"], [0, "&sup3;"], [0, "&acute;"], [0, "&micro;"], [0, "&para;"], [0, "&centerdot;"], [0, "&cedil;"], [0, "&sup1;"], [0, "&ordm;"], [0, "&raquo;"], [0, "&frac14;"], [0, "&frac12;"], [0, "&frac34;"], [0, "&iquest;"], [0, "&Agrave;"], [0, "&Aacute;"], [0, "&Acirc;"], [0, "&Atilde;"], [0, "&Auml;"], [0, "&angst;"], [0, "&AElig;"], [0, "&Ccedil;"], [0, "&Egrave;"], [0, "&Eacute;"], [0, "&Ecirc;"], [0, "&Euml;"], [0, "&Igrave;"], [0, "&Iacute;"], [0, "&Icirc;"], [0, "&Iuml;"], [0, "&ETH;"], [0, "&Ntilde;"], [0, "&Ograve;"], [0, "&Oacute;"], [0, "&Ocirc;"], [0, "&Otilde;"], [0, "&Ouml;"], [0, "&times;"], [0, "&Oslash;"], [0, "&Ugrave;"], [0, "&Uacute;"], [0, "&Ucirc;"], [0, "&Uuml;"], [0, "&Yacute;"], [0, "&THORN;"], [0, "&szlig;"], [0, "&agrave;"], [0, "&aacute;"], [0, "&acirc;"], [0, "&atilde;"], [0, "&auml;"], [0, "&aring;"], [0, "&aelig;"], [0, "&ccedil;"], [0, "&egrave;"], [0, "&eacute;"], [0, "&ecirc;"], [0, "&euml;"], [0, "&igrave;"], [0, "&iacute;"], [0, "&icirc;"], [0, "&iuml;"], [0, "&eth;"], [0, "&ntilde;"], [0, "&ograve;"], [0, "&oacute;"], [0, "&ocirc;"], [0, "&otilde;"], [0, "&ouml;"], [0, "&div;"], [0, "&oslash;"], [0, "&ugrave;"], [0, "&uacute;"], [0, "&ucirc;"], [0, "&uuml;"], [0, "&yacute;"], [0, "&thorn;"], [0, "&yuml;"], [0, "&Amacr;"], [0, "&amacr;"], [0, "&Abreve;"], [0, "&abreve;"], [0, "&Aogon;"], [0, "&aogon;"], [0, "&Cacute;"], [0, "&cacute;"], [0, "&Ccirc;"], [0, "&ccirc;"], [0, "&Cdot;"], [0, "&cdot;"], [0, "&Ccaron;"], [0, "&ccaron;"], [0, "&Dcaron;"], [0, "&dcaron;"], [0, "&Dstrok;"], [0, "&dstrok;"], [0, "&Emacr;"], [0, "&emacr;"], [2, "&Edot;"], [0, "&edot;"], [0, "&Eogon;"], [0, "&eogon;"], [0, "&Ecaron;"], [0, "&ecaron;"], [0, "&Gcirc;"], [0, "&gcirc;"], [0, "&Gbreve;"], [0, "&gbreve;"], [0, "&Gdot;"], [0, "&gdot;"], [0, "&Gcedil;"], [1, "&Hcirc;"], [0, "&hcirc;"], [0, "&Hstrok;"], [0, "&hstrok;"], [0, "&Itilde;"], [0, "&itilde;"], [0, "&Imacr;"], [0, "&imacr;"], [2, "&Iogon;"], [0, "&iogon;"], [0, "&Idot;"], [0, "&imath;"], [0, "&IJlig;"], [0, "&ijlig;"], [0, "&Jcirc;"], [0, "&jcirc;"], [0, "&Kcedil;"], [0, "&kcedil;"], [0, "&kgreen;"], [0, "&Lacute;"], [0, "&lacute;"], [0, "&Lcedil;"], [0, "&lcedil;"], [0, "&Lcaron;"], [0, "&lcaron;"], [0, "&Lmidot;"], [0, "&lmidot;"], [0, "&Lstrok;"], [0, "&lstrok;"], [0, "&Nacute;"], [0, "&nacute;"], [0, "&Ncedil;"], [0, "&ncedil;"], [0, "&Ncaron;"], [0, "&ncaron;"], [0, "&napos;"], [0, "&ENG;"], [0, "&eng;"], [0, "&Omacr;"], [0, "&omacr;"], [2, "&Odblac;"], [0, "&odblac;"], [0, "&OElig;"], [0, "&oelig;"], [0, "&Racute;"], [0, "&racute;"], [0, "&Rcedil;"], [0, "&rcedil;"], [0, "&Rcaron;"], [0, "&rcaron;"], [0, "&Sacute;"], [0, "&sacute;"], [0, "&Scirc;"], [0, "&scirc;"], [0, "&Scedil;"], [0, "&scedil;"], [0, "&Scaron;"], [0, "&scaron;"], [0, "&Tcedil;"], [0, "&tcedil;"], [0, "&Tcaron;"], [0, "&tcaron;"], [0, "&Tstrok;"], [0, "&tstrok;"], [0, "&Utilde;"], [0, "&utilde;"], [0, "&Umacr;"], [0, "&umacr;"], [0, "&Ubreve;"], [0, "&ubreve;"], [0, "&Uring;"], [0, "&uring;"], [0, "&Udblac;"], [0, "&udblac;"], [0, "&Uogon;"], [0, "&uogon;"], [0, "&Wcirc;"], [0, "&wcirc;"], [0, "&Ycirc;"], [0, "&ycirc;"], [0, "&Yuml;"], [0, "&Zacute;"], [0, "&zacute;"], [0, "&Zdot;"], [0, "&zdot;"], [0, "&Zcaron;"], [0, "&zcaron;"], [19, "&fnof;"], [34, "&imped;"], [63, "&gacute;"], [65, "&jmath;"], [142, "&circ;"], [0, "&caron;"], [16, "&breve;"], [0, "&DiacriticalDot;"], [0, "&ring;"], [0, "&ogon;"], [0, "&DiacriticalTilde;"], [0, "&dblac;"], [51, "&DownBreve;"], [127, "&Alpha;"], [0, "&Beta;"], [0, "&Gamma;"], [0, "&Delta;"], [0, "&Epsilon;"], [0, "&Zeta;"], [0, "&Eta;"], [0, "&Theta;"], [0, "&Iota;"], [0, "&Kappa;"], [0, "&Lambda;"], [0, "&Mu;"], [0, "&Nu;"], [0, "&Xi;"], [0, "&Omicron;"], [0, "&Pi;"], [0, "&Rho;"], [1, "&Sigma;"], [0, "&Tau;"], [0, "&Upsilon;"], [0, "&Phi;"], [0, "&Chi;"], [0, "&Psi;"], [0, "&ohm;"], [7, "&alpha;"], [0, "&beta;"], [0, "&gamma;"], [0, "&delta;"], [0, "&epsi;"], [0, "&zeta;"], [0, "&eta;"], [0, "&theta;"], [0, "&iota;"], [0, "&kappa;"], [0, "&lambda;"], [0, "&mu;"], [0, "&nu;"], [0, "&xi;"], [0, "&omicron;"], [0, "&pi;"], [0, "&rho;"], [0, "&sigmaf;"], [0, "&sigma;"], [0, "&tau;"], [0, "&upsi;"], [0, "&phi;"], [0, "&chi;"], [0, "&psi;"], [0, "&omega;"], [7, "&thetasym;"], [0, "&Upsi;"], [2, "&phiv;"], [0, "&piv;"], [5, "&Gammad;"], [0, "&digamma;"], [18, "&kappav;"], [0, "&rhov;"], [3, "&epsiv;"], [0, "&backepsilon;"], [10, "&IOcy;"], [0, "&DJcy;"], [0, "&GJcy;"], [0, "&Jukcy;"], [0, "&DScy;"], [0, "&Iukcy;"], [0, "&YIcy;"], [0, "&Jsercy;"], [0, "&LJcy;"], [0, "&NJcy;"], [0, "&TSHcy;"], [0, "&KJcy;"], [1, "&Ubrcy;"], [0, "&DZcy;"], [0, "&Acy;"], [0, "&Bcy;"], [0, "&Vcy;"], [0, "&Gcy;"], [0, "&Dcy;"], [0, "&IEcy;"], [0, "&ZHcy;"], [0, "&Zcy;"], [0, "&Icy;"], [0, "&Jcy;"], [0, "&Kcy;"], [0, "&Lcy;"], [0, "&Mcy;"], [0, "&Ncy;"], [0, "&Ocy;"], [0, "&Pcy;"], [0, "&Rcy;"], [0, "&Scy;"], [0, "&Tcy;"], [0, "&Ucy;"], [0, "&Fcy;"], [0, "&KHcy;"], [0, "&TScy;"], [0, "&CHcy;"], [0, "&SHcy;"], [0, "&SHCHcy;"], [0, "&HARDcy;"], [0, "&Ycy;"], [0, "&SOFTcy;"], [0, "&Ecy;"], [0, "&YUcy;"], [0, "&YAcy;"], [0, "&acy;"], [0, "&bcy;"], [0, "&vcy;"], [0, "&gcy;"], [0, "&dcy;"], [0, "&iecy;"], [0, "&zhcy;"], [0, "&zcy;"], [0, "&icy;"], [0, "&jcy;"], [0, "&kcy;"], [0, "&lcy;"], [0, "&mcy;"], [0, "&ncy;"], [0, "&ocy;"], [0, "&pcy;"], [0, "&rcy;"], [0, "&scy;"], [0, "&tcy;"], [0, "&ucy;"], [0, "&fcy;"], [0, "&khcy;"], [0, "&tscy;"], [0, "&chcy;"], [0, "&shcy;"], [0, "&shchcy;"], [0, "&hardcy;"], [0, "&ycy;"], [0, "&softcy;"], [0, "&ecy;"], [0, "&yucy;"], [0, "&yacy;"], [1, "&iocy;"], [0, "&djcy;"], [0, "&gjcy;"], [0, "&jukcy;"], [0, "&dscy;"], [0, "&iukcy;"], [0, "&yicy;"], [0, "&jsercy;"], [0, "&ljcy;"], [0, "&njcy;"], [0, "&tshcy;"], [0, "&kjcy;"], [1, "&ubrcy;"], [0, "&dzcy;"], [7074, "&ensp;"], [0, "&emsp;"], [0, "&emsp13;"], [0, "&emsp14;"], [1, "&numsp;"], [0, "&puncsp;"], [0, "&ThinSpace;"], [0, "&hairsp;"], [0, "&NegativeMediumSpace;"], [0, "&zwnj;"], [0, "&zwj;"], [0, "&lrm;"], [0, "&rlm;"], [0, "&dash;"], [2, "&ndash;"], [0, "&mdash;"], [0, "&horbar;"], [0, "&Verbar;"], [1, "&lsquo;"], [0, "&CloseCurlyQuote;"], [0, "&lsquor;"], [1, "&ldquo;"], [0, "&CloseCurlyDoubleQuote;"], [0, "&bdquo;"], [1, "&dagger;"], [0, "&Dagger;"], [0, "&bull;"], [2, "&nldr;"], [0, "&hellip;"], [9, "&permil;"], [0, "&pertenk;"], [0, "&prime;"], [0, "&Prime;"], [0, "&tprime;"], [0, "&backprime;"], [3, "&lsaquo;"], [0, "&rsaquo;"], [3, "&oline;"], [2, "&caret;"], [1, "&hybull;"], [0, "&frasl;"], [10, "&bsemi;"], [7, "&qprime;"], [7, { v: "&MediumSpace;", n: 8202, o: "&ThickSpace;" }], [0, "&NoBreak;"], [0, "&af;"], [0, "&InvisibleTimes;"], [0, "&ic;"], [72, "&euro;"], [46, "&tdot;"], [0, "&DotDot;"], [37, "&complexes;"], [2, "&incare;"], [4, "&gscr;"], [0, "&hamilt;"], [0, "&Hfr;"], [0, "&Hopf;"], [0, "&planckh;"], [0, "&hbar;"], [0, "&imagline;"], [0, "&Ifr;"], [0, "&lagran;"], [0, "&ell;"], [1, "&naturals;"], [0, "&numero;"], [0, "&copysr;"], [0, "&weierp;"], [0, "&Popf;"], [0, "&Qopf;"], [0, "&realine;"], [0, "&real;"], [0, "&reals;"], [0, "&rx;"], [3, "&trade;"], [1, "&integers;"], [2, "&mho;"], [0, "&zeetrf;"], [0, "&iiota;"], [2, "&bernou;"], [0, "&Cayleys;"], [1, "&escr;"], [0, "&Escr;"], [0, "&Fouriertrf;"], [1, "&Mellintrf;"], [0, "&order;"], [0, "&alefsym;"], [0, "&beth;"], [0, "&gimel;"], [0, "&daleth;"], [12, "&CapitalDifferentialD;"], [0, "&dd;"], [0, "&ee;"], [0, "&ii;"], [10, "&frac13;"], [0, "&frac23;"], [0, "&frac15;"], [0, "&frac25;"], [0, "&frac35;"], [0, "&frac45;"], [0, "&frac16;"], [0, "&frac56;"], [0, "&frac18;"], [0, "&frac38;"], [0, "&frac58;"], [0, "&frac78;"], [49, "&larr;"], [0, "&ShortUpArrow;"], [0, "&rarr;"], [0, "&darr;"], [0, "&harr;"], [0, "&updownarrow;"], [0, "&nwarr;"], [0, "&nearr;"], [0, "&LowerRightArrow;"], [0, "&LowerLeftArrow;"], [0, "&nlarr;"], [0, "&nrarr;"], [1, { v: "&rarrw;", n: 824, o: "&nrarrw;" }], [0, "&Larr;"], [0, "&Uarr;"], [0, "&Rarr;"], [0, "&Darr;"], [0, "&larrtl;"], [0, "&rarrtl;"], [0, "&LeftTeeArrow;"], [0, "&mapstoup;"], [0, "&map;"], [0, "&DownTeeArrow;"], [1, "&hookleftarrow;"], [0, "&hookrightarrow;"], [0, "&larrlp;"], [0, "&looparrowright;"], [0, "&harrw;"], [0, "&nharr;"], [1, "&lsh;"], [0, "&rsh;"], [0, "&ldsh;"], [0, "&rdsh;"], [1, "&crarr;"], [0, "&cularr;"], [0, "&curarr;"], [2, "&circlearrowleft;"], [0, "&circlearrowright;"], [0, "&leftharpoonup;"], [0, "&DownLeftVector;"], [0, "&RightUpVector;"], [0, "&LeftUpVector;"], [0, "&rharu;"], [0, "&DownRightVector;"], [0, "&dharr;"], [0, "&dharl;"], [0, "&RightArrowLeftArrow;"], [0, "&udarr;"], [0, "&LeftArrowRightArrow;"], [0, "&leftleftarrows;"], [0, "&upuparrows;"], [0, "&rightrightarrows;"], [0, "&ddarr;"], [0, "&leftrightharpoons;"], [0, "&Equilibrium;"], [0, "&nlArr;"], [0, "&nhArr;"], [0, "&nrArr;"], [0, "&DoubleLeftArrow;"], [0, "&DoubleUpArrow;"], [0, "&DoubleRightArrow;"], [0, "&dArr;"], [0, "&DoubleLeftRightArrow;"], [0, "&DoubleUpDownArrow;"], [0, "&nwArr;"], [0, "&neArr;"], [0, "&seArr;"], [0, "&swArr;"], [0, "&lAarr;"], [0, "&rAarr;"], [1, "&zigrarr;"], [6, "&larrb;"], [0, "&rarrb;"], [15, "&DownArrowUpArrow;"], [7, "&loarr;"], [0, "&roarr;"], [0, "&hoarr;"], [0, "&forall;"], [0, "&comp;"], [0, { v: "&part;", n: 824, o: "&npart;" }], [0, "&exist;"], [0, "&nexist;"], [0, "&empty;"], [1, "&Del;"], [0, "&Element;"], [0, "&NotElement;"], [1, "&ni;"], [0, "&notni;"], [2, "&prod;"], [0, "&coprod;"], [0, "&sum;"], [0, "&minus;"], [0, "&MinusPlus;"], [0, "&dotplus;"], [1, "&Backslash;"], [0, "&lowast;"], [0, "&compfn;"], [1, "&radic;"], [2, "&prop;"], [0, "&infin;"], [0, "&angrt;"], [0, { v: "&ang;", n: 8402, o: "&nang;" }], [0, "&angmsd;"], [0, "&angsph;"], [0, "&mid;"], [0, "&nmid;"], [0, "&DoubleVerticalBar;"], [0, "&NotDoubleVerticalBar;"], [0, "&and;"], [0, "&or;"], [0, { v: "&cap;", n: 65024, o: "&caps;" }], [0, { v: "&cup;", n: 65024, o: "&cups;" }], [0, "&int;"], [0, "&Int;"], [0, "&iiint;"], [0, "&conint;"], [0, "&Conint;"], [0, "&Cconint;"], [0, "&cwint;"], [0, "&ClockwiseContourIntegral;"], [0, "&awconint;"], [0, "&there4;"], [0, "&becaus;"], [0, "&ratio;"], [0, "&Colon;"], [0, "&dotminus;"], [1, "&mDDot;"], [0, "&homtht;"], [0, { v: "&sim;", n: 8402, o: "&nvsim;" }], [0, { v: "&backsim;", n: 817, o: "&race;" }], [0, { v: "&ac;", n: 819, o: "&acE;" }], [0, "&acd;"], [0, "&VerticalTilde;"], [0, "&NotTilde;"], [0, { v: "&eqsim;", n: 824, o: "&nesim;" }], [0, "&sime;"], [0, "&NotTildeEqual;"], [0, "&cong;"], [0, "&simne;"], [0, "&ncong;"], [0, "&ap;"], [0, "&nap;"], [0, "&ape;"], [0, { v: "&apid;", n: 824, o: "&napid;" }], [0, "&backcong;"], [0, { v: "&asympeq;", n: 8402, o: "&nvap;" }], [0, { v: "&bump;", n: 824, o: "&nbump;" }], [0, { v: "&bumpe;", n: 824, o: "&nbumpe;" }], [0, { v: "&doteq;", n: 824, o: "&nedot;" }], [0, "&doteqdot;"], [0, "&efDot;"], [0, "&erDot;"], [0, "&Assign;"], [0, "&ecolon;"], [0, "&ecir;"], [0, "&circeq;"], [1, "&wedgeq;"], [0, "&veeeq;"], [1, "&triangleq;"], [2, "&equest;"], [0, "&ne;"], [0, { v: "&Congruent;", n: 8421, o: "&bnequiv;" }], [0, "&nequiv;"], [1, { v: "&le;", n: 8402, o: "&nvle;" }], [0, { v: "&ge;", n: 8402, o: "&nvge;" }], [0, { v: "&lE;", n: 824, o: "&nlE;" }], [0, { v: "&gE;", n: 824, o: "&ngE;" }], [0, { v: "&lnE;", n: 65024, o: "&lvertneqq;" }], [0, { v: "&gnE;", n: 65024, o: "&gvertneqq;" }], [0, { v: "&ll;", n: new Map(/* @__PURE__ */ restoreDiff([[824, "&nLtv;"], [7577, "&nLt;"]])) }], [0, { v: "&gg;", n: new Map(/* @__PURE__ */ restoreDiff([[824, "&nGtv;"], [7577, "&nGt;"]])) }], [0, "&between;"], [0, "&NotCupCap;"], [0, "&nless;"], [0, "&ngt;"], [0, "&nle;"], [0, "&nge;"], [0, "&lesssim;"], [0, "&GreaterTilde;"], [0, "&nlsim;"], [0, "&ngsim;"], [0, "&LessGreater;"], [0, "&gl;"], [0, "&NotLessGreater;"], [0, "&NotGreaterLess;"], [0, "&pr;"], [0, "&sc;"], [0, "&prcue;"], [0, "&sccue;"], [0, "&PrecedesTilde;"], [0, { v: "&scsim;", n: 824, o: "&NotSucceedsTilde;" }], [0, "&NotPrecedes;"], [0, "&NotSucceeds;"], [0, { v: "&sub;", n: 8402, o: "&NotSubset;" }], [0, { v: "&sup;", n: 8402, o: "&NotSuperset;" }], [0, "&nsub;"], [0, "&nsup;"], [0, "&sube;"], [0, "&supe;"], [0, "&NotSubsetEqual;"], [0, "&NotSupersetEqual;"], [0, { v: "&subne;", n: 65024, o: "&varsubsetneq;" }], [0, { v: "&supne;", n: 65024, o: "&varsupsetneq;" }], [1, "&cupdot;"], [0, "&UnionPlus;"], [0, { v: "&sqsub;", n: 824, o: "&NotSquareSubset;" }], [0, { v: "&sqsup;", n: 824, o: "&NotSquareSuperset;" }], [0, "&sqsube;"], [0, "&sqsupe;"], [0, { v: "&sqcap;", n: 65024, o: "&sqcaps;" }], [0, { v: "&sqcup;", n: 65024, o: "&sqcups;" }], [0, "&CirclePlus;"], [0, "&CircleMinus;"], [0, "&CircleTimes;"], [0, "&osol;"], [0, "&CircleDot;"], [0, "&circledcirc;"], [0, "&circledast;"], [1, "&circleddash;"], [0, "&boxplus;"], [0, "&boxminus;"], [0, "&boxtimes;"], [0, "&dotsquare;"], [0, "&RightTee;"], [0, "&dashv;"], [0, "&DownTee;"], [0, "&bot;"], [1, "&models;"], [0, "&DoubleRightTee;"], [0, "&Vdash;"], [0, "&Vvdash;"], [0, "&VDash;"], [0, "&nvdash;"], [0, "&nvDash;"], [0, "&nVdash;"], [0, "&nVDash;"], [0, "&prurel;"], [1, "&LeftTriangle;"], [0, "&RightTriangle;"], [0, { v: "&LeftTriangleEqual;", n: 8402, o: "&nvltrie;" }], [0, { v: "&RightTriangleEqual;", n: 8402, o: "&nvrtrie;" }], [0, "&origof;"], [0, "&imof;"], [0, "&multimap;"], [0, "&hercon;"], [0, "&intcal;"], [0, "&veebar;"], [1, "&barvee;"], [0, "&angrtvb;"], [0, "&lrtri;"], [0, "&bigwedge;"], [0, "&bigvee;"], [0, "&bigcap;"], [0, "&bigcup;"], [0, "&diam;"], [0, "&sdot;"], [0, "&sstarf;"], [0, "&divideontimes;"], [0, "&bowtie;"], [0, "&ltimes;"], [0, "&rtimes;"], [0, "&leftthreetimes;"], [0, "&rightthreetimes;"], [0, "&backsimeq;"], [0, "&curlyvee;"], [0, "&curlywedge;"], [0, "&Sub;"], [0, "&Sup;"], [0, "&Cap;"], [0, "&Cup;"], [0, "&fork;"], [0, "&epar;"], [0, "&lessdot;"], [0, "&gtdot;"], [0, { v: "&Ll;", n: 824, o: "&nLl;" }], [0, { v: "&Gg;", n: 824, o: "&nGg;" }], [0, { v: "&leg;", n: 65024, o: "&lesg;" }], [0, { v: "&gel;", n: 65024, o: "&gesl;" }], [2, "&cuepr;"], [0, "&cuesc;"], [0, "&NotPrecedesSlantEqual;"], [0, "&NotSucceedsSlantEqual;"], [0, "&NotSquareSubsetEqual;"], [0, "&NotSquareSupersetEqual;"], [2, "&lnsim;"], [0, "&gnsim;"], [0, "&precnsim;"], [0, "&scnsim;"], [0, "&nltri;"], [0, "&NotRightTriangle;"], [0, "&nltrie;"], [0, "&NotRightTriangleEqual;"], [0, "&vellip;"], [0, "&ctdot;"], [0, "&utdot;"], [0, "&dtdot;"], [0, "&disin;"], [0, "&isinsv;"], [0, "&isins;"], [0, { v: "&isindot;", n: 824, o: "&notindot;" }], [0, "&notinvc;"], [0, "&notinvb;"], [1, { v: "&isinE;", n: 824, o: "&notinE;" }], [0, "&nisd;"], [0, "&xnis;"], [0, "&nis;"], [0, "&notnivc;"], [0, "&notnivb;"], [6, "&barwed;"], [0, "&Barwed;"], [1, "&lceil;"], [0, "&rceil;"], [0, "&LeftFloor;"], [0, "&rfloor;"], [0, "&drcrop;"], [0, "&dlcrop;"], [0, "&urcrop;"], [0, "&ulcrop;"], [0, "&bnot;"], [1, "&profline;"], [0, "&profsurf;"], [1, "&telrec;"], [0, "&target;"], [5, "&ulcorn;"], [0, "&urcorn;"], [0, "&dlcorn;"], [0, "&drcorn;"], [2, "&frown;"], [0, "&smile;"], [9, "&cylcty;"], [0, "&profalar;"], [7, "&topbot;"], [6, "&ovbar;"], [1, "&solbar;"], [60, "&angzarr;"], [51, "&lmoustache;"], [0, "&rmoustache;"], [2, "&OverBracket;"], [0, "&bbrk;"], [0, "&bbrktbrk;"], [37, "&OverParenthesis;"], [0, "&UnderParenthesis;"], [0, "&OverBrace;"], [0, "&UnderBrace;"], [2, "&trpezium;"], [4, "&elinters;"], [59, "&blank;"], [164, "&circledS;"], [55, "&boxh;"], [1, "&boxv;"], [9, "&boxdr;"], [3, "&boxdl;"], [3, "&boxur;"], [3, "&boxul;"], [3, "&boxvr;"], [7, "&boxvl;"], [7, "&boxhd;"], [7, "&boxhu;"], [7, "&boxvh;"], [19, "&boxH;"], [0, "&boxV;"], [0, "&boxdR;"], [0, "&boxDr;"], [0, "&boxDR;"], [0, "&boxdL;"], [0, "&boxDl;"], [0, "&boxDL;"], [0, "&boxuR;"], [0, "&boxUr;"], [0, "&boxUR;"], [0, "&boxuL;"], [0, "&boxUl;"], [0, "&boxUL;"], [0, "&boxvR;"], [0, "&boxVr;"], [0, "&boxVR;"], [0, "&boxvL;"], [0, "&boxVl;"], [0, "&boxVL;"], [0, "&boxHd;"], [0, "&boxhD;"], [0, "&boxHD;"], [0, "&boxHu;"], [0, "&boxhU;"], [0, "&boxHU;"], [0, "&boxvH;"], [0, "&boxVh;"], [0, "&boxVH;"], [19, "&uhblk;"], [3, "&lhblk;"], [3, "&block;"], [8, "&blk14;"], [0, "&blk12;"], [0, "&blk34;"], [13, "&square;"], [8, "&blacksquare;"], [0, "&EmptyVerySmallSquare;"], [1, "&rect;"], [0, "&marker;"], [2, "&fltns;"], [1, "&bigtriangleup;"], [0, "&blacktriangle;"], [0, "&triangle;"], [2, "&blacktriangleright;"], [0, "&rtri;"], [3, "&bigtriangledown;"], [0, "&blacktriangledown;"], [0, "&dtri;"], [2, "&blacktriangleleft;"], [0, "&ltri;"], [6, "&loz;"], [0, "&cir;"], [32, "&tridot;"], [2, "&bigcirc;"], [8, "&ultri;"], [0, "&urtri;"], [0, "&lltri;"], [0, "&EmptySmallSquare;"], [0, "&FilledSmallSquare;"], [8, "&bigstar;"], [0, "&star;"], [7, "&phone;"], [49, "&female;"], [1, "&male;"], [29, "&spades;"], [2, "&clubs;"], [1, "&hearts;"], [0, "&diamondsuit;"], [3, "&sung;"], [2, "&flat;"], [0, "&natural;"], [0, "&sharp;"], [163, "&check;"], [3, "&cross;"], [8, "&malt;"], [21, "&sext;"], [33, "&VerticalSeparator;"], [25, "&lbbrk;"], [0, "&rbbrk;"], [84, "&bsolhsub;"], [0, "&suphsol;"], [28, "&LeftDoubleBracket;"], [0, "&RightDoubleBracket;"], [0, "&lang;"], [0, "&rang;"], [0, "&Lang;"], [0, "&Rang;"], [0, "&loang;"], [0, "&roang;"], [7, "&longleftarrow;"], [0, "&longrightarrow;"], [0, "&longleftrightarrow;"], [0, "&DoubleLongLeftArrow;"], [0, "&DoubleLongRightArrow;"], [0, "&DoubleLongLeftRightArrow;"], [1, "&longmapsto;"], [2, "&dzigrarr;"], [258, "&nvlArr;"], [0, "&nvrArr;"], [0, "&nvHarr;"], [0, "&Map;"], [6, "&lbarr;"], [0, "&bkarow;"], [0, "&lBarr;"], [0, "&dbkarow;"], [0, "&drbkarow;"], [0, "&DDotrahd;"], [0, "&UpArrowBar;"], [0, "&DownArrowBar;"], [2, "&Rarrtl;"], [2, "&latail;"], [0, "&ratail;"], [0, "&lAtail;"], [0, "&rAtail;"], [0, "&larrfs;"], [0, "&rarrfs;"], [0, "&larrbfs;"], [0, "&rarrbfs;"], [2, "&nwarhk;"], [0, "&nearhk;"], [0, "&hksearow;"], [0, "&hkswarow;"], [0, "&nwnear;"], [0, "&nesear;"], [0, "&seswar;"], [0, "&swnwar;"], [8, { v: "&rarrc;", n: 824, o: "&nrarrc;" }], [1, "&cudarrr;"], [0, "&ldca;"], [0, "&rdca;"], [0, "&cudarrl;"], [0, "&larrpl;"], [2, "&curarrm;"], [0, "&cularrp;"], [7, "&rarrpl;"], [2, "&harrcir;"], [0, "&Uarrocir;"], [0, "&lurdshar;"], [0, "&ldrushar;"], [2, "&LeftRightVector;"], [0, "&RightUpDownVector;"], [0, "&DownLeftRightVector;"], [0, "&LeftUpDownVector;"], [0, "&LeftVectorBar;"], [0, "&RightVectorBar;"], [0, "&RightUpVectorBar;"], [0, "&RightDownVectorBar;"], [0, "&DownLeftVectorBar;"], [0, "&DownRightVectorBar;"], [0, "&LeftUpVectorBar;"], [0, "&LeftDownVectorBar;"], [0, "&LeftTeeVector;"], [0, "&RightTeeVector;"], [0, "&RightUpTeeVector;"], [0, "&RightDownTeeVector;"], [0, "&DownLeftTeeVector;"], [0, "&DownRightTeeVector;"], [0, "&LeftUpTeeVector;"], [0, "&LeftDownTeeVector;"], [0, "&lHar;"], [0, "&uHar;"], [0, "&rHar;"], [0, "&dHar;"], [0, "&luruhar;"], [0, "&ldrdhar;"], [0, "&ruluhar;"], [0, "&rdldhar;"], [0, "&lharul;"], [0, "&llhard;"], [0, "&rharul;"], [0, "&lrhard;"], [0, "&udhar;"], [0, "&duhar;"], [0, "&RoundImplies;"], [0, "&erarr;"], [0, "&simrarr;"], [0, "&larrsim;"], [0, "&rarrsim;"], [0, "&rarrap;"], [0, "&ltlarr;"], [1, "&gtrarr;"], [0, "&subrarr;"], [1, "&suplarr;"], [0, "&lfisht;"], [0, "&rfisht;"], [0, "&ufisht;"], [0, "&dfisht;"], [5, "&lopar;"], [0, "&ropar;"], [4, "&lbrke;"], [0, "&rbrke;"], [0, "&lbrkslu;"], [0, "&rbrksld;"], [0, "&lbrksld;"], [0, "&rbrkslu;"], [0, "&langd;"], [0, "&rangd;"], [0, "&lparlt;"], [0, "&rpargt;"], [0, "&gtlPar;"], [0, "&ltrPar;"], [3, "&vzigzag;"], [1, "&vangrt;"], [0, "&angrtvbd;"], [6, "&ange;"], [0, "&range;"], [0, "&dwangle;"], [0, "&uwangle;"], [0, "&angmsdaa;"], [0, "&angmsdab;"], [0, "&angmsdac;"], [0, "&angmsdad;"], [0, "&angmsdae;"], [0, "&angmsdaf;"], [0, "&angmsdag;"], [0, "&angmsdah;"], [0, "&bemptyv;"], [0, "&demptyv;"], [0, "&cemptyv;"], [0, "&raemptyv;"], [0, "&laemptyv;"], [0, "&ohbar;"], [0, "&omid;"], [0, "&opar;"], [1, "&operp;"], [1, "&olcross;"], [0, "&odsold;"], [1, "&olcir;"], [0, "&ofcir;"], [0, "&olt;"], [0, "&ogt;"], [0, "&cirscir;"], [0, "&cirE;"], [0, "&solb;"], [0, "&bsolb;"], [3, "&boxbox;"], [3, "&trisb;"], [0, "&rtriltri;"], [0, { v: "&LeftTriangleBar;", n: 824, o: "&NotLeftTriangleBar;" }], [0, { v: "&RightTriangleBar;", n: 824, o: "&NotRightTriangleBar;" }], [11, "&iinfin;"], [0, "&infintie;"], [0, "&nvinfin;"], [4, "&eparsl;"], [0, "&smeparsl;"], [0, "&eqvparsl;"], [5, "&blacklozenge;"], [8, "&RuleDelayed;"], [1, "&dsol;"], [9, "&bigodot;"], [0, "&bigoplus;"], [0, "&bigotimes;"], [1, "&biguplus;"], [1, "&bigsqcup;"], [5, "&iiiint;"], [0, "&fpartint;"], [2, "&cirfnint;"], [0, "&awint;"], [0, "&rppolint;"], [0, "&scpolint;"], [0, "&npolint;"], [0, "&pointint;"], [0, "&quatint;"], [0, "&intlarhk;"], [10, "&pluscir;"], [0, "&plusacir;"], [0, "&simplus;"], [0, "&plusdu;"], [0, "&plussim;"], [0, "&plustwo;"], [1, "&mcomma;"], [0, "&minusdu;"], [2, "&loplus;"], [0, "&roplus;"], [0, "&Cross;"], [0, "&timesd;"], [0, "&timesbar;"], [1, "&smashp;"], [0, "&lotimes;"], [0, "&rotimes;"], [0, "&otimesas;"], [0, "&Otimes;"], [0, "&odiv;"], [0, "&triplus;"], [0, "&triminus;"], [0, "&tritime;"], [0, "&intprod;"], [2, "&amalg;"], [0, "&capdot;"], [1, "&ncup;"], [0, "&ncap;"], [0, "&capand;"], [0, "&cupor;"], [0, "&cupcap;"], [0, "&capcup;"], [0, "&cupbrcap;"], [0, "&capbrcup;"], [0, "&cupcup;"], [0, "&capcap;"], [0, "&ccups;"], [0, "&ccaps;"], [2, "&ccupssm;"], [2, "&And;"], [0, "&Or;"], [0, "&andand;"], [0, "&oror;"], [0, "&orslope;"], [0, "&andslope;"], [1, "&andv;"], [0, "&orv;"], [0, "&andd;"], [0, "&ord;"], [1, "&wedbar;"], [6, "&sdote;"], [3, "&simdot;"], [2, { v: "&congdot;", n: 824, o: "&ncongdot;" }], [0, "&easter;"], [0, "&apacir;"], [0, { v: "&apE;", n: 824, o: "&napE;" }], [0, "&eplus;"], [0, "&pluse;"], [0, "&Esim;"], [0, "&Colone;"], [0, "&Equal;"], [1, "&ddotseq;"], [0, "&equivDD;"], [0, "&ltcir;"], [0, "&gtcir;"], [0, "&ltquest;"], [0, "&gtquest;"], [0, { v: "&leqslant;", n: 824, o: "&nleqslant;" }], [0, { v: "&geqslant;", n: 824, o: "&ngeqslant;" }], [0, "&lesdot;"], [0, "&gesdot;"], [0, "&lesdoto;"], [0, "&gesdoto;"], [0, "&lesdotor;"], [0, "&gesdotol;"], [0, "&lap;"], [0, "&gap;"], [0, "&lne;"], [0, "&gne;"], [0, "&lnap;"], [0, "&gnap;"], [0, "&lEg;"], [0, "&gEl;"], [0, "&lsime;"], [0, "&gsime;"], [0, "&lsimg;"], [0, "&gsiml;"], [0, "&lgE;"], [0, "&glE;"], [0, "&lesges;"], [0, "&gesles;"], [0, "&els;"], [0, "&egs;"], [0, "&elsdot;"], [0, "&egsdot;"], [0, "&el;"], [0, "&eg;"], [2, "&siml;"], [0, "&simg;"], [0, "&simlE;"], [0, "&simgE;"], [0, { v: "&LessLess;", n: 824, o: "&NotNestedLessLess;" }], [0, { v: "&GreaterGreater;", n: 824, o: "&NotNestedGreaterGreater;" }], [1, "&glj;"], [0, "&gla;"], [0, "&ltcc;"], [0, "&gtcc;"], [0, "&lescc;"], [0, "&gescc;"], [0, "&smt;"], [0, "&lat;"], [0, { v: "&smte;", n: 65024, o: "&smtes;" }], [0, { v: "&late;", n: 65024, o: "&lates;" }], [0, "&bumpE;"], [0, { v: "&PrecedesEqual;", n: 824, o: "&NotPrecedesEqual;" }], [0, { v: "&sce;", n: 824, o: "&NotSucceedsEqual;" }], [2, "&prE;"], [0, "&scE;"], [0, "&precneqq;"], [0, "&scnE;"], [0, "&prap;"], [0, "&scap;"], [0, "&precnapprox;"], [0, "&scnap;"], [0, "&Pr;"], [0, "&Sc;"], [0, "&subdot;"], [0, "&supdot;"], [0, "&subplus;"], [0, "&supplus;"], [0, "&submult;"], [0, "&supmult;"], [0, "&subedot;"], [0, "&supedot;"], [0, { v: "&subE;", n: 824, o: "&nsubE;" }], [0, { v: "&supE;", n: 824, o: "&nsupE;" }], [0, "&subsim;"], [0, "&supsim;"], [2, { v: "&subnE;", n: 65024, o: "&varsubsetneqq;" }], [0, { v: "&supnE;", n: 65024, o: "&varsupsetneqq;" }], [2, "&csub;"], [0, "&csup;"], [0, "&csube;"], [0, "&csupe;"], [0, "&subsup;"], [0, "&supsub;"], [0, "&subsub;"], [0, "&supsup;"], [0, "&suphsub;"], [0, "&supdsub;"], [0, "&forkv;"], [0, "&topfork;"], [0, "&mlcp;"], [8, "&Dashv;"], [1, "&Vdashl;"], [0, "&Barv;"], [0, "&vBar;"], [0, "&vBarv;"], [1, "&Vbar;"], [0, "&Not;"], [0, "&bNot;"], [0, "&rnmid;"], [0, "&cirmid;"], [0, "&midcir;"], [0, "&topcir;"], [0, "&nhpar;"], [0, "&parsim;"], [9, { v: "&parsl;", n: 8421, o: "&nparsl;" }], [44343, { n: new Map(/* @__PURE__ */ restoreDiff([[56476, "&Ascr;"], [1, "&Cscr;"], [0, "&Dscr;"], [2, "&Gscr;"], [2, "&Jscr;"], [0, "&Kscr;"], [2, "&Nscr;"], [0, "&Oscr;"], [0, "&Pscr;"], [0, "&Qscr;"], [1, "&Sscr;"], [0, "&Tscr;"], [0, "&Uscr;"], [0, "&Vscr;"], [0, "&Wscr;"], [0, "&Xscr;"], [0, "&Yscr;"], [0, "&Zscr;"], [0, "&ascr;"], [0, "&bscr;"], [0, "&cscr;"], [0, "&dscr;"], [1, "&fscr;"], [1, "&hscr;"], [0, "&iscr;"], [0, "&jscr;"], [0, "&kscr;"], [0, "&lscr;"], [0, "&mscr;"], [0, "&nscr;"], [1, "&pscr;"], [0, "&qscr;"], [0, "&rscr;"], [0, "&sscr;"], [0, "&tscr;"], [0, "&uscr;"], [0, "&vscr;"], [0, "&wscr;"], [0, "&xscr;"], [0, "&yscr;"], [0, "&zscr;"], [52, "&Afr;"], [0, "&Bfr;"], [1, "&Dfr;"], [0, "&Efr;"], [0, "&Ffr;"], [0, "&Gfr;"], [2, "&Jfr;"], [0, "&Kfr;"], [0, "&Lfr;"], [0, "&Mfr;"], [0, "&Nfr;"], [0, "&Ofr;"], [0, "&Pfr;"], [0, "&Qfr;"], [1, "&Sfr;"], [0, "&Tfr;"], [0, "&Ufr;"], [0, "&Vfr;"], [0, "&Wfr;"], [0, "&Xfr;"], [0, "&Yfr;"], [1, "&afr;"], [0, "&bfr;"], [0, "&cfr;"], [0, "&dfr;"], [0, "&efr;"], [0, "&ffr;"], [0, "&gfr;"], [0, "&hfr;"], [0, "&ifr;"], [0, "&jfr;"], [0, "&kfr;"], [0, "&lfr;"], [0, "&mfr;"], [0, "&nfr;"], [0, "&ofr;"], [0, "&pfr;"], [0, "&qfr;"], [0, "&rfr;"], [0, "&sfr;"], [0, "&tfr;"], [0, "&ufr;"], [0, "&vfr;"], [0, "&wfr;"], [0, "&xfr;"], [0, "&yfr;"], [0, "&zfr;"], [0, "&Aopf;"], [0, "&Bopf;"], [1, "&Dopf;"], [0, "&Eopf;"], [0, "&Fopf;"], [0, "&Gopf;"], [1, "&Iopf;"], [0, "&Jopf;"], [0, "&Kopf;"], [0, "&Lopf;"], [0, "&Mopf;"], [1, "&Oopf;"], [3, "&Sopf;"], [0, "&Topf;"], [0, "&Uopf;"], [0, "&Vopf;"], [0, "&Wopf;"], [0, "&Xopf;"], [0, "&Yopf;"], [1, "&aopf;"], [0, "&bopf;"], [0, "&copf;"], [0, "&dopf;"], [0, "&eopf;"], [0, "&fopf;"], [0, "&gopf;"], [0, "&hopf;"], [0, "&iopf;"], [0, "&jopf;"], [0, "&kopf;"], [0, "&lopf;"], [0, "&mopf;"], [0, "&nopf;"], [0, "&oopf;"], [0, "&popf;"], [0, "&qopf;"], [0, "&ropf;"], [0, "&sopf;"], [0, "&topf;"], [0, "&uopf;"], [0, "&vopf;"], [0, "&wopf;"], [0, "&xopf;"], [0, "&yopf;"], [0, "&zopf;"]])) }], [8906, "&fflig;"], [0, "&filig;"], [0, "&fllig;"], [0, "&ffilig;"], [0, "&ffllig;"]]));
var _escape = {};
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.escapeText = exports.escapeAttribute = exports.escapeUTF8 = exports.escape = exports.encodeXML = exports.getCodePoint = exports.xmlReplacer = void 0;
  exports.xmlReplacer = /["&'<>$\x80-\uFFFF]/g;
  var xmlCodeMap = /* @__PURE__ */ new Map([
    [34, "&quot;"],
    [38, "&amp;"],
    [39, "&apos;"],
    [60, "&lt;"],
    [62, "&gt;"]
  ]);
  exports.getCodePoint = String.prototype.codePointAt != null ? function(str, index2) {
    return str.codePointAt(index2);
  } : function(c, index2) {
    return (c.charCodeAt(index2) & 64512) === 55296 ? (c.charCodeAt(index2) - 55296) * 1024 + c.charCodeAt(index2 + 1) - 56320 + 65536 : c.charCodeAt(index2);
  };
  function encodeXML(str) {
    var ret = "";
    var lastIdx = 0;
    var match2;
    while ((match2 = exports.xmlReplacer.exec(str)) !== null) {
      var i = match2.index;
      var char = str.charCodeAt(i);
      var next = xmlCodeMap.get(char);
      if (next !== void 0) {
        ret += str.substring(lastIdx, i) + next;
        lastIdx = i + 1;
      } else {
        ret += "".concat(str.substring(lastIdx, i), "&#x").concat((0, exports.getCodePoint)(str, i).toString(16), ";");
        lastIdx = exports.xmlReplacer.lastIndex += Number((char & 64512) === 55296);
      }
    }
    return ret + str.substr(lastIdx);
  }
  exports.encodeXML = encodeXML;
  exports.escape = encodeXML;
  function getEscaper(regex, map) {
    return function escape(data2) {
      var match2;
      var lastIdx = 0;
      var result = "";
      while (match2 = regex.exec(data2)) {
        if (lastIdx !== match2.index) {
          result += data2.substring(lastIdx, match2.index);
        }
        result += map.get(match2[0].charCodeAt(0));
        lastIdx = match2.index + 1;
      }
      return result + data2.substring(lastIdx);
    };
  }
  exports.escapeUTF8 = getEscaper(/[&<>'"]/g, xmlCodeMap);
  exports.escapeAttribute = getEscaper(/["&\u00A0]/g, /* @__PURE__ */ new Map([
    [34, "&quot;"],
    [38, "&amp;"],
    [160, "&nbsp;"]
  ]));
  exports.escapeText = getEscaper(/[&<>\u00A0]/g, /* @__PURE__ */ new Map([
    [38, "&amp;"],
    [60, "&lt;"],
    [62, "&gt;"],
    [160, "&nbsp;"]
  ]));
})(_escape);
var __importDefault$4 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(encode$3, "__esModule", { value: true });
encode$3.encodeNonAsciiHTML = encode$3.encodeHTML = void 0;
var encode_html_js_1 = __importDefault$4(encodeHtml);
var escape_js_1 = _escape;
var htmlReplacer = /[\t\n!-,./:-@[-`\f{-}$\x80-\uFFFF]/g;
function encodeHTML(data2) {
  return encodeHTMLTrieRe(htmlReplacer, data2);
}
encode$3.encodeHTML = encodeHTML;
function encodeNonAsciiHTML(data2) {
  return encodeHTMLTrieRe(escape_js_1.xmlReplacer, data2);
}
encode$3.encodeNonAsciiHTML = encodeNonAsciiHTML;
function encodeHTMLTrieRe(regExp, str) {
  var ret = "";
  var lastIdx = 0;
  var match2;
  while ((match2 = regExp.exec(str)) !== null) {
    var i = match2.index;
    ret += str.substring(lastIdx, i);
    var char = str.charCodeAt(i);
    var next = encode_html_js_1.default.get(char);
    if (typeof next === "object") {
      if (i + 1 < str.length) {
        var nextChar = str.charCodeAt(i + 1);
        var value2 = typeof next.n === "number" ? next.n === nextChar ? next.o : void 0 : next.n.get(nextChar);
        if (value2 !== void 0) {
          ret += value2;
          lastIdx = regExp.lastIndex += 1;
          continue;
        }
      }
      next = next.v;
    }
    if (next !== void 0) {
      ret += next;
      lastIdx = i + 1;
    } else {
      var cp = (0, escape_js_1.getCodePoint)(str, i);
      ret += "&#x".concat(cp.toString(16), ";");
      lastIdx = regExp.lastIndex += Number(cp !== char);
    }
  }
  return ret + str.substr(lastIdx);
}
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.decodeXMLStrict = exports.decodeHTML5Strict = exports.decodeHTML4Strict = exports.decodeHTML5 = exports.decodeHTML4 = exports.decodeHTMLStrict = exports.decodeHTML = exports.decodeXML = exports.encodeHTML5 = exports.encodeHTML4 = exports.encodeNonAsciiHTML = exports.encodeHTML = exports.escapeText = exports.escapeAttribute = exports.escapeUTF8 = exports.escape = exports.encodeXML = exports.encode = exports.decodeStrict = exports.decode = exports.EncodingMode = exports.DecodingMode = exports.EntityLevel = void 0;
  var decode_js_1 = decode$3;
  var encode_js_1 = encode$3;
  var escape_js_12 = _escape;
  var EntityLevel;
  (function(EntityLevel2) {
    EntityLevel2[EntityLevel2["XML"] = 0] = "XML";
    EntityLevel2[EntityLevel2["HTML"] = 1] = "HTML";
  })(EntityLevel = exports.EntityLevel || (exports.EntityLevel = {}));
  var DecodingMode;
  (function(DecodingMode2) {
    DecodingMode2[DecodingMode2["Legacy"] = 0] = "Legacy";
    DecodingMode2[DecodingMode2["Strict"] = 1] = "Strict";
  })(DecodingMode = exports.DecodingMode || (exports.DecodingMode = {}));
  var EncodingMode;
  (function(EncodingMode2) {
    EncodingMode2[EncodingMode2["UTF8"] = 0] = "UTF8";
    EncodingMode2[EncodingMode2["ASCII"] = 1] = "ASCII";
    EncodingMode2[EncodingMode2["Extensive"] = 2] = "Extensive";
    EncodingMode2[EncodingMode2["Attribute"] = 3] = "Attribute";
    EncodingMode2[EncodingMode2["Text"] = 4] = "Text";
  })(EncodingMode = exports.EncodingMode || (exports.EncodingMode = {}));
  function decode2(data2, options) {
    if (options === void 0) {
      options = EntityLevel.XML;
    }
    var opts = typeof options === "number" ? { level: options } : options;
    if (opts.level === EntityLevel.HTML) {
      if (opts.mode === DecodingMode.Strict) {
        return (0, decode_js_1.decodeHTMLStrict)(data2);
      }
      return (0, decode_js_1.decodeHTML)(data2);
    }
    return (0, decode_js_1.decodeXML)(data2);
  }
  exports.decode = decode2;
  function decodeStrict(data2, options) {
    if (options === void 0) {
      options = EntityLevel.XML;
    }
    var opts = typeof options === "number" ? { level: options } : options;
    if (opts.level === EntityLevel.HTML) {
      if (opts.mode === DecodingMode.Legacy) {
        return (0, decode_js_1.decodeHTML)(data2);
      }
      return (0, decode_js_1.decodeHTMLStrict)(data2);
    }
    return (0, decode_js_1.decodeXML)(data2);
  }
  exports.decodeStrict = decodeStrict;
  function encode2(data2, options) {
    if (options === void 0) {
      options = EntityLevel.XML;
    }
    var opts = typeof options === "number" ? { level: options } : options;
    if (opts.mode === EncodingMode.UTF8)
      return (0, escape_js_12.escapeUTF8)(data2);
    if (opts.mode === EncodingMode.Attribute)
      return (0, escape_js_12.escapeAttribute)(data2);
    if (opts.mode === EncodingMode.Text)
      return (0, escape_js_12.escapeText)(data2);
    if (opts.level === EntityLevel.HTML) {
      if (opts.mode === EncodingMode.ASCII) {
        return (0, encode_js_1.encodeNonAsciiHTML)(data2);
      }
      return (0, encode_js_1.encodeHTML)(data2);
    }
    return (0, escape_js_12.encodeXML)(data2);
  }
  exports.encode = encode2;
  var escape_js_2 = _escape;
  Object.defineProperty(exports, "encodeXML", { enumerable: true, get: function() {
    return escape_js_2.encodeXML;
  } });
  Object.defineProperty(exports, "escape", { enumerable: true, get: function() {
    return escape_js_2.escape;
  } });
  Object.defineProperty(exports, "escapeUTF8", { enumerable: true, get: function() {
    return escape_js_2.escapeUTF8;
  } });
  Object.defineProperty(exports, "escapeAttribute", { enumerable: true, get: function() {
    return escape_js_2.escapeAttribute;
  } });
  Object.defineProperty(exports, "escapeText", { enumerable: true, get: function() {
    return escape_js_2.escapeText;
  } });
  var encode_js_2 = encode$3;
  Object.defineProperty(exports, "encodeHTML", { enumerable: true, get: function() {
    return encode_js_2.encodeHTML;
  } });
  Object.defineProperty(exports, "encodeNonAsciiHTML", { enumerable: true, get: function() {
    return encode_js_2.encodeNonAsciiHTML;
  } });
  Object.defineProperty(exports, "encodeHTML4", { enumerable: true, get: function() {
    return encode_js_2.encodeHTML;
  } });
  Object.defineProperty(exports, "encodeHTML5", { enumerable: true, get: function() {
    return encode_js_2.encodeHTML;
  } });
  var decode_js_2 = decode$3;
  Object.defineProperty(exports, "decodeXML", { enumerable: true, get: function() {
    return decode_js_2.decodeXML;
  } });
  Object.defineProperty(exports, "decodeHTML", { enumerable: true, get: function() {
    return decode_js_2.decodeHTML;
  } });
  Object.defineProperty(exports, "decodeHTMLStrict", { enumerable: true, get: function() {
    return decode_js_2.decodeHTMLStrict;
  } });
  Object.defineProperty(exports, "decodeHTML4", { enumerable: true, get: function() {
    return decode_js_2.decodeHTML;
  } });
  Object.defineProperty(exports, "decodeHTML5", { enumerable: true, get: function() {
    return decode_js_2.decodeHTML;
  } });
  Object.defineProperty(exports, "decodeHTML4Strict", { enumerable: true, get: function() {
    return decode_js_2.decodeHTMLStrict;
  } });
  Object.defineProperty(exports, "decodeHTML5Strict", { enumerable: true, get: function() {
    return decode_js_2.decodeHTMLStrict;
  } });
  Object.defineProperty(exports, "decodeXMLStrict", { enumerable: true, get: function() {
    return decode_js_2.decodeXML;
  } });
})(lib$1);
var foreignNames = {};
Object.defineProperty(foreignNames, "__esModule", { value: true });
foreignNames.attributeNames = foreignNames.elementNames = void 0;
foreignNames.elementNames = new Map([
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feDropShadow",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "textPath"
].map(function(val) {
  return [val.toLowerCase(), val];
}));
foreignNames.attributeNames = new Map([
  "definitionURL",
  "attributeName",
  "attributeType",
  "baseFrequency",
  "baseProfile",
  "calcMode",
  "clipPathUnits",
  "diffuseConstant",
  "edgeMode",
  "filterUnits",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "kernelMatrix",
  "kernelUnitLength",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "limitingConeAngle",
  "markerHeight",
  "markerUnits",
  "markerWidth",
  "maskContentUnits",
  "maskUnits",
  "numOctaves",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "refX",
  "refY",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "specularConstant",
  "specularExponent",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stitchTiles",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textLength",
  "viewBox",
  "viewTarget",
  "xChannelSelector",
  "yChannelSelector",
  "zoomAndPan"
].map(function(val) {
  return [val.toLowerCase(), val];
}));
var __assign = commonjsGlobal && commonjsGlobal.__assign || function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __createBinding$1 = commonjsGlobal && commonjsGlobal.__createBinding || (Object.create ? function(o, m, k, k2) {
  if (k2 === void 0)
    k2 = k;
  var desc = Object.getOwnPropertyDescriptor(m, k);
  if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
    desc = { enumerable: true, get: function() {
      return m[k];
    } };
  }
  Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
  if (k2 === void 0)
    k2 = k;
  o[k2] = m[k];
});
var __setModuleDefault$1 = commonjsGlobal && commonjsGlobal.__setModuleDefault || (Object.create ? function(o, v) {
  Object.defineProperty(o, "default", { enumerable: true, value: v });
} : function(o, v) {
  o["default"] = v;
});
var __importStar$1 = commonjsGlobal && commonjsGlobal.__importStar || function(mod) {
  if (mod && mod.__esModule)
    return mod;
  var result = {};
  if (mod != null) {
    for (var k in mod)
      if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
        __createBinding$1(result, mod, k);
  }
  __setModuleDefault$1(result, mod);
  return result;
};
Object.defineProperty(lib$2, "__esModule", { value: true });
lib$2.render = void 0;
var ElementType = __importStar$1(lib$3);
var entities_1 = lib$1;
var foreignNames_js_1 = foreignNames;
var unencodedElements = /* @__PURE__ */ new Set([
  "style",
  "script",
  "xmp",
  "iframe",
  "noembed",
  "noframes",
  "plaintext",
  "noscript"
]);
function replaceQuotes(value2) {
  return value2.replace(/"/g, "&quot;");
}
function formatAttributes(attributes2, opts) {
  var _a;
  if (!attributes2)
    return;
  var encode2 = ((_a = opts.encodeEntities) !== null && _a !== void 0 ? _a : opts.decodeEntities) === false ? replaceQuotes : opts.xmlMode || opts.encodeEntities !== "utf8" ? entities_1.encodeXML : entities_1.escapeAttribute;
  return Object.keys(attributes2).map(function(key) {
    var _a2, _b;
    var value2 = (_a2 = attributes2[key]) !== null && _a2 !== void 0 ? _a2 : "";
    if (opts.xmlMode === "foreign") {
      key = (_b = foreignNames_js_1.attributeNames.get(key)) !== null && _b !== void 0 ? _b : key;
    }
    if (!opts.emptyAttrs && !opts.xmlMode && value2 === "") {
      return key;
    }
    return "".concat(key, '="').concat(encode2(value2), '"');
  }).join(" ");
}
var singleTag = /* @__PURE__ */ new Set([
  "area",
  "base",
  "basefont",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "img",
  "input",
  "isindex",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]);
function render(node2, options) {
  if (options === void 0) {
    options = {};
  }
  var nodes = "length" in node2 ? node2 : [node2];
  var output = "";
  for (var i = 0; i < nodes.length; i++) {
    output += renderNode(nodes[i], options);
  }
  return output;
}
lib$2.render = render;
lib$2.default = render;
function renderNode(node2, options) {
  switch (node2.type) {
    case ElementType.Root:
      return render(node2.children, options);
    case ElementType.Doctype:
    case ElementType.Directive:
      return renderDirective(node2);
    case ElementType.Comment:
      return renderComment(node2);
    case ElementType.CDATA:
      return renderCdata(node2);
    case ElementType.Script:
    case ElementType.Style:
    case ElementType.Tag:
      return renderTag(node2, options);
    case ElementType.Text:
      return renderText(node2, options);
  }
}
var foreignModeIntegrationPoints = /* @__PURE__ */ new Set([
  "mi",
  "mo",
  "mn",
  "ms",
  "mtext",
  "annotation-xml",
  "foreignObject",
  "desc",
  "title"
]);
var foreignElements = /* @__PURE__ */ new Set(["svg", "math"]);
function renderTag(elem, opts) {
  var _a;
  if (opts.xmlMode === "foreign") {
    elem.name = (_a = foreignNames_js_1.elementNames.get(elem.name)) !== null && _a !== void 0 ? _a : elem.name;
    if (elem.parent && foreignModeIntegrationPoints.has(elem.parent.name)) {
      opts = __assign(__assign({}, opts), { xmlMode: false });
    }
  }
  if (!opts.xmlMode && foreignElements.has(elem.name)) {
    opts = __assign(__assign({}, opts), { xmlMode: "foreign" });
  }
  var tag = "<".concat(elem.name);
  var attribs = formatAttributes(elem.attribs, opts);
  if (attribs) {
    tag += " ".concat(attribs);
  }
  if (elem.children.length === 0 && (opts.xmlMode ? opts.selfClosingTags !== false : opts.selfClosingTags && singleTag.has(elem.name))) {
    if (!opts.xmlMode)
      tag += " ";
    tag += "/>";
  } else {
    tag += ">";
    if (elem.children.length > 0) {
      tag += render(elem.children, opts);
    }
    if (opts.xmlMode || !singleTag.has(elem.name)) {
      tag += "</".concat(elem.name, ">");
    }
  }
  return tag;
}
function renderDirective(elem) {
  return "<".concat(elem.data, ">");
}
function renderText(elem, opts) {
  var _a;
  var data2 = elem.data || "";
  if (((_a = opts.encodeEntities) !== null && _a !== void 0 ? _a : opts.decodeEntities) !== false && !(!opts.xmlMode && elem.parent && unencodedElements.has(elem.parent.name))) {
    data2 = opts.xmlMode || opts.encodeEntities !== "utf8" ? (0, entities_1.encodeXML)(data2) : (0, entities_1.escapeText)(data2);
  }
  return data2;
}
function renderCdata(elem) {
  return "<![CDATA[".concat(elem.children[0].data, "]]>");
}
function renderComment(elem) {
  return "<!--".concat(elem.data, "-->");
}
var __importDefault$3 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(stringify$1, "__esModule", { value: true });
stringify$1.innerText = stringify$1.textContent = stringify$1.getText = stringify$1.getInnerHTML = stringify$1.getOuterHTML = void 0;
var domhandler_1$3 = lib$4;
var dom_serializer_1 = __importDefault$3(lib$2);
var domelementtype_1 = lib$3;
function getOuterHTML(node2, options) {
  return (0, dom_serializer_1.default)(node2, options);
}
stringify$1.getOuterHTML = getOuterHTML;
function getInnerHTML(node2, options) {
  return (0, domhandler_1$3.hasChildren)(node2) ? node2.children.map(function(node3) {
    return getOuterHTML(node3, options);
  }).join("") : "";
}
stringify$1.getInnerHTML = getInnerHTML;
function getText$1(node2) {
  if (Array.isArray(node2))
    return node2.map(getText$1).join("");
  if ((0, domhandler_1$3.isTag)(node2))
    return node2.name === "br" ? "\n" : getText$1(node2.children);
  if ((0, domhandler_1$3.isCDATA)(node2))
    return getText$1(node2.children);
  if ((0, domhandler_1$3.isText)(node2))
    return node2.data;
  return "";
}
stringify$1.getText = getText$1;
function textContent(node2) {
  if (Array.isArray(node2))
    return node2.map(textContent).join("");
  if ((0, domhandler_1$3.hasChildren)(node2) && !(0, domhandler_1$3.isComment)(node2)) {
    return textContent(node2.children);
  }
  if ((0, domhandler_1$3.isText)(node2))
    return node2.data;
  return "";
}
stringify$1.textContent = textContent;
function innerText(node2) {
  if (Array.isArray(node2))
    return node2.map(innerText).join("");
  if ((0, domhandler_1$3.hasChildren)(node2) && (node2.type === domelementtype_1.ElementType.Tag || (0, domhandler_1$3.isCDATA)(node2))) {
    return innerText(node2.children);
  }
  if ((0, domhandler_1$3.isText)(node2))
    return node2.data;
  return "";
}
stringify$1.innerText = innerText;
var traversal = {};
Object.defineProperty(traversal, "__esModule", { value: true });
traversal.prevElementSibling = traversal.nextElementSibling = traversal.getName = traversal.hasAttrib = traversal.getAttributeValue = traversal.getSiblings = traversal.getParent = traversal.getChildren = void 0;
var domhandler_1$2 = lib$4;
function getChildren$1(elem) {
  return (0, domhandler_1$2.hasChildren)(elem) ? elem.children : [];
}
traversal.getChildren = getChildren$1;
function getParent$1(elem) {
  return elem.parent || null;
}
traversal.getParent = getParent$1;
function getSiblings$1(elem) {
  var _a, _b;
  var parent = getParent$1(elem);
  if (parent != null)
    return getChildren$1(parent);
  var siblings = [elem];
  var prev = elem.prev, next = elem.next;
  while (prev != null) {
    siblings.unshift(prev);
    _a = prev, prev = _a.prev;
  }
  while (next != null) {
    siblings.push(next);
    _b = next, next = _b.next;
  }
  return siblings;
}
traversal.getSiblings = getSiblings$1;
function getAttributeValue$1(elem, name2) {
  var _a;
  return (_a = elem.attribs) === null || _a === void 0 ? void 0 : _a[name2];
}
traversal.getAttributeValue = getAttributeValue$1;
function hasAttrib$1(elem, name2) {
  return elem.attribs != null && Object.prototype.hasOwnProperty.call(elem.attribs, name2) && elem.attribs[name2] != null;
}
traversal.hasAttrib = hasAttrib$1;
function getName$1(elem) {
  return elem.name;
}
traversal.getName = getName$1;
function nextElementSibling(elem) {
  var _a;
  var next = elem.next;
  while (next !== null && !(0, domhandler_1$2.isTag)(next))
    _a = next, next = _a.next;
  return next;
}
traversal.nextElementSibling = nextElementSibling;
function prevElementSibling(elem) {
  var _a;
  var prev = elem.prev;
  while (prev !== null && !(0, domhandler_1$2.isTag)(prev))
    _a = prev, prev = _a.prev;
  return prev;
}
traversal.prevElementSibling = prevElementSibling;
var manipulation = {};
Object.defineProperty(manipulation, "__esModule", { value: true });
manipulation.prepend = manipulation.prependChild = manipulation.append = manipulation.appendChild = manipulation.replaceElement = manipulation.removeElement = void 0;
function removeElement(elem) {
  if (elem.prev)
    elem.prev.next = elem.next;
  if (elem.next)
    elem.next.prev = elem.prev;
  if (elem.parent) {
    var childs = elem.parent.children;
    childs.splice(childs.lastIndexOf(elem), 1);
  }
}
manipulation.removeElement = removeElement;
function replaceElement(elem, replacement) {
  var prev = replacement.prev = elem.prev;
  if (prev) {
    prev.next = replacement;
  }
  var next = replacement.next = elem.next;
  if (next) {
    next.prev = replacement;
  }
  var parent = replacement.parent = elem.parent;
  if (parent) {
    var childs = parent.children;
    childs[childs.lastIndexOf(elem)] = replacement;
    elem.parent = null;
  }
}
manipulation.replaceElement = replaceElement;
function appendChild(elem, child) {
  removeElement(child);
  child.next = null;
  child.parent = elem;
  if (elem.children.push(child) > 1) {
    var sibling = elem.children[elem.children.length - 2];
    sibling.next = child;
    child.prev = sibling;
  } else {
    child.prev = null;
  }
}
manipulation.appendChild = appendChild;
function append$1(elem, next) {
  removeElement(next);
  var parent = elem.parent;
  var currNext = elem.next;
  next.next = currNext;
  next.prev = elem;
  elem.next = next;
  next.parent = parent;
  if (currNext) {
    currNext.prev = next;
    if (parent) {
      var childs = parent.children;
      childs.splice(childs.lastIndexOf(currNext), 0, next);
    }
  } else if (parent) {
    parent.children.push(next);
  }
}
manipulation.append = append$1;
function prependChild(elem, child) {
  removeElement(child);
  child.parent = elem;
  child.prev = null;
  if (elem.children.unshift(child) !== 1) {
    var sibling = elem.children[1];
    sibling.prev = child;
    child.next = sibling;
  } else {
    child.next = null;
  }
}
manipulation.prependChild = prependChild;
function prepend(elem, prev) {
  removeElement(prev);
  var parent = elem.parent;
  if (parent) {
    var childs = parent.children;
    childs.splice(childs.indexOf(elem), 0, prev);
  }
  if (elem.prev) {
    elem.prev.next = prev;
  }
  prev.parent = parent;
  prev.prev = elem.prev;
  prev.next = elem;
  elem.prev = prev;
}
manipulation.prepend = prepend;
var querying = {};
Object.defineProperty(querying, "__esModule", { value: true });
querying.findAll = querying.existsOne = querying.findOne = querying.findOneChild = querying.find = querying.filter = void 0;
var domhandler_1$1 = lib$4;
function filter(test, node2, recurse, limit) {
  if (recurse === void 0) {
    recurse = true;
  }
  if (limit === void 0) {
    limit = Infinity;
  }
  if (!Array.isArray(node2))
    node2 = [node2];
  return find$2(test, node2, recurse, limit);
}
querying.filter = filter;
function find$2(test, nodes, recurse, limit) {
  var result = [];
  for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
    var elem = nodes_1[_i];
    if (test(elem)) {
      result.push(elem);
      if (--limit <= 0)
        break;
    }
    if (recurse && (0, domhandler_1$1.hasChildren)(elem) && elem.children.length > 0) {
      var children = find$2(test, elem.children, recurse, limit);
      result.push.apply(result, children);
      limit -= children.length;
      if (limit <= 0)
        break;
    }
  }
  return result;
}
querying.find = find$2;
function findOneChild(test, nodes) {
  return nodes.find(test);
}
querying.findOneChild = findOneChild;
function findOne$1(test, nodes, recurse) {
  if (recurse === void 0) {
    recurse = true;
  }
  var elem = null;
  for (var i = 0; i < nodes.length && !elem; i++) {
    var checked = nodes[i];
    if (!(0, domhandler_1$1.isTag)(checked)) {
      continue;
    } else if (test(checked)) {
      elem = checked;
    } else if (recurse && checked.children.length > 0) {
      elem = findOne$1(test, checked.children, true);
    }
  }
  return elem;
}
querying.findOne = findOne$1;
function existsOne$1(test, nodes) {
  return nodes.some(function(checked) {
    return (0, domhandler_1$1.isTag)(checked) && (test(checked) || checked.children.length > 0 && existsOne$1(test, checked.children));
  });
}
querying.existsOne = existsOne$1;
function findAll$3(test, nodes) {
  var _a;
  var result = [];
  var stack = nodes.filter(domhandler_1$1.isTag);
  var elem;
  while (elem = stack.shift()) {
    var children = (_a = elem.children) === null || _a === void 0 ? void 0 : _a.filter(domhandler_1$1.isTag);
    if (children && children.length > 0) {
      stack.unshift.apply(stack, children);
    }
    if (test(elem))
      result.push(elem);
  }
  return result;
}
querying.findAll = findAll$3;
var legacy = {};
Object.defineProperty(legacy, "__esModule", { value: true });
legacy.getElementsByTagType = legacy.getElementsByTagName = legacy.getElementById = legacy.getElements = legacy.testElement = void 0;
var domhandler_1 = lib$4;
var querying_js_1 = querying;
var Checks = {
  tag_name: function(name2) {
    if (typeof name2 === "function") {
      return function(elem) {
        return (0, domhandler_1.isTag)(elem) && name2(elem.name);
      };
    } else if (name2 === "*") {
      return domhandler_1.isTag;
    }
    return function(elem) {
      return (0, domhandler_1.isTag)(elem) && elem.name === name2;
    };
  },
  tag_type: function(type) {
    if (typeof type === "function") {
      return function(elem) {
        return type(elem.type);
      };
    }
    return function(elem) {
      return elem.type === type;
    };
  },
  tag_contains: function(data2) {
    if (typeof data2 === "function") {
      return function(elem) {
        return (0, domhandler_1.isText)(elem) && data2(elem.data);
      };
    }
    return function(elem) {
      return (0, domhandler_1.isText)(elem) && elem.data === data2;
    };
  }
};
function getAttribCheck(attrib, value2) {
  if (typeof value2 === "function") {
    return function(elem) {
      return (0, domhandler_1.isTag)(elem) && value2(elem.attribs[attrib]);
    };
  }
  return function(elem) {
    return (0, domhandler_1.isTag)(elem) && elem.attribs[attrib] === value2;
  };
}
function combineFuncs(a, b) {
  return function(elem) {
    return a(elem) || b(elem);
  };
}
function compileTest(options) {
  var funcs = Object.keys(options).map(function(key) {
    var value2 = options[key];
    return Object.prototype.hasOwnProperty.call(Checks, key) ? Checks[key](value2) : getAttribCheck(key, value2);
  });
  return funcs.length === 0 ? null : funcs.reduce(combineFuncs);
}
function testElement(options, node2) {
  var test = compileTest(options);
  return test ? test(node2) : true;
}
legacy.testElement = testElement;
function getElements(options, nodes, recurse, limit) {
  if (limit === void 0) {
    limit = Infinity;
  }
  var test = compileTest(options);
  return test ? (0, querying_js_1.filter)(test, nodes, recurse, limit) : [];
}
legacy.getElements = getElements;
function getElementById(id, nodes, recurse) {
  if (recurse === void 0) {
    recurse = true;
  }
  if (!Array.isArray(nodes))
    nodes = [nodes];
  return (0, querying_js_1.findOne)(getAttribCheck("id", id), nodes, recurse);
}
legacy.getElementById = getElementById;
function getElementsByTagName(tagName, nodes, recurse, limit) {
  if (recurse === void 0) {
    recurse = true;
  }
  if (limit === void 0) {
    limit = Infinity;
  }
  return (0, querying_js_1.filter)(Checks["tag_name"](tagName), nodes, recurse, limit);
}
legacy.getElementsByTagName = getElementsByTagName;
function getElementsByTagType(type, nodes, recurse, limit) {
  if (recurse === void 0) {
    recurse = true;
  }
  if (limit === void 0) {
    limit = Infinity;
  }
  return (0, querying_js_1.filter)(Checks["tag_type"](type), nodes, recurse, limit);
}
legacy.getElementsByTagType = getElementsByTagType;
var helpers = {};
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.uniqueSort = exports.compareDocumentPosition = exports.DocumentPosition = exports.removeSubsets = void 0;
  var domhandler_12 = lib$4;
  function removeSubsets2(nodes) {
    var idx = nodes.length;
    while (--idx >= 0) {
      var node2 = nodes[idx];
      if (idx > 0 && nodes.lastIndexOf(node2, idx - 1) >= 0) {
        nodes.splice(idx, 1);
        continue;
      }
      for (var ancestor = node2.parent; ancestor; ancestor = ancestor.parent) {
        if (nodes.includes(ancestor)) {
          nodes.splice(idx, 1);
          break;
        }
      }
    }
    return nodes;
  }
  exports.removeSubsets = removeSubsets2;
  var DocumentPosition;
  (function(DocumentPosition2) {
    DocumentPosition2[DocumentPosition2["DISCONNECTED"] = 1] = "DISCONNECTED";
    DocumentPosition2[DocumentPosition2["PRECEDING"] = 2] = "PRECEDING";
    DocumentPosition2[DocumentPosition2["FOLLOWING"] = 4] = "FOLLOWING";
    DocumentPosition2[DocumentPosition2["CONTAINS"] = 8] = "CONTAINS";
    DocumentPosition2[DocumentPosition2["CONTAINED_BY"] = 16] = "CONTAINED_BY";
  })(DocumentPosition = exports.DocumentPosition || (exports.DocumentPosition = {}));
  function compareDocumentPosition(nodeA, nodeB) {
    var aParents = [];
    var bParents = [];
    if (nodeA === nodeB) {
      return 0;
    }
    var current = (0, domhandler_12.hasChildren)(nodeA) ? nodeA : nodeA.parent;
    while (current) {
      aParents.unshift(current);
      current = current.parent;
    }
    current = (0, domhandler_12.hasChildren)(nodeB) ? nodeB : nodeB.parent;
    while (current) {
      bParents.unshift(current);
      current = current.parent;
    }
    var maxIdx = Math.min(aParents.length, bParents.length);
    var idx = 0;
    while (idx < maxIdx && aParents[idx] === bParents[idx]) {
      idx++;
    }
    if (idx === 0) {
      return DocumentPosition.DISCONNECTED;
    }
    var sharedParent = aParents[idx - 1];
    var siblings = sharedParent.children;
    var aSibling = aParents[idx];
    var bSibling = bParents[idx];
    if (siblings.indexOf(aSibling) > siblings.indexOf(bSibling)) {
      if (sharedParent === nodeB) {
        return DocumentPosition.FOLLOWING | DocumentPosition.CONTAINED_BY;
      }
      return DocumentPosition.FOLLOWING;
    }
    if (sharedParent === nodeA) {
      return DocumentPosition.PRECEDING | DocumentPosition.CONTAINS;
    }
    return DocumentPosition.PRECEDING;
  }
  exports.compareDocumentPosition = compareDocumentPosition;
  function uniqueSort(nodes) {
    nodes = nodes.filter(function(node2, i, arr) {
      return !arr.includes(node2, i + 1);
    });
    nodes.sort(function(a, b) {
      var relative = compareDocumentPosition(a, b);
      if (relative & DocumentPosition.PRECEDING) {
        return -1;
      } else if (relative & DocumentPosition.FOLLOWING) {
        return 1;
      }
      return 0;
    });
    return nodes;
  }
  exports.uniqueSort = uniqueSort;
})(helpers);
var feeds = {};
Object.defineProperty(feeds, "__esModule", { value: true });
feeds.getFeed = void 0;
var stringify_js_1 = stringify$1;
var legacy_js_1 = legacy;
function getFeed(doc) {
  var feedRoot = getOneElement(isValidFeed, doc);
  return !feedRoot ? null : feedRoot.name === "feed" ? getAtomFeed(feedRoot) : getRssFeed(feedRoot);
}
feeds.getFeed = getFeed;
function getAtomFeed(feedRoot) {
  var _a;
  var childs = feedRoot.children;
  var feed = {
    type: "atom",
    items: (0, legacy_js_1.getElementsByTagName)("entry", childs).map(function(item) {
      var _a2;
      var children = item.children;
      var entry = { media: getMediaElements(children) };
      addConditionally(entry, "id", "id", children);
      addConditionally(entry, "title", "title", children);
      var href2 = (_a2 = getOneElement("link", children)) === null || _a2 === void 0 ? void 0 : _a2.attribs["href"];
      if (href2) {
        entry.link = href2;
      }
      var description = fetch("summary", children) || fetch("content", children);
      if (description) {
        entry.description = description;
      }
      var pubDate = fetch("updated", children);
      if (pubDate) {
        entry.pubDate = new Date(pubDate);
      }
      return entry;
    })
  };
  addConditionally(feed, "id", "id", childs);
  addConditionally(feed, "title", "title", childs);
  var href = (_a = getOneElement("link", childs)) === null || _a === void 0 ? void 0 : _a.attribs["href"];
  if (href) {
    feed.link = href;
  }
  addConditionally(feed, "description", "subtitle", childs);
  var updated = fetch("updated", childs);
  if (updated) {
    feed.updated = new Date(updated);
  }
  addConditionally(feed, "author", "email", childs, true);
  return feed;
}
function getRssFeed(feedRoot) {
  var _a, _b;
  var childs = (_b = (_a = getOneElement("channel", feedRoot.children)) === null || _a === void 0 ? void 0 : _a.children) !== null && _b !== void 0 ? _b : [];
  var feed = {
    type: feedRoot.name.substr(0, 3),
    id: "",
    items: (0, legacy_js_1.getElementsByTagName)("item", feedRoot.children).map(function(item) {
      var children = item.children;
      var entry = { media: getMediaElements(children) };
      addConditionally(entry, "id", "guid", children);
      addConditionally(entry, "title", "title", children);
      addConditionally(entry, "link", "link", children);
      addConditionally(entry, "description", "description", children);
      var pubDate = fetch("pubDate", children);
      if (pubDate)
        entry.pubDate = new Date(pubDate);
      return entry;
    })
  };
  addConditionally(feed, "title", "title", childs);
  addConditionally(feed, "link", "link", childs);
  addConditionally(feed, "description", "description", childs);
  var updated = fetch("lastBuildDate", childs);
  if (updated) {
    feed.updated = new Date(updated);
  }
  addConditionally(feed, "author", "managingEditor", childs, true);
  return feed;
}
var MEDIA_KEYS_STRING = ["url", "type", "lang"];
var MEDIA_KEYS_INT = [
  "fileSize",
  "bitrate",
  "framerate",
  "samplingrate",
  "channels",
  "duration",
  "height",
  "width"
];
function getMediaElements(where) {
  return (0, legacy_js_1.getElementsByTagName)("media:content", where).map(function(elem) {
    var attribs = elem.attribs;
    var media2 = {
      medium: attribs["medium"],
      isDefault: !!attribs["isDefault"]
    };
    for (var _i = 0, MEDIA_KEYS_STRING_1 = MEDIA_KEYS_STRING; _i < MEDIA_KEYS_STRING_1.length; _i++) {
      var attrib = MEDIA_KEYS_STRING_1[_i];
      if (attribs[attrib]) {
        media2[attrib] = attribs[attrib];
      }
    }
    for (var _a = 0, MEDIA_KEYS_INT_1 = MEDIA_KEYS_INT; _a < MEDIA_KEYS_INT_1.length; _a++) {
      var attrib = MEDIA_KEYS_INT_1[_a];
      if (attribs[attrib]) {
        media2[attrib] = parseInt(attribs[attrib], 10);
      }
    }
    if (attribs["expression"]) {
      media2.expression = attribs["expression"];
    }
    return media2;
  });
}
function getOneElement(tagName, node2) {
  return (0, legacy_js_1.getElementsByTagName)(tagName, node2, true, 1)[0];
}
function fetch(tagName, where, recurse) {
  if (recurse === void 0) {
    recurse = false;
  }
  return (0, stringify_js_1.textContent)((0, legacy_js_1.getElementsByTagName)(tagName, where, recurse, 1)).trim();
}
function addConditionally(obj, prop, tagName, where, recurse) {
  if (recurse === void 0) {
    recurse = false;
  }
  var val = fetch(tagName, where, recurse);
  if (val)
    obj[prop] = val;
}
function isValidFeed(value2) {
  return value2 === "rss" || value2 === "feed" || value2 === "rdf:RDF";
}
(function(exports) {
  var __createBinding2 = commonjsGlobal && commonjsGlobal.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() {
        return m[k];
      } };
    }
    Object.defineProperty(o, k2, desc);
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __exportStar = commonjsGlobal && commonjsGlobal.__exportStar || function(m, exports2) {
    for (var p in m)
      if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p))
        __createBinding2(exports2, m, p);
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.hasChildren = exports.isDocument = exports.isComment = exports.isText = exports.isCDATA = exports.isTag = void 0;
  __exportStar(stringify$1, exports);
  __exportStar(traversal, exports);
  __exportStar(manipulation, exports);
  __exportStar(querying, exports);
  __exportStar(legacy, exports);
  __exportStar(helpers, exports);
  __exportStar(feeds, exports);
  var domhandler_12 = lib$4;
  Object.defineProperty(exports, "isTag", { enumerable: true, get: function() {
    return domhandler_12.isTag;
  } });
  Object.defineProperty(exports, "isCDATA", { enumerable: true, get: function() {
    return domhandler_12.isCDATA;
  } });
  Object.defineProperty(exports, "isText", { enumerable: true, get: function() {
    return domhandler_12.isText;
  } });
  Object.defineProperty(exports, "isComment", { enumerable: true, get: function() {
    return domhandler_12.isComment;
  } });
  Object.defineProperty(exports, "isDocument", { enumerable: true, get: function() {
    return domhandler_12.isDocument;
  } });
  Object.defineProperty(exports, "hasChildren", { enumerable: true, get: function() {
    return domhandler_12.hasChildren;
  } });
})(lib$5);
var boolbase = {
  trueFunc: function trueFunc() {
    return true;
  },
  falseFunc: function falseFunc() {
    return false;
  }
};
var compile$3 = {};
var SelectorType;
(function(SelectorType2) {
  SelectorType2["Attribute"] = "attribute";
  SelectorType2["Pseudo"] = "pseudo";
  SelectorType2["PseudoElement"] = "pseudo-element";
  SelectorType2["Tag"] = "tag";
  SelectorType2["Universal"] = "universal";
  SelectorType2["Adjacent"] = "adjacent";
  SelectorType2["Child"] = "child";
  SelectorType2["Descendant"] = "descendant";
  SelectorType2["Parent"] = "parent";
  SelectorType2["Sibling"] = "sibling";
  SelectorType2["ColumnCombinator"] = "column-combinator";
})(SelectorType || (SelectorType = {}));
const IgnoreCaseMode = {
  Unknown: null,
  QuirksMode: "quirks",
  IgnoreCase: true,
  CaseSensitive: false
};
var AttributeAction;
(function(AttributeAction2) {
  AttributeAction2["Any"] = "any";
  AttributeAction2["Element"] = "element";
  AttributeAction2["End"] = "end";
  AttributeAction2["Equals"] = "equals";
  AttributeAction2["Exists"] = "exists";
  AttributeAction2["Hyphen"] = "hyphen";
  AttributeAction2["Not"] = "not";
  AttributeAction2["Start"] = "start";
})(AttributeAction || (AttributeAction = {}));
const reName = /^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/;
const reEscape = /\\([\da-f]{1,6}\s?|(\s)|.)/gi;
const actionTypes = /* @__PURE__ */ new Map([
  [126, AttributeAction.Element],
  [94, AttributeAction.Start],
  [36, AttributeAction.End],
  [42, AttributeAction.Any],
  [33, AttributeAction.Not],
  [124, AttributeAction.Hyphen]
]);
const unpackPseudos = /* @__PURE__ */ new Set([
  "has",
  "not",
  "matches",
  "is",
  "where",
  "host",
  "host-context"
]);
function isTraversal$1(selector2) {
  switch (selector2.type) {
    case SelectorType.Adjacent:
    case SelectorType.Child:
    case SelectorType.Descendant:
    case SelectorType.Parent:
    case SelectorType.Sibling:
    case SelectorType.ColumnCombinator:
      return true;
    default:
      return false;
  }
}
const stripQuotesFromPseudos = /* @__PURE__ */ new Set(["contains", "icontains"]);
function funescape(_, escaped, escapedWhitespace) {
  const high = parseInt(escaped, 16) - 65536;
  return high !== high || escapedWhitespace ? escaped : high < 0 ? String.fromCharCode(high + 65536) : String.fromCharCode(high >> 10 | 55296, high & 1023 | 56320);
}
function unescapeCSS(str) {
  return str.replace(reEscape, funescape);
}
function isQuote(c) {
  return c === 39 || c === 34;
}
function isWhitespace(c) {
  return c === 32 || c === 9 || c === 10 || c === 12 || c === 13;
}
function parse$O(selector2) {
  const subselects2 = [];
  const endIndex = parseSelector(subselects2, `${selector2}`, 0);
  if (endIndex < selector2.length) {
    throw new Error(`Unmatched selector: ${selector2.slice(endIndex)}`);
  }
  return subselects2;
}
function parseSelector(subselects2, selector2, selectorIndex) {
  let tokens = [];
  function getName2(offset) {
    const match2 = selector2.slice(selectorIndex + offset).match(reName);
    if (!match2) {
      throw new Error(`Expected name, found ${selector2.slice(selectorIndex)}`);
    }
    const [name2] = match2;
    selectorIndex += offset + name2.length;
    return unescapeCSS(name2);
  }
  function stripWhitespace(offset) {
    selectorIndex += offset;
    while (selectorIndex < selector2.length && isWhitespace(selector2.charCodeAt(selectorIndex))) {
      selectorIndex++;
    }
  }
  function readValueWithParenthesis() {
    selectorIndex += 1;
    const start = selectorIndex;
    let counter = 1;
    for (; counter > 0 && selectorIndex < selector2.length; selectorIndex++) {
      if (selector2.charCodeAt(selectorIndex) === 40 && !isEscaped(selectorIndex)) {
        counter++;
      } else if (selector2.charCodeAt(selectorIndex) === 41 && !isEscaped(selectorIndex)) {
        counter--;
      }
    }
    if (counter) {
      throw new Error("Parenthesis not matched");
    }
    return unescapeCSS(selector2.slice(start, selectorIndex - 1));
  }
  function isEscaped(pos) {
    let slashCount = 0;
    while (selector2.charCodeAt(--pos) === 92)
      slashCount++;
    return (slashCount & 1) === 1;
  }
  function ensureNotTraversal() {
    if (tokens.length > 0 && isTraversal$1(tokens[tokens.length - 1])) {
      throw new Error("Did not expect successive traversals.");
    }
  }
  function addTraversal(type) {
    if (tokens.length > 0 && tokens[tokens.length - 1].type === SelectorType.Descendant) {
      tokens[tokens.length - 1].type = type;
      return;
    }
    ensureNotTraversal();
    tokens.push({ type });
  }
  function addSpecialAttribute(name2, action) {
    tokens.push({
      type: SelectorType.Attribute,
      name: name2,
      action,
      value: getName2(1),
      namespace: null,
      ignoreCase: "quirks"
    });
  }
  function finalizeSubselector() {
    if (tokens.length && tokens[tokens.length - 1].type === SelectorType.Descendant) {
      tokens.pop();
    }
    if (tokens.length === 0) {
      throw new Error("Empty sub-selector");
    }
    subselects2.push(tokens);
  }
  stripWhitespace(0);
  if (selector2.length === selectorIndex) {
    return selectorIndex;
  }
  loop:
    while (selectorIndex < selector2.length) {
      const firstChar = selector2.charCodeAt(selectorIndex);
      switch (firstChar) {
        case 32:
        case 9:
        case 10:
        case 12:
        case 13: {
          if (tokens.length === 0 || tokens[0].type !== SelectorType.Descendant) {
            ensureNotTraversal();
            tokens.push({ type: SelectorType.Descendant });
          }
          stripWhitespace(1);
          break;
        }
        case 62: {
          addTraversal(SelectorType.Child);
          stripWhitespace(1);
          break;
        }
        case 60: {
          addTraversal(SelectorType.Parent);
          stripWhitespace(1);
          break;
        }
        case 126: {
          addTraversal(SelectorType.Sibling);
          stripWhitespace(1);
          break;
        }
        case 43: {
          addTraversal(SelectorType.Adjacent);
          stripWhitespace(1);
          break;
        }
        case 46: {
          addSpecialAttribute("class", AttributeAction.Element);
          break;
        }
        case 35: {
          addSpecialAttribute("id", AttributeAction.Equals);
          break;
        }
        case 91: {
          stripWhitespace(1);
          let name2;
          let namespace = null;
          if (selector2.charCodeAt(selectorIndex) === 124) {
            name2 = getName2(1);
          } else if (selector2.startsWith("*|", selectorIndex)) {
            namespace = "*";
            name2 = getName2(2);
          } else {
            name2 = getName2(0);
            if (selector2.charCodeAt(selectorIndex) === 124 && selector2.charCodeAt(selectorIndex + 1) !== 61) {
              namespace = name2;
              name2 = getName2(1);
            }
          }
          stripWhitespace(0);
          let action = AttributeAction.Exists;
          const possibleAction = actionTypes.get(selector2.charCodeAt(selectorIndex));
          if (possibleAction) {
            action = possibleAction;
            if (selector2.charCodeAt(selectorIndex + 1) !== 61) {
              throw new Error("Expected `=`");
            }
            stripWhitespace(2);
          } else if (selector2.charCodeAt(selectorIndex) === 61) {
            action = AttributeAction.Equals;
            stripWhitespace(1);
          }
          let value2 = "";
          let ignoreCase = null;
          if (action !== "exists") {
            if (isQuote(selector2.charCodeAt(selectorIndex))) {
              const quote = selector2.charCodeAt(selectorIndex);
              let sectionEnd = selectorIndex + 1;
              while (sectionEnd < selector2.length && (selector2.charCodeAt(sectionEnd) !== quote || isEscaped(sectionEnd))) {
                sectionEnd += 1;
              }
              if (selector2.charCodeAt(sectionEnd) !== quote) {
                throw new Error("Attribute value didn't end");
              }
              value2 = unescapeCSS(selector2.slice(selectorIndex + 1, sectionEnd));
              selectorIndex = sectionEnd + 1;
            } else {
              const valueStart = selectorIndex;
              while (selectorIndex < selector2.length && (!isWhitespace(selector2.charCodeAt(selectorIndex)) && selector2.charCodeAt(selectorIndex) !== 93 || isEscaped(selectorIndex))) {
                selectorIndex += 1;
              }
              value2 = unescapeCSS(selector2.slice(valueStart, selectorIndex));
            }
            stripWhitespace(0);
            const forceIgnore = selector2.charCodeAt(selectorIndex) | 32;
            if (forceIgnore === 115) {
              ignoreCase = false;
              stripWhitespace(1);
            } else if (forceIgnore === 105) {
              ignoreCase = true;
              stripWhitespace(1);
            }
          }
          if (selector2.charCodeAt(selectorIndex) !== 93) {
            throw new Error("Attribute selector didn't terminate");
          }
          selectorIndex += 1;
          const attributeSelector = {
            type: SelectorType.Attribute,
            name: name2,
            action,
            value: value2,
            namespace,
            ignoreCase
          };
          tokens.push(attributeSelector);
          break;
        }
        case 58: {
          if (selector2.charCodeAt(selectorIndex + 1) === 58) {
            tokens.push({
              type: SelectorType.PseudoElement,
              name: getName2(2).toLowerCase(),
              data: selector2.charCodeAt(selectorIndex) === 40 ? readValueWithParenthesis() : null
            });
            continue;
          }
          const name2 = getName2(1).toLowerCase();
          let data2 = null;
          if (selector2.charCodeAt(selectorIndex) === 40) {
            if (unpackPseudos.has(name2)) {
              if (isQuote(selector2.charCodeAt(selectorIndex + 1))) {
                throw new Error(`Pseudo-selector ${name2} cannot be quoted`);
              }
              data2 = [];
              selectorIndex = parseSelector(data2, selector2, selectorIndex + 1);
              if (selector2.charCodeAt(selectorIndex) !== 41) {
                throw new Error(`Missing closing parenthesis in :${name2} (${selector2})`);
              }
              selectorIndex += 1;
            } else {
              data2 = readValueWithParenthesis();
              if (stripQuotesFromPseudos.has(name2)) {
                const quot = data2.charCodeAt(0);
                if (quot === data2.charCodeAt(data2.length - 1) && isQuote(quot)) {
                  data2 = data2.slice(1, -1);
                }
              }
              data2 = unescapeCSS(data2);
            }
          }
          tokens.push({ type: SelectorType.Pseudo, name: name2, data: data2 });
          break;
        }
        case 44: {
          finalizeSubselector();
          tokens = [];
          stripWhitespace(1);
          break;
        }
        default: {
          if (selector2.startsWith("/*", selectorIndex)) {
            const endIndex = selector2.indexOf("*/", selectorIndex + 2);
            if (endIndex < 0) {
              throw new Error("Comment was not terminated");
            }
            selectorIndex = endIndex + 2;
            if (tokens.length === 0) {
              stripWhitespace(0);
            }
            break;
          }
          let namespace = null;
          let name2;
          if (firstChar === 42) {
            selectorIndex += 1;
            name2 = "*";
          } else if (firstChar === 124) {
            name2 = "";
            if (selector2.charCodeAt(selectorIndex + 1) === 124) {
              addTraversal(SelectorType.ColumnCombinator);
              stripWhitespace(2);
              break;
            }
          } else if (reName.test(selector2.slice(selectorIndex))) {
            name2 = getName2(0);
          } else {
            break loop;
          }
          if (selector2.charCodeAt(selectorIndex) === 124 && selector2.charCodeAt(selectorIndex + 1) !== 124) {
            namespace = name2;
            if (selector2.charCodeAt(selectorIndex + 1) === 42) {
              name2 = "*";
              selectorIndex += 2;
            } else {
              name2 = getName2(1);
            }
          }
          tokens.push(name2 === "*" ? { type: SelectorType.Universal, namespace } : { type: SelectorType.Tag, name: name2, namespace });
        }
      }
    }
  finalizeSubselector();
  return selectorIndex;
}
const attribValChars = ["\\", '"'];
const pseudoValChars = [...attribValChars, "(", ")"];
const charsToEscapeInAttributeValue = new Set(attribValChars.map((c) => c.charCodeAt(0)));
const charsToEscapeInPseudoValue = new Set(pseudoValChars.map((c) => c.charCodeAt(0)));
const charsToEscapeInName = new Set([
  ...pseudoValChars,
  "~",
  "^",
  "$",
  "*",
  "+",
  "!",
  "|",
  ":",
  "[",
  "]",
  " ",
  "."
].map((c) => c.charCodeAt(0)));
function stringify(selector2) {
  return selector2.map((token) => token.map(stringifyToken).join("")).join(", ");
}
function stringifyToken(token, index2, arr) {
  switch (token.type) {
    case SelectorType.Child:
      return index2 === 0 ? "> " : " > ";
    case SelectorType.Parent:
      return index2 === 0 ? "< " : " < ";
    case SelectorType.Sibling:
      return index2 === 0 ? "~ " : " ~ ";
    case SelectorType.Adjacent:
      return index2 === 0 ? "+ " : " + ";
    case SelectorType.Descendant:
      return " ";
    case SelectorType.ColumnCombinator:
      return index2 === 0 ? "|| " : " || ";
    case SelectorType.Universal:
      return token.namespace === "*" && index2 + 1 < arr.length && "name" in arr[index2 + 1] ? "" : `${getNamespace(token.namespace)}*`;
    case SelectorType.Tag:
      return getNamespacedName(token);
    case SelectorType.PseudoElement:
      return `::${escapeName(token.name, charsToEscapeInName)}${token.data === null ? "" : `(${escapeName(token.data, charsToEscapeInPseudoValue)})`}`;
    case SelectorType.Pseudo:
      return `:${escapeName(token.name, charsToEscapeInName)}${token.data === null ? "" : `(${typeof token.data === "string" ? escapeName(token.data, charsToEscapeInPseudoValue) : stringify(token.data)})`}`;
    case SelectorType.Attribute: {
      if (token.name === "id" && token.action === AttributeAction.Equals && token.ignoreCase === "quirks" && !token.namespace) {
        return `#${escapeName(token.value, charsToEscapeInName)}`;
      }
      if (token.name === "class" && token.action === AttributeAction.Element && token.ignoreCase === "quirks" && !token.namespace) {
        return `.${escapeName(token.value, charsToEscapeInName)}`;
      }
      const name2 = getNamespacedName(token);
      if (token.action === AttributeAction.Exists) {
        return `[${name2}]`;
      }
      return `[${name2}${getActionValue(token.action)}="${escapeName(token.value, charsToEscapeInAttributeValue)}"${token.ignoreCase === null ? "" : token.ignoreCase ? " i" : " s"}]`;
    }
  }
}
function getActionValue(action) {
  switch (action) {
    case AttributeAction.Equals:
      return "";
    case AttributeAction.Element:
      return "~";
    case AttributeAction.Start:
      return "^";
    case AttributeAction.End:
      return "$";
    case AttributeAction.Any:
      return "*";
    case AttributeAction.Not:
      return "!";
    case AttributeAction.Hyphen:
      return "|";
    case AttributeAction.Exists:
      throw new Error("Shouldn't be here");
  }
}
function getNamespacedName(token) {
  return `${getNamespace(token.namespace)}${escapeName(token.name, charsToEscapeInName)}`;
}
function getNamespace(namespace) {
  return namespace !== null ? `${namespace === "*" ? "*" : escapeName(namespace, charsToEscapeInName)}|` : "";
}
function escapeName(str, charsToEscape) {
  let lastIdx = 0;
  let ret = "";
  for (let i = 0; i < str.length; i++) {
    if (charsToEscape.has(str.charCodeAt(i))) {
      ret += `${str.slice(lastIdx, i)}\\${str.charAt(i)}`;
      lastIdx = i + 1;
    }
  }
  return ret.length > 0 ? ret + str.slice(lastIdx) : str;
}
var es = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  isTraversal: isTraversal$1,
  parse: parse$O,
  stringify,
  get SelectorType() {
    return SelectorType;
  },
  IgnoreCaseMode,
  get AttributeAction() {
    return AttributeAction;
  }
});
var require$$0 = /* @__PURE__ */ getAugmentedNamespace(es);
var sort = {};
Object.defineProperty(sort, "__esModule", { value: true });
sort.isTraversal = void 0;
var css_what_1$2 = require$$0;
var procedure = /* @__PURE__ */ new Map([
  [css_what_1$2.SelectorType.Universal, 50],
  [css_what_1$2.SelectorType.Tag, 30],
  [css_what_1$2.SelectorType.Attribute, 1],
  [css_what_1$2.SelectorType.Pseudo, 0]
]);
function isTraversal(token) {
  return !procedure.has(token.type);
}
sort.isTraversal = isTraversal;
var attributes$1 = /* @__PURE__ */ new Map([
  [css_what_1$2.AttributeAction.Exists, 10],
  [css_what_1$2.AttributeAction.Equals, 8],
  [css_what_1$2.AttributeAction.Not, 7],
  [css_what_1$2.AttributeAction.Start, 6],
  [css_what_1$2.AttributeAction.End, 6],
  [css_what_1$2.AttributeAction.Any, 5]
]);
function sortByProcedure(arr) {
  var procs = arr.map(getProcedure);
  for (var i = 1; i < arr.length; i++) {
    var procNew = procs[i];
    if (procNew < 0)
      continue;
    for (var j = i - 1; j >= 0 && procNew < procs[j]; j--) {
      var token = arr[j + 1];
      arr[j + 1] = arr[j];
      arr[j] = token;
      procs[j + 1] = procs[j];
      procs[j] = procNew;
    }
  }
}
sort.default = sortByProcedure;
function getProcedure(token) {
  var _a, _b;
  var proc = (_a = procedure.get(token.type)) !== null && _a !== void 0 ? _a : -1;
  if (token.type === css_what_1$2.SelectorType.Attribute) {
    proc = (_b = attributes$1.get(token.action)) !== null && _b !== void 0 ? _b : 4;
    if (token.action === css_what_1$2.AttributeAction.Equals && token.name === "id") {
      proc = 9;
    }
    if (token.ignoreCase) {
      proc >>= 1;
    }
  } else if (token.type === css_what_1$2.SelectorType.Pseudo) {
    if (!token.data) {
      proc = 3;
    } else if (token.name === "has" || token.name === "contains") {
      proc = 0;
    } else if (Array.isArray(token.data)) {
      proc = Math.min.apply(Math, token.data.map(function(d) {
        return Math.min.apply(Math, d.map(getProcedure));
      }));
      if (proc < 0) {
        proc = 0;
      }
    } else {
      proc = 2;
    }
  }
  return proc;
}
var general = {};
var attributes = {};
var __importDefault$2 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(attributes, "__esModule", { value: true });
attributes.attributeRules = void 0;
var boolbase_1$2 = __importDefault$2(boolbase);
var reChars = /[-[\]{}()*+?.,\\^$|#\s]/g;
function escapeRegex(value2) {
  return value2.replace(reChars, "\\$&");
}
var caseInsensitiveAttributes = /* @__PURE__ */ new Set([
  "accept",
  "accept-charset",
  "align",
  "alink",
  "axis",
  "bgcolor",
  "charset",
  "checked",
  "clear",
  "codetype",
  "color",
  "compact",
  "declare",
  "defer",
  "dir",
  "direction",
  "disabled",
  "enctype",
  "face",
  "frame",
  "hreflang",
  "http-equiv",
  "lang",
  "language",
  "link",
  "media",
  "method",
  "multiple",
  "nohref",
  "noresize",
  "noshade",
  "nowrap",
  "readonly",
  "rel",
  "rev",
  "rules",
  "scope",
  "scrolling",
  "selected",
  "shape",
  "target",
  "text",
  "type",
  "valign",
  "valuetype",
  "vlink"
]);
function shouldIgnoreCase(selector2, options) {
  return typeof selector2.ignoreCase === "boolean" ? selector2.ignoreCase : selector2.ignoreCase === "quirks" ? !!options.quirksMode : !options.xmlMode && caseInsensitiveAttributes.has(selector2.name);
}
attributes.attributeRules = {
  equals: function(next, data2, options) {
    var adapter = options.adapter;
    var name2 = data2.name;
    var value2 = data2.value;
    if (shouldIgnoreCase(data2, options)) {
      value2 = value2.toLowerCase();
      return function(elem) {
        var attr = adapter.getAttributeValue(elem, name2);
        return attr != null && attr.length === value2.length && attr.toLowerCase() === value2 && next(elem);
      };
    }
    return function(elem) {
      return adapter.getAttributeValue(elem, name2) === value2 && next(elem);
    };
  },
  hyphen: function(next, data2, options) {
    var adapter = options.adapter;
    var name2 = data2.name;
    var value2 = data2.value;
    var len = value2.length;
    if (shouldIgnoreCase(data2, options)) {
      value2 = value2.toLowerCase();
      return function hyphenIC(elem) {
        var attr = adapter.getAttributeValue(elem, name2);
        return attr != null && (attr.length === len || attr.charAt(len) === "-") && attr.substr(0, len).toLowerCase() === value2 && next(elem);
      };
    }
    return function hyphen(elem) {
      var attr = adapter.getAttributeValue(elem, name2);
      return attr != null && (attr.length === len || attr.charAt(len) === "-") && attr.substr(0, len) === value2 && next(elem);
    };
  },
  element: function(next, data2, options) {
    var adapter = options.adapter;
    var name2 = data2.name, value2 = data2.value;
    if (/\s/.test(value2)) {
      return boolbase_1$2.default.falseFunc;
    }
    var regex = new RegExp("(?:^|\\s)".concat(escapeRegex(value2), "(?:$|\\s)"), shouldIgnoreCase(data2, options) ? "i" : "");
    return function element(elem) {
      var attr = adapter.getAttributeValue(elem, name2);
      return attr != null && attr.length >= value2.length && regex.test(attr) && next(elem);
    };
  },
  exists: function(next, _a, _b) {
    var name2 = _a.name;
    var adapter = _b.adapter;
    return function(elem) {
      return adapter.hasAttrib(elem, name2) && next(elem);
    };
  },
  start: function(next, data2, options) {
    var adapter = options.adapter;
    var name2 = data2.name;
    var value2 = data2.value;
    var len = value2.length;
    if (len === 0) {
      return boolbase_1$2.default.falseFunc;
    }
    if (shouldIgnoreCase(data2, options)) {
      value2 = value2.toLowerCase();
      return function(elem) {
        var attr = adapter.getAttributeValue(elem, name2);
        return attr != null && attr.length >= len && attr.substr(0, len).toLowerCase() === value2 && next(elem);
      };
    }
    return function(elem) {
      var _a;
      return !!((_a = adapter.getAttributeValue(elem, name2)) === null || _a === void 0 ? void 0 : _a.startsWith(value2)) && next(elem);
    };
  },
  end: function(next, data2, options) {
    var adapter = options.adapter;
    var name2 = data2.name;
    var value2 = data2.value;
    var len = -value2.length;
    if (len === 0) {
      return boolbase_1$2.default.falseFunc;
    }
    if (shouldIgnoreCase(data2, options)) {
      value2 = value2.toLowerCase();
      return function(elem) {
        var _a;
        return ((_a = adapter.getAttributeValue(elem, name2)) === null || _a === void 0 ? void 0 : _a.substr(len).toLowerCase()) === value2 && next(elem);
      };
    }
    return function(elem) {
      var _a;
      return !!((_a = adapter.getAttributeValue(elem, name2)) === null || _a === void 0 ? void 0 : _a.endsWith(value2)) && next(elem);
    };
  },
  any: function(next, data2, options) {
    var adapter = options.adapter;
    var name2 = data2.name, value2 = data2.value;
    if (value2 === "") {
      return boolbase_1$2.default.falseFunc;
    }
    if (shouldIgnoreCase(data2, options)) {
      var regex_1 = new RegExp(escapeRegex(value2), "i");
      return function anyIC(elem) {
        var attr = adapter.getAttributeValue(elem, name2);
        return attr != null && attr.length >= value2.length && regex_1.test(attr) && next(elem);
      };
    }
    return function(elem) {
      var _a;
      return !!((_a = adapter.getAttributeValue(elem, name2)) === null || _a === void 0 ? void 0 : _a.includes(value2)) && next(elem);
    };
  },
  not: function(next, data2, options) {
    var adapter = options.adapter;
    var name2 = data2.name;
    var value2 = data2.value;
    if (value2 === "") {
      return function(elem) {
        return !!adapter.getAttributeValue(elem, name2) && next(elem);
      };
    } else if (shouldIgnoreCase(data2, options)) {
      value2 = value2.toLowerCase();
      return function(elem) {
        var attr = adapter.getAttributeValue(elem, name2);
        return (attr == null || attr.length !== value2.length || attr.toLowerCase() !== value2) && next(elem);
      };
    }
    return function(elem) {
      return adapter.getAttributeValue(elem, name2) !== value2 && next(elem);
    };
  }
};
var pseudoSelectors = {};
var filters$1 = {};
var lib = {};
var parse$N = {};
Object.defineProperty(parse$N, "__esModule", { value: true });
parse$N.parse = void 0;
var whitespace = /* @__PURE__ */ new Set([9, 10, 12, 13, 32]);
var ZERO = "0".charCodeAt(0);
var NINE = "9".charCodeAt(0);
function parse$M(formula) {
  formula = formula.trim().toLowerCase();
  if (formula === "even") {
    return [2, 0];
  } else if (formula === "odd") {
    return [2, 1];
  }
  var idx = 0;
  var a = 0;
  var sign = readSign();
  var number2 = readNumber2();
  if (idx < formula.length && formula.charAt(idx) === "n") {
    idx++;
    a = sign * (number2 !== null && number2 !== void 0 ? number2 : 1);
    skipWhitespace();
    if (idx < formula.length) {
      sign = readSign();
      skipWhitespace();
      number2 = readNumber2();
    } else {
      sign = number2 = 0;
    }
  }
  if (number2 === null || idx < formula.length) {
    throw new Error("n-th rule couldn't be parsed ('".concat(formula, "')"));
  }
  return [a, sign * number2];
  function readSign() {
    if (formula.charAt(idx) === "-") {
      idx++;
      return -1;
    }
    if (formula.charAt(idx) === "+") {
      idx++;
    }
    return 1;
  }
  function readNumber2() {
    var start = idx;
    var value2 = 0;
    while (idx < formula.length && formula.charCodeAt(idx) >= ZERO && formula.charCodeAt(idx) <= NINE) {
      value2 = value2 * 10 + (formula.charCodeAt(idx) - ZERO);
      idx++;
    }
    return idx === start ? null : value2;
  }
  function skipWhitespace() {
    while (idx < formula.length && whitespace.has(formula.charCodeAt(idx))) {
      idx++;
    }
  }
}
parse$N.parse = parse$M;
var compile$2 = {};
var __importDefault$1 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(compile$2, "__esModule", { value: true });
compile$2.generate = compile$2.compile = void 0;
var boolbase_1$1 = __importDefault$1(boolbase);
function compile$1(parsed) {
  var a = parsed[0];
  var b = parsed[1] - 1;
  if (b < 0 && a <= 0)
    return boolbase_1$1.default.falseFunc;
  if (a === -1)
    return function(index2) {
      return index2 <= b;
    };
  if (a === 0)
    return function(index2) {
      return index2 === b;
    };
  if (a === 1)
    return b < 0 ? boolbase_1$1.default.trueFunc : function(index2) {
      return index2 >= b;
    };
  var absA = Math.abs(a);
  var bMod = (b % absA + absA) % absA;
  return a > 1 ? function(index2) {
    return index2 >= b && index2 % absA === bMod;
  } : function(index2) {
    return index2 <= b && index2 % absA === bMod;
  };
}
compile$2.compile = compile$1;
function generate$M(parsed) {
  var a = parsed[0];
  var b = parsed[1] - 1;
  var n = 0;
  if (a < 0) {
    var aPos_1 = -a;
    var minValue_1 = (b % aPos_1 + aPos_1) % aPos_1;
    return function() {
      var val = minValue_1 + aPos_1 * n++;
      return val > b ? null : val;
    };
  }
  if (a === 0)
    return b < 0 ? function() {
      return null;
    } : function() {
      return n++ === 0 ? b : null;
    };
  if (b < 0) {
    b += a * Math.ceil(-b / a);
  }
  return function() {
    return a * n++ + b;
  };
}
compile$2.generate = generate$M;
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.sequence = exports.generate = exports.compile = exports.parse = void 0;
  var parse_js_1 = parse$N;
  Object.defineProperty(exports, "parse", { enumerable: true, get: function() {
    return parse_js_1.parse;
  } });
  var compile_js_1 = compile$2;
  Object.defineProperty(exports, "compile", { enumerable: true, get: function() {
    return compile_js_1.compile;
  } });
  Object.defineProperty(exports, "generate", { enumerable: true, get: function() {
    return compile_js_1.generate;
  } });
  function nthCheck(formula) {
    return (0, compile_js_1.compile)((0, parse_js_1.parse)(formula));
  }
  exports.default = nthCheck;
  function sequence2(formula) {
    return (0, compile_js_1.generate)((0, parse_js_1.parse)(formula));
  }
  exports.sequence = sequence2;
})(lib);
(function(exports) {
  var __importDefault2 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.filters = void 0;
  var nth_check_1 = __importDefault2(lib);
  var boolbase_12 = __importDefault2(boolbase);
  function getChildFunc(next, adapter) {
    return function(elem) {
      var parent = adapter.getParent(elem);
      return parent != null && adapter.isTag(parent) && next(elem);
    };
  }
  exports.filters = {
    contains: function(next, text, _a) {
      var adapter = _a.adapter;
      return function contains(elem) {
        return next(elem) && adapter.getText(elem).includes(text);
      };
    },
    icontains: function(next, text, _a) {
      var adapter = _a.adapter;
      var itext = text.toLowerCase();
      return function icontains(elem) {
        return next(elem) && adapter.getText(elem).toLowerCase().includes(itext);
      };
    },
    "nth-child": function(next, rule, _a) {
      var adapter = _a.adapter, equals = _a.equals;
      var func = (0, nth_check_1.default)(rule);
      if (func === boolbase_12.default.falseFunc)
        return boolbase_12.default.falseFunc;
      if (func === boolbase_12.default.trueFunc)
        return getChildFunc(next, adapter);
      return function nthChild(elem) {
        var siblings = adapter.getSiblings(elem);
        var pos = 0;
        for (var i = 0; i < siblings.length; i++) {
          if (equals(elem, siblings[i]))
            break;
          if (adapter.isTag(siblings[i])) {
            pos++;
          }
        }
        return func(pos) && next(elem);
      };
    },
    "nth-last-child": function(next, rule, _a) {
      var adapter = _a.adapter, equals = _a.equals;
      var func = (0, nth_check_1.default)(rule);
      if (func === boolbase_12.default.falseFunc)
        return boolbase_12.default.falseFunc;
      if (func === boolbase_12.default.trueFunc)
        return getChildFunc(next, adapter);
      return function nthLastChild(elem) {
        var siblings = adapter.getSiblings(elem);
        var pos = 0;
        for (var i = siblings.length - 1; i >= 0; i--) {
          if (equals(elem, siblings[i]))
            break;
          if (adapter.isTag(siblings[i])) {
            pos++;
          }
        }
        return func(pos) && next(elem);
      };
    },
    "nth-of-type": function(next, rule, _a) {
      var adapter = _a.adapter, equals = _a.equals;
      var func = (0, nth_check_1.default)(rule);
      if (func === boolbase_12.default.falseFunc)
        return boolbase_12.default.falseFunc;
      if (func === boolbase_12.default.trueFunc)
        return getChildFunc(next, adapter);
      return function nthOfType(elem) {
        var siblings = adapter.getSiblings(elem);
        var pos = 0;
        for (var i = 0; i < siblings.length; i++) {
          var currentSibling = siblings[i];
          if (equals(elem, currentSibling))
            break;
          if (adapter.isTag(currentSibling) && adapter.getName(currentSibling) === adapter.getName(elem)) {
            pos++;
          }
        }
        return func(pos) && next(elem);
      };
    },
    "nth-last-of-type": function(next, rule, _a) {
      var adapter = _a.adapter, equals = _a.equals;
      var func = (0, nth_check_1.default)(rule);
      if (func === boolbase_12.default.falseFunc)
        return boolbase_12.default.falseFunc;
      if (func === boolbase_12.default.trueFunc)
        return getChildFunc(next, adapter);
      return function nthLastOfType(elem) {
        var siblings = adapter.getSiblings(elem);
        var pos = 0;
        for (var i = siblings.length - 1; i >= 0; i--) {
          var currentSibling = siblings[i];
          if (equals(elem, currentSibling))
            break;
          if (adapter.isTag(currentSibling) && adapter.getName(currentSibling) === adapter.getName(elem)) {
            pos++;
          }
        }
        return func(pos) && next(elem);
      };
    },
    root: function(next, _rule, _a) {
      var adapter = _a.adapter;
      return function(elem) {
        var parent = adapter.getParent(elem);
        return (parent == null || !adapter.isTag(parent)) && next(elem);
      };
    },
    scope: function(next, rule, options, context) {
      var equals = options.equals;
      if (!context || context.length === 0) {
        return exports.filters["root"](next, rule, options);
      }
      if (context.length === 1) {
        return function(elem) {
          return equals(context[0], elem) && next(elem);
        };
      }
      return function(elem) {
        return context.includes(elem) && next(elem);
      };
    },
    hover: dynamicStatePseudo("isHovered"),
    visited: dynamicStatePseudo("isVisited"),
    active: dynamicStatePseudo("isActive")
  };
  function dynamicStatePseudo(name2) {
    return function dynamicPseudo(next, _rule, _a) {
      var adapter = _a.adapter;
      var func = adapter[name2];
      if (typeof func !== "function") {
        return boolbase_12.default.falseFunc;
      }
      return function active(elem) {
        return func(elem) && next(elem);
      };
    };
  }
})(filters$1);
var pseudos = {};
Object.defineProperty(pseudos, "__esModule", { value: true });
pseudos.verifyPseudoArgs = pseudos.pseudos = void 0;
pseudos.pseudos = {
  empty: function(elem, _a) {
    var adapter = _a.adapter;
    return !adapter.getChildren(elem).some(function(elem2) {
      return adapter.isTag(elem2) || adapter.getText(elem2) !== "";
    });
  },
  "first-child": function(elem, _a) {
    var adapter = _a.adapter, equals = _a.equals;
    if (adapter.prevElementSibling) {
      return adapter.prevElementSibling(elem) == null;
    }
    var firstChild = adapter.getSiblings(elem).find(function(elem2) {
      return adapter.isTag(elem2);
    });
    return firstChild != null && equals(elem, firstChild);
  },
  "last-child": function(elem, _a) {
    var adapter = _a.adapter, equals = _a.equals;
    var siblings = adapter.getSiblings(elem);
    for (var i = siblings.length - 1; i >= 0; i--) {
      if (equals(elem, siblings[i]))
        return true;
      if (adapter.isTag(siblings[i]))
        break;
    }
    return false;
  },
  "first-of-type": function(elem, _a) {
    var adapter = _a.adapter, equals = _a.equals;
    var siblings = adapter.getSiblings(elem);
    var elemName = adapter.getName(elem);
    for (var i = 0; i < siblings.length; i++) {
      var currentSibling = siblings[i];
      if (equals(elem, currentSibling))
        return true;
      if (adapter.isTag(currentSibling) && adapter.getName(currentSibling) === elemName) {
        break;
      }
    }
    return false;
  },
  "last-of-type": function(elem, _a) {
    var adapter = _a.adapter, equals = _a.equals;
    var siblings = adapter.getSiblings(elem);
    var elemName = adapter.getName(elem);
    for (var i = siblings.length - 1; i >= 0; i--) {
      var currentSibling = siblings[i];
      if (equals(elem, currentSibling))
        return true;
      if (adapter.isTag(currentSibling) && adapter.getName(currentSibling) === elemName) {
        break;
      }
    }
    return false;
  },
  "only-of-type": function(elem, _a) {
    var adapter = _a.adapter, equals = _a.equals;
    var elemName = adapter.getName(elem);
    return adapter.getSiblings(elem).every(function(sibling) {
      return equals(elem, sibling) || !adapter.isTag(sibling) || adapter.getName(sibling) !== elemName;
    });
  },
  "only-child": function(elem, _a) {
    var adapter = _a.adapter, equals = _a.equals;
    return adapter.getSiblings(elem).every(function(sibling) {
      return equals(elem, sibling) || !adapter.isTag(sibling);
    });
  }
};
function verifyPseudoArgs(func, name2, subselect, argIndex) {
  if (subselect === null) {
    if (func.length > argIndex) {
      throw new Error("Pseudo-class :".concat(name2, " requires an argument"));
    }
  } else if (func.length === argIndex) {
    throw new Error("Pseudo-class :".concat(name2, " doesn't have any arguments"));
  }
}
pseudos.verifyPseudoArgs = verifyPseudoArgs;
var aliases = {};
Object.defineProperty(aliases, "__esModule", { value: true });
aliases.aliases = void 0;
aliases.aliases = {
  "any-link": ":is(a, area, link)[href]",
  link: ":any-link:not(:visited)",
  disabled: ":is(\n        :is(button, input, select, textarea, optgroup, option)[disabled],\n        optgroup[disabled] > option,\n        fieldset[disabled]:not(fieldset[disabled] legend:first-of-type *)\n    )",
  enabled: ":not(:disabled)",
  checked: ":is(:is(input[type=radio], input[type=checkbox])[checked], option:selected)",
  required: ":is(input, select, textarea)[required]",
  optional: ":is(input, select, textarea):not([required])",
  selected: "option:is([selected], select:not([multiple]):not(:has(> option[selected])) > :first-of-type)",
  checkbox: "[type=checkbox]",
  file: "[type=file]",
  password: "[type=password]",
  radio: "[type=radio]",
  reset: "[type=reset]",
  image: "[type=image]",
  submit: "[type=submit]",
  parent: ":not(:empty)",
  header: ":is(h1, h2, h3, h4, h5, h6)",
  button: ":is(button, input[type=button])",
  input: ":is(input, textarea, select, button)",
  text: "input:is(:not([type!='']), [type=text])"
};
var subselects = {};
(function(exports) {
  var __spreadArray = commonjsGlobal && commonjsGlobal.__spreadArray || function(to, from, pack) {
    if (pack || arguments.length === 2)
      for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
          if (!ar)
            ar = Array.prototype.slice.call(from, 0, i);
          ar[i] = from[i];
        }
      }
    return to.concat(ar || Array.prototype.slice.call(from));
  };
  var __importDefault2 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.subselects = exports.getNextSiblings = exports.ensureIsTag = exports.PLACEHOLDER_ELEMENT = void 0;
  var boolbase_12 = __importDefault2(boolbase);
  var sort_js_12 = sort;
  exports.PLACEHOLDER_ELEMENT = {};
  function ensureIsTag(next, adapter) {
    if (next === boolbase_12.default.falseFunc)
      return boolbase_12.default.falseFunc;
    return function(elem) {
      return adapter.isTag(elem) && next(elem);
    };
  }
  exports.ensureIsTag = ensureIsTag;
  function getNextSiblings(elem, adapter) {
    var siblings = adapter.getSiblings(elem);
    if (siblings.length <= 1)
      return [];
    var elemIndex = siblings.indexOf(elem);
    if (elemIndex < 0 || elemIndex === siblings.length - 1)
      return [];
    return siblings.slice(elemIndex + 1).filter(adapter.isTag);
  }
  exports.getNextSiblings = getNextSiblings;
  function copyOptions(options) {
    return {
      xmlMode: !!options.xmlMode,
      lowerCaseAttributeNames: !!options.lowerCaseAttributeNames,
      lowerCaseTags: !!options.lowerCaseTags,
      quirksMode: !!options.quirksMode,
      cacheResults: !!options.cacheResults,
      pseudos: options.pseudos,
      adapter: options.adapter,
      equals: options.equals
    };
  }
  var is2 = function(next, token, options, context, compileToken2) {
    var func = compileToken2(token, copyOptions(options), context);
    return func === boolbase_12.default.trueFunc ? next : func === boolbase_12.default.falseFunc ? boolbase_12.default.falseFunc : function(elem) {
      return func(elem) && next(elem);
    };
  };
  exports.subselects = {
    is: is2,
    matches: is2,
    where: is2,
    not: function(next, token, options, context, compileToken2) {
      var func = compileToken2(token, copyOptions(options), context);
      return func === boolbase_12.default.falseFunc ? next : func === boolbase_12.default.trueFunc ? boolbase_12.default.falseFunc : function(elem) {
        return !func(elem) && next(elem);
      };
    },
    has: function(next, subselect, options, _context, compileToken2) {
      var adapter = options.adapter;
      var opts = copyOptions(options);
      opts.relativeSelector = true;
      var context = subselect.some(function(s) {
        return s.some(sort_js_12.isTraversal);
      }) ? [exports.PLACEHOLDER_ELEMENT] : void 0;
      var compiled = compileToken2(subselect, opts, context);
      if (compiled === boolbase_12.default.falseFunc)
        return boolbase_12.default.falseFunc;
      var hasElement = ensureIsTag(compiled, adapter);
      if (context && compiled !== boolbase_12.default.trueFunc) {
        var _a = compiled.shouldTestNextSiblings, shouldTestNextSiblings_1 = _a === void 0 ? false : _a;
        return function(elem) {
          if (!next(elem))
            return false;
          context[0] = elem;
          var childs = adapter.getChildren(elem);
          var nextElements = shouldTestNextSiblings_1 ? __spreadArray(__spreadArray([], childs, true), getNextSiblings(elem, adapter), true) : childs;
          return adapter.existsOne(hasElement, nextElements);
        };
      }
      return function(elem) {
        return next(elem) && adapter.existsOne(hasElement, adapter.getChildren(elem));
      };
    }
  };
})(subselects);
(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.compilePseudoSelector = exports.aliases = exports.pseudos = exports.filters = void 0;
  var css_what_12 = require$$0;
  var filters_js_1 = filters$1;
  Object.defineProperty(exports, "filters", { enumerable: true, get: function() {
    return filters_js_1.filters;
  } });
  var pseudos_js_1 = pseudos;
  Object.defineProperty(exports, "pseudos", { enumerable: true, get: function() {
    return pseudos_js_1.pseudos;
  } });
  var aliases_js_1 = aliases;
  Object.defineProperty(exports, "aliases", { enumerable: true, get: function() {
    return aliases_js_1.aliases;
  } });
  var subselects_js_12 = subselects;
  function compilePseudoSelector(next, selector2, options, context, compileToken2) {
    var _a;
    var name2 = selector2.name, data2 = selector2.data;
    if (Array.isArray(data2)) {
      if (!(name2 in subselects_js_12.subselects)) {
        throw new Error("Unknown pseudo-class :".concat(name2, "(").concat(data2, ")"));
      }
      return subselects_js_12.subselects[name2](next, data2, options, context, compileToken2);
    }
    var userPseudo = (_a = options.pseudos) === null || _a === void 0 ? void 0 : _a[name2];
    var stringPseudo = typeof userPseudo === "string" ? userPseudo : aliases_js_1.aliases[name2];
    if (typeof stringPseudo === "string") {
      if (data2 != null) {
        throw new Error("Pseudo ".concat(name2, " doesn't have any arguments"));
      }
      var alias = (0, css_what_12.parse)(stringPseudo);
      return subselects_js_12.subselects["is"](next, alias, options, context, compileToken2);
    }
    if (typeof userPseudo === "function") {
      (0, pseudos_js_1.verifyPseudoArgs)(userPseudo, name2, data2, 1);
      return function(elem) {
        return userPseudo(elem, data2) && next(elem);
      };
    }
    if (name2 in filters_js_1.filters) {
      return filters_js_1.filters[name2](next, data2, options, context);
    }
    if (name2 in pseudos_js_1.pseudos) {
      var pseudo_12 = pseudos_js_1.pseudos[name2];
      (0, pseudos_js_1.verifyPseudoArgs)(pseudo_12, name2, data2, 2);
      return function(elem) {
        return pseudo_12(elem, options, data2) && next(elem);
      };
    }
    throw new Error("Unknown pseudo-class :".concat(name2));
  }
  exports.compilePseudoSelector = compilePseudoSelector;
})(pseudoSelectors);
Object.defineProperty(general, "__esModule", { value: true });
general.compileGeneralSelector = void 0;
var attributes_js_1 = attributes;
var index_js_1 = pseudoSelectors;
var css_what_1$1 = require$$0;
function getElementParent(node2, adapter) {
  var parent = adapter.getParent(node2);
  if (parent && adapter.isTag(parent)) {
    return parent;
  }
  return null;
}
function compileGeneralSelector(next, selector2, options, context, compileToken2) {
  var adapter = options.adapter, equals = options.equals;
  switch (selector2.type) {
    case css_what_1$1.SelectorType.PseudoElement: {
      throw new Error("Pseudo-elements are not supported by css-select");
    }
    case css_what_1$1.SelectorType.ColumnCombinator: {
      throw new Error("Column combinators are not yet supported by css-select");
    }
    case css_what_1$1.SelectorType.Attribute: {
      if (selector2.namespace != null) {
        throw new Error("Namespaced attributes are not yet supported by css-select");
      }
      if (!options.xmlMode || options.lowerCaseAttributeNames) {
        selector2.name = selector2.name.toLowerCase();
      }
      return attributes_js_1.attributeRules[selector2.action](next, selector2, options);
    }
    case css_what_1$1.SelectorType.Pseudo: {
      return (0, index_js_1.compilePseudoSelector)(next, selector2, options, context, compileToken2);
    }
    case css_what_1$1.SelectorType.Tag: {
      if (selector2.namespace != null) {
        throw new Error("Namespaced tag names are not yet supported by css-select");
      }
      var name_1 = selector2.name;
      if (!options.xmlMode || options.lowerCaseTags) {
        name_1 = name_1.toLowerCase();
      }
      return function tag(elem) {
        return adapter.getName(elem) === name_1 && next(elem);
      };
    }
    case css_what_1$1.SelectorType.Descendant: {
      if (options.cacheResults === false || typeof WeakSet === "undefined") {
        return function descendant(elem) {
          var current = elem;
          while (current = getElementParent(current, adapter)) {
            if (next(current)) {
              return true;
            }
          }
          return false;
        };
      }
      var isFalseCache_1 = /* @__PURE__ */ new WeakSet();
      return function cachedDescendant(elem) {
        var current = elem;
        while (current = getElementParent(current, adapter)) {
          if (!isFalseCache_1.has(current)) {
            if (adapter.isTag(current) && next(current)) {
              return true;
            }
            isFalseCache_1.add(current);
          }
        }
        return false;
      };
    }
    case "_flexibleDescendant": {
      return function flexibleDescendant(elem) {
        var current = elem;
        do {
          if (next(current))
            return true;
        } while (current = getElementParent(current, adapter));
        return false;
      };
    }
    case css_what_1$1.SelectorType.Parent: {
      return function parent(elem) {
        return adapter.getChildren(elem).some(function(elem2) {
          return adapter.isTag(elem2) && next(elem2);
        });
      };
    }
    case css_what_1$1.SelectorType.Child: {
      return function child(elem) {
        var parent = adapter.getParent(elem);
        return parent != null && adapter.isTag(parent) && next(parent);
      };
    }
    case css_what_1$1.SelectorType.Sibling: {
      return function sibling(elem) {
        var siblings = adapter.getSiblings(elem);
        for (var i = 0; i < siblings.length; i++) {
          var currentSibling = siblings[i];
          if (equals(elem, currentSibling))
            break;
          if (adapter.isTag(currentSibling) && next(currentSibling)) {
            return true;
          }
        }
        return false;
      };
    }
    case css_what_1$1.SelectorType.Adjacent: {
      if (adapter.prevElementSibling) {
        return function adjacent(elem) {
          var previous = adapter.prevElementSibling(elem);
          return previous != null && next(previous);
        };
      }
      return function adjacent(elem) {
        var siblings = adapter.getSiblings(elem);
        var lastElement;
        for (var i = 0; i < siblings.length; i++) {
          var currentSibling = siblings[i];
          if (equals(elem, currentSibling))
            break;
          if (adapter.isTag(currentSibling)) {
            lastElement = currentSibling;
          }
        }
        return !!lastElement && next(lastElement);
      };
    }
    case css_what_1$1.SelectorType.Universal: {
      if (selector2.namespace != null && selector2.namespace !== "*") {
        throw new Error("Namespaced universal selectors are not yet supported by css-select");
      }
      return next;
    }
  }
}
general.compileGeneralSelector = compileGeneralSelector;
var __createBinding = commonjsGlobal && commonjsGlobal.__createBinding || (Object.create ? function(o, m, k, k2) {
  if (k2 === void 0)
    k2 = k;
  var desc = Object.getOwnPropertyDescriptor(m, k);
  if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
    desc = { enumerable: true, get: function() {
      return m[k];
    } };
  }
  Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
  if (k2 === void 0)
    k2 = k;
  o[k2] = m[k];
});
var __setModuleDefault = commonjsGlobal && commonjsGlobal.__setModuleDefault || (Object.create ? function(o, v) {
  Object.defineProperty(o, "default", { enumerable: true, value: v });
} : function(o, v) {
  o["default"] = v;
});
var __importStar = commonjsGlobal && commonjsGlobal.__importStar || function(mod) {
  if (mod && mod.__esModule)
    return mod;
  var result = {};
  if (mod != null) {
    for (var k in mod)
      if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
        __createBinding(result, mod, k);
  }
  __setModuleDefault(result, mod);
  return result;
};
var __importDefault = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(compile$3, "__esModule", { value: true });
compile$3.compileToken = compile$3.compileUnsafe = compile$3.compile = void 0;
var css_what_1 = require$$0;
var boolbase_1 = __importDefault(boolbase);
var sort_js_1 = __importStar(sort);
var general_js_1 = general;
var subselects_js_1 = subselects;
function compile(selector2, options, context) {
  var next = compileUnsafe(selector2, options, context);
  return (0, subselects_js_1.ensureIsTag)(next, options.adapter);
}
compile$3.compile = compile;
function compileUnsafe(selector2, options, context) {
  var token = typeof selector2 === "string" ? (0, css_what_1.parse)(selector2) : selector2;
  return compileToken(token, options, context);
}
compile$3.compileUnsafe = compileUnsafe;
function includesScopePseudo(t) {
  return t.type === css_what_1.SelectorType.Pseudo && (t.name === "scope" || Array.isArray(t.data) && t.data.some(function(data2) {
    return data2.some(includesScopePseudo);
  }));
}
var DESCENDANT_TOKEN = { type: css_what_1.SelectorType.Descendant };
var FLEXIBLE_DESCENDANT_TOKEN = {
  type: "_flexibleDescendant"
};
var SCOPE_TOKEN = {
  type: css_what_1.SelectorType.Pseudo,
  name: "scope",
  data: null
};
function absolutize(token, _a, context) {
  var adapter = _a.adapter;
  var hasContext = !!(context === null || context === void 0 ? void 0 : context.every(function(e) {
    var parent = adapter.isTag(e) && adapter.getParent(e);
    return e === subselects_js_1.PLACEHOLDER_ELEMENT || parent && adapter.isTag(parent);
  }));
  for (var _i = 0, token_1 = token; _i < token_1.length; _i++) {
    var t = token_1[_i];
    if (t.length > 0 && (0, sort_js_1.isTraversal)(t[0]) && t[0].type !== css_what_1.SelectorType.Descendant)
      ;
    else if (hasContext && !t.some(includesScopePseudo)) {
      t.unshift(DESCENDANT_TOKEN);
    } else {
      continue;
    }
    t.unshift(SCOPE_TOKEN);
  }
}
function compileToken(token, options, context) {
  var _a;
  token.forEach(sort_js_1.default);
  context = (_a = options.context) !== null && _a !== void 0 ? _a : context;
  var isArrayContext = Array.isArray(context);
  var finalContext = context && (Array.isArray(context) ? context : [context]);
  if (options.relativeSelector !== false) {
    absolutize(token, options, finalContext);
  } else if (token.some(function(t) {
    return t.length > 0 && (0, sort_js_1.isTraversal)(t[0]);
  })) {
    throw new Error("Relative selectors are not allowed when the `relativeSelector` option is disabled");
  }
  var shouldTestNextSiblings = false;
  var query = token.map(function(rules) {
    if (rules.length >= 2) {
      var first = rules[0], second = rules[1];
      if (first.type !== css_what_1.SelectorType.Pseudo || first.name !== "scope")
        ;
      else if (isArrayContext && second.type === css_what_1.SelectorType.Descendant) {
        rules[1] = FLEXIBLE_DESCENDANT_TOKEN;
      } else if (second.type === css_what_1.SelectorType.Adjacent || second.type === css_what_1.SelectorType.Sibling) {
        shouldTestNextSiblings = true;
      }
    }
    return compileRules(rules, options, finalContext);
  }).reduce(reduceRules, boolbase_1.default.falseFunc);
  query.shouldTestNextSiblings = shouldTestNextSiblings;
  return query;
}
compile$3.compileToken = compileToken;
function compileRules(rules, options, context) {
  var _a;
  return rules.reduce(function(previous, rule) {
    return previous === boolbase_1.default.falseFunc ? boolbase_1.default.falseFunc : (0, general_js_1.compileGeneralSelector)(previous, rule, options, context, compileToken);
  }, (_a = options.rootFunc) !== null && _a !== void 0 ? _a : boolbase_1.default.trueFunc);
}
function reduceRules(a, b) {
  if (b === boolbase_1.default.falseFunc || a === boolbase_1.default.trueFunc) {
    return a;
  }
  if (a === boolbase_1.default.falseFunc || b === boolbase_1.default.trueFunc) {
    return b;
  }
  return function combine(elem) {
    return a(elem) || b(elem);
  };
}
(function(exports) {
  var __createBinding2 = commonjsGlobal && commonjsGlobal.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() {
        return m[k];
      } };
    }
    Object.defineProperty(o, k2, desc);
  } : function(o, m, k, k2) {
    if (k2 === void 0)
      k2 = k;
    o[k2] = m[k];
  });
  var __setModuleDefault2 = commonjsGlobal && commonjsGlobal.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
  } : function(o, v) {
    o["default"] = v;
  });
  var __importStar2 = commonjsGlobal && commonjsGlobal.__importStar || function(mod) {
    if (mod && mod.__esModule)
      return mod;
    var result = {};
    if (mod != null) {
      for (var k in mod)
        if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
          __createBinding2(result, mod, k);
    }
    __setModuleDefault2(result, mod);
    return result;
  };
  var __importDefault2 = commonjsGlobal && commonjsGlobal.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.aliases = exports.pseudos = exports.filters = exports.is = exports.selectOne = exports.selectAll = exports.prepareContext = exports._compileToken = exports._compileUnsafe = exports.compile = void 0;
  var DomUtils = __importStar2(lib$5);
  var boolbase_12 = __importDefault2(boolbase);
  var compile_js_1 = compile$3;
  var subselects_js_12 = subselects;
  var defaultEquals = function(a, b) {
    return a === b;
  };
  var defaultOptions = {
    adapter: DomUtils,
    equals: defaultEquals
  };
  function convertOptionFormats(options) {
    var _a, _b, _c, _d;
    var opts = options !== null && options !== void 0 ? options : defaultOptions;
    (_a = opts.adapter) !== null && _a !== void 0 ? _a : opts.adapter = DomUtils;
    (_b = opts.equals) !== null && _b !== void 0 ? _b : opts.equals = (_d = (_c = opts.adapter) === null || _c === void 0 ? void 0 : _c.equals) !== null && _d !== void 0 ? _d : defaultEquals;
    return opts;
  }
  function wrapCompile(func) {
    return function addAdapter(selector2, options, context) {
      var opts = convertOptionFormats(options);
      return func(selector2, opts, context);
    };
  }
  exports.compile = wrapCompile(compile_js_1.compile);
  exports._compileUnsafe = wrapCompile(compile_js_1.compileUnsafe);
  exports._compileToken = wrapCompile(compile_js_1.compileToken);
  function getSelectorFunc(searchFunc) {
    return function select(query, elements, options) {
      var opts = convertOptionFormats(options);
      if (typeof query !== "function") {
        query = (0, compile_js_1.compileUnsafe)(query, opts, elements);
      }
      var filteredElements = prepareContext(elements, opts.adapter, query.shouldTestNextSiblings);
      return searchFunc(query, filteredElements, opts);
    };
  }
  function prepareContext(elems2, adapter, shouldTestNextSiblings) {
    if (shouldTestNextSiblings === void 0) {
      shouldTestNextSiblings = false;
    }
    if (shouldTestNextSiblings) {
      elems2 = appendNextSiblings(elems2, adapter);
    }
    return Array.isArray(elems2) ? adapter.removeSubsets(elems2) : adapter.getChildren(elems2);
  }
  exports.prepareContext = prepareContext;
  function appendNextSiblings(elem, adapter) {
    var elems2 = Array.isArray(elem) ? elem.slice(0) : [elem];
    var elemsLength = elems2.length;
    for (var i = 0; i < elemsLength; i++) {
      var nextSiblings = (0, subselects_js_12.getNextSiblings)(elems2[i], adapter);
      elems2.push.apply(elems2, nextSiblings);
    }
    return elems2;
  }
  exports.selectAll = getSelectorFunc(function(query, elems2, options) {
    return query === boolbase_12.default.falseFunc || !elems2 || elems2.length === 0 ? [] : options.adapter.findAll(query, elems2);
  });
  exports.selectOne = getSelectorFunc(function(query, elems2, options) {
    return query === boolbase_12.default.falseFunc || !elems2 || elems2.length === 0 ? null : options.adapter.findOne(query, elems2);
  });
  function is2(elem, query, options) {
    var opts = convertOptionFormats(options);
    return (typeof query === "function" ? query : (0, compile_js_1.compile)(query, opts))(elem);
  }
  exports.is = is2;
  exports.default = exports.selectAll;
  var index_js_12 = pseudoSelectors;
  Object.defineProperty(exports, "filters", { enumerable: true, get: function() {
    return index_js_12.filters;
  } });
  Object.defineProperty(exports, "pseudos", { enumerable: true, get: function() {
    return index_js_12.pseudos;
  } });
  Object.defineProperty(exports, "aliases", { enumerable: true, get: function() {
    return index_js_12.aliases;
  } });
})(lib$6);
const isTag = (node2) => {
  return node2.type === "element";
};
const existsOne = (test, elems2) => {
  return elems2.some((elem) => {
    if (isTag(elem)) {
      return test(elem) || existsOne(test, getChildren(elem));
    } else {
      return false;
    }
  });
};
const getAttributeValue = (elem, name2) => {
  return elem.attributes[name2];
};
const getChildren = (node2) => {
  return node2.children || [];
};
const getName = (elemAst) => {
  return elemAst.name;
};
const getParent = (node2) => {
  return node2.parentNode || null;
};
const getSiblings = (elem) => {
  var parent = getParent(elem);
  return parent ? getChildren(parent) : [];
};
const getText = (node2) => {
  if (node2.children[0].type === "text" && node2.children[0].type === "cdata") {
    return node2.children[0].value;
  }
  return "";
};
const hasAttrib = (elem, name2) => {
  return elem.attributes[name2] !== void 0;
};
const removeSubsets = (nodes) => {
  let idx = nodes.length;
  let node2;
  let ancestor;
  let replace2;
  while (--idx > -1) {
    node2 = ancestor = nodes[idx];
    nodes[idx] = null;
    replace2 = true;
    while (ancestor) {
      if (nodes.includes(ancestor)) {
        replace2 = false;
        nodes.splice(idx, 1);
        break;
      }
      ancestor = getParent(ancestor);
    }
    if (replace2) {
      nodes[idx] = node2;
    }
  }
  return nodes;
};
const findAll$2 = (test, elems2) => {
  const result = [];
  for (const elem of elems2) {
    if (isTag(elem)) {
      if (test(elem)) {
        result.push(elem);
      }
      result.push(...findAll$2(test, getChildren(elem)));
    }
  }
  return result;
};
const findOne = (test, elems2) => {
  for (const elem of elems2) {
    if (isTag(elem)) {
      if (test(elem)) {
        return elem;
      }
      const result = findOne(test, getChildren(elem));
      if (result) {
        return result;
      }
    }
  }
  return null;
};
const svgoCssSelectAdapter = {
  isTag,
  existsOne,
  getAttributeValue,
  getChildren,
  getName,
  getParent,
  getSiblings,
  getText,
  hasAttrib,
  removeSubsets,
  findAll: findAll$2,
  findOne
};
var cssSelectAdapter = svgoCssSelectAdapter;
const { selectAll, selectOne, is } = lib$6;
const xastAdaptor = cssSelectAdapter;
const cssSelectOptions = {
  xmlMode: true,
  adapter: xastAdaptor
};
const querySelectorAll$2 = (node2, selector2) => {
  return selectAll(selector2, node2, cssSelectOptions);
};
xast.querySelectorAll = querySelectorAll$2;
const querySelector$1 = (node2, selector2) => {
  return selectOne(selector2, node2, cssSelectOptions);
};
xast.querySelector = querySelector$1;
const matches$1 = (node2, selector2) => {
  return is(node2, selector2, cssSelectOptions);
};
xast.matches = matches$1;
const visitSkip$7 = Symbol();
xast.visitSkip = visitSkip$7;
const visit$7 = (node2, visitor, parentNode) => {
  const callbacks = visitor[node2.type];
  if (callbacks && callbacks.enter) {
    const symbol = callbacks.enter(node2, parentNode);
    if (symbol === visitSkip$7) {
      return;
    }
  }
  if (node2.type === "root") {
    for (const child of node2.children) {
      visit$7(child, visitor, node2);
    }
  }
  if (node2.type === "element") {
    if (parentNode.children.includes(node2)) {
      for (const child of node2.children) {
        visit$7(child, visitor, node2);
      }
    }
  }
  if (callbacks && callbacks.exit) {
    callbacks.exit(node2, parentNode);
  }
};
xast.visit = visit$7;
const detachNodeFromParent$m = (node2, parentNode) => {
  parentNode.children = parentNode.children.filter((child) => child !== node2);
};
xast.detachNodeFromParent = detachNodeFromParent$m;
const { visit: visit$6 } = xast;
const invokePlugins$1 = (ast, info, plugins2, overrides, globalOverrides) => {
  for (const plugin of plugins2) {
    const override = overrides == null ? null : overrides[plugin.name];
    if (override === false) {
      continue;
    }
    const params = { ...plugin.params, ...globalOverrides, ...override };
    if (plugin.active) {
      const visitor = plugin.fn(ast, params, info);
      if (visitor != null) {
        visit$6(ast, visitor);
      }
    }
  }
  return ast;
};
plugins.invokePlugins = invokePlugins$1;
const createPreset$1 = ({ name: name2, plugins: plugins2 }) => {
  return {
    name: name2,
    type: "full",
    fn: (ast, params, info) => {
      const { floatPrecision, overrides } = params;
      const globalOverrides = {};
      if (floatPrecision != null) {
        globalOverrides.floatPrecision = floatPrecision;
      }
      if (overrides) {
        const pluginNames = plugins2.map(({ name: name3 }) => name3);
        for (const pluginName of Object.keys(overrides)) {
          if (!pluginNames.includes(pluginName)) {
            console.warn(
              `You are trying to configure ${pluginName} which is not part of ${name2}.
Try to put it before or after, for example

plugins: [
  {
    name: '${name2}',
  },
  '${pluginName}'
]
`
            );
          }
        }
      }
      return invokePlugins$1(ast, info, plugins2, overrides, globalOverrides);
    }
  };
};
plugins.createPreset = createPreset$1;
var removeDoctype$1 = {};
const { detachNodeFromParent: detachNodeFromParent$l } = xast;
removeDoctype$1.name = "removeDoctype";
removeDoctype$1.type = "visitor";
removeDoctype$1.active = true;
removeDoctype$1.description = "removes doctype declaration";
removeDoctype$1.fn = () => {
  return {
    doctype: {
      enter: (node2, parentNode) => {
        detachNodeFromParent$l(node2, parentNode);
      }
    }
  };
};
var removeXMLProcInst$1 = {};
const { detachNodeFromParent: detachNodeFromParent$k } = xast;
removeXMLProcInst$1.name = "removeXMLProcInst";
removeXMLProcInst$1.type = "visitor";
removeXMLProcInst$1.active = true;
removeXMLProcInst$1.description = "removes XML processing instructions";
removeXMLProcInst$1.fn = () => {
  return {
    instruction: {
      enter: (node2, parentNode) => {
        if (node2.name === "xml") {
          detachNodeFromParent$k(node2, parentNode);
        }
      }
    }
  };
};
var removeComments$1 = {};
const { detachNodeFromParent: detachNodeFromParent$j } = xast;
removeComments$1.name = "removeComments";
removeComments$1.type = "visitor";
removeComments$1.active = true;
removeComments$1.description = "removes comments";
removeComments$1.fn = () => {
  return {
    comment: {
      enter: (node2, parentNode) => {
        if (node2.value.charAt(0) !== "!") {
          detachNodeFromParent$j(node2, parentNode);
        }
      }
    }
  };
};
var removeMetadata$1 = {};
const { detachNodeFromParent: detachNodeFromParent$i } = xast;
removeMetadata$1.name = "removeMetadata";
removeMetadata$1.type = "visitor";
removeMetadata$1.active = true;
removeMetadata$1.description = "removes <metadata>";
removeMetadata$1.fn = () => {
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "metadata") {
          detachNodeFromParent$i(node2, parentNode);
        }
      }
    }
  };
};
var removeEditorsNSData$1 = {};
var _collections = {};
(function(exports) {
  exports.elemsGroups = {
    animation: [
      "animate",
      "animateColor",
      "animateMotion",
      "animateTransform",
      "set"
    ],
    descriptive: ["desc", "metadata", "title"],
    shape: ["circle", "ellipse", "line", "path", "polygon", "polyline", "rect"],
    structural: ["defs", "g", "svg", "symbol", "use"],
    paintServer: [
      "solidColor",
      "linearGradient",
      "radialGradient",
      "meshGradient",
      "pattern",
      "hatch"
    ],
    nonRendering: [
      "linearGradient",
      "radialGradient",
      "pattern",
      "clipPath",
      "mask",
      "marker",
      "symbol",
      "filter",
      "solidColor"
    ],
    container: [
      "a",
      "defs",
      "g",
      "marker",
      "mask",
      "missing-glyph",
      "pattern",
      "svg",
      "switch",
      "symbol",
      "foreignObject"
    ],
    textContent: [
      "altGlyph",
      "altGlyphDef",
      "altGlyphItem",
      "glyph",
      "glyphRef",
      "textPath",
      "text",
      "tref",
      "tspan"
    ],
    textContentChild: ["altGlyph", "textPath", "tref", "tspan"],
    lightSource: [
      "feDiffuseLighting",
      "feSpecularLighting",
      "feDistantLight",
      "fePointLight",
      "feSpotLight"
    ],
    filterPrimitive: [
      "feBlend",
      "feColorMatrix",
      "feComponentTransfer",
      "feComposite",
      "feConvolveMatrix",
      "feDiffuseLighting",
      "feDisplacementMap",
      "feDropShadow",
      "feFlood",
      "feFuncA",
      "feFuncB",
      "feFuncG",
      "feFuncR",
      "feGaussianBlur",
      "feImage",
      "feMerge",
      "feMergeNode",
      "feMorphology",
      "feOffset",
      "feSpecularLighting",
      "feTile",
      "feTurbulence"
    ]
  };
  exports.textElems = exports.elemsGroups.textContent.concat("title");
  exports.pathElems = ["path", "glyph", "missing-glyph"];
  exports.attrsGroups = {
    animationAddition: ["additive", "accumulate"],
    animationAttributeTarget: ["attributeType", "attributeName"],
    animationEvent: ["onbegin", "onend", "onrepeat", "onload"],
    animationTiming: [
      "begin",
      "dur",
      "end",
      "min",
      "max",
      "restart",
      "repeatCount",
      "repeatDur",
      "fill"
    ],
    animationValue: [
      "calcMode",
      "values",
      "keyTimes",
      "keySplines",
      "from",
      "to",
      "by"
    ],
    conditionalProcessing: [
      "requiredFeatures",
      "requiredExtensions",
      "systemLanguage"
    ],
    core: ["id", "tabindex", "xml:base", "xml:lang", "xml:space"],
    graphicalEvent: [
      "onfocusin",
      "onfocusout",
      "onactivate",
      "onclick",
      "onmousedown",
      "onmouseup",
      "onmouseover",
      "onmousemove",
      "onmouseout",
      "onload"
    ],
    presentation: [
      "alignment-baseline",
      "baseline-shift",
      "clip",
      "clip-path",
      "clip-rule",
      "color",
      "color-interpolation",
      "color-interpolation-filters",
      "color-profile",
      "color-rendering",
      "cursor",
      "direction",
      "display",
      "dominant-baseline",
      "enable-background",
      "fill",
      "fill-opacity",
      "fill-rule",
      "filter",
      "flood-color",
      "flood-opacity",
      "font-family",
      "font-size",
      "font-size-adjust",
      "font-stretch",
      "font-style",
      "font-variant",
      "font-weight",
      "glyph-orientation-horizontal",
      "glyph-orientation-vertical",
      "image-rendering",
      "letter-spacing",
      "lighting-color",
      "marker-end",
      "marker-mid",
      "marker-start",
      "mask",
      "opacity",
      "overflow",
      "paint-order",
      "pointer-events",
      "shape-rendering",
      "stop-color",
      "stop-opacity",
      "stroke",
      "stroke-dasharray",
      "stroke-dashoffset",
      "stroke-linecap",
      "stroke-linejoin",
      "stroke-miterlimit",
      "stroke-opacity",
      "stroke-width",
      "text-anchor",
      "text-decoration",
      "text-overflow",
      "text-rendering",
      "transform",
      "transform-origin",
      "unicode-bidi",
      "vector-effect",
      "visibility",
      "word-spacing",
      "writing-mode"
    ],
    xlink: [
      "xlink:href",
      "xlink:show",
      "xlink:actuate",
      "xlink:type",
      "xlink:role",
      "xlink:arcrole",
      "xlink:title"
    ],
    documentEvent: [
      "onunload",
      "onabort",
      "onerror",
      "onresize",
      "onscroll",
      "onzoom"
    ],
    filterPrimitive: ["x", "y", "width", "height", "result"],
    transferFunction: [
      "type",
      "tableValues",
      "slope",
      "intercept",
      "amplitude",
      "exponent",
      "offset"
    ]
  };
  exports.attrsGroupsDefaults = {
    core: { "xml:space": "default" },
    presentation: {
      clip: "auto",
      "clip-path": "none",
      "clip-rule": "nonzero",
      mask: "none",
      opacity: "1",
      "stop-color": "#000",
      "stop-opacity": "1",
      "fill-opacity": "1",
      "fill-rule": "nonzero",
      fill: "#000",
      stroke: "none",
      "stroke-width": "1",
      "stroke-linecap": "butt",
      "stroke-linejoin": "miter",
      "stroke-miterlimit": "4",
      "stroke-dasharray": "none",
      "stroke-dashoffset": "0",
      "stroke-opacity": "1",
      "paint-order": "normal",
      "vector-effect": "none",
      display: "inline",
      visibility: "visible",
      "marker-start": "none",
      "marker-mid": "none",
      "marker-end": "none",
      "color-interpolation": "sRGB",
      "color-interpolation-filters": "linearRGB",
      "color-rendering": "auto",
      "shape-rendering": "auto",
      "text-rendering": "auto",
      "image-rendering": "auto",
      "font-style": "normal",
      "font-variant": "normal",
      "font-weight": "normal",
      "font-stretch": "normal",
      "font-size": "medium",
      "font-size-adjust": "none",
      kerning: "auto",
      "letter-spacing": "normal",
      "word-spacing": "normal",
      "text-decoration": "none",
      "text-anchor": "start",
      "text-overflow": "clip",
      "writing-mode": "lr-tb",
      "glyph-orientation-vertical": "auto",
      "glyph-orientation-horizontal": "0deg",
      direction: "ltr",
      "unicode-bidi": "normal",
      "dominant-baseline": "auto",
      "alignment-baseline": "baseline",
      "baseline-shift": "baseline"
    },
    transferFunction: {
      slope: "1",
      intercept: "0",
      amplitude: "1",
      exponent: "1",
      offset: "0"
    }
  };
  exports.elems = {
    a: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation",
        "xlink"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "target"
      ],
      defaults: {
        target: "_self"
      },
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view",
        "tspan"
      ]
    },
    altGlyph: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation",
        "xlink"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "x",
        "y",
        "dx",
        "dy",
        "glyphRef",
        "format",
        "rotate"
      ]
    },
    altGlyphDef: {
      attrsGroups: ["core"],
      content: ["glyphRef"]
    },
    altGlyphItem: {
      attrsGroups: ["core"],
      content: ["glyphRef", "altGlyphItem"]
    },
    animate: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "animationAddition",
        "animationAttributeTarget",
        "animationEvent",
        "animationTiming",
        "animationValue",
        "presentation",
        "xlink"
      ],
      attrs: ["externalResourcesRequired"],
      contentGroups: ["descriptive"]
    },
    animateColor: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "animationEvent",
        "xlink",
        "animationAttributeTarget",
        "animationTiming",
        "animationValue",
        "animationAddition",
        "presentation"
      ],
      attrs: ["externalResourcesRequired"],
      contentGroups: ["descriptive"]
    },
    animateMotion: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "animationEvent",
        "xlink",
        "animationTiming",
        "animationValue",
        "animationAddition"
      ],
      attrs: [
        "externalResourcesRequired",
        "path",
        "keyPoints",
        "rotate",
        "origin"
      ],
      defaults: {
        rotate: "0"
      },
      contentGroups: ["descriptive"],
      content: ["mpath"]
    },
    animateTransform: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "animationEvent",
        "xlink",
        "animationAttributeTarget",
        "animationTiming",
        "animationValue",
        "animationAddition"
      ],
      attrs: ["externalResourcesRequired", "type"],
      contentGroups: ["descriptive"]
    },
    circle: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "cx",
        "cy",
        "r"
      ],
      defaults: {
        cx: "0",
        cy: "0"
      },
      contentGroups: ["animation", "descriptive"]
    },
    clipPath: {
      attrsGroups: ["conditionalProcessing", "core", "presentation"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "clipPathUnits"
      ],
      defaults: {
        clipPathUnits: "userSpaceOnUse"
      },
      contentGroups: ["animation", "descriptive", "shape"],
      content: ["text", "use"]
    },
    "color-profile": {
      attrsGroups: ["core", "xlink"],
      attrs: ["local", "name", "rendering-intent"],
      defaults: {
        name: "sRGB",
        "rendering-intent": "auto"
      },
      contentGroups: ["descriptive"]
    },
    cursor: {
      attrsGroups: ["core", "conditionalProcessing", "xlink"],
      attrs: ["externalResourcesRequired", "x", "y"],
      defaults: {
        x: "0",
        y: "0"
      },
      contentGroups: ["descriptive"]
    },
    defs: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: ["class", "style", "externalResourcesRequired", "transform"],
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    desc: {
      attrsGroups: ["core"],
      attrs: ["class", "style"]
    },
    ellipse: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "cx",
        "cy",
        "rx",
        "ry"
      ],
      defaults: {
        cx: "0",
        cy: "0"
      },
      contentGroups: ["animation", "descriptive"]
    },
    feBlend: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: [
        "class",
        "style",
        "in",
        "in2",
        "mode"
      ],
      defaults: {
        mode: "normal"
      },
      content: ["animate", "set"]
    },
    feColorMatrix: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style", "in", "type", "values"],
      defaults: {
        type: "matrix"
      },
      content: ["animate", "set"]
    },
    feComponentTransfer: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style", "in"],
      content: ["feFuncA", "feFuncB", "feFuncG", "feFuncR"]
    },
    feComposite: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style", "in", "in2", "operator", "k1", "k2", "k3", "k4"],
      defaults: {
        operator: "over",
        k1: "0",
        k2: "0",
        k3: "0",
        k4: "0"
      },
      content: ["animate", "set"]
    },
    feConvolveMatrix: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: [
        "class",
        "style",
        "in",
        "order",
        "kernelMatrix",
        "divisor",
        "bias",
        "targetX",
        "targetY",
        "edgeMode",
        "kernelUnitLength",
        "preserveAlpha"
      ],
      defaults: {
        order: "3",
        bias: "0",
        edgeMode: "duplicate",
        preserveAlpha: "false"
      },
      content: ["animate", "set"]
    },
    feDiffuseLighting: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: [
        "class",
        "style",
        "in",
        "surfaceScale",
        "diffuseConstant",
        "kernelUnitLength"
      ],
      defaults: {
        surfaceScale: "1",
        diffuseConstant: "1"
      },
      contentGroups: ["descriptive"],
      content: [
        "feDistantLight",
        "fePointLight",
        "feSpotLight"
      ]
    },
    feDisplacementMap: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: [
        "class",
        "style",
        "in",
        "in2",
        "scale",
        "xChannelSelector",
        "yChannelSelector"
      ],
      defaults: {
        scale: "0",
        xChannelSelector: "A",
        yChannelSelector: "A"
      },
      content: ["animate", "set"]
    },
    feDistantLight: {
      attrsGroups: ["core"],
      attrs: ["azimuth", "elevation"],
      defaults: {
        azimuth: "0",
        elevation: "0"
      },
      content: ["animate", "set"]
    },
    feFlood: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style"],
      content: ["animate", "animateColor", "set"]
    },
    feFuncA: {
      attrsGroups: ["core", "transferFunction"],
      content: ["set", "animate"]
    },
    feFuncB: {
      attrsGroups: ["core", "transferFunction"],
      content: ["set", "animate"]
    },
    feFuncG: {
      attrsGroups: ["core", "transferFunction"],
      content: ["set", "animate"]
    },
    feFuncR: {
      attrsGroups: ["core", "transferFunction"],
      content: ["set", "animate"]
    },
    feGaussianBlur: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style", "in", "stdDeviation"],
      defaults: {
        stdDeviation: "0"
      },
      content: ["set", "animate"]
    },
    feImage: {
      attrsGroups: ["core", "presentation", "filterPrimitive", "xlink"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "preserveAspectRatio",
        "href",
        "xlink:href"
      ],
      defaults: {
        preserveAspectRatio: "xMidYMid meet"
      },
      content: ["animate", "animateTransform", "set"]
    },
    feMerge: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style"],
      content: ["feMergeNode"]
    },
    feMergeNode: {
      attrsGroups: ["core"],
      attrs: ["in"],
      content: ["animate", "set"]
    },
    feMorphology: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style", "in", "operator", "radius"],
      defaults: {
        operator: "erode",
        radius: "0"
      },
      content: ["animate", "set"]
    },
    feOffset: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style", "in", "dx", "dy"],
      defaults: {
        dx: "0",
        dy: "0"
      },
      content: ["animate", "set"]
    },
    fePointLight: {
      attrsGroups: ["core"],
      attrs: ["x", "y", "z"],
      defaults: {
        x: "0",
        y: "0",
        z: "0"
      },
      content: ["animate", "set"]
    },
    feSpecularLighting: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: [
        "class",
        "style",
        "in",
        "surfaceScale",
        "specularConstant",
        "specularExponent",
        "kernelUnitLength"
      ],
      defaults: {
        surfaceScale: "1",
        specularConstant: "1",
        specularExponent: "1"
      },
      contentGroups: [
        "descriptive",
        "lightSource"
      ]
    },
    feSpotLight: {
      attrsGroups: ["core"],
      attrs: [
        "x",
        "y",
        "z",
        "pointsAtX",
        "pointsAtY",
        "pointsAtZ",
        "specularExponent",
        "limitingConeAngle"
      ],
      defaults: {
        x: "0",
        y: "0",
        z: "0",
        pointsAtX: "0",
        pointsAtY: "0",
        pointsAtZ: "0",
        specularExponent: "1"
      },
      content: ["animate", "set"]
    },
    feTile: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: ["class", "style", "in"],
      content: ["animate", "set"]
    },
    feTurbulence: {
      attrsGroups: ["core", "presentation", "filterPrimitive"],
      attrs: [
        "class",
        "style",
        "baseFrequency",
        "numOctaves",
        "seed",
        "stitchTiles",
        "type"
      ],
      defaults: {
        baseFrequency: "0",
        numOctaves: "1",
        seed: "0",
        stitchTiles: "noStitch",
        type: "turbulence"
      },
      content: ["animate", "set"]
    },
    filter: {
      attrsGroups: ["core", "presentation", "xlink"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "x",
        "y",
        "width",
        "height",
        "filterRes",
        "filterUnits",
        "primitiveUnits",
        "href",
        "xlink:href"
      ],
      defaults: {
        primitiveUnits: "userSpaceOnUse",
        x: "-10%",
        y: "-10%",
        width: "120%",
        height: "120%"
      },
      contentGroups: ["descriptive", "filterPrimitive"],
      content: ["animate", "set"]
    },
    font: {
      attrsGroups: ["core", "presentation"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "horiz-origin-x",
        "horiz-origin-y",
        "horiz-adv-x",
        "vert-origin-x",
        "vert-origin-y",
        "vert-adv-y"
      ],
      defaults: {
        "horiz-origin-x": "0",
        "horiz-origin-y": "0"
      },
      contentGroups: ["descriptive"],
      content: ["font-face", "glyph", "hkern", "missing-glyph", "vkern"]
    },
    "font-face": {
      attrsGroups: ["core"],
      attrs: [
        "font-family",
        "font-style",
        "font-variant",
        "font-weight",
        "font-stretch",
        "font-size",
        "unicode-range",
        "units-per-em",
        "panose-1",
        "stemv",
        "stemh",
        "slope",
        "cap-height",
        "x-height",
        "accent-height",
        "ascent",
        "descent",
        "widths",
        "bbox",
        "ideographic",
        "alphabetic",
        "mathematical",
        "hanging",
        "v-ideographic",
        "v-alphabetic",
        "v-mathematical",
        "v-hanging",
        "underline-position",
        "underline-thickness",
        "strikethrough-position",
        "strikethrough-thickness",
        "overline-position",
        "overline-thickness"
      ],
      defaults: {
        "font-style": "all",
        "font-variant": "normal",
        "font-weight": "all",
        "font-stretch": "normal",
        "unicode-range": "U+0-10FFFF",
        "units-per-em": "1000",
        "panose-1": "0 0 0 0 0 0 0 0 0 0",
        slope: "0"
      },
      contentGroups: ["descriptive"],
      content: [
        "font-face-src"
      ]
    },
    "font-face-format": {
      attrsGroups: ["core"],
      attrs: ["string"]
    },
    "font-face-name": {
      attrsGroups: ["core"],
      attrs: ["name"]
    },
    "font-face-src": {
      attrsGroups: ["core"],
      content: ["font-face-name", "font-face-uri"]
    },
    "font-face-uri": {
      attrsGroups: ["core", "xlink"],
      attrs: ["href", "xlink:href"],
      content: ["font-face-format"]
    },
    foreignObject: {
      attrsGroups: [
        "core",
        "conditionalProcessing",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "x",
        "y",
        "width",
        "height"
      ],
      defaults: {
        x: "0",
        y: "0"
      }
    },
    g: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: ["class", "style", "externalResourcesRequired", "transform"],
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    glyph: {
      attrsGroups: ["core", "presentation"],
      attrs: [
        "class",
        "style",
        "d",
        "horiz-adv-x",
        "vert-origin-x",
        "vert-origin-y",
        "vert-adv-y",
        "unicode",
        "glyph-name",
        "orientation",
        "arabic-form",
        "lang"
      ],
      defaults: {
        "arabic-form": "initial"
      },
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    glyphRef: {
      attrsGroups: ["core", "presentation"],
      attrs: [
        "class",
        "style",
        "d",
        "horiz-adv-x",
        "vert-origin-x",
        "vert-origin-y",
        "vert-adv-y"
      ],
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    hatch: {
      attrsGroups: ["core", "presentation", "xlink"],
      attrs: [
        "class",
        "style",
        "x",
        "y",
        "pitch",
        "rotate",
        "hatchUnits",
        "hatchContentUnits",
        "transform"
      ],
      defaults: {
        hatchUnits: "objectBoundingBox",
        hatchContentUnits: "userSpaceOnUse",
        x: "0",
        y: "0",
        pitch: "0",
        rotate: "0"
      },
      contentGroups: ["animation", "descriptive"],
      content: ["hatchPath"]
    },
    hatchPath: {
      attrsGroups: ["core", "presentation", "xlink"],
      attrs: ["class", "style", "d", "offset"],
      defaults: {
        offset: "0"
      },
      contentGroups: ["animation", "descriptive"]
    },
    hkern: {
      attrsGroups: ["core"],
      attrs: ["u1", "g1", "u2", "g2", "k"]
    },
    image: {
      attrsGroups: [
        "core",
        "conditionalProcessing",
        "graphicalEvent",
        "xlink",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "preserveAspectRatio",
        "transform",
        "x",
        "y",
        "width",
        "height",
        "href",
        "xlink:href"
      ],
      defaults: {
        x: "0",
        y: "0",
        preserveAspectRatio: "xMidYMid meet"
      },
      contentGroups: ["animation", "descriptive"]
    },
    line: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "x1",
        "y1",
        "x2",
        "y2"
      ],
      defaults: {
        x1: "0",
        y1: "0",
        x2: "0",
        y2: "0"
      },
      contentGroups: ["animation", "descriptive"]
    },
    linearGradient: {
      attrsGroups: ["core", "presentation", "xlink"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "x1",
        "y1",
        "x2",
        "y2",
        "gradientUnits",
        "gradientTransform",
        "spreadMethod",
        "href",
        "xlink:href"
      ],
      defaults: {
        x1: "0",
        y1: "0",
        x2: "100%",
        y2: "0",
        spreadMethod: "pad"
      },
      contentGroups: ["descriptive"],
      content: ["animate", "animateTransform", "set", "stop"]
    },
    marker: {
      attrsGroups: ["core", "presentation"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "viewBox",
        "preserveAspectRatio",
        "refX",
        "refY",
        "markerUnits",
        "markerWidth",
        "markerHeight",
        "orient"
      ],
      defaults: {
        markerUnits: "strokeWidth",
        refX: "0",
        refY: "0",
        markerWidth: "3",
        markerHeight: "3"
      },
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    mask: {
      attrsGroups: ["conditionalProcessing", "core", "presentation"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "x",
        "y",
        "width",
        "height",
        "mask-type",
        "maskUnits",
        "maskContentUnits"
      ],
      defaults: {
        maskUnits: "objectBoundingBox",
        maskContentUnits: "userSpaceOnUse",
        x: "-10%",
        y: "-10%",
        width: "120%",
        height: "120%"
      },
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    metadata: {
      attrsGroups: ["core"]
    },
    "missing-glyph": {
      attrsGroups: ["core", "presentation"],
      attrs: [
        "class",
        "style",
        "d",
        "horiz-adv-x",
        "vert-origin-x",
        "vert-origin-y",
        "vert-adv-y"
      ],
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    mpath: {
      attrsGroups: ["core", "xlink"],
      attrs: ["externalResourcesRequired", "href", "xlink:href"],
      contentGroups: ["descriptive"]
    },
    path: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "d",
        "pathLength"
      ],
      contentGroups: ["animation", "descriptive"]
    },
    pattern: {
      attrsGroups: ["conditionalProcessing", "core", "presentation", "xlink"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "viewBox",
        "preserveAspectRatio",
        "x",
        "y",
        "width",
        "height",
        "patternUnits",
        "patternContentUnits",
        "patternTransform",
        "href",
        "xlink:href"
      ],
      defaults: {
        patternUnits: "objectBoundingBox",
        patternContentUnits: "userSpaceOnUse",
        x: "0",
        y: "0",
        width: "0",
        height: "0",
        preserveAspectRatio: "xMidYMid meet"
      },
      contentGroups: [
        "animation",
        "descriptive",
        "paintServer",
        "shape",
        "structural"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    polygon: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "points"
      ],
      contentGroups: ["animation", "descriptive"]
    },
    polyline: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "points"
      ],
      contentGroups: ["animation", "descriptive"]
    },
    radialGradient: {
      attrsGroups: ["core", "presentation", "xlink"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "cx",
        "cy",
        "r",
        "fx",
        "fy",
        "fr",
        "gradientUnits",
        "gradientTransform",
        "spreadMethod",
        "href",
        "xlink:href"
      ],
      defaults: {
        gradientUnits: "objectBoundingBox",
        cx: "50%",
        cy: "50%",
        r: "50%"
      },
      contentGroups: ["descriptive"],
      content: ["animate", "animateTransform", "set", "stop"]
    },
    meshGradient: {
      attrsGroups: ["core", "presentation", "xlink"],
      attrs: ["class", "style", "x", "y", "gradientUnits", "transform"],
      contentGroups: ["descriptive", "paintServer", "animation"],
      content: ["meshRow"]
    },
    meshRow: {
      attrsGroups: ["core", "presentation"],
      attrs: ["class", "style"],
      contentGroups: ["descriptive"],
      content: ["meshPatch"]
    },
    meshPatch: {
      attrsGroups: ["core", "presentation"],
      attrs: ["class", "style"],
      contentGroups: ["descriptive"],
      content: ["stop"]
    },
    rect: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "x",
        "y",
        "width",
        "height",
        "rx",
        "ry"
      ],
      defaults: {
        x: "0",
        y: "0"
      },
      contentGroups: ["animation", "descriptive"]
    },
    script: {
      attrsGroups: ["core", "xlink"],
      attrs: ["externalResourcesRequired", "type", "href", "xlink:href"]
    },
    set: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "animation",
        "xlink",
        "animationAttributeTarget",
        "animationTiming"
      ],
      attrs: ["externalResourcesRequired", "to"],
      contentGroups: ["descriptive"]
    },
    solidColor: {
      attrsGroups: ["core", "presentation"],
      attrs: ["class", "style"],
      contentGroups: ["paintServer"]
    },
    stop: {
      attrsGroups: ["core", "presentation"],
      attrs: ["class", "style", "offset", "path"],
      content: ["animate", "animateColor", "set"]
    },
    style: {
      attrsGroups: ["core"],
      attrs: ["type", "media", "title"],
      defaults: {
        type: "text/css"
      }
    },
    svg: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "documentEvent",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "x",
        "y",
        "width",
        "height",
        "viewBox",
        "preserveAspectRatio",
        "zoomAndPan",
        "version",
        "baseProfile",
        "contentScriptType",
        "contentStyleType"
      ],
      defaults: {
        x: "0",
        y: "0",
        width: "100%",
        height: "100%",
        preserveAspectRatio: "xMidYMid meet",
        zoomAndPan: "magnify",
        version: "1.1",
        baseProfile: "none",
        contentScriptType: "application/ecmascript",
        contentStyleType: "text/css"
      },
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    switch: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: ["class", "style", "externalResourcesRequired", "transform"],
      contentGroups: ["animation", "descriptive", "shape"],
      content: [
        "a",
        "foreignObject",
        "g",
        "image",
        "svg",
        "switch",
        "text",
        "use"
      ]
    },
    symbol: {
      attrsGroups: ["core", "graphicalEvent", "presentation"],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "preserveAspectRatio",
        "viewBox",
        "refX",
        "refY"
      ],
      defaults: {
        refX: "0",
        refY: "0"
      },
      contentGroups: [
        "animation",
        "descriptive",
        "shape",
        "structural",
        "paintServer"
      ],
      content: [
        "a",
        "altGlyphDef",
        "clipPath",
        "color-profile",
        "cursor",
        "filter",
        "font",
        "font-face",
        "foreignObject",
        "image",
        "marker",
        "mask",
        "pattern",
        "script",
        "style",
        "switch",
        "text",
        "view"
      ]
    },
    text: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "lengthAdjust",
        "x",
        "y",
        "dx",
        "dy",
        "rotate",
        "textLength"
      ],
      defaults: {
        x: "0",
        y: "0",
        lengthAdjust: "spacing"
      },
      contentGroups: ["animation", "descriptive", "textContentChild"],
      content: ["a"]
    },
    textPath: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation",
        "xlink"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "href",
        "xlink:href",
        "startOffset",
        "method",
        "spacing",
        "d"
      ],
      defaults: {
        startOffset: "0",
        method: "align",
        spacing: "exact"
      },
      contentGroups: ["descriptive"],
      content: [
        "a",
        "altGlyph",
        "animate",
        "animateColor",
        "set",
        "tref",
        "tspan"
      ]
    },
    title: {
      attrsGroups: ["core"],
      attrs: ["class", "style"]
    },
    tref: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation",
        "xlink"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "href",
        "xlink:href"
      ],
      contentGroups: ["descriptive"],
      content: ["animate", "animateColor", "set"]
    },
    tspan: {
      attrsGroups: [
        "conditionalProcessing",
        "core",
        "graphicalEvent",
        "presentation"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "x",
        "y",
        "dx",
        "dy",
        "rotate",
        "textLength",
        "lengthAdjust"
      ],
      contentGroups: ["descriptive"],
      content: [
        "a",
        "altGlyph",
        "animate",
        "animateColor",
        "set",
        "tref",
        "tspan"
      ]
    },
    use: {
      attrsGroups: [
        "core",
        "conditionalProcessing",
        "graphicalEvent",
        "presentation",
        "xlink"
      ],
      attrs: [
        "class",
        "style",
        "externalResourcesRequired",
        "transform",
        "x",
        "y",
        "width",
        "height",
        "href",
        "xlink:href"
      ],
      defaults: {
        x: "0",
        y: "0"
      },
      contentGroups: ["animation", "descriptive"]
    },
    view: {
      attrsGroups: ["core"],
      attrs: [
        "externalResourcesRequired",
        "viewBox",
        "preserveAspectRatio",
        "zoomAndPan",
        "viewTarget"
      ],
      contentGroups: ["descriptive"]
    },
    vkern: {
      attrsGroups: ["core"],
      attrs: ["u1", "g1", "u2", "g2", "k"]
    }
  };
  exports.editorNamespaces = [
    "http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd",
    "http://inkscape.sourceforge.net/DTD/sodipodi-0.dtd",
    "http://www.inkscape.org/namespaces/inkscape",
    "http://www.bohemiancoding.com/sketch/ns",
    "http://ns.adobe.com/AdobeIllustrator/10.0/",
    "http://ns.adobe.com/Graphs/1.0/",
    "http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/",
    "http://ns.adobe.com/Variables/1.0/",
    "http://ns.adobe.com/SaveForWeb/1.0/",
    "http://ns.adobe.com/Extensibility/1.0/",
    "http://ns.adobe.com/Flows/1.0/",
    "http://ns.adobe.com/ImageReplacement/1.0/",
    "http://ns.adobe.com/GenericCustomNamespace/1.0/",
    "http://ns.adobe.com/XPath/1.0/",
    "http://schemas.microsoft.com/visio/2003/SVGExtensions/",
    "http://taptrix.com/vectorillustrator/svg_extensions",
    "http://www.figma.com/figma/ns",
    "http://purl.org/dc/elements/1.1/",
    "http://creativecommons.org/ns#",
    "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    "http://www.serif.com/",
    "http://www.vector.evaxdesign.sk"
  ];
  exports.referencesProps = [
    "clip-path",
    "color-profile",
    "fill",
    "filter",
    "marker-start",
    "marker-mid",
    "marker-end",
    "mask",
    "stroke",
    "style"
  ];
  exports.inheritableAttrs = [
    "clip-rule",
    "color",
    "color-interpolation",
    "color-interpolation-filters",
    "color-profile",
    "color-rendering",
    "cursor",
    "direction",
    "dominant-baseline",
    "fill",
    "fill-opacity",
    "fill-rule",
    "font",
    "font-family",
    "font-size",
    "font-size-adjust",
    "font-stretch",
    "font-style",
    "font-variant",
    "font-weight",
    "glyph-orientation-horizontal",
    "glyph-orientation-vertical",
    "image-rendering",
    "letter-spacing",
    "marker",
    "marker-end",
    "marker-mid",
    "marker-start",
    "paint-order",
    "pointer-events",
    "shape-rendering",
    "stroke",
    "stroke-dasharray",
    "stroke-dashoffset",
    "stroke-linecap",
    "stroke-linejoin",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke-width",
    "text-anchor",
    "text-rendering",
    "transform",
    "visibility",
    "word-spacing",
    "writing-mode"
  ];
  exports.presentationNonInheritableGroupAttrs = [
    "display",
    "clip-path",
    "filter",
    "mask",
    "opacity",
    "text-decoration",
    "transform",
    "unicode-bidi"
  ];
  exports.colorsNames = {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#0ff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000",
    blanchedalmond: "#ffebcd",
    blue: "#00f",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyan: "#0ff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#f0f",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#789",
    lightslategrey: "#789",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#0f0",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#f0f",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#639",
    red: "#f00",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    steelblue: "#4682b4",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    tomato: "#ff6347",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#fff",
    whitesmoke: "#f5f5f5",
    yellow: "#ff0",
    yellowgreen: "#9acd32"
  };
  exports.colorsShortNames = {
    "#f0ffff": "azure",
    "#f5f5dc": "beige",
    "#ffe4c4": "bisque",
    "#a52a2a": "brown",
    "#ff7f50": "coral",
    "#ffd700": "gold",
    "#808080": "gray",
    "#008000": "green",
    "#4b0082": "indigo",
    "#fffff0": "ivory",
    "#f0e68c": "khaki",
    "#faf0e6": "linen",
    "#800000": "maroon",
    "#000080": "navy",
    "#808000": "olive",
    "#ffa500": "orange",
    "#da70d6": "orchid",
    "#cd853f": "peru",
    "#ffc0cb": "pink",
    "#dda0dd": "plum",
    "#800080": "purple",
    "#f00": "red",
    "#ff0000": "red",
    "#fa8072": "salmon",
    "#a0522d": "sienna",
    "#c0c0c0": "silver",
    "#fffafa": "snow",
    "#d2b48c": "tan",
    "#008080": "teal",
    "#ff6347": "tomato",
    "#ee82ee": "violet",
    "#f5deb3": "wheat"
  };
  exports.colorsProps = [
    "color",
    "fill",
    "stroke",
    "stop-color",
    "flood-color",
    "lighting-color"
  ];
})(_collections);
const { detachNodeFromParent: detachNodeFromParent$h } = xast;
const { editorNamespaces } = _collections;
removeEditorsNSData$1.type = "visitor";
removeEditorsNSData$1.name = "removeEditorsNSData";
removeEditorsNSData$1.active = true;
removeEditorsNSData$1.description = "removes editors namespaces, elements and attributes";
removeEditorsNSData$1.fn = (_root, params) => {
  let namespaces = editorNamespaces;
  if (Array.isArray(params.additionalNamespaces)) {
    namespaces = [...editorNamespaces, ...params.additionalNamespaces];
  }
  const prefixes = [];
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "svg") {
          for (const [name2, value2] of Object.entries(node2.attributes)) {
            if (name2.startsWith("xmlns:") && namespaces.includes(value2)) {
              prefixes.push(name2.slice("xmlns:".length));
              delete node2.attributes[name2];
            }
          }
        }
        for (const name2 of Object.keys(node2.attributes)) {
          if (name2.includes(":")) {
            const [prefix] = name2.split(":");
            if (prefixes.includes(prefix)) {
              delete node2.attributes[name2];
            }
          }
        }
        if (node2.name.includes(":")) {
          const [prefix] = node2.name.split(":");
          if (prefixes.includes(prefix)) {
            detachNodeFromParent$h(node2, parentNode);
          }
        }
      }
    }
  };
};
var cleanupAttrs$1 = {};
cleanupAttrs$1.name = "cleanupAttrs";
cleanupAttrs$1.type = "visitor";
cleanupAttrs$1.active = true;
cleanupAttrs$1.description = "cleanups attributes from newlines, trailing and repeating spaces";
const regNewlinesNeedSpace = /(\S)\r?\n(\S)/g;
const regNewlines = /\r?\n/g;
const regSpaces = /\s{2,}/g;
cleanupAttrs$1.fn = (root, params) => {
  const { newlines = true, trim = true, spaces = true } = params;
  return {
    element: {
      enter: (node2) => {
        for (const name2 of Object.keys(node2.attributes)) {
          if (newlines) {
            node2.attributes[name2] = node2.attributes[name2].replace(
              regNewlinesNeedSpace,
              (match2, p1, p2) => p1 + " " + p2
            );
            node2.attributes[name2] = node2.attributes[name2].replace(
              regNewlines,
              ""
            );
          }
          if (trim) {
            node2.attributes[name2] = node2.attributes[name2].trim();
          }
          if (spaces) {
            node2.attributes[name2] = node2.attributes[name2].replace(
              regSpaces,
              " "
            );
          }
        }
      }
    }
  };
};
var mergeStyles$1 = {};
const { visitSkip: visitSkip$6, detachNodeFromParent: detachNodeFromParent$g } = xast;
mergeStyles$1.name = "mergeStyles";
mergeStyles$1.type = "visitor";
mergeStyles$1.active = true;
mergeStyles$1.description = "merge multiple style elements into one";
mergeStyles$1.fn = () => {
  let firstStyleElement = null;
  let collectedStyles = "";
  let styleContentType = "text";
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "foreignObject") {
          return visitSkip$6;
        }
        if (node2.name !== "style") {
          return;
        }
        if (node2.attributes.type != null && node2.attributes.type !== "" && node2.attributes.type !== "text/css") {
          return;
        }
        let css = "";
        for (const child of node2.children) {
          if (child.type === "text") {
            css += child.value;
          }
          if (child.type === "cdata") {
            styleContentType = "cdata";
            css += child.value;
          }
        }
        if (css.trim().length === 0) {
          detachNodeFromParent$g(node2, parentNode);
          return;
        }
        if (node2.attributes.media == null) {
          collectedStyles += css;
        } else {
          collectedStyles += `@media ${node2.attributes.media}{${css}}`;
          delete node2.attributes.media;
        }
        if (firstStyleElement == null) {
          firstStyleElement = node2;
        } else {
          detachNodeFromParent$g(node2, parentNode);
          const child = { type: styleContentType, value: collectedStyles };
          Object.defineProperty(child, "parentNode", {
            writable: true,
            value: firstStyleElement
          });
          firstStyleElement.children = [child];
        }
      }
    }
  };
};
var inlineStyles$1 = {};
var cjs$1 = {};
var tokenizer$2 = {};
var types$R = {};
const EOF$1 = 0;
const Ident = 1;
const Function$2 = 2;
const AtKeyword = 3;
const Hash$3 = 4;
const String$2 = 5;
const BadString = 6;
const Url$5 = 7;
const BadUrl = 8;
const Delim = 9;
const Number$3 = 10;
const Percentage$5 = 11;
const Dimension$5 = 12;
const WhiteSpace$5 = 13;
const CDO$3 = 14;
const CDC$3 = 15;
const Colon = 16;
const Semicolon = 17;
const Comma = 18;
const LeftSquareBracket = 19;
const RightSquareBracket = 20;
const LeftParenthesis = 21;
const RightParenthesis = 22;
const LeftCurlyBracket = 23;
const RightCurlyBracket = 24;
const Comment$5 = 25;
types$R.AtKeyword = AtKeyword;
types$R.BadString = BadString;
types$R.BadUrl = BadUrl;
types$R.CDC = CDC$3;
types$R.CDO = CDO$3;
types$R.Colon = Colon;
types$R.Comma = Comma;
types$R.Comment = Comment$5;
types$R.Delim = Delim;
types$R.Dimension = Dimension$5;
types$R.EOF = EOF$1;
types$R.Function = Function$2;
types$R.Hash = Hash$3;
types$R.Ident = Ident;
types$R.LeftCurlyBracket = LeftCurlyBracket;
types$R.LeftParenthesis = LeftParenthesis;
types$R.LeftSquareBracket = LeftSquareBracket;
types$R.Number = Number$3;
types$R.Percentage = Percentage$5;
types$R.RightCurlyBracket = RightCurlyBracket;
types$R.RightParenthesis = RightParenthesis;
types$R.RightSquareBracket = RightSquareBracket;
types$R.Semicolon = Semicolon;
types$R.String = String$2;
types$R.Url = Url$5;
types$R.WhiteSpace = WhiteSpace$5;
var charCodeDefinitions$c = {};
const EOF = 0;
function isDigit$1(code2) {
  return code2 >= 48 && code2 <= 57;
}
function isHexDigit(code2) {
  return isDigit$1(code2) || code2 >= 65 && code2 <= 70 || code2 >= 97 && code2 <= 102;
}
function isUppercaseLetter(code2) {
  return code2 >= 65 && code2 <= 90;
}
function isLowercaseLetter(code2) {
  return code2 >= 97 && code2 <= 122;
}
function isLetter(code2) {
  return isUppercaseLetter(code2) || isLowercaseLetter(code2);
}
function isNonAscii(code2) {
  return code2 >= 128;
}
function isNameStart(code2) {
  return isLetter(code2) || isNonAscii(code2) || code2 === 95;
}
function isName(code2) {
  return isNameStart(code2) || isDigit$1(code2) || code2 === 45;
}
function isNonPrintable(code2) {
  return code2 >= 0 && code2 <= 8 || code2 === 11 || code2 >= 14 && code2 <= 31 || code2 === 127;
}
function isNewline(code2) {
  return code2 === 10 || code2 === 13 || code2 === 12;
}
function isWhiteSpace(code2) {
  return isNewline(code2) || code2 === 32 || code2 === 9;
}
function isValidEscape(first, second) {
  if (first !== 92) {
    return false;
  }
  if (isNewline(second) || second === EOF) {
    return false;
  }
  return true;
}
function isIdentifierStart(first, second, third) {
  if (first === 45) {
    return isNameStart(second) || second === 45 || isValidEscape(second, third);
  }
  if (isNameStart(first)) {
    return true;
  }
  if (first === 92) {
    return isValidEscape(first, second);
  }
  return false;
}
function isNumberStart(first, second, third) {
  if (first === 43 || first === 45) {
    if (isDigit$1(second)) {
      return 2;
    }
    return second === 46 && isDigit$1(third) ? 3 : 0;
  }
  if (first === 46) {
    return isDigit$1(second) ? 2 : 0;
  }
  if (isDigit$1(first)) {
    return 1;
  }
  return 0;
}
function isBOM(code2) {
  if (code2 === 65279) {
    return 1;
  }
  if (code2 === 65534) {
    return 1;
  }
  return 0;
}
const CATEGORY = new Array(128);
const EofCategory = 128;
const WhiteSpaceCategory = 130;
const DigitCategory = 131;
const NameStartCategory = 132;
const NonPrintableCategory = 133;
for (let i = 0; i < CATEGORY.length; i++) {
  CATEGORY[i] = isWhiteSpace(i) && WhiteSpaceCategory || isDigit$1(i) && DigitCategory || isNameStart(i) && NameStartCategory || isNonPrintable(i) && NonPrintableCategory || i || EofCategory;
}
function charCodeCategory(code2) {
  return code2 < 128 ? CATEGORY[code2] : NameStartCategory;
}
charCodeDefinitions$c.DigitCategory = DigitCategory;
charCodeDefinitions$c.EofCategory = EofCategory;
charCodeDefinitions$c.NameStartCategory = NameStartCategory;
charCodeDefinitions$c.NonPrintableCategory = NonPrintableCategory;
charCodeDefinitions$c.WhiteSpaceCategory = WhiteSpaceCategory;
charCodeDefinitions$c.charCodeCategory = charCodeCategory;
charCodeDefinitions$c.isBOM = isBOM;
charCodeDefinitions$c.isDigit = isDigit$1;
charCodeDefinitions$c.isHexDigit = isHexDigit;
charCodeDefinitions$c.isIdentifierStart = isIdentifierStart;
charCodeDefinitions$c.isLetter = isLetter;
charCodeDefinitions$c.isLowercaseLetter = isLowercaseLetter;
charCodeDefinitions$c.isName = isName;
charCodeDefinitions$c.isNameStart = isNameStart;
charCodeDefinitions$c.isNewline = isNewline;
charCodeDefinitions$c.isNonAscii = isNonAscii;
charCodeDefinitions$c.isNonPrintable = isNonPrintable;
charCodeDefinitions$c.isNumberStart = isNumberStart;
charCodeDefinitions$c.isUppercaseLetter = isUppercaseLetter;
charCodeDefinitions$c.isValidEscape = isValidEscape;
charCodeDefinitions$c.isWhiteSpace = isWhiteSpace;
var utils$k = {};
const charCodeDefinitions$b = charCodeDefinitions$c;
function getCharCode(source, offset) {
  return offset < source.length ? source.charCodeAt(offset) : 0;
}
function getNewlineLength(source, offset, code2) {
  if (code2 === 13 && getCharCode(source, offset + 1) === 10) {
    return 2;
  }
  return 1;
}
function cmpChar(testStr, offset, referenceCode) {
  let code2 = testStr.charCodeAt(offset);
  if (charCodeDefinitions$b.isUppercaseLetter(code2)) {
    code2 = code2 | 32;
  }
  return code2 === referenceCode;
}
function cmpStr(testStr, start, end, referenceStr) {
  if (end - start !== referenceStr.length) {
    return false;
  }
  if (start < 0 || end > testStr.length) {
    return false;
  }
  for (let i = start; i < end; i++) {
    const referenceCode = referenceStr.charCodeAt(i - start);
    let testCode = testStr.charCodeAt(i);
    if (charCodeDefinitions$b.isUppercaseLetter(testCode)) {
      testCode = testCode | 32;
    }
    if (testCode !== referenceCode) {
      return false;
    }
  }
  return true;
}
function findWhiteSpaceStart(source, offset) {
  for (; offset >= 0; offset--) {
    if (!charCodeDefinitions$b.isWhiteSpace(source.charCodeAt(offset))) {
      break;
    }
  }
  return offset + 1;
}
function findWhiteSpaceEnd(source, offset) {
  for (; offset < source.length; offset++) {
    if (!charCodeDefinitions$b.isWhiteSpace(source.charCodeAt(offset))) {
      break;
    }
  }
  return offset;
}
function findDecimalNumberEnd(source, offset) {
  for (; offset < source.length; offset++) {
    if (!charCodeDefinitions$b.isDigit(source.charCodeAt(offset))) {
      break;
    }
  }
  return offset;
}
function consumeEscaped(source, offset) {
  offset += 2;
  if (charCodeDefinitions$b.isHexDigit(getCharCode(source, offset - 1))) {
    for (const maxOffset = Math.min(source.length, offset + 5); offset < maxOffset; offset++) {
      if (!charCodeDefinitions$b.isHexDigit(getCharCode(source, offset))) {
        break;
      }
    }
    const code2 = getCharCode(source, offset);
    if (charCodeDefinitions$b.isWhiteSpace(code2)) {
      offset += getNewlineLength(source, offset, code2);
    }
  }
  return offset;
}
function consumeName(source, offset) {
  for (; offset < source.length; offset++) {
    const code2 = source.charCodeAt(offset);
    if (charCodeDefinitions$b.isName(code2)) {
      continue;
    }
    if (charCodeDefinitions$b.isValidEscape(code2, getCharCode(source, offset + 1))) {
      offset = consumeEscaped(source, offset) - 1;
      continue;
    }
    break;
  }
  return offset;
}
function consumeNumber$1(source, offset) {
  let code2 = source.charCodeAt(offset);
  if (code2 === 43 || code2 === 45) {
    code2 = source.charCodeAt(offset += 1);
  }
  if (charCodeDefinitions$b.isDigit(code2)) {
    offset = findDecimalNumberEnd(source, offset + 1);
    code2 = source.charCodeAt(offset);
  }
  if (code2 === 46 && charCodeDefinitions$b.isDigit(source.charCodeAt(offset + 1))) {
    offset += 2;
    offset = findDecimalNumberEnd(source, offset);
  }
  if (cmpChar(source, offset, 101)) {
    let sign = 0;
    code2 = source.charCodeAt(offset + 1);
    if (code2 === 45 || code2 === 43) {
      sign = 1;
      code2 = source.charCodeAt(offset + 2);
    }
    if (charCodeDefinitions$b.isDigit(code2)) {
      offset = findDecimalNumberEnd(source, offset + 1 + sign + 1);
    }
  }
  return offset;
}
function consumeBadUrlRemnants(source, offset) {
  for (; offset < source.length; offset++) {
    const code2 = source.charCodeAt(offset);
    if (code2 === 41) {
      offset++;
      break;
    }
    if (charCodeDefinitions$b.isValidEscape(code2, getCharCode(source, offset + 1))) {
      offset = consumeEscaped(source, offset);
    }
  }
  return offset;
}
function decodeEscaped(escaped) {
  if (escaped.length === 1 && !charCodeDefinitions$b.isHexDigit(escaped.charCodeAt(0))) {
    return escaped[0];
  }
  let code2 = parseInt(escaped, 16);
  if (code2 === 0 || code2 >= 55296 && code2 <= 57343 || code2 > 1114111) {
    code2 = 65533;
  }
  return String.fromCodePoint(code2);
}
utils$k.cmpChar = cmpChar;
utils$k.cmpStr = cmpStr;
utils$k.consumeBadUrlRemnants = consumeBadUrlRemnants;
utils$k.consumeEscaped = consumeEscaped;
utils$k.consumeName = consumeName;
utils$k.consumeNumber = consumeNumber$1;
utils$k.decodeEscaped = decodeEscaped;
utils$k.findDecimalNumberEnd = findDecimalNumberEnd;
utils$k.findWhiteSpaceEnd = findWhiteSpaceEnd;
utils$k.findWhiteSpaceStart = findWhiteSpaceStart;
utils$k.getNewlineLength = getNewlineLength;
const tokenNames = [
  "EOF-token",
  "ident-token",
  "function-token",
  "at-keyword-token",
  "hash-token",
  "string-token",
  "bad-string-token",
  "url-token",
  "bad-url-token",
  "delim-token",
  "number-token",
  "percentage-token",
  "dimension-token",
  "whitespace-token",
  "CDO-token",
  "CDC-token",
  "colon-token",
  "semicolon-token",
  "comma-token",
  "[-token",
  "]-token",
  "(-token",
  ")-token",
  "{-token",
  "}-token"
];
var names$8 = tokenNames;
var OffsetToLocation$3 = {};
var adoptBuffer$3 = {};
const MIN_SIZE = 16 * 1024;
function adoptBuffer$2(buffer = null, size) {
  if (buffer === null || buffer.length < size) {
    return new Uint32Array(Math.max(size + 1024, MIN_SIZE));
  }
  return buffer;
}
adoptBuffer$3.adoptBuffer = adoptBuffer$2;
const adoptBuffer$1 = adoptBuffer$3;
const charCodeDefinitions$a = charCodeDefinitions$c;
const N$4 = 10;
const F$2 = 12;
const R$2 = 13;
function computeLinesAndColumns(host) {
  const source = host.source;
  const sourceLength = source.length;
  const startOffset = source.length > 0 ? charCodeDefinitions$a.isBOM(source.charCodeAt(0)) : 0;
  const lines = adoptBuffer$1.adoptBuffer(host.lines, sourceLength);
  const columns = adoptBuffer$1.adoptBuffer(host.columns, sourceLength);
  let line = host.startLine;
  let column = host.startColumn;
  for (let i = startOffset; i < sourceLength; i++) {
    const code2 = source.charCodeAt(i);
    lines[i] = line;
    columns[i] = column++;
    if (code2 === N$4 || code2 === R$2 || code2 === F$2) {
      if (code2 === R$2 && i + 1 < sourceLength && source.charCodeAt(i + 1) === N$4) {
        i++;
        lines[i] = line;
        columns[i] = column;
      }
      line++;
      column = 1;
    }
  }
  lines[sourceLength] = line;
  columns[sourceLength] = column;
  host.lines = lines;
  host.columns = columns;
  host.computed = true;
}
class OffsetToLocation$2 {
  constructor() {
    this.lines = null;
    this.columns = null;
    this.computed = false;
  }
  setSource(source, startOffset = 0, startLine = 1, startColumn = 1) {
    this.source = source;
    this.startOffset = startOffset;
    this.startLine = startLine;
    this.startColumn = startColumn;
    this.computed = false;
  }
  getLocation(offset, filename) {
    if (!this.computed) {
      computeLinesAndColumns(this);
    }
    return {
      source: filename,
      offset: this.startOffset + offset,
      line: this.lines[offset],
      column: this.columns[offset]
    };
  }
  getLocationRange(start, end, filename) {
    if (!this.computed) {
      computeLinesAndColumns(this);
    }
    return {
      source: filename,
      start: {
        offset: this.startOffset + start,
        line: this.lines[start],
        column: this.columns[start]
      },
      end: {
        offset: this.startOffset + end,
        line: this.lines[end],
        column: this.columns[end]
      }
    };
  }
}
OffsetToLocation$3.OffsetToLocation = OffsetToLocation$2;
var TokenStream$4 = {};
const adoptBuffer = adoptBuffer$3;
const utils$j = utils$k;
const names$7 = names$8;
const types$Q = types$R;
const OFFSET_MASK = 16777215;
const TYPE_SHIFT = 24;
const balancePair$1 = /* @__PURE__ */ new Map([
  [types$Q.Function, types$Q.RightParenthesis],
  [types$Q.LeftParenthesis, types$Q.RightParenthesis],
  [types$Q.LeftSquareBracket, types$Q.RightSquareBracket],
  [types$Q.LeftCurlyBracket, types$Q.RightCurlyBracket]
]);
class TokenStream$3 {
  constructor(source, tokenize2) {
    this.setSource(source, tokenize2);
  }
  reset() {
    this.eof = false;
    this.tokenIndex = -1;
    this.tokenType = 0;
    this.tokenStart = this.firstCharOffset;
    this.tokenEnd = this.firstCharOffset;
  }
  setSource(source = "", tokenize2 = () => {
  }) {
    source = String(source || "");
    const sourceLength = source.length;
    const offsetAndType = adoptBuffer.adoptBuffer(this.offsetAndType, source.length + 1);
    const balance = adoptBuffer.adoptBuffer(this.balance, source.length + 1);
    let tokenCount = 0;
    let balanceCloseType = 0;
    let balanceStart = 0;
    let firstCharOffset = -1;
    this.offsetAndType = null;
    this.balance = null;
    tokenize2(source, (type, start, end) => {
      switch (type) {
        default:
          balance[tokenCount] = sourceLength;
          break;
        case balanceCloseType: {
          let balancePrev = balanceStart & OFFSET_MASK;
          balanceStart = balance[balancePrev];
          balanceCloseType = balanceStart >> TYPE_SHIFT;
          balance[tokenCount] = balancePrev;
          balance[balancePrev++] = tokenCount;
          for (; balancePrev < tokenCount; balancePrev++) {
            if (balance[balancePrev] === sourceLength) {
              balance[balancePrev] = tokenCount;
            }
          }
          break;
        }
        case types$Q.LeftParenthesis:
        case types$Q.Function:
        case types$Q.LeftSquareBracket:
        case types$Q.LeftCurlyBracket:
          balance[tokenCount] = balanceStart;
          balanceCloseType = balancePair$1.get(type);
          balanceStart = balanceCloseType << TYPE_SHIFT | tokenCount;
          break;
      }
      offsetAndType[tokenCount++] = type << TYPE_SHIFT | end;
      if (firstCharOffset === -1) {
        firstCharOffset = start;
      }
    });
    offsetAndType[tokenCount] = types$Q.EOF << TYPE_SHIFT | sourceLength;
    balance[tokenCount] = sourceLength;
    balance[sourceLength] = sourceLength;
    while (balanceStart !== 0) {
      const balancePrev = balanceStart & OFFSET_MASK;
      balanceStart = balance[balancePrev];
      balance[balancePrev] = sourceLength;
    }
    this.source = source;
    this.firstCharOffset = firstCharOffset === -1 ? 0 : firstCharOffset;
    this.tokenCount = tokenCount;
    this.offsetAndType = offsetAndType;
    this.balance = balance;
    this.reset();
    this.next();
  }
  lookupType(offset) {
    offset += this.tokenIndex;
    if (offset < this.tokenCount) {
      return this.offsetAndType[offset] >> TYPE_SHIFT;
    }
    return types$Q.EOF;
  }
  lookupOffset(offset) {
    offset += this.tokenIndex;
    if (offset < this.tokenCount) {
      return this.offsetAndType[offset - 1] & OFFSET_MASK;
    }
    return this.source.length;
  }
  lookupValue(offset, referenceStr) {
    offset += this.tokenIndex;
    if (offset < this.tokenCount) {
      return utils$j.cmpStr(
        this.source,
        this.offsetAndType[offset - 1] & OFFSET_MASK,
        this.offsetAndType[offset] & OFFSET_MASK,
        referenceStr
      );
    }
    return false;
  }
  getTokenStart(tokenIndex) {
    if (tokenIndex === this.tokenIndex) {
      return this.tokenStart;
    }
    if (tokenIndex > 0) {
      return tokenIndex < this.tokenCount ? this.offsetAndType[tokenIndex - 1] & OFFSET_MASK : this.offsetAndType[this.tokenCount] & OFFSET_MASK;
    }
    return this.firstCharOffset;
  }
  substrToCursor(start) {
    return this.source.substring(start, this.tokenStart);
  }
  isBalanceEdge(pos) {
    return this.balance[this.tokenIndex] < pos;
  }
  isDelim(code2, offset) {
    if (offset) {
      return this.lookupType(offset) === types$Q.Delim && this.source.charCodeAt(this.lookupOffset(offset)) === code2;
    }
    return this.tokenType === types$Q.Delim && this.source.charCodeAt(this.tokenStart) === code2;
  }
  skip(tokenCount) {
    let next = this.tokenIndex + tokenCount;
    if (next < this.tokenCount) {
      this.tokenIndex = next;
      this.tokenStart = this.offsetAndType[next - 1] & OFFSET_MASK;
      next = this.offsetAndType[next];
      this.tokenType = next >> TYPE_SHIFT;
      this.tokenEnd = next & OFFSET_MASK;
    } else {
      this.tokenIndex = this.tokenCount;
      this.next();
    }
  }
  next() {
    let next = this.tokenIndex + 1;
    if (next < this.tokenCount) {
      this.tokenIndex = next;
      this.tokenStart = this.tokenEnd;
      next = this.offsetAndType[next];
      this.tokenType = next >> TYPE_SHIFT;
      this.tokenEnd = next & OFFSET_MASK;
    } else {
      this.eof = true;
      this.tokenIndex = this.tokenCount;
      this.tokenType = types$Q.EOF;
      this.tokenStart = this.tokenEnd = this.source.length;
    }
  }
  skipSC() {
    while (this.tokenType === types$Q.WhiteSpace || this.tokenType === types$Q.Comment) {
      this.next();
    }
  }
  skipUntilBalanced(startToken, stopConsume) {
    let cursor = startToken;
    let balanceEnd;
    let offset;
    loop:
      for (; cursor < this.tokenCount; cursor++) {
        balanceEnd = this.balance[cursor];
        if (balanceEnd < startToken) {
          break loop;
        }
        offset = cursor > 0 ? this.offsetAndType[cursor - 1] & OFFSET_MASK : this.firstCharOffset;
        switch (stopConsume(this.source.charCodeAt(offset))) {
          case 1:
            break loop;
          case 2:
            cursor++;
            break loop;
          default:
            if (this.balance[balanceEnd] === cursor) {
              cursor = balanceEnd;
            }
        }
      }
    this.skip(cursor - this.tokenIndex);
  }
  forEachToken(fn) {
    for (let i = 0, offset = this.firstCharOffset; i < this.tokenCount; i++) {
      const start = offset;
      const item = this.offsetAndType[i];
      const end = item & OFFSET_MASK;
      const type = item >> TYPE_SHIFT;
      offset = end;
      fn(type, start, end, i);
    }
  }
  dump() {
    const tokens = new Array(this.tokenCount);
    this.forEachToken((type, start, end, index2) => {
      tokens[index2] = {
        idx: index2,
        type: names$7[type],
        chunk: this.source.substring(start, end),
        balance: this.balance[index2]
      };
    });
    return tokens;
  }
}
TokenStream$4.TokenStream = TokenStream$3;
const types$P = types$R;
const charCodeDefinitions$9 = charCodeDefinitions$c;
const utils$i = utils$k;
const names$6 = names$8;
const OffsetToLocation$1 = OffsetToLocation$3;
const TokenStream$2 = TokenStream$4;
function tokenize$2(source, onToken) {
  function getCharCode2(offset2) {
    return offset2 < sourceLength ? source.charCodeAt(offset2) : 0;
  }
  function consumeNumericToken() {
    offset = utils$i.consumeNumber(source, offset);
    if (charCodeDefinitions$9.isIdentifierStart(getCharCode2(offset), getCharCode2(offset + 1), getCharCode2(offset + 2))) {
      type = types$P.Dimension;
      offset = utils$i.consumeName(source, offset);
      return;
    }
    if (getCharCode2(offset) === 37) {
      type = types$P.Percentage;
      offset++;
      return;
    }
    type = types$P.Number;
  }
  function consumeIdentLikeToken() {
    const nameStartOffset = offset;
    offset = utils$i.consumeName(source, offset);
    if (utils$i.cmpStr(source, nameStartOffset, offset, "url") && getCharCode2(offset) === 40) {
      offset = utils$i.findWhiteSpaceEnd(source, offset + 1);
      if (getCharCode2(offset) === 34 || getCharCode2(offset) === 39) {
        type = types$P.Function;
        offset = nameStartOffset + 4;
        return;
      }
      consumeUrlToken();
      return;
    }
    if (getCharCode2(offset) === 40) {
      type = types$P.Function;
      offset++;
      return;
    }
    type = types$P.Ident;
  }
  function consumeStringToken(endingCodePoint) {
    if (!endingCodePoint) {
      endingCodePoint = getCharCode2(offset++);
    }
    type = types$P.String;
    for (; offset < source.length; offset++) {
      const code2 = source.charCodeAt(offset);
      switch (charCodeDefinitions$9.charCodeCategory(code2)) {
        case endingCodePoint:
          offset++;
          return;
        case charCodeDefinitions$9.WhiteSpaceCategory:
          if (charCodeDefinitions$9.isNewline(code2)) {
            offset += utils$i.getNewlineLength(source, offset, code2);
            type = types$P.BadString;
            return;
          }
          break;
        case 92:
          if (offset === source.length - 1) {
            break;
          }
          const nextCode = getCharCode2(offset + 1);
          if (charCodeDefinitions$9.isNewline(nextCode)) {
            offset += utils$i.getNewlineLength(source, offset + 1, nextCode);
          } else if (charCodeDefinitions$9.isValidEscape(code2, nextCode)) {
            offset = utils$i.consumeEscaped(source, offset) - 1;
          }
          break;
      }
    }
  }
  function consumeUrlToken() {
    type = types$P.Url;
    offset = utils$i.findWhiteSpaceEnd(source, offset);
    for (; offset < source.length; offset++) {
      const code2 = source.charCodeAt(offset);
      switch (charCodeDefinitions$9.charCodeCategory(code2)) {
        case 41:
          offset++;
          return;
        case charCodeDefinitions$9.WhiteSpaceCategory:
          offset = utils$i.findWhiteSpaceEnd(source, offset);
          if (getCharCode2(offset) === 41 || offset >= source.length) {
            if (offset < source.length) {
              offset++;
            }
            return;
          }
          offset = utils$i.consumeBadUrlRemnants(source, offset);
          type = types$P.BadUrl;
          return;
        case 34:
        case 39:
        case 40:
        case charCodeDefinitions$9.NonPrintableCategory:
          offset = utils$i.consumeBadUrlRemnants(source, offset);
          type = types$P.BadUrl;
          return;
        case 92:
          if (charCodeDefinitions$9.isValidEscape(code2, getCharCode2(offset + 1))) {
            offset = utils$i.consumeEscaped(source, offset) - 1;
            break;
          }
          offset = utils$i.consumeBadUrlRemnants(source, offset);
          type = types$P.BadUrl;
          return;
      }
    }
  }
  source = String(source || "");
  const sourceLength = source.length;
  let start = charCodeDefinitions$9.isBOM(getCharCode2(0));
  let offset = start;
  let type;
  while (offset < sourceLength) {
    const code2 = source.charCodeAt(offset);
    switch (charCodeDefinitions$9.charCodeCategory(code2)) {
      case charCodeDefinitions$9.WhiteSpaceCategory:
        type = types$P.WhiteSpace;
        offset = utils$i.findWhiteSpaceEnd(source, offset + 1);
        break;
      case 34:
        consumeStringToken();
        break;
      case 35:
        if (charCodeDefinitions$9.isName(getCharCode2(offset + 1)) || charCodeDefinitions$9.isValidEscape(getCharCode2(offset + 1), getCharCode2(offset + 2))) {
          type = types$P.Hash;
          offset = utils$i.consumeName(source, offset + 1);
        } else {
          type = types$P.Delim;
          offset++;
        }
        break;
      case 39:
        consumeStringToken();
        break;
      case 40:
        type = types$P.LeftParenthesis;
        offset++;
        break;
      case 41:
        type = types$P.RightParenthesis;
        offset++;
        break;
      case 43:
        if (charCodeDefinitions$9.isNumberStart(code2, getCharCode2(offset + 1), getCharCode2(offset + 2))) {
          consumeNumericToken();
        } else {
          type = types$P.Delim;
          offset++;
        }
        break;
      case 44:
        type = types$P.Comma;
        offset++;
        break;
      case 45:
        if (charCodeDefinitions$9.isNumberStart(code2, getCharCode2(offset + 1), getCharCode2(offset + 2))) {
          consumeNumericToken();
        } else {
          if (getCharCode2(offset + 1) === 45 && getCharCode2(offset + 2) === 62) {
            type = types$P.CDC;
            offset = offset + 3;
          } else {
            if (charCodeDefinitions$9.isIdentifierStart(code2, getCharCode2(offset + 1), getCharCode2(offset + 2))) {
              consumeIdentLikeToken();
            } else {
              type = types$P.Delim;
              offset++;
            }
          }
        }
        break;
      case 46:
        if (charCodeDefinitions$9.isNumberStart(code2, getCharCode2(offset + 1), getCharCode2(offset + 2))) {
          consumeNumericToken();
        } else {
          type = types$P.Delim;
          offset++;
        }
        break;
      case 47:
        if (getCharCode2(offset + 1) === 42) {
          type = types$P.Comment;
          offset = source.indexOf("*/", offset + 2);
          offset = offset === -1 ? source.length : offset + 2;
        } else {
          type = types$P.Delim;
          offset++;
        }
        break;
      case 58:
        type = types$P.Colon;
        offset++;
        break;
      case 59:
        type = types$P.Semicolon;
        offset++;
        break;
      case 60:
        if (getCharCode2(offset + 1) === 33 && getCharCode2(offset + 2) === 45 && getCharCode2(offset + 3) === 45) {
          type = types$P.CDO;
          offset = offset + 4;
        } else {
          type = types$P.Delim;
          offset++;
        }
        break;
      case 64:
        if (charCodeDefinitions$9.isIdentifierStart(getCharCode2(offset + 1), getCharCode2(offset + 2), getCharCode2(offset + 3))) {
          type = types$P.AtKeyword;
          offset = utils$i.consumeName(source, offset + 1);
        } else {
          type = types$P.Delim;
          offset++;
        }
        break;
      case 91:
        type = types$P.LeftSquareBracket;
        offset++;
        break;
      case 92:
        if (charCodeDefinitions$9.isValidEscape(code2, getCharCode2(offset + 1))) {
          consumeIdentLikeToken();
        } else {
          type = types$P.Delim;
          offset++;
        }
        break;
      case 93:
        type = types$P.RightSquareBracket;
        offset++;
        break;
      case 123:
        type = types$P.LeftCurlyBracket;
        offset++;
        break;
      case 125:
        type = types$P.RightCurlyBracket;
        offset++;
        break;
      case charCodeDefinitions$9.DigitCategory:
        consumeNumericToken();
        break;
      case charCodeDefinitions$9.NameStartCategory:
        consumeIdentLikeToken();
        break;
      default:
        type = types$P.Delim;
        offset++;
    }
    onToken(type, start, start = offset);
  }
}
tokenizer$2.AtKeyword = types$P.AtKeyword;
tokenizer$2.BadString = types$P.BadString;
tokenizer$2.BadUrl = types$P.BadUrl;
tokenizer$2.CDC = types$P.CDC;
tokenizer$2.CDO = types$P.CDO;
tokenizer$2.Colon = types$P.Colon;
tokenizer$2.Comma = types$P.Comma;
tokenizer$2.Comment = types$P.Comment;
tokenizer$2.Delim = types$P.Delim;
tokenizer$2.Dimension = types$P.Dimension;
tokenizer$2.EOF = types$P.EOF;
tokenizer$2.Function = types$P.Function;
tokenizer$2.Hash = types$P.Hash;
tokenizer$2.Ident = types$P.Ident;
tokenizer$2.LeftCurlyBracket = types$P.LeftCurlyBracket;
tokenizer$2.LeftParenthesis = types$P.LeftParenthesis;
tokenizer$2.LeftSquareBracket = types$P.LeftSquareBracket;
tokenizer$2.Number = types$P.Number;
tokenizer$2.Percentage = types$P.Percentage;
tokenizer$2.RightCurlyBracket = types$P.RightCurlyBracket;
tokenizer$2.RightParenthesis = types$P.RightParenthesis;
tokenizer$2.RightSquareBracket = types$P.RightSquareBracket;
tokenizer$2.Semicolon = types$P.Semicolon;
tokenizer$2.String = types$P.String;
tokenizer$2.Url = types$P.Url;
tokenizer$2.WhiteSpace = types$P.WhiteSpace;
tokenizer$2.tokenTypes = types$P;
tokenizer$2.DigitCategory = charCodeDefinitions$9.DigitCategory;
tokenizer$2.EofCategory = charCodeDefinitions$9.EofCategory;
tokenizer$2.NameStartCategory = charCodeDefinitions$9.NameStartCategory;
tokenizer$2.NonPrintableCategory = charCodeDefinitions$9.NonPrintableCategory;
tokenizer$2.WhiteSpaceCategory = charCodeDefinitions$9.WhiteSpaceCategory;
tokenizer$2.charCodeCategory = charCodeDefinitions$9.charCodeCategory;
tokenizer$2.isBOM = charCodeDefinitions$9.isBOM;
tokenizer$2.isDigit = charCodeDefinitions$9.isDigit;
tokenizer$2.isHexDigit = charCodeDefinitions$9.isHexDigit;
tokenizer$2.isIdentifierStart = charCodeDefinitions$9.isIdentifierStart;
tokenizer$2.isLetter = charCodeDefinitions$9.isLetter;
tokenizer$2.isLowercaseLetter = charCodeDefinitions$9.isLowercaseLetter;
tokenizer$2.isName = charCodeDefinitions$9.isName;
tokenizer$2.isNameStart = charCodeDefinitions$9.isNameStart;
tokenizer$2.isNewline = charCodeDefinitions$9.isNewline;
tokenizer$2.isNonAscii = charCodeDefinitions$9.isNonAscii;
tokenizer$2.isNonPrintable = charCodeDefinitions$9.isNonPrintable;
tokenizer$2.isNumberStart = charCodeDefinitions$9.isNumberStart;
tokenizer$2.isUppercaseLetter = charCodeDefinitions$9.isUppercaseLetter;
tokenizer$2.isValidEscape = charCodeDefinitions$9.isValidEscape;
tokenizer$2.isWhiteSpace = charCodeDefinitions$9.isWhiteSpace;
tokenizer$2.cmpChar = utils$i.cmpChar;
tokenizer$2.cmpStr = utils$i.cmpStr;
tokenizer$2.consumeBadUrlRemnants = utils$i.consumeBadUrlRemnants;
tokenizer$2.consumeEscaped = utils$i.consumeEscaped;
tokenizer$2.consumeName = utils$i.consumeName;
tokenizer$2.consumeNumber = utils$i.consumeNumber;
tokenizer$2.decodeEscaped = utils$i.decodeEscaped;
tokenizer$2.findDecimalNumberEnd = utils$i.findDecimalNumberEnd;
tokenizer$2.findWhiteSpaceEnd = utils$i.findWhiteSpaceEnd;
tokenizer$2.findWhiteSpaceStart = utils$i.findWhiteSpaceStart;
tokenizer$2.getNewlineLength = utils$i.getNewlineLength;
tokenizer$2.tokenNames = names$6;
tokenizer$2.OffsetToLocation = OffsetToLocation$1.OffsetToLocation;
tokenizer$2.TokenStream = TokenStream$2.TokenStream;
tokenizer$2.tokenize = tokenize$2;
var create$7 = {};
var List$7 = {};
let releasedCursors = null;
class List$6 {
  static createItem(data2) {
    return {
      prev: null,
      next: null,
      data: data2
    };
  }
  constructor() {
    this.head = null;
    this.tail = null;
    this.cursor = null;
  }
  createItem(data2) {
    return List$6.createItem(data2);
  }
  allocateCursor(prev, next) {
    let cursor;
    if (releasedCursors !== null) {
      cursor = releasedCursors;
      releasedCursors = releasedCursors.cursor;
      cursor.prev = prev;
      cursor.next = next;
      cursor.cursor = this.cursor;
    } else {
      cursor = {
        prev,
        next,
        cursor: this.cursor
      };
    }
    this.cursor = cursor;
    return cursor;
  }
  releaseCursor() {
    const { cursor } = this;
    this.cursor = cursor.cursor;
    cursor.prev = null;
    cursor.next = null;
    cursor.cursor = releasedCursors;
    releasedCursors = cursor;
  }
  updateCursors(prevOld, prevNew, nextOld, nextNew) {
    let { cursor } = this;
    while (cursor !== null) {
      if (cursor.prev === prevOld) {
        cursor.prev = prevNew;
      }
      if (cursor.next === nextOld) {
        cursor.next = nextNew;
      }
      cursor = cursor.cursor;
    }
  }
  *[Symbol.iterator]() {
    for (let cursor = this.head; cursor !== null; cursor = cursor.next) {
      yield cursor.data;
    }
  }
  get size() {
    let size = 0;
    for (let cursor = this.head; cursor !== null; cursor = cursor.next) {
      size++;
    }
    return size;
  }
  get isEmpty() {
    return this.head === null;
  }
  get first() {
    return this.head && this.head.data;
  }
  get last() {
    return this.tail && this.tail.data;
  }
  fromArray(array) {
    let cursor = null;
    this.head = null;
    for (let data2 of array) {
      const item = List$6.createItem(data2);
      if (cursor !== null) {
        cursor.next = item;
      } else {
        this.head = item;
      }
      item.prev = cursor;
      cursor = item;
    }
    this.tail = cursor;
    return this;
  }
  toArray() {
    return [...this];
  }
  toJSON() {
    return [...this];
  }
  forEach(fn, thisArg = this) {
    const cursor = this.allocateCursor(null, this.head);
    while (cursor.next !== null) {
      const item = cursor.next;
      cursor.next = item.next;
      fn.call(thisArg, item.data, item, this);
    }
    this.releaseCursor();
  }
  forEachRight(fn, thisArg = this) {
    const cursor = this.allocateCursor(this.tail, null);
    while (cursor.prev !== null) {
      const item = cursor.prev;
      cursor.prev = item.prev;
      fn.call(thisArg, item.data, item, this);
    }
    this.releaseCursor();
  }
  reduce(fn, initialValue, thisArg = this) {
    let cursor = this.allocateCursor(null, this.head);
    let acc = initialValue;
    let item;
    while (cursor.next !== null) {
      item = cursor.next;
      cursor.next = item.next;
      acc = fn.call(thisArg, acc, item.data, item, this);
    }
    this.releaseCursor();
    return acc;
  }
  reduceRight(fn, initialValue, thisArg = this) {
    let cursor = this.allocateCursor(this.tail, null);
    let acc = initialValue;
    let item;
    while (cursor.prev !== null) {
      item = cursor.prev;
      cursor.prev = item.prev;
      acc = fn.call(thisArg, acc, item.data, item, this);
    }
    this.releaseCursor();
    return acc;
  }
  some(fn, thisArg = this) {
    for (let cursor = this.head; cursor !== null; cursor = cursor.next) {
      if (fn.call(thisArg, cursor.data, cursor, this)) {
        return true;
      }
    }
    return false;
  }
  map(fn, thisArg = this) {
    const result = new List$6();
    for (let cursor = this.head; cursor !== null; cursor = cursor.next) {
      result.appendData(fn.call(thisArg, cursor.data, cursor, this));
    }
    return result;
  }
  filter(fn, thisArg = this) {
    const result = new List$6();
    for (let cursor = this.head; cursor !== null; cursor = cursor.next) {
      if (fn.call(thisArg, cursor.data, cursor, this)) {
        result.appendData(cursor.data);
      }
    }
    return result;
  }
  nextUntil(start, fn, thisArg = this) {
    if (start === null) {
      return;
    }
    const cursor = this.allocateCursor(null, start);
    while (cursor.next !== null) {
      const item = cursor.next;
      cursor.next = item.next;
      if (fn.call(thisArg, item.data, item, this)) {
        break;
      }
    }
    this.releaseCursor();
  }
  prevUntil(start, fn, thisArg = this) {
    if (start === null) {
      return;
    }
    const cursor = this.allocateCursor(start, null);
    while (cursor.prev !== null) {
      const item = cursor.prev;
      cursor.prev = item.prev;
      if (fn.call(thisArg, item.data, item, this)) {
        break;
      }
    }
    this.releaseCursor();
  }
  clear() {
    this.head = null;
    this.tail = null;
  }
  copy() {
    const result = new List$6();
    for (let data2 of this) {
      result.appendData(data2);
    }
    return result;
  }
  prepend(item) {
    this.updateCursors(null, item, this.head, item);
    if (this.head !== null) {
      this.head.prev = item;
      item.next = this.head;
    } else {
      this.tail = item;
    }
    this.head = item;
    return this;
  }
  prependData(data2) {
    return this.prepend(List$6.createItem(data2));
  }
  append(item) {
    return this.insert(item);
  }
  appendData(data2) {
    return this.insert(List$6.createItem(data2));
  }
  insert(item, before = null) {
    if (before !== null) {
      this.updateCursors(before.prev, item, before, item);
      if (before.prev === null) {
        if (this.head !== before) {
          throw new Error("before doesn't belong to list");
        }
        this.head = item;
        before.prev = item;
        item.next = before;
        this.updateCursors(null, item);
      } else {
        before.prev.next = item;
        item.prev = before.prev;
        before.prev = item;
        item.next = before;
      }
    } else {
      this.updateCursors(this.tail, item, null, item);
      if (this.tail !== null) {
        this.tail.next = item;
        item.prev = this.tail;
      } else {
        this.head = item;
      }
      this.tail = item;
    }
    return this;
  }
  insertData(data2, before) {
    return this.insert(List$6.createItem(data2), before);
  }
  remove(item) {
    this.updateCursors(item, item.prev, item, item.next);
    if (item.prev !== null) {
      item.prev.next = item.next;
    } else {
      if (this.head !== item) {
        throw new Error("item doesn't belong to list");
      }
      this.head = item.next;
    }
    if (item.next !== null) {
      item.next.prev = item.prev;
    } else {
      if (this.tail !== item) {
        throw new Error("item doesn't belong to list");
      }
      this.tail = item.prev;
    }
    item.prev = null;
    item.next = null;
    return item;
  }
  push(data2) {
    this.insert(List$6.createItem(data2));
  }
  pop() {
    return this.tail !== null ? this.remove(this.tail) : null;
  }
  unshift(data2) {
    this.prepend(List$6.createItem(data2));
  }
  shift() {
    return this.head !== null ? this.remove(this.head) : null;
  }
  prependList(list) {
    return this.insertList(list, this.head);
  }
  appendList(list) {
    return this.insertList(list);
  }
  insertList(list, before) {
    if (list.head === null) {
      return this;
    }
    if (before !== void 0 && before !== null) {
      this.updateCursors(before.prev, list.tail, before, list.head);
      if (before.prev !== null) {
        before.prev.next = list.head;
        list.head.prev = before.prev;
      } else {
        this.head = list.head;
      }
      before.prev = list.tail;
      list.tail.next = before;
    } else {
      this.updateCursors(this.tail, list.tail, null, list.head);
      if (this.tail !== null) {
        this.tail.next = list.head;
        list.head.prev = this.tail;
      } else {
        this.head = list.head;
      }
      this.tail = list.tail;
    }
    list.head = null;
    list.tail = null;
    return this;
  }
  replace(oldItem, newItemOrList) {
    if ("head" in newItemOrList) {
      this.insertList(newItemOrList, oldItem);
    } else {
      this.insert(newItemOrList, oldItem);
    }
    this.remove(oldItem);
  }
}
List$7.List = List$6;
var _SyntaxError$1 = {};
var createCustomError$4 = {};
function createCustomError$3(name2, message) {
  const error2 = Object.create(SyntaxError.prototype);
  const errorStack = new Error();
  return Object.assign(error2, {
    name: name2,
    message,
    get stack() {
      return (errorStack.stack || "").replace(/^(.+\n){1,3}/, `${name2}: ${message}
`);
    }
  });
}
createCustomError$4.createCustomError = createCustomError$3;
const createCustomError$2 = createCustomError$4;
const MAX_LINE_LENGTH = 100;
const OFFSET_CORRECTION = 60;
const TAB_REPLACEMENT = "    ";
function sourceFragment({ source, line, column }, extraLines) {
  function processLines(start, end) {
    return lines.slice(start, end).map(
      (line2, idx) => String(start + idx + 1).padStart(maxNumLength) + " |" + line2
    ).join("\n");
  }
  const lines = source.split(/\r\n?|\n|\f/);
  const startLine = Math.max(1, line - extraLines) - 1;
  const endLine = Math.min(line + extraLines, lines.length + 1);
  const maxNumLength = Math.max(4, String(endLine).length) + 1;
  let cutLeft = 0;
  column += (TAB_REPLACEMENT.length - 1) * (lines[line - 1].substr(0, column - 1).match(/\t/g) || []).length;
  if (column > MAX_LINE_LENGTH) {
    cutLeft = column - OFFSET_CORRECTION + 3;
    column = OFFSET_CORRECTION - 2;
  }
  for (let i = startLine; i <= endLine; i++) {
    if (i >= 0 && i < lines.length) {
      lines[i] = lines[i].replace(/\t/g, TAB_REPLACEMENT);
      lines[i] = (cutLeft > 0 && lines[i].length > cutLeft ? "\u2026" : "") + lines[i].substr(cutLeft, MAX_LINE_LENGTH - 2) + (lines[i].length > cutLeft + MAX_LINE_LENGTH - 1 ? "\u2026" : "");
    }
  }
  return [
    processLines(startLine, line),
    new Array(column + maxNumLength + 2).join("-") + "^",
    processLines(line, endLine)
  ].filter(Boolean).join("\n");
}
function SyntaxError$5(message, source, offset, line, column) {
  const error2 = Object.assign(createCustomError$2.createCustomError("SyntaxError", message), {
    source,
    offset,
    line,
    column,
    sourceFragment(extraLines) {
      return sourceFragment({ source, line, column }, isNaN(extraLines) ? 0 : extraLines);
    },
    get formattedMessage() {
      return `Parse error: ${message}
` + sourceFragment({ source, line, column }, 2);
    }
  });
  return error2;
}
_SyntaxError$1.SyntaxError = SyntaxError$5;
var sequence$1 = {};
const types$O = types$R;
function readSequence$1(recognizer) {
  const children = this.createList();
  let space = false;
  const context = {
    recognizer
  };
  while (!this.eof) {
    switch (this.tokenType) {
      case types$O.Comment:
        this.next();
        continue;
      case types$O.WhiteSpace:
        space = true;
        this.next();
        continue;
    }
    let child = recognizer.getNode.call(this, context);
    if (child === void 0) {
      break;
    }
    if (space) {
      if (recognizer.onWhiteSpace) {
        recognizer.onWhiteSpace.call(this, child, children, context);
      }
      space = false;
    }
    children.push(child);
  }
  if (space && recognizer.onWhiteSpace) {
    recognizer.onWhiteSpace.call(this, null, children, context);
  }
  return children;
}
sequence$1.readSequence = readSequence$1;
const List$5 = List$7;
const SyntaxError$4 = _SyntaxError$1;
const index$b = tokenizer$2;
const sequence = sequence$1;
const OffsetToLocation = OffsetToLocation$3;
const TokenStream$1 = TokenStream$4;
const utils$h = utils$k;
const types$N = types$R;
const names$5 = names$8;
const NOOP = () => {
};
const EXCLAMATIONMARK$3 = 33;
const NUMBERSIGN$4 = 35;
const SEMICOLON = 59;
const LEFTCURLYBRACKET$1 = 123;
const NULL = 0;
function createParseContext(name2) {
  return function() {
    return this[name2]();
  };
}
function fetchParseValues(dict) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const name2 in dict) {
    const item = dict[name2];
    const fn = item.parse || item;
    if (fn) {
      result[name2] = fn;
    }
  }
  return result;
}
function processConfig(config2) {
  const parseConfig = {
    context: /* @__PURE__ */ Object.create(null),
    scope: Object.assign(/* @__PURE__ */ Object.create(null), config2.scope),
    atrule: fetchParseValues(config2.atrule),
    pseudo: fetchParseValues(config2.pseudo),
    node: fetchParseValues(config2.node)
  };
  for (const name2 in config2.parseContext) {
    switch (typeof config2.parseContext[name2]) {
      case "function":
        parseConfig.context[name2] = config2.parseContext[name2];
        break;
      case "string":
        parseConfig.context[name2] = createParseContext(config2.parseContext[name2]);
        break;
    }
  }
  return {
    config: parseConfig,
    ...parseConfig,
    ...parseConfig.node
  };
}
function createParser(config2) {
  let source = "";
  let filename = "<unknown>";
  let needPositions = false;
  let onParseError = NOOP;
  let onParseErrorThrow = false;
  const locationMap = new OffsetToLocation.OffsetToLocation();
  const parser2 = Object.assign(new TokenStream$1.TokenStream(), processConfig(config2 || {}), {
    parseAtrulePrelude: true,
    parseRulePrelude: true,
    parseValue: true,
    parseCustomProperty: false,
    readSequence: sequence.readSequence,
    consumeUntilBalanceEnd: () => 0,
    consumeUntilLeftCurlyBracket(code2) {
      return code2 === LEFTCURLYBRACKET$1 ? 1 : 0;
    },
    consumeUntilLeftCurlyBracketOrSemicolon(code2) {
      return code2 === LEFTCURLYBRACKET$1 || code2 === SEMICOLON ? 1 : 0;
    },
    consumeUntilExclamationMarkOrSemicolon(code2) {
      return code2 === EXCLAMATIONMARK$3 || code2 === SEMICOLON ? 1 : 0;
    },
    consumeUntilSemicolonIncluded(code2) {
      return code2 === SEMICOLON ? 2 : 0;
    },
    createList() {
      return new List$5.List();
    },
    createSingleNodeList(node2) {
      return new List$5.List().appendData(node2);
    },
    getFirstListNode(list) {
      return list && list.first;
    },
    getLastListNode(list) {
      return list && list.last;
    },
    parseWithFallback(consumer, fallback) {
      const startToken = this.tokenIndex;
      try {
        return consumer.call(this);
      } catch (e) {
        if (onParseErrorThrow) {
          throw e;
        }
        const fallbackNode = fallback.call(this, startToken);
        onParseErrorThrow = true;
        onParseError(e, fallbackNode);
        onParseErrorThrow = false;
        return fallbackNode;
      }
    },
    lookupNonWSType(offset) {
      let type;
      do {
        type = this.lookupType(offset++);
        if (type !== types$N.WhiteSpace) {
          return type;
        }
      } while (type !== NULL);
      return NULL;
    },
    charCodeAt(offset) {
      return offset >= 0 && offset < source.length ? source.charCodeAt(offset) : 0;
    },
    substring(offsetStart, offsetEnd) {
      return source.substring(offsetStart, offsetEnd);
    },
    substrToCursor(start) {
      return this.source.substring(start, this.tokenStart);
    },
    cmpChar(offset, charCode) {
      return utils$h.cmpChar(source, offset, charCode);
    },
    cmpStr(offsetStart, offsetEnd, str) {
      return utils$h.cmpStr(source, offsetStart, offsetEnd, str);
    },
    consume(tokenType2) {
      const start = this.tokenStart;
      this.eat(tokenType2);
      return this.substrToCursor(start);
    },
    consumeFunctionName() {
      const name2 = source.substring(this.tokenStart, this.tokenEnd - 1);
      this.eat(types$N.Function);
      return name2;
    },
    consumeNumber(type) {
      const number2 = source.substring(this.tokenStart, utils$h.consumeNumber(source, this.tokenStart));
      this.eat(type);
      return number2;
    },
    eat(tokenType2) {
      if (this.tokenType !== tokenType2) {
        const tokenName = names$5[tokenType2].slice(0, -6).replace(/-/g, " ").replace(/^./, (m) => m.toUpperCase());
        let message = `${/[[\](){}]/.test(tokenName) ? `"${tokenName}"` : tokenName} is expected`;
        let offset = this.tokenStart;
        switch (tokenType2) {
          case types$N.Ident:
            if (this.tokenType === types$N.Function || this.tokenType === types$N.Url) {
              offset = this.tokenEnd - 1;
              message = "Identifier is expected but function found";
            } else {
              message = "Identifier is expected";
            }
            break;
          case types$N.Hash:
            if (this.isDelim(NUMBERSIGN$4)) {
              this.next();
              offset++;
              message = "Name is expected";
            }
            break;
          case types$N.Percentage:
            if (this.tokenType === types$N.Number) {
              offset = this.tokenEnd;
              message = "Percent sign is expected";
            }
            break;
        }
        this.error(message, offset);
      }
      this.next();
    },
    eatIdent(name2) {
      if (this.tokenType !== types$N.Ident || this.lookupValue(0, name2) === false) {
        this.error(`Identifier "${name2}" is expected`);
      }
      this.next();
    },
    eatDelim(code2) {
      if (!this.isDelim(code2)) {
        this.error(`Delim "${String.fromCharCode(code2)}" is expected`);
      }
      this.next();
    },
    getLocation(start, end) {
      if (needPositions) {
        return locationMap.getLocationRange(
          start,
          end,
          filename
        );
      }
      return null;
    },
    getLocationFromList(list) {
      if (needPositions) {
        const head = this.getFirstListNode(list);
        const tail = this.getLastListNode(list);
        return locationMap.getLocationRange(
          head !== null ? head.loc.start.offset - locationMap.startOffset : this.tokenStart,
          tail !== null ? tail.loc.end.offset - locationMap.startOffset : this.tokenStart,
          filename
        );
      }
      return null;
    },
    error(message, offset) {
      const location = typeof offset !== "undefined" && offset < source.length ? locationMap.getLocation(offset) : this.eof ? locationMap.getLocation(utils$h.findWhiteSpaceStart(source, source.length - 1)) : locationMap.getLocation(this.tokenStart);
      throw new SyntaxError$4.SyntaxError(
        message || "Unexpected input",
        source,
        location.offset,
        location.line,
        location.column
      );
    }
  });
  const parse2 = function(source_, options) {
    source = source_;
    options = options || {};
    parser2.setSource(source, index$b.tokenize);
    locationMap.setSource(
      source,
      options.offset,
      options.line,
      options.column
    );
    filename = options.filename || "<unknown>";
    needPositions = Boolean(options.positions);
    onParseError = typeof options.onParseError === "function" ? options.onParseError : NOOP;
    onParseErrorThrow = false;
    parser2.parseAtrulePrelude = "parseAtrulePrelude" in options ? Boolean(options.parseAtrulePrelude) : true;
    parser2.parseRulePrelude = "parseRulePrelude" in options ? Boolean(options.parseRulePrelude) : true;
    parser2.parseValue = "parseValue" in options ? Boolean(options.parseValue) : true;
    parser2.parseCustomProperty = "parseCustomProperty" in options ? Boolean(options.parseCustomProperty) : false;
    const { context = "default", onComment } = options;
    if (context in parser2.context === false) {
      throw new Error("Unknown context `" + context + "`");
    }
    if (typeof onComment === "function") {
      parser2.forEachToken((type, start, end) => {
        if (type === types$N.Comment) {
          const loc = parser2.getLocation(start, end);
          const value2 = utils$h.cmpStr(source, end - 2, end, "*/") ? source.slice(start + 2, end - 2) : source.slice(start + 2, end);
          onComment(value2, loc);
        }
      });
    }
    const ast = parser2.context[context].call(parser2, options);
    if (!parser2.eof) {
      parser2.error();
    }
    return ast;
  };
  return Object.assign(parse2, {
    SyntaxError: SyntaxError$4.SyntaxError,
    config: parser2.config
  });
}
create$7.createParser = createParser;
var create$6 = {};
var sourceMap$1 = {};
var sourceMapGenerator = {};
var base64Vlq = {};
var base64$1 = {};
var intToCharMap = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
base64$1.encode = function(number2) {
  if (0 <= number2 && number2 < intToCharMap.length) {
    return intToCharMap[number2];
  }
  throw new TypeError("Must be between 0 and 63: " + number2);
};
base64$1.decode = function(charCode) {
  var bigA = 65;
  var bigZ = 90;
  var littleA = 97;
  var littleZ = 122;
  var zero2 = 48;
  var nine = 57;
  var plus = 43;
  var slash = 47;
  var littleOffset = 26;
  var numberOffset = 52;
  if (bigA <= charCode && charCode <= bigZ) {
    return charCode - bigA;
  }
  if (littleA <= charCode && charCode <= littleZ) {
    return charCode - littleA + littleOffset;
  }
  if (zero2 <= charCode && charCode <= nine) {
    return charCode - zero2 + numberOffset;
  }
  if (charCode == plus) {
    return 62;
  }
  if (charCode == slash) {
    return 63;
  }
  return -1;
};
var base64 = base64$1;
var VLQ_BASE_SHIFT = 5;
var VLQ_BASE = 1 << VLQ_BASE_SHIFT;
var VLQ_BASE_MASK = VLQ_BASE - 1;
var VLQ_CONTINUATION_BIT = VLQ_BASE;
function toVLQSigned(aValue) {
  return aValue < 0 ? (-aValue << 1) + 1 : (aValue << 1) + 0;
}
function fromVLQSigned(aValue) {
  var isNegative = (aValue & 1) === 1;
  var shifted = aValue >> 1;
  return isNegative ? -shifted : shifted;
}
base64Vlq.encode = function base64VLQ_encode(aValue) {
  var encoded = "";
  var digit;
  var vlq = toVLQSigned(aValue);
  do {
    digit = vlq & VLQ_BASE_MASK;
    vlq >>>= VLQ_BASE_SHIFT;
    if (vlq > 0) {
      digit |= VLQ_CONTINUATION_BIT;
    }
    encoded += base64.encode(digit);
  } while (vlq > 0);
  return encoded;
};
base64Vlq.decode = function base64VLQ_decode(aStr, aIndex, aOutParam) {
  var strLen = aStr.length;
  var result = 0;
  var shift = 0;
  var continuation, digit;
  do {
    if (aIndex >= strLen) {
      throw new Error("Expected more digits in base 64 VLQ value.");
    }
    digit = base64.decode(aStr.charCodeAt(aIndex++));
    if (digit === -1) {
      throw new Error("Invalid base64 digit: " + aStr.charAt(aIndex - 1));
    }
    continuation = !!(digit & VLQ_CONTINUATION_BIT);
    digit &= VLQ_BASE_MASK;
    result = result + (digit << shift);
    shift += VLQ_BASE_SHIFT;
  } while (continuation);
  aOutParam.value = fromVLQSigned(result);
  aOutParam.rest = aIndex;
};
var util$3 = {};
(function(exports) {
  function getArg(aArgs, aName, aDefaultValue) {
    if (aName in aArgs) {
      return aArgs[aName];
    } else if (arguments.length === 3) {
      return aDefaultValue;
    } else {
      throw new Error('"' + aName + '" is a required argument.');
    }
  }
  exports.getArg = getArg;
  var urlRegexp = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/;
  var dataUrlRegexp = /^data:.+\,.+$/;
  function urlParse(aUrl) {
    var match2 = aUrl.match(urlRegexp);
    if (!match2) {
      return null;
    }
    return {
      scheme: match2[1],
      auth: match2[2],
      host: match2[3],
      port: match2[4],
      path: match2[5]
    };
  }
  exports.urlParse = urlParse;
  function urlGenerate(aParsedUrl) {
    var url2 = "";
    if (aParsedUrl.scheme) {
      url2 += aParsedUrl.scheme + ":";
    }
    url2 += "//";
    if (aParsedUrl.auth) {
      url2 += aParsedUrl.auth + "@";
    }
    if (aParsedUrl.host) {
      url2 += aParsedUrl.host;
    }
    if (aParsedUrl.port) {
      url2 += ":" + aParsedUrl.port;
    }
    if (aParsedUrl.path) {
      url2 += aParsedUrl.path;
    }
    return url2;
  }
  exports.urlGenerate = urlGenerate;
  var MAX_CACHED_INPUTS = 32;
  function lruMemoize(f) {
    var cache = [];
    return function(input) {
      for (var i = 0; i < cache.length; i++) {
        if (cache[i].input === input) {
          var temp = cache[0];
          cache[0] = cache[i];
          cache[i] = temp;
          return cache[0].result;
        }
      }
      var result = f(input);
      cache.unshift({
        input,
        result
      });
      if (cache.length > MAX_CACHED_INPUTS) {
        cache.pop();
      }
      return result;
    };
  }
  var normalize = lruMemoize(function normalize2(aPath) {
    var path2 = aPath;
    var url2 = urlParse(aPath);
    if (url2) {
      if (!url2.path) {
        return aPath;
      }
      path2 = url2.path;
    }
    var isAbsolute = exports.isAbsolute(path2);
    var parts = [];
    var start = 0;
    var i = 0;
    while (true) {
      start = i;
      i = path2.indexOf("/", start);
      if (i === -1) {
        parts.push(path2.slice(start));
        break;
      } else {
        parts.push(path2.slice(start, i));
        while (i < path2.length && path2[i] === "/") {
          i++;
        }
      }
    }
    for (var part, up = 0, i = parts.length - 1; i >= 0; i--) {
      part = parts[i];
      if (part === ".") {
        parts.splice(i, 1);
      } else if (part === "..") {
        up++;
      } else if (up > 0) {
        if (part === "") {
          parts.splice(i + 1, up);
          up = 0;
        } else {
          parts.splice(i, 2);
          up--;
        }
      }
    }
    path2 = parts.join("/");
    if (path2 === "") {
      path2 = isAbsolute ? "/" : ".";
    }
    if (url2) {
      url2.path = path2;
      return urlGenerate(url2);
    }
    return path2;
  });
  exports.normalize = normalize;
  function join(aRoot, aPath) {
    if (aRoot === "") {
      aRoot = ".";
    }
    if (aPath === "") {
      aPath = ".";
    }
    var aPathUrl = urlParse(aPath);
    var aRootUrl = urlParse(aRoot);
    if (aRootUrl) {
      aRoot = aRootUrl.path || "/";
    }
    if (aPathUrl && !aPathUrl.scheme) {
      if (aRootUrl) {
        aPathUrl.scheme = aRootUrl.scheme;
      }
      return urlGenerate(aPathUrl);
    }
    if (aPathUrl || aPath.match(dataUrlRegexp)) {
      return aPath;
    }
    if (aRootUrl && !aRootUrl.host && !aRootUrl.path) {
      aRootUrl.host = aPath;
      return urlGenerate(aRootUrl);
    }
    var joined = aPath.charAt(0) === "/" ? aPath : normalize(aRoot.replace(/\/+$/, "") + "/" + aPath);
    if (aRootUrl) {
      aRootUrl.path = joined;
      return urlGenerate(aRootUrl);
    }
    return joined;
  }
  exports.join = join;
  exports.isAbsolute = function(aPath) {
    return aPath.charAt(0) === "/" || urlRegexp.test(aPath);
  };
  function relative(aRoot, aPath) {
    if (aRoot === "") {
      aRoot = ".";
    }
    aRoot = aRoot.replace(/\/$/, "");
    var level = 0;
    while (aPath.indexOf(aRoot + "/") !== 0) {
      var index2 = aRoot.lastIndexOf("/");
      if (index2 < 0) {
        return aPath;
      }
      aRoot = aRoot.slice(0, index2);
      if (aRoot.match(/^([^\/]+:\/)?\/*$/)) {
        return aPath;
      }
      ++level;
    }
    return Array(level + 1).join("../") + aPath.substr(aRoot.length + 1);
  }
  exports.relative = relative;
  var supportsNullProto = function() {
    var obj = /* @__PURE__ */ Object.create(null);
    return !("__proto__" in obj);
  }();
  function identity(s) {
    return s;
  }
  function toSetString(aStr) {
    if (isProtoString(aStr)) {
      return "$" + aStr;
    }
    return aStr;
  }
  exports.toSetString = supportsNullProto ? identity : toSetString;
  function fromSetString(aStr) {
    if (isProtoString(aStr)) {
      return aStr.slice(1);
    }
    return aStr;
  }
  exports.fromSetString = supportsNullProto ? identity : fromSetString;
  function isProtoString(s) {
    if (!s) {
      return false;
    }
    var length = s.length;
    if (length < 9) {
      return false;
    }
    if (s.charCodeAt(length - 1) !== 95 || s.charCodeAt(length - 2) !== 95 || s.charCodeAt(length - 3) !== 111 || s.charCodeAt(length - 4) !== 116 || s.charCodeAt(length - 5) !== 111 || s.charCodeAt(length - 6) !== 114 || s.charCodeAt(length - 7) !== 112 || s.charCodeAt(length - 8) !== 95 || s.charCodeAt(length - 9) !== 95) {
      return false;
    }
    for (var i = length - 10; i >= 0; i--) {
      if (s.charCodeAt(i) !== 36) {
        return false;
      }
    }
    return true;
  }
  function compareByOriginalPositions(mappingA, mappingB, onlyCompareOriginal) {
    var cmp = strcmp(mappingA.source, mappingB.source);
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (cmp !== 0 || onlyCompareOriginal) {
      return cmp;
    }
    cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.generatedLine - mappingB.generatedLine;
    if (cmp !== 0) {
      return cmp;
    }
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByOriginalPositions = compareByOriginalPositions;
  function compareByOriginalPositionsNoSource(mappingA, mappingB, onlyCompareOriginal) {
    var cmp;
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (cmp !== 0 || onlyCompareOriginal) {
      return cmp;
    }
    cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.generatedLine - mappingB.generatedLine;
    if (cmp !== 0) {
      return cmp;
    }
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByOriginalPositionsNoSource = compareByOriginalPositionsNoSource;
  function compareByGeneratedPositionsDeflated(mappingA, mappingB, onlyCompareGenerated) {
    var cmp = mappingA.generatedLine - mappingB.generatedLine;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (cmp !== 0 || onlyCompareGenerated) {
      return cmp;
    }
    cmp = strcmp(mappingA.source, mappingB.source);
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (cmp !== 0) {
      return cmp;
    }
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByGeneratedPositionsDeflated = compareByGeneratedPositionsDeflated;
  function compareByGeneratedPositionsDeflatedNoLine(mappingA, mappingB, onlyCompareGenerated) {
    var cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (cmp !== 0 || onlyCompareGenerated) {
      return cmp;
    }
    cmp = strcmp(mappingA.source, mappingB.source);
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (cmp !== 0) {
      return cmp;
    }
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByGeneratedPositionsDeflatedNoLine = compareByGeneratedPositionsDeflatedNoLine;
  function strcmp(aStr1, aStr2) {
    if (aStr1 === aStr2) {
      return 0;
    }
    if (aStr1 === null) {
      return 1;
    }
    if (aStr2 === null) {
      return -1;
    }
    if (aStr1 > aStr2) {
      return 1;
    }
    return -1;
  }
  function compareByGeneratedPositionsInflated(mappingA, mappingB) {
    var cmp = mappingA.generatedLine - mappingB.generatedLine;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = strcmp(mappingA.source, mappingB.source);
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (cmp !== 0) {
      return cmp;
    }
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (cmp !== 0) {
      return cmp;
    }
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByGeneratedPositionsInflated = compareByGeneratedPositionsInflated;
  function parseSourceMapInput(str) {
    return JSON.parse(str.replace(/^\)]}'[^\n]*\n/, ""));
  }
  exports.parseSourceMapInput = parseSourceMapInput;
  function computeSourceURL(sourceRoot, sourceURL, sourceMapURL) {
    sourceURL = sourceURL || "";
    if (sourceRoot) {
      if (sourceRoot[sourceRoot.length - 1] !== "/" && sourceURL[0] !== "/") {
        sourceRoot += "/";
      }
      sourceURL = sourceRoot + sourceURL;
    }
    if (sourceMapURL) {
      var parsed = urlParse(sourceMapURL);
      if (!parsed) {
        throw new Error("sourceMapURL could not be parsed");
      }
      if (parsed.path) {
        var index2 = parsed.path.lastIndexOf("/");
        if (index2 >= 0) {
          parsed.path = parsed.path.substring(0, index2 + 1);
        }
      }
      sourceURL = join(urlGenerate(parsed), sourceURL);
    }
    return normalize(sourceURL);
  }
  exports.computeSourceURL = computeSourceURL;
})(util$3);
var arraySet = {};
var util$2 = util$3;
var has = Object.prototype.hasOwnProperty;
var hasNativeMap = typeof Map !== "undefined";
function ArraySet$1() {
  this._array = [];
  this._set = hasNativeMap ? /* @__PURE__ */ new Map() : /* @__PURE__ */ Object.create(null);
}
ArraySet$1.fromArray = function ArraySet_fromArray(aArray, aAllowDuplicates) {
  var set2 = new ArraySet$1();
  for (var i = 0, len = aArray.length; i < len; i++) {
    set2.add(aArray[i], aAllowDuplicates);
  }
  return set2;
};
ArraySet$1.prototype.size = function ArraySet_size() {
  return hasNativeMap ? this._set.size : Object.getOwnPropertyNames(this._set).length;
};
ArraySet$1.prototype.add = function ArraySet_add(aStr, aAllowDuplicates) {
  var sStr = hasNativeMap ? aStr : util$2.toSetString(aStr);
  var isDuplicate = hasNativeMap ? this.has(aStr) : has.call(this._set, sStr);
  var idx = this._array.length;
  if (!isDuplicate || aAllowDuplicates) {
    this._array.push(aStr);
  }
  if (!isDuplicate) {
    if (hasNativeMap) {
      this._set.set(aStr, idx);
    } else {
      this._set[sStr] = idx;
    }
  }
};
ArraySet$1.prototype.has = function ArraySet_has(aStr) {
  if (hasNativeMap) {
    return this._set.has(aStr);
  } else {
    var sStr = util$2.toSetString(aStr);
    return has.call(this._set, sStr);
  }
};
ArraySet$1.prototype.indexOf = function ArraySet_indexOf(aStr) {
  if (hasNativeMap) {
    var idx = this._set.get(aStr);
    if (idx >= 0) {
      return idx;
    }
  } else {
    var sStr = util$2.toSetString(aStr);
    if (has.call(this._set, sStr)) {
      return this._set[sStr];
    }
  }
  throw new Error('"' + aStr + '" is not in the set.');
};
ArraySet$1.prototype.at = function ArraySet_at(aIdx) {
  if (aIdx >= 0 && aIdx < this._array.length) {
    return this._array[aIdx];
  }
  throw new Error("No element indexed by " + aIdx);
};
ArraySet$1.prototype.toArray = function ArraySet_toArray() {
  return this._array.slice();
};
arraySet.ArraySet = ArraySet$1;
var mappingList = {};
var util$1 = util$3;
function generatedPositionAfter(mappingA, mappingB) {
  var lineA = mappingA.generatedLine;
  var lineB = mappingB.generatedLine;
  var columnA = mappingA.generatedColumn;
  var columnB = mappingB.generatedColumn;
  return lineB > lineA || lineB == lineA && columnB >= columnA || util$1.compareByGeneratedPositionsInflated(mappingA, mappingB) <= 0;
}
function MappingList$1() {
  this._array = [];
  this._sorted = true;
  this._last = { generatedLine: -1, generatedColumn: 0 };
}
MappingList$1.prototype.unsortedForEach = function MappingList_forEach(aCallback, aThisArg) {
  this._array.forEach(aCallback, aThisArg);
};
MappingList$1.prototype.add = function MappingList_add(aMapping) {
  if (generatedPositionAfter(this._last, aMapping)) {
    this._last = aMapping;
    this._array.push(aMapping);
  } else {
    this._sorted = false;
    this._array.push(aMapping);
  }
};
MappingList$1.prototype.toArray = function MappingList_toArray() {
  if (!this._sorted) {
    this._array.sort(util$1.compareByGeneratedPositionsInflated);
    this._sorted = true;
  }
  return this._array;
};
mappingList.MappingList = MappingList$1;
var base64VLQ = base64Vlq;
var util = util$3;
var ArraySet = arraySet.ArraySet;
var MappingList = mappingList.MappingList;
function SourceMapGenerator(aArgs) {
  if (!aArgs) {
    aArgs = {};
  }
  this._file = util.getArg(aArgs, "file", null);
  this._sourceRoot = util.getArg(aArgs, "sourceRoot", null);
  this._skipValidation = util.getArg(aArgs, "skipValidation", false);
  this._sources = new ArraySet();
  this._names = new ArraySet();
  this._mappings = new MappingList();
  this._sourcesContents = null;
}
SourceMapGenerator.prototype._version = 3;
SourceMapGenerator.fromSourceMap = function SourceMapGenerator_fromSourceMap(aSourceMapConsumer) {
  var sourceRoot = aSourceMapConsumer.sourceRoot;
  var generator = new SourceMapGenerator({
    file: aSourceMapConsumer.file,
    sourceRoot
  });
  aSourceMapConsumer.eachMapping(function(mapping) {
    var newMapping = {
      generated: {
        line: mapping.generatedLine,
        column: mapping.generatedColumn
      }
    };
    if (mapping.source != null) {
      newMapping.source = mapping.source;
      if (sourceRoot != null) {
        newMapping.source = util.relative(sourceRoot, newMapping.source);
      }
      newMapping.original = {
        line: mapping.originalLine,
        column: mapping.originalColumn
      };
      if (mapping.name != null) {
        newMapping.name = mapping.name;
      }
    }
    generator.addMapping(newMapping);
  });
  aSourceMapConsumer.sources.forEach(function(sourceFile) {
    var sourceRelative = sourceFile;
    if (sourceRoot !== null) {
      sourceRelative = util.relative(sourceRoot, sourceFile);
    }
    if (!generator._sources.has(sourceRelative)) {
      generator._sources.add(sourceRelative);
    }
    var content = aSourceMapConsumer.sourceContentFor(sourceFile);
    if (content != null) {
      generator.setSourceContent(sourceFile, content);
    }
  });
  return generator;
};
SourceMapGenerator.prototype.addMapping = function SourceMapGenerator_addMapping(aArgs) {
  var generated = util.getArg(aArgs, "generated");
  var original = util.getArg(aArgs, "original", null);
  var source = util.getArg(aArgs, "source", null);
  var name2 = util.getArg(aArgs, "name", null);
  if (!this._skipValidation) {
    this._validateMapping(generated, original, source, name2);
  }
  if (source != null) {
    source = String(source);
    if (!this._sources.has(source)) {
      this._sources.add(source);
    }
  }
  if (name2 != null) {
    name2 = String(name2);
    if (!this._names.has(name2)) {
      this._names.add(name2);
    }
  }
  this._mappings.add({
    generatedLine: generated.line,
    generatedColumn: generated.column,
    originalLine: original != null && original.line,
    originalColumn: original != null && original.column,
    source,
    name: name2
  });
};
SourceMapGenerator.prototype.setSourceContent = function SourceMapGenerator_setSourceContent(aSourceFile, aSourceContent) {
  var source = aSourceFile;
  if (this._sourceRoot != null) {
    source = util.relative(this._sourceRoot, source);
  }
  if (aSourceContent != null) {
    if (!this._sourcesContents) {
      this._sourcesContents = /* @__PURE__ */ Object.create(null);
    }
    this._sourcesContents[util.toSetString(source)] = aSourceContent;
  } else if (this._sourcesContents) {
    delete this._sourcesContents[util.toSetString(source)];
    if (Object.keys(this._sourcesContents).length === 0) {
      this._sourcesContents = null;
    }
  }
};
SourceMapGenerator.prototype.applySourceMap = function SourceMapGenerator_applySourceMap(aSourceMapConsumer, aSourceFile, aSourceMapPath) {
  var sourceFile = aSourceFile;
  if (aSourceFile == null) {
    if (aSourceMapConsumer.file == null) {
      throw new Error(
        `SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map's "file" property. Both were omitted.`
      );
    }
    sourceFile = aSourceMapConsumer.file;
  }
  var sourceRoot = this._sourceRoot;
  if (sourceRoot != null) {
    sourceFile = util.relative(sourceRoot, sourceFile);
  }
  var newSources = new ArraySet();
  var newNames = new ArraySet();
  this._mappings.unsortedForEach(function(mapping) {
    if (mapping.source === sourceFile && mapping.originalLine != null) {
      var original = aSourceMapConsumer.originalPositionFor({
        line: mapping.originalLine,
        column: mapping.originalColumn
      });
      if (original.source != null) {
        mapping.source = original.source;
        if (aSourceMapPath != null) {
          mapping.source = util.join(aSourceMapPath, mapping.source);
        }
        if (sourceRoot != null) {
          mapping.source = util.relative(sourceRoot, mapping.source);
        }
        mapping.originalLine = original.line;
        mapping.originalColumn = original.column;
        if (original.name != null) {
          mapping.name = original.name;
        }
      }
    }
    var source = mapping.source;
    if (source != null && !newSources.has(source)) {
      newSources.add(source);
    }
    var name2 = mapping.name;
    if (name2 != null && !newNames.has(name2)) {
      newNames.add(name2);
    }
  }, this);
  this._sources = newSources;
  this._names = newNames;
  aSourceMapConsumer.sources.forEach(function(sourceFile2) {
    var content = aSourceMapConsumer.sourceContentFor(sourceFile2);
    if (content != null) {
      if (aSourceMapPath != null) {
        sourceFile2 = util.join(aSourceMapPath, sourceFile2);
      }
      if (sourceRoot != null) {
        sourceFile2 = util.relative(sourceRoot, sourceFile2);
      }
      this.setSourceContent(sourceFile2, content);
    }
  }, this);
};
SourceMapGenerator.prototype._validateMapping = function SourceMapGenerator_validateMapping(aGenerated, aOriginal, aSource, aName) {
  if (aOriginal && typeof aOriginal.line !== "number" && typeof aOriginal.column !== "number") {
    throw new Error(
      "original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values."
    );
  }
  if (aGenerated && "line" in aGenerated && "column" in aGenerated && aGenerated.line > 0 && aGenerated.column >= 0 && !aOriginal && !aSource && !aName) {
    return;
  } else if (aGenerated && "line" in aGenerated && "column" in aGenerated && aOriginal && "line" in aOriginal && "column" in aOriginal && aGenerated.line > 0 && aGenerated.column >= 0 && aOriginal.line > 0 && aOriginal.column >= 0 && aSource) {
    return;
  } else {
    throw new Error("Invalid mapping: " + JSON.stringify({
      generated: aGenerated,
      source: aSource,
      original: aOriginal,
      name: aName
    }));
  }
};
SourceMapGenerator.prototype._serializeMappings = function SourceMapGenerator_serializeMappings() {
  var previousGeneratedColumn = 0;
  var previousGeneratedLine = 1;
  var previousOriginalColumn = 0;
  var previousOriginalLine = 0;
  var previousName = 0;
  var previousSource = 0;
  var result = "";
  var next;
  var mapping;
  var nameIdx;
  var sourceIdx;
  var mappings = this._mappings.toArray();
  for (var i = 0, len = mappings.length; i < len; i++) {
    mapping = mappings[i];
    next = "";
    if (mapping.generatedLine !== previousGeneratedLine) {
      previousGeneratedColumn = 0;
      while (mapping.generatedLine !== previousGeneratedLine) {
        next += ";";
        previousGeneratedLine++;
      }
    } else {
      if (i > 0) {
        if (!util.compareByGeneratedPositionsInflated(mapping, mappings[i - 1])) {
          continue;
        }
        next += ",";
      }
    }
    next += base64VLQ.encode(mapping.generatedColumn - previousGeneratedColumn);
    previousGeneratedColumn = mapping.generatedColumn;
    if (mapping.source != null) {
      sourceIdx = this._sources.indexOf(mapping.source);
      next += base64VLQ.encode(sourceIdx - previousSource);
      previousSource = sourceIdx;
      next += base64VLQ.encode(mapping.originalLine - 1 - previousOriginalLine);
      previousOriginalLine = mapping.originalLine - 1;
      next += base64VLQ.encode(mapping.originalColumn - previousOriginalColumn);
      previousOriginalColumn = mapping.originalColumn;
      if (mapping.name != null) {
        nameIdx = this._names.indexOf(mapping.name);
        next += base64VLQ.encode(nameIdx - previousName);
        previousName = nameIdx;
      }
    }
    result += next;
  }
  return result;
};
SourceMapGenerator.prototype._generateSourcesContent = function SourceMapGenerator_generateSourcesContent(aSources, aSourceRoot) {
  return aSources.map(function(source) {
    if (!this._sourcesContents) {
      return null;
    }
    if (aSourceRoot != null) {
      source = util.relative(aSourceRoot, source);
    }
    var key = util.toSetString(source);
    return Object.prototype.hasOwnProperty.call(this._sourcesContents, key) ? this._sourcesContents[key] : null;
  }, this);
};
SourceMapGenerator.prototype.toJSON = function SourceMapGenerator_toJSON() {
  var map = {
    version: this._version,
    sources: this._sources.toArray(),
    names: this._names.toArray(),
    mappings: this._serializeMappings()
  };
  if (this._file != null) {
    map.file = this._file;
  }
  if (this._sourceRoot != null) {
    map.sourceRoot = this._sourceRoot;
  }
  if (this._sourcesContents) {
    map.sourcesContent = this._generateSourcesContent(map.sources, map.sourceRoot);
  }
  return map;
};
SourceMapGenerator.prototype.toString = function SourceMapGenerator_toString() {
  return JSON.stringify(this.toJSON());
};
sourceMapGenerator.SourceMapGenerator = SourceMapGenerator;
const sourceMapGenerator_js = sourceMapGenerator;
const trackNodes = /* @__PURE__ */ new Set(["Atrule", "Selector", "Declaration"]);
function generateSourceMap(handlers2) {
  const map = new sourceMapGenerator_js.SourceMapGenerator();
  const generated = {
    line: 1,
    column: 0
  };
  const original = {
    line: 0,
    column: 0
  };
  const activatedGenerated = {
    line: 1,
    column: 0
  };
  const activatedMapping = {
    generated: activatedGenerated
  };
  let line = 1;
  let column = 0;
  let sourceMappingActive = false;
  const origHandlersNode = handlers2.node;
  handlers2.node = function(node2) {
    if (node2.loc && node2.loc.start && trackNodes.has(node2.type)) {
      const nodeLine = node2.loc.start.line;
      const nodeColumn = node2.loc.start.column - 1;
      if (original.line !== nodeLine || original.column !== nodeColumn) {
        original.line = nodeLine;
        original.column = nodeColumn;
        generated.line = line;
        generated.column = column;
        if (sourceMappingActive) {
          sourceMappingActive = false;
          if (generated.line !== activatedGenerated.line || generated.column !== activatedGenerated.column) {
            map.addMapping(activatedMapping);
          }
        }
        sourceMappingActive = true;
        map.addMapping({
          source: node2.loc.source,
          original,
          generated
        });
      }
    }
    origHandlersNode.call(this, node2);
    if (sourceMappingActive && trackNodes.has(node2.type)) {
      activatedGenerated.line = line;
      activatedGenerated.column = column;
    }
  };
  const origHandlersEmit = handlers2.emit;
  handlers2.emit = function(value2, type, auto) {
    for (let i = 0; i < value2.length; i++) {
      if (value2.charCodeAt(i) === 10) {
        line++;
        column = 0;
      } else {
        column++;
      }
    }
    origHandlersEmit(value2, type, auto);
  };
  const origHandlersResult = handlers2.result;
  handlers2.result = function() {
    if (sourceMappingActive) {
      map.addMapping(activatedMapping);
    }
    return {
      css: origHandlersResult(),
      map
    };
  };
  return handlers2;
}
sourceMap$1.generateSourceMap = generateSourceMap;
var tokenBefore$1 = {};
const types$M = types$R;
const PLUSSIGN$9 = 43;
const HYPHENMINUS$6 = 45;
const code = (type, value2) => {
  if (type === types$M.Delim) {
    type = value2;
  }
  if (typeof type === "string") {
    const charCode = type.charCodeAt(0);
    return charCode > 127 ? 32768 : charCode << 8;
  }
  return type;
};
const specPairs = [
  [types$M.Ident, types$M.Ident],
  [types$M.Ident, types$M.Function],
  [types$M.Ident, types$M.Url],
  [types$M.Ident, types$M.BadUrl],
  [types$M.Ident, "-"],
  [types$M.Ident, types$M.Number],
  [types$M.Ident, types$M.Percentage],
  [types$M.Ident, types$M.Dimension],
  [types$M.Ident, types$M.CDC],
  [types$M.Ident, types$M.LeftParenthesis],
  [types$M.AtKeyword, types$M.Ident],
  [types$M.AtKeyword, types$M.Function],
  [types$M.AtKeyword, types$M.Url],
  [types$M.AtKeyword, types$M.BadUrl],
  [types$M.AtKeyword, "-"],
  [types$M.AtKeyword, types$M.Number],
  [types$M.AtKeyword, types$M.Percentage],
  [types$M.AtKeyword, types$M.Dimension],
  [types$M.AtKeyword, types$M.CDC],
  [types$M.Hash, types$M.Ident],
  [types$M.Hash, types$M.Function],
  [types$M.Hash, types$M.Url],
  [types$M.Hash, types$M.BadUrl],
  [types$M.Hash, "-"],
  [types$M.Hash, types$M.Number],
  [types$M.Hash, types$M.Percentage],
  [types$M.Hash, types$M.Dimension],
  [types$M.Hash, types$M.CDC],
  [types$M.Dimension, types$M.Ident],
  [types$M.Dimension, types$M.Function],
  [types$M.Dimension, types$M.Url],
  [types$M.Dimension, types$M.BadUrl],
  [types$M.Dimension, "-"],
  [types$M.Dimension, types$M.Number],
  [types$M.Dimension, types$M.Percentage],
  [types$M.Dimension, types$M.Dimension],
  [types$M.Dimension, types$M.CDC],
  ["#", types$M.Ident],
  ["#", types$M.Function],
  ["#", types$M.Url],
  ["#", types$M.BadUrl],
  ["#", "-"],
  ["#", types$M.Number],
  ["#", types$M.Percentage],
  ["#", types$M.Dimension],
  ["#", types$M.CDC],
  ["-", types$M.Ident],
  ["-", types$M.Function],
  ["-", types$M.Url],
  ["-", types$M.BadUrl],
  ["-", "-"],
  ["-", types$M.Number],
  ["-", types$M.Percentage],
  ["-", types$M.Dimension],
  ["-", types$M.CDC],
  [types$M.Number, types$M.Ident],
  [types$M.Number, types$M.Function],
  [types$M.Number, types$M.Url],
  [types$M.Number, types$M.BadUrl],
  [types$M.Number, types$M.Number],
  [types$M.Number, types$M.Percentage],
  [types$M.Number, types$M.Dimension],
  [types$M.Number, "%"],
  [types$M.Number, types$M.CDC],
  ["@", types$M.Ident],
  ["@", types$M.Function],
  ["@", types$M.Url],
  ["@", types$M.BadUrl],
  ["@", "-"],
  ["@", types$M.CDC],
  [".", types$M.Number],
  [".", types$M.Percentage],
  [".", types$M.Dimension],
  ["+", types$M.Number],
  ["+", types$M.Percentage],
  ["+", types$M.Dimension],
  ["/", "*"]
];
const safePairs = specPairs.concat([
  [types$M.Ident, types$M.Hash],
  [types$M.Dimension, types$M.Hash],
  [types$M.Hash, types$M.Hash],
  [types$M.AtKeyword, types$M.LeftParenthesis],
  [types$M.AtKeyword, types$M.String],
  [types$M.AtKeyword, types$M.Colon],
  [types$M.Percentage, types$M.Percentage],
  [types$M.Percentage, types$M.Dimension],
  [types$M.Percentage, types$M.Function],
  [types$M.Percentage, "-"],
  [types$M.RightParenthesis, types$M.Ident],
  [types$M.RightParenthesis, types$M.Function],
  [types$M.RightParenthesis, types$M.Percentage],
  [types$M.RightParenthesis, types$M.Dimension],
  [types$M.RightParenthesis, types$M.Hash],
  [types$M.RightParenthesis, "-"]
]);
function createMap(pairs) {
  const isWhiteSpaceRequired = new Set(
    pairs.map(([prev, next]) => code(prev) << 16 | code(next))
  );
  return function(prevCode, type, value2) {
    const nextCode = code(type, value2);
    const nextCharCode = value2.charCodeAt(0);
    const emitWs = nextCharCode === HYPHENMINUS$6 && type !== types$M.Ident && type !== types$M.Function && type !== types$M.CDC || nextCharCode === PLUSSIGN$9 ? isWhiteSpaceRequired.has(prevCode << 16 | nextCharCode << 8) : isWhiteSpaceRequired.has(prevCode << 16 | nextCode);
    if (emitWs) {
      this.emit(" ", types$M.WhiteSpace, true);
    }
    return nextCode;
  };
}
const spec = createMap(specPairs);
const safe = createMap(safePairs);
tokenBefore$1.safe = safe;
tokenBefore$1.spec = spec;
const index$a = tokenizer$2;
const sourceMap = sourceMap$1;
const tokenBefore = tokenBefore$1;
const types$L = types$R;
const REVERSESOLIDUS = 92;
function processChildren(node2, delimeter) {
  if (typeof delimeter === "function") {
    let prev = null;
    node2.children.forEach((node3) => {
      if (prev !== null) {
        delimeter.call(this, prev);
      }
      this.node(node3);
      prev = node3;
    });
    return;
  }
  node2.children.forEach(this.node, this);
}
function processChunk(chunk) {
  index$a.tokenize(chunk, (type, start, end) => {
    this.token(type, chunk.slice(start, end));
  });
}
function createGenerator(config2) {
  const types$12 = /* @__PURE__ */ new Map();
  for (let name2 in config2.node) {
    const item = config2.node[name2];
    const fn = item.generate || item;
    if (typeof fn === "function") {
      types$12.set(name2, item.generate || item);
    }
  }
  return function(node2, options) {
    let buffer = "";
    let prevCode = 0;
    let handlers2 = {
      node(node3) {
        if (types$12.has(node3.type)) {
          types$12.get(node3.type).call(publicApi, node3);
        } else {
          throw new Error("Unknown node type: " + node3.type);
        }
      },
      tokenBefore: tokenBefore.safe,
      token(type, value2) {
        prevCode = this.tokenBefore(prevCode, type, value2);
        this.emit(value2, type, false);
        if (type === types$L.Delim && value2.charCodeAt(0) === REVERSESOLIDUS) {
          this.emit("\n", types$L.WhiteSpace, true);
        }
      },
      emit(value2) {
        buffer += value2;
      },
      result() {
        return buffer;
      }
    };
    if (options) {
      if (typeof options.decorator === "function") {
        handlers2 = options.decorator(handlers2);
      }
      if (options.sourceMap) {
        handlers2 = sourceMap.generateSourceMap(handlers2);
      }
      if (options.mode in tokenBefore) {
        handlers2.tokenBefore = tokenBefore[options.mode];
      }
    }
    const publicApi = {
      node: (node3) => handlers2.node(node3),
      children: processChildren,
      token: (type, value2) => handlers2.token(type, value2),
      tokenize: processChunk
    };
    handlers2.node(node2);
    return handlers2.result();
  };
}
create$6.createGenerator = createGenerator;
var create$5 = {};
const List$4 = List$7;
function createConvertor(walk2) {
  return {
    fromPlainObject(ast) {
      walk2(ast, {
        enter(node2) {
          if (node2.children && node2.children instanceof List$4.List === false) {
            node2.children = new List$4.List().fromArray(node2.children);
          }
        }
      });
      return ast;
    },
    toPlainObject(ast) {
      walk2(ast, {
        leave(node2) {
          if (node2.children && node2.children instanceof List$4.List) {
            node2.children = node2.children.toArray();
          }
        }
      });
      return ast;
    }
  };
}
create$5.createConvertor = createConvertor;
var create$4 = {};
const { hasOwnProperty: hasOwnProperty$8 } = Object.prototype;
const noop$2 = function() {
};
function ensureFunction$1(value2) {
  return typeof value2 === "function" ? value2 : noop$2;
}
function invokeForType(fn, type) {
  return function(node2, item, list) {
    if (node2.type === type) {
      fn.call(this, node2, item, list);
    }
  };
}
function getWalkersFromStructure(name2, nodeType) {
  const structure2 = nodeType.structure;
  const walkers = [];
  for (const key in structure2) {
    if (hasOwnProperty$8.call(structure2, key) === false) {
      continue;
    }
    let fieldTypes = structure2[key];
    const walker2 = {
      name: key,
      type: false,
      nullable: false
    };
    if (!Array.isArray(fieldTypes)) {
      fieldTypes = [fieldTypes];
    }
    for (const fieldType of fieldTypes) {
      if (fieldType === null) {
        walker2.nullable = true;
      } else if (typeof fieldType === "string") {
        walker2.type = "node";
      } else if (Array.isArray(fieldType)) {
        walker2.type = "list";
      }
    }
    if (walker2.type) {
      walkers.push(walker2);
    }
  }
  if (walkers.length) {
    return {
      context: nodeType.walkContext,
      fields: walkers
    };
  }
  return null;
}
function getTypesFromConfig(config2) {
  const types2 = {};
  for (const name2 in config2.node) {
    if (hasOwnProperty$8.call(config2.node, name2)) {
      const nodeType = config2.node[name2];
      if (!nodeType.structure) {
        throw new Error("Missed `structure` field in `" + name2 + "` node type definition");
      }
      types2[name2] = getWalkersFromStructure(name2, nodeType);
    }
  }
  return types2;
}
function createTypeIterator(config2, reverse) {
  const fields = config2.fields.slice();
  const contextName = config2.context;
  const useContext = typeof contextName === "string";
  if (reverse) {
    fields.reverse();
  }
  return function(node2, context, walk2, walkReducer) {
    let prevContextValue;
    if (useContext) {
      prevContextValue = context[contextName];
      context[contextName] = node2;
    }
    for (const field of fields) {
      const ref = node2[field.name];
      if (!field.nullable || ref) {
        if (field.type === "list") {
          const breakWalk = reverse ? ref.reduceRight(walkReducer, false) : ref.reduce(walkReducer, false);
          if (breakWalk) {
            return true;
          }
        } else if (walk2(ref)) {
          return true;
        }
      }
    }
    if (useContext) {
      context[contextName] = prevContextValue;
    }
  };
}
function createFastTraveralMap({
  StyleSheet: StyleSheet2,
  Atrule: Atrule2,
  Rule: Rule2,
  Block: Block2,
  DeclarationList: DeclarationList2
}) {
  return {
    Atrule: {
      StyleSheet: StyleSheet2,
      Atrule: Atrule2,
      Rule: Rule2,
      Block: Block2
    },
    Rule: {
      StyleSheet: StyleSheet2,
      Atrule: Atrule2,
      Rule: Rule2,
      Block: Block2
    },
    Declaration: {
      StyleSheet: StyleSheet2,
      Atrule: Atrule2,
      Rule: Rule2,
      Block: Block2,
      DeclarationList: DeclarationList2
    }
  };
}
function createWalker(config2) {
  const types2 = getTypesFromConfig(config2);
  const iteratorsNatural = {};
  const iteratorsReverse = {};
  const breakWalk = Symbol("break-walk");
  const skipNode = Symbol("skip-node");
  for (const name2 in types2) {
    if (hasOwnProperty$8.call(types2, name2) && types2[name2] !== null) {
      iteratorsNatural[name2] = createTypeIterator(types2[name2], false);
      iteratorsReverse[name2] = createTypeIterator(types2[name2], true);
    }
  }
  const fastTraversalIteratorsNatural = createFastTraveralMap(iteratorsNatural);
  const fastTraversalIteratorsReverse = createFastTraveralMap(iteratorsReverse);
  const walk2 = function(root, options) {
    function walkNode(node2, item, list) {
      const enterRet = enter.call(context, node2, item, list);
      if (enterRet === breakWalk) {
        return true;
      }
      if (enterRet === skipNode) {
        return false;
      }
      if (iterators.hasOwnProperty(node2.type)) {
        if (iterators[node2.type](node2, context, walkNode, walkReducer)) {
          return true;
        }
      }
      if (leave.call(context, node2, item, list) === breakWalk) {
        return true;
      }
      return false;
    }
    let enter = noop$2;
    let leave = noop$2;
    let iterators = iteratorsNatural;
    let walkReducer = (ret, data2, item, list) => ret || walkNode(data2, item, list);
    const context = {
      break: breakWalk,
      skip: skipNode,
      root,
      stylesheet: null,
      atrule: null,
      atrulePrelude: null,
      rule: null,
      selector: null,
      block: null,
      declaration: null,
      function: null
    };
    if (typeof options === "function") {
      enter = options;
    } else if (options) {
      enter = ensureFunction$1(options.enter);
      leave = ensureFunction$1(options.leave);
      if (options.reverse) {
        iterators = iteratorsReverse;
      }
      if (options.visit) {
        if (fastTraversalIteratorsNatural.hasOwnProperty(options.visit)) {
          iterators = options.reverse ? fastTraversalIteratorsReverse[options.visit] : fastTraversalIteratorsNatural[options.visit];
        } else if (!types2.hasOwnProperty(options.visit)) {
          throw new Error("Bad value `" + options.visit + "` for `visit` option (should be: " + Object.keys(types2).sort().join(", ") + ")");
        }
        enter = invokeForType(enter, options.visit);
        leave = invokeForType(leave, options.visit);
      }
    }
    if (enter === noop$2 && leave === noop$2) {
      throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function");
    }
    walkNode(root);
  };
  walk2.break = breakWalk;
  walk2.skip = skipNode;
  walk2.find = function(ast, fn) {
    let found = null;
    walk2(ast, function(node2, item, list) {
      if (fn.call(this, node2, item, list)) {
        found = node2;
        return breakWalk;
      }
    });
    return found;
  };
  walk2.findLast = function(ast, fn) {
    let found = null;
    walk2(ast, {
      reverse: true,
      enter(node2, item, list) {
        if (fn.call(this, node2, item, list)) {
          found = node2;
          return breakWalk;
        }
      }
    });
    return found;
  };
  walk2.findAll = function(ast, fn) {
    const found = [];
    walk2(ast, function(node2, item, list) {
      if (fn.call(this, node2, item, list)) {
        found.push(node2);
      }
    });
    return found;
  };
  return walk2;
}
create$4.createWalker = createWalker;
var Lexer$3 = {};
var error$2 = {};
var generate$L = {};
function noop$1(value2) {
  return value2;
}
function generateMultiplier(multiplier) {
  const { min, max, comma } = multiplier;
  if (min === 0 && max === 0) {
    return comma ? "#?" : "*";
  }
  if (min === 0 && max === 1) {
    return "?";
  }
  if (min === 1 && max === 0) {
    return comma ? "#" : "+";
  }
  if (min === 1 && max === 1) {
    return "";
  }
  return (comma ? "#" : "") + (min === max ? "{" + min + "}" : "{" + min + "," + (max !== 0 ? max : "") + "}");
}
function generateTypeOpts(node2) {
  switch (node2.type) {
    case "Range":
      return " [" + (node2.min === null ? "-\u221E" : node2.min) + "," + (node2.max === null ? "\u221E" : node2.max) + "]";
    default:
      throw new Error("Unknown node type `" + node2.type + "`");
  }
}
function generateSequence(node2, decorate, forceBraces, compact) {
  const combinator = node2.combinator === " " || compact ? node2.combinator : " " + node2.combinator + " ";
  const result = node2.terms.map((term) => internalGenerate(term, decorate, forceBraces, compact)).join(combinator);
  if (node2.explicit || forceBraces) {
    return (compact || result[0] === "," ? "[" : "[ ") + result + (compact ? "]" : " ]");
  }
  return result;
}
function internalGenerate(node2, decorate, forceBraces, compact) {
  let result;
  switch (node2.type) {
    case "Group":
      result = generateSequence(node2, decorate, forceBraces, compact) + (node2.disallowEmpty ? "!" : "");
      break;
    case "Multiplier":
      return internalGenerate(node2.term, decorate, forceBraces, compact) + decorate(generateMultiplier(node2), node2);
    case "Type":
      result = "<" + node2.name + (node2.opts ? decorate(generateTypeOpts(node2.opts), node2.opts) : "") + ">";
      break;
    case "Property":
      result = "<'" + node2.name + "'>";
      break;
    case "Keyword":
      result = node2.name;
      break;
    case "AtKeyword":
      result = "@" + node2.name;
      break;
    case "Function":
      result = node2.name + "(";
      break;
    case "String":
    case "Token":
      result = node2.value;
      break;
    case "Comma":
      result = ",";
      break;
    default:
      throw new Error("Unknown node type `" + node2.type + "`");
  }
  return decorate(result, node2);
}
function generate$K(node2, options) {
  let decorate = noop$1;
  let forceBraces = false;
  let compact = false;
  if (typeof options === "function") {
    decorate = options;
  } else if (options) {
    forceBraces = Boolean(options.forceBraces);
    compact = Boolean(options.compact);
    if (typeof options.decorate === "function") {
      decorate = options.decorate;
    }
  }
  return internalGenerate(node2, decorate, forceBraces, compact);
}
generate$L.generate = generate$K;
const createCustomError$1 = createCustomError$4;
const generate$J = generate$L;
const defaultLoc = { offset: 0, line: 1, column: 1 };
function locateMismatch(matchResult, node2) {
  const tokens = matchResult.tokens;
  const longestMatch = matchResult.longestMatch;
  const mismatchNode = longestMatch < tokens.length ? tokens[longestMatch].node || null : null;
  const badNode = mismatchNode !== node2 ? mismatchNode : null;
  let mismatchOffset = 0;
  let mismatchLength = 0;
  let entries = 0;
  let css = "";
  let start;
  let end;
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i].value;
    if (i === longestMatch) {
      mismatchLength = token.length;
      mismatchOffset = css.length;
    }
    if (badNode !== null && tokens[i].node === badNode) {
      if (i <= longestMatch) {
        entries++;
      } else {
        entries = 0;
      }
    }
    css += token;
  }
  if (longestMatch === tokens.length || entries > 1) {
    start = fromLoc(badNode || node2, "end") || buildLoc(defaultLoc, css);
    end = buildLoc(start);
  } else {
    start = fromLoc(badNode, "start") || buildLoc(fromLoc(node2, "start") || defaultLoc, css.slice(0, mismatchOffset));
    end = fromLoc(badNode, "end") || buildLoc(start, css.substr(mismatchOffset, mismatchLength));
  }
  return {
    css,
    mismatchOffset,
    mismatchLength,
    start,
    end
  };
}
function fromLoc(node2, point) {
  const value2 = node2 && node2.loc && node2.loc[point];
  if (value2) {
    return "line" in value2 ? buildLoc(value2) : value2;
  }
  return null;
}
function buildLoc({ offset, line, column }, extra) {
  const loc = {
    offset,
    line,
    column
  };
  if (extra) {
    const lines = extra.split(/\n|\r\n?|\f/);
    loc.offset += extra.length;
    loc.line += lines.length - 1;
    loc.column = lines.length === 1 ? loc.column + extra.length : lines.pop().length + 1;
  }
  return loc;
}
const SyntaxReferenceError = function(type, referenceName) {
  const error2 = createCustomError$1.createCustomError(
    "SyntaxReferenceError",
    type + (referenceName ? " `" + referenceName + "`" : "")
  );
  error2.reference = referenceName;
  return error2;
};
const SyntaxMatchError = function(message, syntax2, node2, matchResult) {
  const error2 = createCustomError$1.createCustomError("SyntaxMatchError", message);
  const {
    css,
    mismatchOffset,
    mismatchLength,
    start,
    end
  } = locateMismatch(matchResult, node2);
  error2.rawMessage = message;
  error2.syntax = syntax2 ? generate$J.generate(syntax2) : "<generic>";
  error2.css = css;
  error2.mismatchOffset = mismatchOffset;
  error2.mismatchLength = mismatchLength;
  error2.message = message + "\n  syntax: " + error2.syntax + "\n   value: " + (css || "<empty string>") + "\n  --------" + new Array(error2.mismatchOffset + 1).join("-") + "^";
  Object.assign(error2, start);
  error2.loc = {
    source: node2 && node2.loc && node2.loc.source || "<unknown>",
    start,
    end
  };
  return error2;
};
error$2.SyntaxMatchError = SyntaxMatchError;
error$2.SyntaxReferenceError = SyntaxReferenceError;
var names$4 = {};
const keywords = /* @__PURE__ */ new Map();
const properties = /* @__PURE__ */ new Map();
const HYPHENMINUS$5 = 45;
const keyword = getKeywordDescriptor;
const property = getPropertyDescriptor;
const vendorPrefix = getVendorPrefix;
function isCustomProperty(str, offset) {
  offset = offset || 0;
  return str.length - offset >= 2 && str.charCodeAt(offset) === HYPHENMINUS$5 && str.charCodeAt(offset + 1) === HYPHENMINUS$5;
}
function getVendorPrefix(str, offset) {
  offset = offset || 0;
  if (str.length - offset >= 3) {
    if (str.charCodeAt(offset) === HYPHENMINUS$5 && str.charCodeAt(offset + 1) !== HYPHENMINUS$5) {
      const secondDashIndex = str.indexOf("-", offset + 2);
      if (secondDashIndex !== -1) {
        return str.substring(offset, secondDashIndex + 1);
      }
    }
  }
  return "";
}
function getKeywordDescriptor(keyword2) {
  if (keywords.has(keyword2)) {
    return keywords.get(keyword2);
  }
  const name2 = keyword2.toLowerCase();
  let descriptor = keywords.get(name2);
  if (descriptor === void 0) {
    const custom = isCustomProperty(name2, 0);
    const vendor = !custom ? getVendorPrefix(name2, 0) : "";
    descriptor = Object.freeze({
      basename: name2.substr(vendor.length),
      name: name2,
      prefix: vendor,
      vendor,
      custom
    });
  }
  keywords.set(keyword2, descriptor);
  return descriptor;
}
function getPropertyDescriptor(property2) {
  if (properties.has(property2)) {
    return properties.get(property2);
  }
  let name2 = property2;
  let hack = property2[0];
  if (hack === "/") {
    hack = property2[1] === "/" ? "//" : "/";
  } else if (hack !== "_" && hack !== "*" && hack !== "$" && hack !== "#" && hack !== "+" && hack !== "&") {
    hack = "";
  }
  const custom = isCustomProperty(name2, hack.length);
  if (!custom) {
    name2 = name2.toLowerCase();
    if (properties.has(name2)) {
      const descriptor2 = properties.get(name2);
      properties.set(property2, descriptor2);
      return descriptor2;
    }
  }
  const vendor = !custom ? getVendorPrefix(name2, hack.length) : "";
  const prefix = name2.substr(0, hack.length + vendor.length);
  const descriptor = Object.freeze({
    basename: name2.substr(prefix.length),
    name: name2.substr(hack.length),
    hack,
    vendor,
    prefix,
    custom
  });
  properties.set(property2, descriptor);
  return descriptor;
}
names$4.isCustomProperty = isCustomProperty;
names$4.keyword = keyword;
names$4.property = property;
names$4.vendorPrefix = vendorPrefix;
var genericConst$2 = {};
const cssWideKeywords = [
  "initial",
  "inherit",
  "unset",
  "revert",
  "revert-layer"
];
genericConst$2.cssWideKeywords = cssWideKeywords;
const charCodeDefinitions$8 = charCodeDefinitions$c;
const types$K = types$R;
const utils$g = utils$k;
const PLUSSIGN$8 = 43;
const HYPHENMINUS$4 = 45;
const N$3 = 110;
const DISALLOW_SIGN$1 = true;
const ALLOW_SIGN$1 = false;
function isDelim$1(token, code2) {
  return token !== null && token.type === types$K.Delim && token.value.charCodeAt(0) === code2;
}
function skipSC(token, offset, getNextToken) {
  while (token !== null && (token.type === types$K.WhiteSpace || token.type === types$K.Comment)) {
    token = getNextToken(++offset);
  }
  return offset;
}
function checkInteger$1(token, valueOffset, disallowSign, offset) {
  if (!token) {
    return 0;
  }
  const code2 = token.value.charCodeAt(valueOffset);
  if (code2 === PLUSSIGN$8 || code2 === HYPHENMINUS$4) {
    if (disallowSign) {
      return 0;
    }
    valueOffset++;
  }
  for (; valueOffset < token.value.length; valueOffset++) {
    if (!charCodeDefinitions$8.isDigit(token.value.charCodeAt(valueOffset))) {
      return 0;
    }
  }
  return offset + 1;
}
function consumeB$1(token, offset_, getNextToken) {
  let sign = false;
  let offset = skipSC(token, offset_, getNextToken);
  token = getNextToken(offset);
  if (token === null) {
    return offset_;
  }
  if (token.type !== types$K.Number) {
    if (isDelim$1(token, PLUSSIGN$8) || isDelim$1(token, HYPHENMINUS$4)) {
      sign = true;
      offset = skipSC(getNextToken(++offset), offset, getNextToken);
      token = getNextToken(offset);
      if (token === null || token.type !== types$K.Number) {
        return 0;
      }
    } else {
      return offset_;
    }
  }
  if (!sign) {
    const code2 = token.value.charCodeAt(0);
    if (code2 !== PLUSSIGN$8 && code2 !== HYPHENMINUS$4) {
      return 0;
    }
  }
  return checkInteger$1(token, sign ? 0 : 1, sign, offset);
}
function anPlusB(token, getNextToken) {
  let offset = 0;
  if (!token) {
    return 0;
  }
  if (token.type === types$K.Number) {
    return checkInteger$1(token, 0, ALLOW_SIGN$1, offset);
  } else if (token.type === types$K.Ident && token.value.charCodeAt(0) === HYPHENMINUS$4) {
    if (!utils$g.cmpChar(token.value, 1, N$3)) {
      return 0;
    }
    switch (token.value.length) {
      case 2:
        return consumeB$1(getNextToken(++offset), offset, getNextToken);
      case 3:
        if (token.value.charCodeAt(2) !== HYPHENMINUS$4) {
          return 0;
        }
        offset = skipSC(getNextToken(++offset), offset, getNextToken);
        token = getNextToken(offset);
        return checkInteger$1(token, 0, DISALLOW_SIGN$1, offset);
      default:
        if (token.value.charCodeAt(2) !== HYPHENMINUS$4) {
          return 0;
        }
        return checkInteger$1(token, 3, DISALLOW_SIGN$1, offset);
    }
  } else if (token.type === types$K.Ident || isDelim$1(token, PLUSSIGN$8) && getNextToken(offset + 1).type === types$K.Ident) {
    if (token.type !== types$K.Ident) {
      token = getNextToken(++offset);
    }
    if (token === null || !utils$g.cmpChar(token.value, 0, N$3)) {
      return 0;
    }
    switch (token.value.length) {
      case 1:
        return consumeB$1(getNextToken(++offset), offset, getNextToken);
      case 2:
        if (token.value.charCodeAt(1) !== HYPHENMINUS$4) {
          return 0;
        }
        offset = skipSC(getNextToken(++offset), offset, getNextToken);
        token = getNextToken(offset);
        return checkInteger$1(token, 0, DISALLOW_SIGN$1, offset);
      default:
        if (token.value.charCodeAt(1) !== HYPHENMINUS$4) {
          return 0;
        }
        return checkInteger$1(token, 2, DISALLOW_SIGN$1, offset);
    }
  } else if (token.type === types$K.Dimension) {
    let code2 = token.value.charCodeAt(0);
    let sign = code2 === PLUSSIGN$8 || code2 === HYPHENMINUS$4 ? 1 : 0;
    let i = sign;
    for (; i < token.value.length; i++) {
      if (!charCodeDefinitions$8.isDigit(token.value.charCodeAt(i))) {
        break;
      }
    }
    if (i === sign) {
      return 0;
    }
    if (!utils$g.cmpChar(token.value, i, N$3)) {
      return 0;
    }
    if (i + 1 === token.value.length) {
      return consumeB$1(getNextToken(++offset), offset, getNextToken);
    } else {
      if (token.value.charCodeAt(i + 1) !== HYPHENMINUS$4) {
        return 0;
      }
      if (i + 2 === token.value.length) {
        offset = skipSC(getNextToken(++offset), offset, getNextToken);
        token = getNextToken(offset);
        return checkInteger$1(token, 0, DISALLOW_SIGN$1, offset);
      } else {
        return checkInteger$1(token, i + 2, DISALLOW_SIGN$1, offset);
      }
    }
  }
  return 0;
}
var genericAnPlusB$1 = anPlusB;
const charCodeDefinitions$7 = charCodeDefinitions$c;
const types$J = types$R;
const utils$f = utils$k;
const PLUSSIGN$7 = 43;
const HYPHENMINUS$3 = 45;
const QUESTIONMARK$2 = 63;
const U$1 = 117;
function isDelim(token, code2) {
  return token !== null && token.type === types$J.Delim && token.value.charCodeAt(0) === code2;
}
function startsWith$1(token, code2) {
  return token.value.charCodeAt(0) === code2;
}
function hexSequence(token, offset, allowDash) {
  let hexlen = 0;
  for (let pos = offset; pos < token.value.length; pos++) {
    const code2 = token.value.charCodeAt(pos);
    if (code2 === HYPHENMINUS$3 && allowDash && hexlen !== 0) {
      hexSequence(token, offset + hexlen + 1, false);
      return 6;
    }
    if (!charCodeDefinitions$7.isHexDigit(code2)) {
      return 0;
    }
    if (++hexlen > 6) {
      return 0;
    }
  }
  return hexlen;
}
function withQuestionMarkSequence(consumed, length, getNextToken) {
  if (!consumed) {
    return 0;
  }
  while (isDelim(getNextToken(length), QUESTIONMARK$2)) {
    if (++consumed > 6) {
      return 0;
    }
    length++;
  }
  return length;
}
function urange(token, getNextToken) {
  let length = 0;
  if (token === null || token.type !== types$J.Ident || !utils$f.cmpChar(token.value, 0, U$1)) {
    return 0;
  }
  token = getNextToken(++length);
  if (token === null) {
    return 0;
  }
  if (isDelim(token, PLUSSIGN$7)) {
    token = getNextToken(++length);
    if (token === null) {
      return 0;
    }
    if (token.type === types$J.Ident) {
      return withQuestionMarkSequence(hexSequence(token, 0, true), ++length, getNextToken);
    }
    if (isDelim(token, QUESTIONMARK$2)) {
      return withQuestionMarkSequence(1, ++length, getNextToken);
    }
    return 0;
  }
  if (token.type === types$J.Number) {
    const consumedHexLength = hexSequence(token, 1, true);
    if (consumedHexLength === 0) {
      return 0;
    }
    token = getNextToken(++length);
    if (token === null) {
      return length;
    }
    if (token.type === types$J.Dimension || token.type === types$J.Number) {
      if (!startsWith$1(token, HYPHENMINUS$3) || !hexSequence(token, 1, false)) {
        return 0;
      }
      return length + 1;
    }
    return withQuestionMarkSequence(consumedHexLength, length, getNextToken);
  }
  if (token.type === types$J.Dimension) {
    return withQuestionMarkSequence(hexSequence(token, 1, true), ++length, getNextToken);
  }
  return 0;
}
var genericUrange$1 = urange;
const genericConst$1 = genericConst$2;
const genericAnPlusB = genericAnPlusB$1;
const genericUrange = genericUrange$1;
const types$I = types$R;
const charCodeDefinitions$6 = charCodeDefinitions$c;
const utils$e = utils$k;
const calcFunctionNames = ["calc(", "-moz-calc(", "-webkit-calc("];
const balancePair = /* @__PURE__ */ new Map([
  [types$I.Function, types$I.RightParenthesis],
  [types$I.LeftParenthesis, types$I.RightParenthesis],
  [types$I.LeftSquareBracket, types$I.RightSquareBracket],
  [types$I.LeftCurlyBracket, types$I.RightCurlyBracket]
]);
const LENGTH = [
  "cm",
  "mm",
  "q",
  "in",
  "pt",
  "pc",
  "px",
  "em",
  "rem",
  "ex",
  "rex",
  "cap",
  "rcap",
  "ch",
  "rch",
  "ic",
  "ric",
  "lh",
  "rlh",
  "vw",
  "svw",
  "lvw",
  "dvw",
  "vh",
  "svh",
  "lvh",
  "dvh",
  "vi",
  "svi",
  "lvi",
  "dvi",
  "vb",
  "svb",
  "lvb",
  "dvb",
  "vmin",
  "svmin",
  "lvmin",
  "dvmin",
  "vmax",
  "svmax",
  "lvmax",
  "dvmax",
  "cqw",
  "cqh",
  "cqi",
  "cqb",
  "cqmin",
  "cqmax"
];
const ANGLE = ["deg", "grad", "rad", "turn"];
const TIME = ["s", "ms"];
const FREQUENCY = ["hz", "khz"];
const RESOLUTION = ["dpi", "dpcm", "dppx", "x"];
const FLEX = ["fr"];
const DECIBEL = ["db"];
const SEMITONES = ["st"];
function charCodeAt(str, index2) {
  return index2 < str.length ? str.charCodeAt(index2) : 0;
}
function eqStr(actual, expected) {
  return utils$e.cmpStr(actual, 0, actual.length, expected);
}
function eqStrAny(actual, expected) {
  for (let i = 0; i < expected.length; i++) {
    if (eqStr(actual, expected[i])) {
      return true;
    }
  }
  return false;
}
function isPostfixIeHack(str, offset) {
  if (offset !== str.length - 2) {
    return false;
  }
  return charCodeAt(str, offset) === 92 && charCodeDefinitions$6.isDigit(charCodeAt(str, offset + 1));
}
function outOfRange(opts, value2, numEnd) {
  if (opts && opts.type === "Range") {
    const num = Number(
      numEnd !== void 0 && numEnd !== value2.length ? value2.substr(0, numEnd) : value2
    );
    if (isNaN(num)) {
      return true;
    }
    if (opts.min !== null && num < opts.min && typeof opts.min !== "string") {
      return true;
    }
    if (opts.max !== null && num > opts.max && typeof opts.max !== "string") {
      return true;
    }
  }
  return false;
}
function consumeFunction(token, getNextToken) {
  let balanceCloseType = 0;
  let balanceStash = [];
  let length = 0;
  scan:
    do {
      switch (token.type) {
        case types$I.RightCurlyBracket:
        case types$I.RightParenthesis:
        case types$I.RightSquareBracket:
          if (token.type !== balanceCloseType) {
            break scan;
          }
          balanceCloseType = balanceStash.pop();
          if (balanceStash.length === 0) {
            length++;
            break scan;
          }
          break;
        case types$I.Function:
        case types$I.LeftParenthesis:
        case types$I.LeftSquareBracket:
        case types$I.LeftCurlyBracket:
          balanceStash.push(balanceCloseType);
          balanceCloseType = balancePair.get(token.type);
          break;
      }
      length++;
    } while (token = getNextToken(length));
  return length;
}
function calc(next) {
  return function(token, getNextToken, opts) {
    if (token === null) {
      return 0;
    }
    if (token.type === types$I.Function && eqStrAny(token.value, calcFunctionNames)) {
      return consumeFunction(token, getNextToken);
    }
    return next(token, getNextToken, opts);
  };
}
function tokenType(expectedTokenType) {
  return function(token) {
    if (token === null || token.type !== expectedTokenType) {
      return 0;
    }
    return 1;
  };
}
function customIdent(token) {
  if (token === null || token.type !== types$I.Ident) {
    return 0;
  }
  const name2 = token.value.toLowerCase();
  if (eqStrAny(name2, genericConst$1.cssWideKeywords)) {
    return 0;
  }
  if (eqStr(name2, "default")) {
    return 0;
  }
  return 1;
}
function customPropertyName(token) {
  if (token === null || token.type !== types$I.Ident) {
    return 0;
  }
  if (charCodeAt(token.value, 0) !== 45 || charCodeAt(token.value, 1) !== 45) {
    return 0;
  }
  return 1;
}
function hexColor(token) {
  if (token === null || token.type !== types$I.Hash) {
    return 0;
  }
  const length = token.value.length;
  if (length !== 4 && length !== 5 && length !== 7 && length !== 9) {
    return 0;
  }
  for (let i = 1; i < length; i++) {
    if (!charCodeDefinitions$6.isHexDigit(charCodeAt(token.value, i))) {
      return 0;
    }
  }
  return 1;
}
function idSelector(token) {
  if (token === null || token.type !== types$I.Hash) {
    return 0;
  }
  if (!charCodeDefinitions$6.isIdentifierStart(charCodeAt(token.value, 1), charCodeAt(token.value, 2), charCodeAt(token.value, 3))) {
    return 0;
  }
  return 1;
}
function declarationValue(token, getNextToken) {
  if (!token) {
    return 0;
  }
  let balanceCloseType = 0;
  let balanceStash = [];
  let length = 0;
  scan:
    do {
      switch (token.type) {
        case types$I.BadString:
        case types$I.BadUrl:
          break scan;
        case types$I.RightCurlyBracket:
        case types$I.RightParenthesis:
        case types$I.RightSquareBracket:
          if (token.type !== balanceCloseType) {
            break scan;
          }
          balanceCloseType = balanceStash.pop();
          break;
        case types$I.Semicolon:
          if (balanceCloseType === 0) {
            break scan;
          }
          break;
        case types$I.Delim:
          if (balanceCloseType === 0 && token.value === "!") {
            break scan;
          }
          break;
        case types$I.Function:
        case types$I.LeftParenthesis:
        case types$I.LeftSquareBracket:
        case types$I.LeftCurlyBracket:
          balanceStash.push(balanceCloseType);
          balanceCloseType = balancePair.get(token.type);
          break;
      }
      length++;
    } while (token = getNextToken(length));
  return length;
}
function anyValue(token, getNextToken) {
  if (!token) {
    return 0;
  }
  let balanceCloseType = 0;
  let balanceStash = [];
  let length = 0;
  scan:
    do {
      switch (token.type) {
        case types$I.BadString:
        case types$I.BadUrl:
          break scan;
        case types$I.RightCurlyBracket:
        case types$I.RightParenthesis:
        case types$I.RightSquareBracket:
          if (token.type !== balanceCloseType) {
            break scan;
          }
          balanceCloseType = balanceStash.pop();
          break;
        case types$I.Function:
        case types$I.LeftParenthesis:
        case types$I.LeftSquareBracket:
        case types$I.LeftCurlyBracket:
          balanceStash.push(balanceCloseType);
          balanceCloseType = balancePair.get(token.type);
          break;
      }
      length++;
    } while (token = getNextToken(length));
  return length;
}
function dimension(type) {
  if (type) {
    type = new Set(type);
  }
  return function(token, getNextToken, opts) {
    if (token === null || token.type !== types$I.Dimension) {
      return 0;
    }
    const numberEnd = utils$e.consumeNumber(token.value, 0);
    if (type !== null) {
      const reverseSolidusOffset = token.value.indexOf("\\", numberEnd);
      const unit = reverseSolidusOffset === -1 || !isPostfixIeHack(token.value, reverseSolidusOffset) ? token.value.substr(numberEnd) : token.value.substring(numberEnd, reverseSolidusOffset);
      if (type.has(unit.toLowerCase()) === false) {
        return 0;
      }
    }
    if (outOfRange(opts, token.value, numberEnd)) {
      return 0;
    }
    return 1;
  };
}
function percentage(token, getNextToken, opts) {
  if (token === null || token.type !== types$I.Percentage) {
    return 0;
  }
  if (outOfRange(opts, token.value, token.value.length - 1)) {
    return 0;
  }
  return 1;
}
function zero(next) {
  if (typeof next !== "function") {
    next = function() {
      return 0;
    };
  }
  return function(token, getNextToken, opts) {
    if (token !== null && token.type === types$I.Number) {
      if (Number(token.value) === 0) {
        return 1;
      }
    }
    return next(token, getNextToken, opts);
  };
}
function number(token, getNextToken, opts) {
  if (token === null) {
    return 0;
  }
  const numberEnd = utils$e.consumeNumber(token.value, 0);
  const isNumber = numberEnd === token.value.length;
  if (!isNumber && !isPostfixIeHack(token.value, numberEnd)) {
    return 0;
  }
  if (outOfRange(opts, token.value, numberEnd)) {
    return 0;
  }
  return 1;
}
function integer(token, getNextToken, opts) {
  if (token === null || token.type !== types$I.Number) {
    return 0;
  }
  let i = charCodeAt(token.value, 0) === 43 || charCodeAt(token.value, 0) === 45 ? 1 : 0;
  for (; i < token.value.length; i++) {
    if (!charCodeDefinitions$6.isDigit(charCodeAt(token.value, i))) {
      return 0;
    }
  }
  if (outOfRange(opts, token.value, i)) {
    return 0;
  }
  return 1;
}
const genericSyntaxes = {
  "ident-token": tokenType(types$I.Ident),
  "function-token": tokenType(types$I.Function),
  "at-keyword-token": tokenType(types$I.AtKeyword),
  "hash-token": tokenType(types$I.Hash),
  "string-token": tokenType(types$I.String),
  "bad-string-token": tokenType(types$I.BadString),
  "url-token": tokenType(types$I.Url),
  "bad-url-token": tokenType(types$I.BadUrl),
  "delim-token": tokenType(types$I.Delim),
  "number-token": tokenType(types$I.Number),
  "percentage-token": tokenType(types$I.Percentage),
  "dimension-token": tokenType(types$I.Dimension),
  "whitespace-token": tokenType(types$I.WhiteSpace),
  "CDO-token": tokenType(types$I.CDO),
  "CDC-token": tokenType(types$I.CDC),
  "colon-token": tokenType(types$I.Colon),
  "semicolon-token": tokenType(types$I.Semicolon),
  "comma-token": tokenType(types$I.Comma),
  "[-token": tokenType(types$I.LeftSquareBracket),
  "]-token": tokenType(types$I.RightSquareBracket),
  "(-token": tokenType(types$I.LeftParenthesis),
  ")-token": tokenType(types$I.RightParenthesis),
  "{-token": tokenType(types$I.LeftCurlyBracket),
  "}-token": tokenType(types$I.RightCurlyBracket),
  "string": tokenType(types$I.String),
  "ident": tokenType(types$I.Ident),
  "custom-ident": customIdent,
  "custom-property-name": customPropertyName,
  "hex-color": hexColor,
  "id-selector": idSelector,
  "an-plus-b": genericAnPlusB,
  "urange": genericUrange,
  "declaration-value": declarationValue,
  "any-value": anyValue,
  "dimension": calc(dimension(null)),
  "angle": calc(dimension(ANGLE)),
  "decibel": calc(dimension(DECIBEL)),
  "frequency": calc(dimension(FREQUENCY)),
  "flex": calc(dimension(FLEX)),
  "length": calc(zero(dimension(LENGTH))),
  "resolution": calc(dimension(RESOLUTION)),
  "semitones": calc(dimension(SEMITONES)),
  "time": calc(dimension(TIME)),
  "percentage": calc(percentage),
  "zero": zero(),
  "number": calc(number),
  "integer": calc(integer)
};
var generic$1 = genericSyntaxes;
const index$9 = tokenizer$2;
const astToTokens = {
  decorator(handlers2) {
    const tokens = [];
    let curNode = null;
    return {
      ...handlers2,
      node(node2) {
        const tmp = curNode;
        curNode = node2;
        handlers2.node.call(this, node2);
        curNode = tmp;
      },
      emit(value2, type, auto) {
        tokens.push({
          type,
          value: value2,
          node: auto ? null : curNode
        });
      },
      result() {
        return tokens;
      }
    };
  }
};
function stringToTokens(str) {
  const tokens = [];
  index$9.tokenize(
    str,
    (type, start, end) => tokens.push({
      type,
      value: str.slice(start, end),
      node: null
    })
  );
  return tokens;
}
function prepareTokens$1(value2, syntax2) {
  if (typeof value2 === "string") {
    return stringToTokens(value2);
  }
  return syntax2.generate(value2, astToTokens);
}
var prepareTokens_1 = prepareTokens$1;
var matchGraph$2 = {};
var parse$L = {};
var tokenizer$1 = {};
var _SyntaxError = {};
const createCustomError = createCustomError$4;
function SyntaxError$3(message, input, offset) {
  return Object.assign(createCustomError.createCustomError("SyntaxError", message), {
    input,
    offset,
    rawMessage: message,
    message: message + "\n  " + input + "\n--" + new Array((offset || input.length) + 1).join("-") + "^"
  });
}
_SyntaxError.SyntaxError = SyntaxError$3;
const SyntaxError$2 = _SyntaxError;
const TAB$1 = 9;
const N$2 = 10;
const F$1 = 12;
const R$1 = 13;
const SPACE$3 = 32;
class Tokenizer {
  constructor(str) {
    this.str = str;
    this.pos = 0;
  }
  charCodeAt(pos) {
    return pos < this.str.length ? this.str.charCodeAt(pos) : 0;
  }
  charCode() {
    return this.charCodeAt(this.pos);
  }
  nextCharCode() {
    return this.charCodeAt(this.pos + 1);
  }
  nextNonWsCode(pos) {
    return this.charCodeAt(this.findWsEnd(pos));
  }
  findWsEnd(pos) {
    for (; pos < this.str.length; pos++) {
      const code2 = this.str.charCodeAt(pos);
      if (code2 !== R$1 && code2 !== N$2 && code2 !== F$1 && code2 !== SPACE$3 && code2 !== TAB$1) {
        break;
      }
    }
    return pos;
  }
  substringToPos(end) {
    return this.str.substring(this.pos, this.pos = end);
  }
  eat(code2) {
    if (this.charCode() !== code2) {
      this.error("Expect `" + String.fromCharCode(code2) + "`");
    }
    this.pos++;
  }
  peek() {
    return this.pos < this.str.length ? this.str.charAt(this.pos++) : "";
  }
  error(message) {
    throw new SyntaxError$2.SyntaxError(message, this.str, this.pos);
  }
}
tokenizer$1.Tokenizer = Tokenizer;
const tokenizer = tokenizer$1;
const TAB = 9;
const N$1 = 10;
const F = 12;
const R = 13;
const SPACE$2 = 32;
const EXCLAMATIONMARK$2 = 33;
const NUMBERSIGN$3 = 35;
const AMPERSAND$1 = 38;
const APOSTROPHE$2 = 39;
const LEFTPARENTHESIS$2 = 40;
const RIGHTPARENTHESIS$2 = 41;
const ASTERISK$6 = 42;
const PLUSSIGN$6 = 43;
const COMMA = 44;
const HYPERMINUS = 45;
const LESSTHANSIGN = 60;
const GREATERTHANSIGN$2 = 62;
const QUESTIONMARK$1 = 63;
const COMMERCIALAT = 64;
const LEFTSQUAREBRACKET = 91;
const RIGHTSQUAREBRACKET = 93;
const LEFTCURLYBRACKET = 123;
const VERTICALLINE$3 = 124;
const RIGHTCURLYBRACKET = 125;
const INFINITY = 8734;
const NAME_CHAR = new Uint8Array(128).map(
  (_, idx) => /[a-zA-Z0-9\-]/.test(String.fromCharCode(idx)) ? 1 : 0
);
const COMBINATOR_PRECEDENCE = {
  " ": 1,
  "&&": 2,
  "||": 3,
  "|": 4
};
function scanSpaces(tokenizer2) {
  return tokenizer2.substringToPos(
    tokenizer2.findWsEnd(tokenizer2.pos)
  );
}
function scanWord(tokenizer2) {
  let end = tokenizer2.pos;
  for (; end < tokenizer2.str.length; end++) {
    const code2 = tokenizer2.str.charCodeAt(end);
    if (code2 >= 128 || NAME_CHAR[code2] === 0) {
      break;
    }
  }
  if (tokenizer2.pos === end) {
    tokenizer2.error("Expect a keyword");
  }
  return tokenizer2.substringToPos(end);
}
function scanNumber(tokenizer2) {
  let end = tokenizer2.pos;
  for (; end < tokenizer2.str.length; end++) {
    const code2 = tokenizer2.str.charCodeAt(end);
    if (code2 < 48 || code2 > 57) {
      break;
    }
  }
  if (tokenizer2.pos === end) {
    tokenizer2.error("Expect a number");
  }
  return tokenizer2.substringToPos(end);
}
function scanString(tokenizer2) {
  const end = tokenizer2.str.indexOf("'", tokenizer2.pos + 1);
  if (end === -1) {
    tokenizer2.pos = tokenizer2.str.length;
    tokenizer2.error("Expect an apostrophe");
  }
  return tokenizer2.substringToPos(end + 1);
}
function readMultiplierRange(tokenizer2) {
  let min = null;
  let max = null;
  tokenizer2.eat(LEFTCURLYBRACKET);
  min = scanNumber(tokenizer2);
  if (tokenizer2.charCode() === COMMA) {
    tokenizer2.pos++;
    if (tokenizer2.charCode() !== RIGHTCURLYBRACKET) {
      max = scanNumber(tokenizer2);
    }
  } else {
    max = min;
  }
  tokenizer2.eat(RIGHTCURLYBRACKET);
  return {
    min: Number(min),
    max: max ? Number(max) : 0
  };
}
function readMultiplier(tokenizer2) {
  let range = null;
  let comma = false;
  switch (tokenizer2.charCode()) {
    case ASTERISK$6:
      tokenizer2.pos++;
      range = {
        min: 0,
        max: 0
      };
      break;
    case PLUSSIGN$6:
      tokenizer2.pos++;
      range = {
        min: 1,
        max: 0
      };
      break;
    case QUESTIONMARK$1:
      tokenizer2.pos++;
      range = {
        min: 0,
        max: 1
      };
      break;
    case NUMBERSIGN$3:
      tokenizer2.pos++;
      comma = true;
      if (tokenizer2.charCode() === LEFTCURLYBRACKET) {
        range = readMultiplierRange(tokenizer2);
      } else if (tokenizer2.charCode() === QUESTIONMARK$1) {
        tokenizer2.pos++;
        range = {
          min: 0,
          max: 0
        };
      } else {
        range = {
          min: 1,
          max: 0
        };
      }
      break;
    case LEFTCURLYBRACKET:
      range = readMultiplierRange(tokenizer2);
      break;
    default:
      return null;
  }
  return {
    type: "Multiplier",
    comma,
    min: range.min,
    max: range.max,
    term: null
  };
}
function maybeMultiplied(tokenizer2, node2) {
  const multiplier = readMultiplier(tokenizer2);
  if (multiplier !== null) {
    multiplier.term = node2;
    if (tokenizer2.charCode() === NUMBERSIGN$3 && tokenizer2.charCodeAt(tokenizer2.pos - 1) === PLUSSIGN$6) {
      return maybeMultiplied(tokenizer2, multiplier);
    }
    return multiplier;
  }
  return node2;
}
function maybeToken(tokenizer2) {
  const ch = tokenizer2.peek();
  if (ch === "") {
    return null;
  }
  return {
    type: "Token",
    value: ch
  };
}
function readProperty$1(tokenizer2) {
  let name2;
  tokenizer2.eat(LESSTHANSIGN);
  tokenizer2.eat(APOSTROPHE$2);
  name2 = scanWord(tokenizer2);
  tokenizer2.eat(APOSTROPHE$2);
  tokenizer2.eat(GREATERTHANSIGN$2);
  return maybeMultiplied(tokenizer2, {
    type: "Property",
    name: name2
  });
}
function readTypeRange(tokenizer2) {
  let min = null;
  let max = null;
  let sign = 1;
  tokenizer2.eat(LEFTSQUAREBRACKET);
  if (tokenizer2.charCode() === HYPERMINUS) {
    tokenizer2.peek();
    sign = -1;
  }
  if (sign == -1 && tokenizer2.charCode() === INFINITY) {
    tokenizer2.peek();
  } else {
    min = sign * Number(scanNumber(tokenizer2));
    if (NAME_CHAR[tokenizer2.charCode()] !== 0) {
      min += scanWord(tokenizer2);
    }
  }
  scanSpaces(tokenizer2);
  tokenizer2.eat(COMMA);
  scanSpaces(tokenizer2);
  if (tokenizer2.charCode() === INFINITY) {
    tokenizer2.peek();
  } else {
    sign = 1;
    if (tokenizer2.charCode() === HYPERMINUS) {
      tokenizer2.peek();
      sign = -1;
    }
    max = sign * Number(scanNumber(tokenizer2));
    if (NAME_CHAR[tokenizer2.charCode()] !== 0) {
      max += scanWord(tokenizer2);
    }
  }
  tokenizer2.eat(RIGHTSQUAREBRACKET);
  return {
    type: "Range",
    min,
    max
  };
}
function readType(tokenizer2) {
  let name2;
  let opts = null;
  tokenizer2.eat(LESSTHANSIGN);
  name2 = scanWord(tokenizer2);
  if (tokenizer2.charCode() === LEFTPARENTHESIS$2 && tokenizer2.nextCharCode() === RIGHTPARENTHESIS$2) {
    tokenizer2.pos += 2;
    name2 += "()";
  }
  if (tokenizer2.charCodeAt(tokenizer2.findWsEnd(tokenizer2.pos)) === LEFTSQUAREBRACKET) {
    scanSpaces(tokenizer2);
    opts = readTypeRange(tokenizer2);
  }
  tokenizer2.eat(GREATERTHANSIGN$2);
  return maybeMultiplied(tokenizer2, {
    type: "Type",
    name: name2,
    opts
  });
}
function readKeywordOrFunction(tokenizer2) {
  const name2 = scanWord(tokenizer2);
  if (tokenizer2.charCode() === LEFTPARENTHESIS$2) {
    tokenizer2.pos++;
    return {
      type: "Function",
      name: name2
    };
  }
  return maybeMultiplied(tokenizer2, {
    type: "Keyword",
    name: name2
  });
}
function regroupTerms(terms, combinators) {
  function createGroup(terms2, combinator2) {
    return {
      type: "Group",
      terms: terms2,
      combinator: combinator2,
      disallowEmpty: false,
      explicit: false
    };
  }
  let combinator;
  combinators = Object.keys(combinators).sort((a, b) => COMBINATOR_PRECEDENCE[a] - COMBINATOR_PRECEDENCE[b]);
  while (combinators.length > 0) {
    combinator = combinators.shift();
    let i = 0;
    let subgroupStart = 0;
    for (; i < terms.length; i++) {
      const term = terms[i];
      if (term.type === "Combinator") {
        if (term.value === combinator) {
          if (subgroupStart === -1) {
            subgroupStart = i - 1;
          }
          terms.splice(i, 1);
          i--;
        } else {
          if (subgroupStart !== -1 && i - subgroupStart > 1) {
            terms.splice(
              subgroupStart,
              i - subgroupStart,
              createGroup(terms.slice(subgroupStart, i), combinator)
            );
            i = subgroupStart + 1;
          }
          subgroupStart = -1;
        }
      }
    }
    if (subgroupStart !== -1 && combinators.length) {
      terms.splice(
        subgroupStart,
        i - subgroupStart,
        createGroup(terms.slice(subgroupStart, i), combinator)
      );
    }
  }
  return combinator;
}
function readImplicitGroup(tokenizer2) {
  const terms = [];
  const combinators = {};
  let token;
  let prevToken = null;
  let prevTokenPos = tokenizer2.pos;
  while (token = peek(tokenizer2)) {
    if (token.type !== "Spaces") {
      if (token.type === "Combinator") {
        if (prevToken === null || prevToken.type === "Combinator") {
          tokenizer2.pos = prevTokenPos;
          tokenizer2.error("Unexpected combinator");
        }
        combinators[token.value] = true;
      } else if (prevToken !== null && prevToken.type !== "Combinator") {
        combinators[" "] = true;
        terms.push({
          type: "Combinator",
          value: " "
        });
      }
      terms.push(token);
      prevToken = token;
      prevTokenPos = tokenizer2.pos;
    }
  }
  if (prevToken !== null && prevToken.type === "Combinator") {
    tokenizer2.pos -= prevTokenPos;
    tokenizer2.error("Unexpected combinator");
  }
  return {
    type: "Group",
    terms,
    combinator: regroupTerms(terms, combinators) || " ",
    disallowEmpty: false,
    explicit: false
  };
}
function readGroup(tokenizer2) {
  let result;
  tokenizer2.eat(LEFTSQUAREBRACKET);
  result = readImplicitGroup(tokenizer2);
  tokenizer2.eat(RIGHTSQUAREBRACKET);
  result.explicit = true;
  if (tokenizer2.charCode() === EXCLAMATIONMARK$2) {
    tokenizer2.pos++;
    result.disallowEmpty = true;
  }
  return result;
}
function peek(tokenizer2) {
  let code2 = tokenizer2.charCode();
  if (code2 < 128 && NAME_CHAR[code2] === 1) {
    return readKeywordOrFunction(tokenizer2);
  }
  switch (code2) {
    case RIGHTSQUAREBRACKET:
      break;
    case LEFTSQUAREBRACKET:
      return maybeMultiplied(tokenizer2, readGroup(tokenizer2));
    case LESSTHANSIGN:
      return tokenizer2.nextCharCode() === APOSTROPHE$2 ? readProperty$1(tokenizer2) : readType(tokenizer2);
    case VERTICALLINE$3:
      return {
        type: "Combinator",
        value: tokenizer2.substringToPos(
          tokenizer2.pos + (tokenizer2.nextCharCode() === VERTICALLINE$3 ? 2 : 1)
        )
      };
    case AMPERSAND$1:
      tokenizer2.pos++;
      tokenizer2.eat(AMPERSAND$1);
      return {
        type: "Combinator",
        value: "&&"
      };
    case COMMA:
      tokenizer2.pos++;
      return {
        type: "Comma"
      };
    case APOSTROPHE$2:
      return maybeMultiplied(tokenizer2, {
        type: "String",
        value: scanString(tokenizer2)
      });
    case SPACE$2:
    case TAB:
    case N$1:
    case R:
    case F:
      return {
        type: "Spaces",
        value: scanSpaces(tokenizer2)
      };
    case COMMERCIALAT:
      code2 = tokenizer2.nextCharCode();
      if (code2 < 128 && NAME_CHAR[code2] === 1) {
        tokenizer2.pos++;
        return {
          type: "AtKeyword",
          name: scanWord(tokenizer2)
        };
      }
      return maybeToken(tokenizer2);
    case ASTERISK$6:
    case PLUSSIGN$6:
    case QUESTIONMARK$1:
    case NUMBERSIGN$3:
    case EXCLAMATIONMARK$2:
      break;
    case LEFTCURLYBRACKET:
      code2 = tokenizer2.nextCharCode();
      if (code2 < 48 || code2 > 57) {
        return maybeToken(tokenizer2);
      }
      break;
    default:
      return maybeToken(tokenizer2);
  }
}
function parse$K(source) {
  const tokenizer$12 = new tokenizer.Tokenizer(source);
  const result = readImplicitGroup(tokenizer$12);
  if (tokenizer$12.pos !== source.length) {
    tokenizer$12.error("Unexpected input");
  }
  if (result.terms.length === 1 && result.terms[0].type === "Group") {
    return result.terms[0];
  }
  return result;
}
parse$L.parse = parse$K;
const parse$J = parse$L;
const MATCH = { type: "Match" };
const MISMATCH = { type: "Mismatch" };
const DISALLOW_EMPTY = { type: "DisallowEmpty" };
const LEFTPARENTHESIS$1 = 40;
const RIGHTPARENTHESIS$1 = 41;
function createCondition(match2, thenBranch, elseBranch) {
  if (thenBranch === MATCH && elseBranch === MISMATCH) {
    return match2;
  }
  if (match2 === MATCH && thenBranch === MATCH && elseBranch === MATCH) {
    return match2;
  }
  if (match2.type === "If" && match2.else === MISMATCH && thenBranch === MATCH) {
    thenBranch = match2.then;
    match2 = match2.match;
  }
  return {
    type: "If",
    match: match2,
    then: thenBranch,
    else: elseBranch
  };
}
function isFunctionType(name2) {
  return name2.length > 2 && name2.charCodeAt(name2.length - 2) === LEFTPARENTHESIS$1 && name2.charCodeAt(name2.length - 1) === RIGHTPARENTHESIS$1;
}
function isEnumCapatible(term) {
  return term.type === "Keyword" || term.type === "AtKeyword" || term.type === "Function" || term.type === "Type" && isFunctionType(term.name);
}
function buildGroupMatchGraph(combinator, terms, atLeastOneTermMatched) {
  switch (combinator) {
    case " ": {
      let result = MATCH;
      for (let i = terms.length - 1; i >= 0; i--) {
        const term = terms[i];
        result = createCondition(
          term,
          result,
          MISMATCH
        );
      }
      return result;
    }
    case "|": {
      let result = MISMATCH;
      let map = null;
      for (let i = terms.length - 1; i >= 0; i--) {
        let term = terms[i];
        if (isEnumCapatible(term)) {
          if (map === null && i > 0 && isEnumCapatible(terms[i - 1])) {
            map = /* @__PURE__ */ Object.create(null);
            result = createCondition(
              {
                type: "Enum",
                map
              },
              MATCH,
              result
            );
          }
          if (map !== null) {
            const key = (isFunctionType(term.name) ? term.name.slice(0, -1) : term.name).toLowerCase();
            if (key in map === false) {
              map[key] = term;
              continue;
            }
          }
        }
        map = null;
        result = createCondition(
          term,
          MATCH,
          result
        );
      }
      return result;
    }
    case "&&": {
      if (terms.length > 5) {
        return {
          type: "MatchOnce",
          terms,
          all: true
        };
      }
      let result = MISMATCH;
      for (let i = terms.length - 1; i >= 0; i--) {
        const term = terms[i];
        let thenClause;
        if (terms.length > 1) {
          thenClause = buildGroupMatchGraph(
            combinator,
            terms.filter(function(newGroupTerm) {
              return newGroupTerm !== term;
            }),
            false
          );
        } else {
          thenClause = MATCH;
        }
        result = createCondition(
          term,
          thenClause,
          result
        );
      }
      return result;
    }
    case "||": {
      if (terms.length > 5) {
        return {
          type: "MatchOnce",
          terms,
          all: false
        };
      }
      let result = atLeastOneTermMatched ? MATCH : MISMATCH;
      for (let i = terms.length - 1; i >= 0; i--) {
        const term = terms[i];
        let thenClause;
        if (terms.length > 1) {
          thenClause = buildGroupMatchGraph(
            combinator,
            terms.filter(function(newGroupTerm) {
              return newGroupTerm !== term;
            }),
            true
          );
        } else {
          thenClause = MATCH;
        }
        result = createCondition(
          term,
          thenClause,
          result
        );
      }
      return result;
    }
  }
}
function buildMultiplierMatchGraph(node2) {
  let result = MATCH;
  let matchTerm = buildMatchGraphInternal(node2.term);
  if (node2.max === 0) {
    matchTerm = createCondition(
      matchTerm,
      DISALLOW_EMPTY,
      MISMATCH
    );
    result = createCondition(
      matchTerm,
      null,
      MISMATCH
    );
    result.then = createCondition(
      MATCH,
      MATCH,
      result
    );
    if (node2.comma) {
      result.then.else = createCondition(
        { type: "Comma", syntax: node2 },
        result,
        MISMATCH
      );
    }
  } else {
    for (let i = node2.min || 1; i <= node2.max; i++) {
      if (node2.comma && result !== MATCH) {
        result = createCondition(
          { type: "Comma", syntax: node2 },
          result,
          MISMATCH
        );
      }
      result = createCondition(
        matchTerm,
        createCondition(
          MATCH,
          MATCH,
          result
        ),
        MISMATCH
      );
    }
  }
  if (node2.min === 0) {
    result = createCondition(
      MATCH,
      MATCH,
      result
    );
  } else {
    for (let i = 0; i < node2.min - 1; i++) {
      if (node2.comma && result !== MATCH) {
        result = createCondition(
          { type: "Comma", syntax: node2 },
          result,
          MISMATCH
        );
      }
      result = createCondition(
        matchTerm,
        result,
        MISMATCH
      );
    }
  }
  return result;
}
function buildMatchGraphInternal(node2) {
  if (typeof node2 === "function") {
    return {
      type: "Generic",
      fn: node2
    };
  }
  switch (node2.type) {
    case "Group": {
      let result = buildGroupMatchGraph(
        node2.combinator,
        node2.terms.map(buildMatchGraphInternal),
        false
      );
      if (node2.disallowEmpty) {
        result = createCondition(
          result,
          DISALLOW_EMPTY,
          MISMATCH
        );
      }
      return result;
    }
    case "Multiplier":
      return buildMultiplierMatchGraph(node2);
    case "Type":
    case "Property":
      return {
        type: node2.type,
        name: node2.name,
        syntax: node2
      };
    case "Keyword":
      return {
        type: node2.type,
        name: node2.name.toLowerCase(),
        syntax: node2
      };
    case "AtKeyword":
      return {
        type: node2.type,
        name: "@" + node2.name.toLowerCase(),
        syntax: node2
      };
    case "Function":
      return {
        type: node2.type,
        name: node2.name.toLowerCase() + "(",
        syntax: node2
      };
    case "String":
      if (node2.value.length === 3) {
        return {
          type: "Token",
          value: node2.value.charAt(1),
          syntax: node2
        };
      }
      return {
        type: node2.type,
        value: node2.value.substr(1, node2.value.length - 2).replace(/\\'/g, "'"),
        syntax: node2
      };
    case "Token":
      return {
        type: node2.type,
        value: node2.value,
        syntax: node2
      };
    case "Comma":
      return {
        type: node2.type,
        syntax: node2
      };
    default:
      throw new Error("Unknown node type:", node2.type);
  }
}
function buildMatchGraph(syntaxTree, ref) {
  if (typeof syntaxTree === "string") {
    syntaxTree = parse$J.parse(syntaxTree);
  }
  return {
    type: "MatchGraph",
    match: buildMatchGraphInternal(syntaxTree),
    syntax: ref || null,
    source: syntaxTree
  };
}
matchGraph$2.DISALLOW_EMPTY = DISALLOW_EMPTY;
matchGraph$2.MATCH = MATCH;
matchGraph$2.MISMATCH = MISMATCH;
matchGraph$2.buildMatchGraph = buildMatchGraph;
var match$1 = {};
const matchGraph$1 = matchGraph$2;
const types$H = types$R;
const { hasOwnProperty: hasOwnProperty$7 } = Object.prototype;
const STUB = 0;
const TOKEN = 1;
const OPEN_SYNTAX = 2;
const CLOSE_SYNTAX = 3;
const EXIT_REASON_MATCH = "Match";
const EXIT_REASON_MISMATCH = "Mismatch";
const EXIT_REASON_ITERATION_LIMIT = "Maximum iteration number exceeded (please fill an issue on https://github.com/csstree/csstree/issues)";
const ITERATION_LIMIT = 15e3;
function reverseList(list) {
  let prev = null;
  let next = null;
  let item = list;
  while (item !== null) {
    next = item.prev;
    item.prev = prev;
    prev = item;
    item = next;
  }
  return prev;
}
function areStringsEqualCaseInsensitive(testStr, referenceStr) {
  if (testStr.length !== referenceStr.length) {
    return false;
  }
  for (let i = 0; i < testStr.length; i++) {
    const referenceCode = referenceStr.charCodeAt(i);
    let testCode = testStr.charCodeAt(i);
    if (testCode >= 65 && testCode <= 90) {
      testCode = testCode | 32;
    }
    if (testCode !== referenceCode) {
      return false;
    }
  }
  return true;
}
function isContextEdgeDelim(token) {
  if (token.type !== types$H.Delim) {
    return false;
  }
  return token.value !== "?";
}
function isCommaContextStart(token) {
  if (token === null) {
    return true;
  }
  return token.type === types$H.Comma || token.type === types$H.Function || token.type === types$H.LeftParenthesis || token.type === types$H.LeftSquareBracket || token.type === types$H.LeftCurlyBracket || isContextEdgeDelim(token);
}
function isCommaContextEnd(token) {
  if (token === null) {
    return true;
  }
  return token.type === types$H.RightParenthesis || token.type === types$H.RightSquareBracket || token.type === types$H.RightCurlyBracket || token.type === types$H.Delim && token.value === "/";
}
function internalMatch(tokens, state, syntaxes) {
  function moveToNextToken() {
    do {
      tokenIndex++;
      token = tokenIndex < tokens.length ? tokens[tokenIndex] : null;
    } while (token !== null && (token.type === types$H.WhiteSpace || token.type === types$H.Comment));
  }
  function getNextToken(offset) {
    const nextIndex = tokenIndex + offset;
    return nextIndex < tokens.length ? tokens[nextIndex] : null;
  }
  function stateSnapshotFromSyntax(nextState, prev) {
    return {
      nextState,
      matchStack,
      syntaxStack,
      thenStack,
      tokenIndex,
      prev
    };
  }
  function pushThenStack(nextState) {
    thenStack = {
      nextState,
      matchStack,
      syntaxStack,
      prev: thenStack
    };
  }
  function pushElseStack(nextState) {
    elseStack = stateSnapshotFromSyntax(nextState, elseStack);
  }
  function addTokenToMatch() {
    matchStack = {
      type: TOKEN,
      syntax: state.syntax,
      token,
      prev: matchStack
    };
    moveToNextToken();
    syntaxStash = null;
    if (tokenIndex > longestMatch) {
      longestMatch = tokenIndex;
    }
  }
  function openSyntax() {
    syntaxStack = {
      syntax: state.syntax,
      opts: state.syntax.opts || syntaxStack !== null && syntaxStack.opts || null,
      prev: syntaxStack
    };
    matchStack = {
      type: OPEN_SYNTAX,
      syntax: state.syntax,
      token: matchStack.token,
      prev: matchStack
    };
  }
  function closeSyntax() {
    if (matchStack.type === OPEN_SYNTAX) {
      matchStack = matchStack.prev;
    } else {
      matchStack = {
        type: CLOSE_SYNTAX,
        syntax: syntaxStack.syntax,
        token: matchStack.token,
        prev: matchStack
      };
    }
    syntaxStack = syntaxStack.prev;
  }
  let syntaxStack = null;
  let thenStack = null;
  let elseStack = null;
  let syntaxStash = null;
  let iterationCount = 0;
  let exitReason = null;
  let token = null;
  let tokenIndex = -1;
  let longestMatch = 0;
  let matchStack = {
    type: STUB,
    syntax: null,
    token: null,
    prev: null
  };
  moveToNextToken();
  while (exitReason === null && ++iterationCount < ITERATION_LIMIT) {
    switch (state.type) {
      case "Match":
        if (thenStack === null) {
          if (token !== null) {
            if (tokenIndex !== tokens.length - 1 || token.value !== "\\0" && token.value !== "\\9") {
              state = matchGraph$1.MISMATCH;
              break;
            }
          }
          exitReason = EXIT_REASON_MATCH;
          break;
        }
        state = thenStack.nextState;
        if (state === matchGraph$1.DISALLOW_EMPTY) {
          if (thenStack.matchStack === matchStack) {
            state = matchGraph$1.MISMATCH;
            break;
          } else {
            state = matchGraph$1.MATCH;
          }
        }
        while (thenStack.syntaxStack !== syntaxStack) {
          closeSyntax();
        }
        thenStack = thenStack.prev;
        break;
      case "Mismatch":
        if (syntaxStash !== null && syntaxStash !== false) {
          if (elseStack === null || tokenIndex > elseStack.tokenIndex) {
            elseStack = syntaxStash;
            syntaxStash = false;
          }
        } else if (elseStack === null) {
          exitReason = EXIT_REASON_MISMATCH;
          break;
        }
        state = elseStack.nextState;
        thenStack = elseStack.thenStack;
        syntaxStack = elseStack.syntaxStack;
        matchStack = elseStack.matchStack;
        tokenIndex = elseStack.tokenIndex;
        token = tokenIndex < tokens.length ? tokens[tokenIndex] : null;
        elseStack = elseStack.prev;
        break;
      case "MatchGraph":
        state = state.match;
        break;
      case "If":
        if (state.else !== matchGraph$1.MISMATCH) {
          pushElseStack(state.else);
        }
        if (state.then !== matchGraph$1.MATCH) {
          pushThenStack(state.then);
        }
        state = state.match;
        break;
      case "MatchOnce":
        state = {
          type: "MatchOnceBuffer",
          syntax: state,
          index: 0,
          mask: 0
        };
        break;
      case "MatchOnceBuffer": {
        const terms = state.syntax.terms;
        if (state.index === terms.length) {
          if (state.mask === 0 || state.syntax.all) {
            state = matchGraph$1.MISMATCH;
            break;
          }
          state = matchGraph$1.MATCH;
          break;
        }
        if (state.mask === (1 << terms.length) - 1) {
          state = matchGraph$1.MATCH;
          break;
        }
        for (; state.index < terms.length; state.index++) {
          const matchFlag = 1 << state.index;
          if ((state.mask & matchFlag) === 0) {
            pushElseStack(state);
            pushThenStack({
              type: "AddMatchOnce",
              syntax: state.syntax,
              mask: state.mask | matchFlag
            });
            state = terms[state.index++];
            break;
          }
        }
        break;
      }
      case "AddMatchOnce":
        state = {
          type: "MatchOnceBuffer",
          syntax: state.syntax,
          index: 0,
          mask: state.mask
        };
        break;
      case "Enum":
        if (token !== null) {
          let name2 = token.value.toLowerCase();
          if (name2.indexOf("\\") !== -1) {
            name2 = name2.replace(/\\[09].*$/, "");
          }
          if (hasOwnProperty$7.call(state.map, name2)) {
            state = state.map[name2];
            break;
          }
        }
        state = matchGraph$1.MISMATCH;
        break;
      case "Generic": {
        const opts = syntaxStack !== null ? syntaxStack.opts : null;
        const lastTokenIndex2 = tokenIndex + Math.floor(state.fn(token, getNextToken, opts));
        if (!isNaN(lastTokenIndex2) && lastTokenIndex2 > tokenIndex) {
          while (tokenIndex < lastTokenIndex2) {
            addTokenToMatch();
          }
          state = matchGraph$1.MATCH;
        } else {
          state = matchGraph$1.MISMATCH;
        }
        break;
      }
      case "Type":
      case "Property": {
        const syntaxDict = state.type === "Type" ? "types" : "properties";
        const dictSyntax = hasOwnProperty$7.call(syntaxes, syntaxDict) ? syntaxes[syntaxDict][state.name] : null;
        if (!dictSyntax || !dictSyntax.match) {
          throw new Error(
            "Bad syntax reference: " + (state.type === "Type" ? "<" + state.name + ">" : "<'" + state.name + "'>")
          );
        }
        if (syntaxStash !== false && token !== null && state.type === "Type") {
          const lowPriorityMatching = state.name === "custom-ident" && token.type === types$H.Ident || state.name === "length" && token.value === "0";
          if (lowPriorityMatching) {
            if (syntaxStash === null) {
              syntaxStash = stateSnapshotFromSyntax(state, elseStack);
            }
            state = matchGraph$1.MISMATCH;
            break;
          }
        }
        openSyntax();
        state = dictSyntax.match;
        break;
      }
      case "Keyword": {
        const name2 = state.name;
        if (token !== null) {
          let keywordName = token.value;
          if (keywordName.indexOf("\\") !== -1) {
            keywordName = keywordName.replace(/\\[09].*$/, "");
          }
          if (areStringsEqualCaseInsensitive(keywordName, name2)) {
            addTokenToMatch();
            state = matchGraph$1.MATCH;
            break;
          }
        }
        state = matchGraph$1.MISMATCH;
        break;
      }
      case "AtKeyword":
      case "Function":
        if (token !== null && areStringsEqualCaseInsensitive(token.value, state.name)) {
          addTokenToMatch();
          state = matchGraph$1.MATCH;
          break;
        }
        state = matchGraph$1.MISMATCH;
        break;
      case "Token":
        if (token !== null && token.value === state.value) {
          addTokenToMatch();
          state = matchGraph$1.MATCH;
          break;
        }
        state = matchGraph$1.MISMATCH;
        break;
      case "Comma":
        if (token !== null && token.type === types$H.Comma) {
          if (isCommaContextStart(matchStack.token)) {
            state = matchGraph$1.MISMATCH;
          } else {
            addTokenToMatch();
            state = isCommaContextEnd(token) ? matchGraph$1.MISMATCH : matchGraph$1.MATCH;
          }
        } else {
          state = isCommaContextStart(matchStack.token) || isCommaContextEnd(token) ? matchGraph$1.MATCH : matchGraph$1.MISMATCH;
        }
        break;
      case "String":
        let string2 = "";
        let lastTokenIndex = tokenIndex;
        for (; lastTokenIndex < tokens.length && string2.length < state.value.length; lastTokenIndex++) {
          string2 += tokens[lastTokenIndex].value;
        }
        if (areStringsEqualCaseInsensitive(string2, state.value)) {
          while (tokenIndex < lastTokenIndex) {
            addTokenToMatch();
          }
          state = matchGraph$1.MATCH;
        } else {
          state = matchGraph$1.MISMATCH;
        }
        break;
      default:
        throw new Error("Unknown node type: " + state.type);
    }
  }
  switch (exitReason) {
    case null:
      console.warn("[csstree-match] BREAK after " + ITERATION_LIMIT + " iterations");
      exitReason = EXIT_REASON_ITERATION_LIMIT;
      matchStack = null;
      break;
    case EXIT_REASON_MATCH:
      while (syntaxStack !== null) {
        closeSyntax();
      }
      break;
    default:
      matchStack = null;
  }
  return {
    tokens,
    reason: exitReason,
    iterations: iterationCount,
    match: matchStack,
    longestMatch
  };
}
function matchAsList(tokens, matchGraph2, syntaxes) {
  const matchResult = internalMatch(tokens, matchGraph2, syntaxes || {});
  if (matchResult.match !== null) {
    let item = reverseList(matchResult.match).prev;
    matchResult.match = [];
    while (item !== null) {
      switch (item.type) {
        case OPEN_SYNTAX:
        case CLOSE_SYNTAX:
          matchResult.match.push({
            type: item.type,
            syntax: item.syntax
          });
          break;
        default:
          matchResult.match.push({
            token: item.token.value,
            node: item.token.node
          });
          break;
      }
      item = item.prev;
    }
  }
  return matchResult;
}
function matchAsTree(tokens, matchGraph2, syntaxes) {
  const matchResult = internalMatch(tokens, matchGraph2, syntaxes || {});
  if (matchResult.match === null) {
    return matchResult;
  }
  let item = matchResult.match;
  let host = matchResult.match = {
    syntax: matchGraph2.syntax || null,
    match: []
  };
  const hostStack = [host];
  item = reverseList(item).prev;
  while (item !== null) {
    switch (item.type) {
      case OPEN_SYNTAX:
        host.match.push(host = {
          syntax: item.syntax,
          match: []
        });
        hostStack.push(host);
        break;
      case CLOSE_SYNTAX:
        hostStack.pop();
        host = hostStack[hostStack.length - 1];
        break;
      default:
        host.match.push({
          syntax: item.syntax || null,
          token: item.token.value,
          node: item.token.node
        });
    }
    item = item.prev;
  }
  return matchResult;
}
match$1.matchAsList = matchAsList;
match$1.matchAsTree = matchAsTree;
var trace$1 = {};
function getTrace(node2) {
  function shouldPutToTrace(syntax2) {
    if (syntax2 === null) {
      return false;
    }
    return syntax2.type === "Type" || syntax2.type === "Property" || syntax2.type === "Keyword";
  }
  function hasMatch(matchNode) {
    if (Array.isArray(matchNode.match)) {
      for (let i = 0; i < matchNode.match.length; i++) {
        if (hasMatch(matchNode.match[i])) {
          if (shouldPutToTrace(matchNode.syntax)) {
            result.unshift(matchNode.syntax);
          }
          return true;
        }
      }
    } else if (matchNode.node === node2) {
      result = shouldPutToTrace(matchNode.syntax) ? [matchNode.syntax] : [];
      return true;
    }
    return false;
  }
  let result = null;
  if (this.matched !== null) {
    hasMatch(this.matched);
  }
  return result;
}
function isType(node2, type) {
  return testNode(this, node2, (match2) => match2.type === "Type" && match2.name === type);
}
function isProperty(node2, property2) {
  return testNode(this, node2, (match2) => match2.type === "Property" && match2.name === property2);
}
function isKeyword(node2) {
  return testNode(this, node2, (match2) => match2.type === "Keyword");
}
function testNode(match2, node2, fn) {
  const trace2 = getTrace.call(match2, node2);
  if (trace2 === null) {
    return false;
  }
  return trace2.some(fn);
}
trace$1.getTrace = getTrace;
trace$1.isKeyword = isKeyword;
trace$1.isProperty = isProperty;
trace$1.isType = isType;
var search$1 = {};
const List$3 = List$7;
function getFirstMatchNode(matchNode) {
  if ("node" in matchNode) {
    return matchNode.node;
  }
  return getFirstMatchNode(matchNode.match[0]);
}
function getLastMatchNode(matchNode) {
  if ("node" in matchNode) {
    return matchNode.node;
  }
  return getLastMatchNode(matchNode.match[matchNode.match.length - 1]);
}
function matchFragments(lexer2, ast, match2, type, name2) {
  function findFragments(matchNode) {
    if (matchNode.syntax !== null && matchNode.syntax.type === type && matchNode.syntax.name === name2) {
      const start = getFirstMatchNode(matchNode);
      const end = getLastMatchNode(matchNode);
      lexer2.syntax.walk(ast, function(node2, item, list) {
        if (node2 === start) {
          const nodes = new List$3.List();
          do {
            nodes.appendData(item.data);
            if (item.data === end) {
              break;
            }
            item = item.next;
          } while (item !== null);
          fragments.push({
            parent: list,
            nodes
          });
        }
      });
    }
    if (Array.isArray(matchNode.match)) {
      matchNode.match.forEach(findFragments);
    }
  }
  const fragments = [];
  if (match2.matched !== null) {
    findFragments(match2.matched);
  }
  return fragments;
}
search$1.matchFragments = matchFragments;
var structure$F = {};
const List$2 = List$7;
const { hasOwnProperty: hasOwnProperty$6 } = Object.prototype;
function isValidNumber(value2) {
  return typeof value2 === "number" && isFinite(value2) && Math.floor(value2) === value2 && value2 >= 0;
}
function isValidLocation(loc) {
  return Boolean(loc) && isValidNumber(loc.offset) && isValidNumber(loc.line) && isValidNumber(loc.column);
}
function createNodeStructureChecker(type, fields) {
  return function checkNode(node2, warn) {
    if (!node2 || node2.constructor !== Object) {
      return warn(node2, "Type of node should be an Object");
    }
    for (let key in node2) {
      let valid = true;
      if (hasOwnProperty$6.call(node2, key) === false) {
        continue;
      }
      if (key === "type") {
        if (node2.type !== type) {
          warn(node2, "Wrong node type `" + node2.type + "`, expected `" + type + "`");
        }
      } else if (key === "loc") {
        if (node2.loc === null) {
          continue;
        } else if (node2.loc && node2.loc.constructor === Object) {
          if (typeof node2.loc.source !== "string") {
            key += ".source";
          } else if (!isValidLocation(node2.loc.start)) {
            key += ".start";
          } else if (!isValidLocation(node2.loc.end)) {
            key += ".end";
          } else {
            continue;
          }
        }
        valid = false;
      } else if (fields.hasOwnProperty(key)) {
        valid = false;
        for (let i = 0; !valid && i < fields[key].length; i++) {
          const fieldType = fields[key][i];
          switch (fieldType) {
            case String:
              valid = typeof node2[key] === "string";
              break;
            case Boolean:
              valid = typeof node2[key] === "boolean";
              break;
            case null:
              valid = node2[key] === null;
              break;
            default:
              if (typeof fieldType === "string") {
                valid = node2[key] && node2[key].type === fieldType;
              } else if (Array.isArray(fieldType)) {
                valid = node2[key] instanceof List$2.List;
              }
          }
        }
      } else {
        warn(node2, "Unknown field `" + key + "` for " + type + " node type");
      }
      if (!valid) {
        warn(node2, "Bad value for `" + type + "." + key + "`");
      }
    }
    for (const key in fields) {
      if (hasOwnProperty$6.call(fields, key) && hasOwnProperty$6.call(node2, key) === false) {
        warn(node2, "Field `" + type + "." + key + "` is missed");
      }
    }
  };
}
function processStructure(name2, nodeType) {
  const structure2 = nodeType.structure;
  const fields = {
    type: String,
    loc: true
  };
  const docs = {
    type: '"' + name2 + '"'
  };
  for (const key in structure2) {
    if (hasOwnProperty$6.call(structure2, key) === false) {
      continue;
    }
    const docsTypes = [];
    const fieldTypes = fields[key] = Array.isArray(structure2[key]) ? structure2[key].slice() : [structure2[key]];
    for (let i = 0; i < fieldTypes.length; i++) {
      const fieldType = fieldTypes[i];
      if (fieldType === String || fieldType === Boolean) {
        docsTypes.push(fieldType.name);
      } else if (fieldType === null) {
        docsTypes.push("null");
      } else if (typeof fieldType === "string") {
        docsTypes.push("<" + fieldType + ">");
      } else if (Array.isArray(fieldType)) {
        docsTypes.push("List");
      } else {
        throw new Error("Wrong value `" + fieldType + "` in `" + name2 + "." + key + "` structure definition");
      }
    }
    docs[key] = docsTypes.join(" | ");
  }
  return {
    docs,
    check: createNodeStructureChecker(name2, fields)
  };
}
function getStructureFromConfig(config2) {
  const structure2 = {};
  if (config2.node) {
    for (const name2 in config2.node) {
      if (hasOwnProperty$6.call(config2.node, name2)) {
        const nodeType = config2.node[name2];
        if (nodeType.structure) {
          structure2[name2] = processStructure(name2, nodeType);
        } else {
          throw new Error("Missed `structure` field in `" + name2 + "` node type definition");
        }
      }
    }
  }
  return structure2;
}
structure$F.getStructureFromConfig = getStructureFromConfig;
var walk$5 = {};
const noop = function() {
};
function ensureFunction(value2) {
  return typeof value2 === "function" ? value2 : noop;
}
function walk$4(node2, options, context) {
  function walk2(node3) {
    enter.call(context, node3);
    switch (node3.type) {
      case "Group":
        node3.terms.forEach(walk2);
        break;
      case "Multiplier":
        walk2(node3.term);
        break;
      case "Type":
      case "Property":
      case "Keyword":
      case "AtKeyword":
      case "Function":
      case "String":
      case "Token":
      case "Comma":
        break;
      default:
        throw new Error("Unknown type: " + node3.type);
    }
    leave.call(context, node3);
  }
  let enter = noop;
  let leave = noop;
  if (typeof options === "function") {
    enter = options;
  } else if (options) {
    enter = ensureFunction(options.enter);
    leave = ensureFunction(options.leave);
  }
  if (enter === noop && leave === noop) {
    throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function");
  }
  walk2(node2);
}
walk$5.walk = walk$4;
const error$1 = error$2;
const names$3 = names$4;
const genericConst = genericConst$2;
const generic = generic$1;
const prepareTokens = prepareTokens_1;
const matchGraph = matchGraph$2;
const match = match$1;
const trace = trace$1;
const search = search$1;
const structure$E = structure$F;
const parse$I = parse$L;
const generate$I = generate$L;
const walk$3 = walk$5;
const cssWideKeywordsSyntax = matchGraph.buildMatchGraph(genericConst.cssWideKeywords.join(" | "));
function dumpMapSyntax(map, compact, syntaxAsAst) {
  const result = {};
  for (const name2 in map) {
    if (map[name2].syntax) {
      result[name2] = syntaxAsAst ? map[name2].syntax : generate$I.generate(map[name2].syntax, { compact });
    }
  }
  return result;
}
function dumpAtruleMapSyntax(map, compact, syntaxAsAst) {
  const result = {};
  for (const [name2, atrule2] of Object.entries(map)) {
    result[name2] = {
      prelude: atrule2.prelude && (syntaxAsAst ? atrule2.prelude.syntax : generate$I.generate(atrule2.prelude.syntax, { compact })),
      descriptors: atrule2.descriptors && dumpMapSyntax(atrule2.descriptors, compact, syntaxAsAst)
    };
  }
  return result;
}
function valueHasVar(tokens) {
  for (let i = 0; i < tokens.length; i++) {
    if (tokens[i].value.toLowerCase() === "var(") {
      return true;
    }
  }
  return false;
}
function buildMatchResult(matched, error2, iterations) {
  return {
    matched,
    iterations,
    error: error2,
    ...trace
  };
}
function matchSyntax(lexer2, syntax2, value2, useCssWideKeywords) {
  const tokens = prepareTokens(value2, lexer2.syntax);
  let result;
  if (valueHasVar(tokens)) {
    return buildMatchResult(null, new Error("Matching for a tree with var() is not supported"));
  }
  if (useCssWideKeywords) {
    result = match.matchAsTree(tokens, lexer2.cssWideKeywordsSyntax, lexer2);
  }
  if (!useCssWideKeywords || !result.match) {
    result = match.matchAsTree(tokens, syntax2.match, lexer2);
    if (!result.match) {
      return buildMatchResult(
        null,
        new error$1.SyntaxMatchError(result.reason, syntax2.syntax, value2, result),
        result.iterations
      );
    }
  }
  return buildMatchResult(result.match, null, result.iterations);
}
class Lexer$2 {
  constructor(config2, syntax2, structure$12) {
    this.cssWideKeywordsSyntax = cssWideKeywordsSyntax;
    this.syntax = syntax2;
    this.generic = false;
    this.atrules = /* @__PURE__ */ Object.create(null);
    this.properties = /* @__PURE__ */ Object.create(null);
    this.types = /* @__PURE__ */ Object.create(null);
    this.structure = structure$12 || structure$E.getStructureFromConfig(config2);
    if (config2) {
      if (config2.types) {
        for (const name2 in config2.types) {
          this.addType_(name2, config2.types[name2]);
        }
      }
      if (config2.generic) {
        this.generic = true;
        for (const name2 in generic) {
          this.addType_(name2, generic[name2]);
        }
      }
      if (config2.atrules) {
        for (const name2 in config2.atrules) {
          this.addAtrule_(name2, config2.atrules[name2]);
        }
      }
      if (config2.properties) {
        for (const name2 in config2.properties) {
          this.addProperty_(name2, config2.properties[name2]);
        }
      }
    }
  }
  checkStructure(ast) {
    function collectWarning(node2, message) {
      warns.push({ node: node2, message });
    }
    const structure2 = this.structure;
    const warns = [];
    this.syntax.walk(ast, function(node2) {
      if (structure2.hasOwnProperty(node2.type)) {
        structure2[node2.type].check(node2, collectWarning);
      } else {
        collectWarning(node2, "Unknown node type `" + node2.type + "`");
      }
    });
    return warns.length ? warns : false;
  }
  createDescriptor(syntax2, type, name2, parent = null) {
    const ref = {
      type,
      name: name2
    };
    const descriptor = {
      type,
      name: name2,
      parent,
      serializable: typeof syntax2 === "string" || syntax2 && typeof syntax2.type === "string",
      syntax: null,
      match: null
    };
    if (typeof syntax2 === "function") {
      descriptor.match = matchGraph.buildMatchGraph(syntax2, ref);
    } else {
      if (typeof syntax2 === "string") {
        Object.defineProperty(descriptor, "syntax", {
          get() {
            Object.defineProperty(descriptor, "syntax", {
              value: parse$I.parse(syntax2)
            });
            return descriptor.syntax;
          }
        });
      } else {
        descriptor.syntax = syntax2;
      }
      Object.defineProperty(descriptor, "match", {
        get() {
          Object.defineProperty(descriptor, "match", {
            value: matchGraph.buildMatchGraph(descriptor.syntax, ref)
          });
          return descriptor.match;
        }
      });
    }
    return descriptor;
  }
  addAtrule_(name2, syntax2) {
    if (!syntax2) {
      return;
    }
    this.atrules[name2] = {
      type: "Atrule",
      name: name2,
      prelude: syntax2.prelude ? this.createDescriptor(syntax2.prelude, "AtrulePrelude", name2) : null,
      descriptors: syntax2.descriptors ? Object.keys(syntax2.descriptors).reduce(
        (map, descName) => {
          map[descName] = this.createDescriptor(syntax2.descriptors[descName], "AtruleDescriptor", descName, name2);
          return map;
        },
        /* @__PURE__ */ Object.create(null)
      ) : null
    };
  }
  addProperty_(name2, syntax2) {
    if (!syntax2) {
      return;
    }
    this.properties[name2] = this.createDescriptor(syntax2, "Property", name2);
  }
  addType_(name2, syntax2) {
    if (!syntax2) {
      return;
    }
    this.types[name2] = this.createDescriptor(syntax2, "Type", name2);
  }
  checkAtruleName(atruleName) {
    if (!this.getAtrule(atruleName)) {
      return new error$1.SyntaxReferenceError("Unknown at-rule", "@" + atruleName);
    }
  }
  checkAtrulePrelude(atruleName, prelude) {
    const error2 = this.checkAtruleName(atruleName);
    if (error2) {
      return error2;
    }
    const atrule2 = this.getAtrule(atruleName);
    if (!atrule2.prelude && prelude) {
      return new SyntaxError("At-rule `@" + atruleName + "` should not contain a prelude");
    }
    if (atrule2.prelude && !prelude) {
      if (!matchSyntax(this, atrule2.prelude, "", false).matched) {
        return new SyntaxError("At-rule `@" + atruleName + "` should contain a prelude");
      }
    }
  }
  checkAtruleDescriptorName(atruleName, descriptorName) {
    const error$1$1 = this.checkAtruleName(atruleName);
    if (error$1$1) {
      return error$1$1;
    }
    const atrule2 = this.getAtrule(atruleName);
    const descriptor = names$3.keyword(descriptorName);
    if (!atrule2.descriptors) {
      return new SyntaxError("At-rule `@" + atruleName + "` has no known descriptors");
    }
    if (!atrule2.descriptors[descriptor.name] && !atrule2.descriptors[descriptor.basename]) {
      return new error$1.SyntaxReferenceError("Unknown at-rule descriptor", descriptorName);
    }
  }
  checkPropertyName(propertyName) {
    if (!this.getProperty(propertyName)) {
      return new error$1.SyntaxReferenceError("Unknown property", propertyName);
    }
  }
  matchAtrulePrelude(atruleName, prelude) {
    const error2 = this.checkAtrulePrelude(atruleName, prelude);
    if (error2) {
      return buildMatchResult(null, error2);
    }
    const atrule2 = this.getAtrule(atruleName);
    if (!atrule2.prelude) {
      return buildMatchResult(null, null);
    }
    return matchSyntax(this, atrule2.prelude, prelude || "", false);
  }
  matchAtruleDescriptor(atruleName, descriptorName, value2) {
    const error2 = this.checkAtruleDescriptorName(atruleName, descriptorName);
    if (error2) {
      return buildMatchResult(null, error2);
    }
    const atrule2 = this.getAtrule(atruleName);
    const descriptor = names$3.keyword(descriptorName);
    return matchSyntax(this, atrule2.descriptors[descriptor.name] || atrule2.descriptors[descriptor.basename], value2, false);
  }
  matchDeclaration(node2) {
    if (node2.type !== "Declaration") {
      return buildMatchResult(null, new Error("Not a Declaration node"));
    }
    return this.matchProperty(node2.property, node2.value);
  }
  matchProperty(propertyName, value2) {
    if (names$3.property(propertyName).custom) {
      return buildMatchResult(null, new Error("Lexer matching doesn't applicable for custom properties"));
    }
    const error2 = this.checkPropertyName(propertyName);
    if (error2) {
      return buildMatchResult(null, error2);
    }
    return matchSyntax(this, this.getProperty(propertyName), value2, true);
  }
  matchType(typeName, value2) {
    const typeSyntax = this.getType(typeName);
    if (!typeSyntax) {
      return buildMatchResult(null, new error$1.SyntaxReferenceError("Unknown type", typeName));
    }
    return matchSyntax(this, typeSyntax, value2, false);
  }
  match(syntax2, value2) {
    if (typeof syntax2 !== "string" && (!syntax2 || !syntax2.type)) {
      return buildMatchResult(null, new error$1.SyntaxReferenceError("Bad syntax"));
    }
    if (typeof syntax2 === "string" || !syntax2.match) {
      syntax2 = this.createDescriptor(syntax2, "Type", "anonymous");
    }
    return matchSyntax(this, syntax2, value2, false);
  }
  findValueFragments(propertyName, value2, type, name2) {
    return search.matchFragments(this, value2, this.matchProperty(propertyName, value2), type, name2);
  }
  findDeclarationValueFragments(declaration, type, name2) {
    return search.matchFragments(this, declaration.value, this.matchDeclaration(declaration), type, name2);
  }
  findAllFragments(ast, type, name2) {
    const result = [];
    this.syntax.walk(ast, {
      visit: "Declaration",
      enter: (declaration) => {
        result.push.apply(result, this.findDeclarationValueFragments(declaration, type, name2));
      }
    });
    return result;
  }
  getAtrule(atruleName, fallbackBasename = true) {
    const atrule2 = names$3.keyword(atruleName);
    const atruleEntry = atrule2.vendor && fallbackBasename ? this.atrules[atrule2.name] || this.atrules[atrule2.basename] : this.atrules[atrule2.name];
    return atruleEntry || null;
  }
  getAtrulePrelude(atruleName, fallbackBasename = true) {
    const atrule2 = this.getAtrule(atruleName, fallbackBasename);
    return atrule2 && atrule2.prelude || null;
  }
  getAtruleDescriptor(atruleName, name2) {
    return this.atrules.hasOwnProperty(atruleName) && this.atrules.declarators ? this.atrules[atruleName].declarators[name2] || null : null;
  }
  getProperty(propertyName, fallbackBasename = true) {
    const property2 = names$3.property(propertyName);
    const propertyEntry = property2.vendor && fallbackBasename ? this.properties[property2.name] || this.properties[property2.basename] : this.properties[property2.name];
    return propertyEntry || null;
  }
  getType(name2) {
    return hasOwnProperty.call(this.types, name2) ? this.types[name2] : null;
  }
  validate() {
    function validate(syntax2, name2, broken, descriptor) {
      if (broken.has(name2)) {
        return broken.get(name2);
      }
      broken.set(name2, false);
      if (descriptor.syntax !== null) {
        walk$3.walk(descriptor.syntax, function(node2) {
          if (node2.type !== "Type" && node2.type !== "Property") {
            return;
          }
          const map = node2.type === "Type" ? syntax2.types : syntax2.properties;
          const brokenMap = node2.type === "Type" ? brokenTypes : brokenProperties;
          if (!hasOwnProperty.call(map, node2.name) || validate(syntax2, node2.name, brokenMap, map[node2.name])) {
            broken.set(name2, true);
          }
        }, this);
      }
    }
    let brokenTypes = /* @__PURE__ */ new Map();
    let brokenProperties = /* @__PURE__ */ new Map();
    for (const key in this.types) {
      validate(this, key, brokenTypes, this.types[key]);
    }
    for (const key in this.properties) {
      validate(this, key, brokenProperties, this.properties[key]);
    }
    brokenTypes = [...brokenTypes.keys()].filter((name2) => brokenTypes.get(name2));
    brokenProperties = [...brokenProperties.keys()].filter((name2) => brokenProperties.get(name2));
    if (brokenTypes.length || brokenProperties.length) {
      return {
        types: brokenTypes,
        properties: brokenProperties
      };
    }
    return null;
  }
  dump(syntaxAsAst, pretty) {
    return {
      generic: this.generic,
      types: dumpMapSyntax(this.types, !pretty, syntaxAsAst),
      properties: dumpMapSyntax(this.properties, !pretty, syntaxAsAst),
      atrules: dumpAtruleMapSyntax(this.atrules, !pretty, syntaxAsAst)
    };
  }
  toString() {
    return JSON.stringify(this.dump());
  }
}
Lexer$3.Lexer = Lexer$2;
const { hasOwnProperty: hasOwnProperty$5 } = Object.prototype;
const shape = {
  generic: true,
  types: appendOrAssign,
  atrules: {
    prelude: appendOrAssignOrNull,
    descriptors: appendOrAssignOrNull
  },
  properties: appendOrAssign,
  parseContext: assign,
  scope: deepAssign,
  atrule: ["parse"],
  pseudo: ["parse"],
  node: ["name", "structure", "parse", "generate", "walkContext"]
};
function isObject(value2) {
  return value2 && value2.constructor === Object;
}
function copy(value2) {
  return isObject(value2) ? { ...value2 } : value2;
}
function assign(dest, src) {
  return Object.assign(dest, src);
}
function deepAssign(dest, src) {
  for (const key in src) {
    if (hasOwnProperty$5.call(src, key)) {
      if (isObject(dest[key])) {
        deepAssign(dest[key], src[key]);
      } else {
        dest[key] = copy(src[key]);
      }
    }
  }
  return dest;
}
function append(a, b) {
  if (typeof b === "string" && /^\s*\|/.test(b)) {
    return typeof a === "string" ? a + b : b.replace(/^\s*\|\s*/, "");
  }
  return b || null;
}
function appendOrAssign(a, b) {
  if (typeof b === "string") {
    return append(a, b);
  }
  const result = { ...a };
  for (let key in b) {
    if (hasOwnProperty$5.call(b, key)) {
      result[key] = append(hasOwnProperty$5.call(a, key) ? a[key] : void 0, b[key]);
    }
  }
  return result;
}
function appendOrAssignOrNull(a, b) {
  const result = appendOrAssign(a, b);
  return !isObject(result) || Object.keys(result).length ? result : null;
}
function mix$1(dest, src, shape2) {
  for (const key in shape2) {
    if (hasOwnProperty$5.call(shape2, key) === false) {
      continue;
    }
    if (shape2[key] === true) {
      if (hasOwnProperty$5.call(src, key)) {
        dest[key] = copy(src[key]);
      }
    } else if (shape2[key]) {
      if (typeof shape2[key] === "function") {
        const fn = shape2[key];
        dest[key] = fn({}, dest[key]);
        dest[key] = fn(dest[key] || {}, src[key]);
      } else if (isObject(shape2[key])) {
        const result = {};
        for (let name2 in dest[key]) {
          result[name2] = mix$1({}, dest[key][name2], shape2[key]);
        }
        for (let name2 in src[key]) {
          result[name2] = mix$1(result[name2] || {}, src[key][name2], shape2[key]);
        }
        dest[key] = result;
      } else if (Array.isArray(shape2[key])) {
        const res = {};
        const innerShape = shape2[key].reduce(function(s, k) {
          s[k] = true;
          return s;
        }, {});
        for (const [name2, value2] of Object.entries(dest[key] || {})) {
          res[name2] = {};
          if (value2) {
            mix$1(res[name2], value2, innerShape);
          }
        }
        for (const name2 in src[key]) {
          if (hasOwnProperty$5.call(src[key], name2)) {
            if (!res[name2]) {
              res[name2] = {};
            }
            if (src[key] && src[key][name2]) {
              mix$1(res[name2], src[key][name2], innerShape);
            }
          }
        }
        dest[key] = res;
      }
    }
  }
  return dest;
}
const mix$1$1 = (dest, src) => mix$1(dest, src, shape);
var mix_1 = mix$1$1;
const index$8 = tokenizer$2;
const create$2 = create$7;
const create$2$1 = create$6;
const create$3 = create$5;
const create$1$1 = create$4;
const Lexer$1 = Lexer$3;
const mix = mix_1;
function createSyntax(config2) {
  const parse2 = create$2.createParser(config2);
  const walk2 = create$1$1.createWalker(config2);
  const generate2 = create$2$1.createGenerator(config2);
  const { fromPlainObject: fromPlainObject2, toPlainObject: toPlainObject2 } = create$3.createConvertor(walk2);
  const syntax2 = {
    lexer: null,
    createLexer: (config3) => new Lexer$1.Lexer(config3, syntax2, syntax2.lexer.structure),
    tokenize: index$8.tokenize,
    parse: parse2,
    generate: generate2,
    walk: walk2,
    find: walk2.find,
    findLast: walk2.findLast,
    findAll: walk2.findAll,
    fromPlainObject: fromPlainObject2,
    toPlainObject: toPlainObject2,
    fork(extension) {
      const base = mix({}, config2);
      return createSyntax(
        typeof extension === "function" ? extension(base, Object.assign) : mix(base, extension)
      );
    }
  };
  syntax2.lexer = new Lexer$1.Lexer({
    generic: true,
    types: config2.types,
    atrules: config2.atrules,
    properties: config2.properties,
    node: config2.node
  }, syntax2);
  return syntax2;
}
const createSyntax$1 = (config2) => createSyntax(mix({}, config2));
var create_1 = createSyntax$1;
var data$1 = {
  "generic": true,
  "types": {
    "absolute-size": "xx-small|x-small|small|medium|large|x-large|xx-large|xxx-large",
    "alpha-value": "<number>|<percentage>",
    "angle-percentage": "<angle>|<percentage>",
    "angular-color-hint": "<angle-percentage>",
    "angular-color-stop": "<color>&&<color-stop-angle>?",
    "angular-color-stop-list": "[<angular-color-stop> [, <angular-color-hint>]?]# , <angular-color-stop>",
    "animateable-feature": "scroll-position|contents|<custom-ident>",
    "attachment": "scroll|fixed|local",
    "attr()": "attr( <attr-name> <type-or-unit>? [, <attr-fallback>]? )",
    "attr-matcher": "['~'|'|'|'^'|'$'|'*']? '='",
    "attr-modifier": "i|s",
    "attribute-selector": "'[' <wq-name> ']'|'[' <wq-name> <attr-matcher> [<string-token>|<ident-token>] <attr-modifier>? ']'",
    "auto-repeat": "repeat( [auto-fill|auto-fit] , [<line-names>? <fixed-size>]+ <line-names>? )",
    "auto-track-list": "[<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>? <auto-repeat> [<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>?",
    "baseline-position": "[first|last]? baseline",
    "basic-shape": "<inset()>|<circle()>|<ellipse()>|<polygon()>|<path()>",
    "bg-image": "none|<image>",
    "bg-layer": "<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>",
    "bg-position": "[[left|center|right|top|bottom|<length-percentage>]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]|[center|[left|right] <length-percentage>?]&&[center|[top|bottom] <length-percentage>?]]",
    "bg-size": "[<length-percentage>|auto]{1,2}|cover|contain",
    "blur()": "blur( <length> )",
    "blend-mode": "normal|multiply|screen|overlay|darken|lighten|color-dodge|color-burn|hard-light|soft-light|difference|exclusion|hue|saturation|color|luminosity",
    "box": "border-box|padding-box|content-box",
    "brightness()": "brightness( <number-percentage> )",
    "calc()": "calc( <calc-sum> )",
    "calc-sum": "<calc-product> [['+'|'-'] <calc-product>]*",
    "calc-product": "<calc-value> ['*' <calc-value>|'/' <number>]*",
    "calc-value": "<number>|<dimension>|<percentage>|( <calc-sum> )",
    "cf-final-image": "<image>|<color>",
    "cf-mixing-image": "<percentage>?&&<image>",
    "circle()": "circle( [<shape-radius>]? [at <position>]? )",
    "clamp()": "clamp( <calc-sum>#{3} )",
    "class-selector": "'.' <ident-token>",
    "clip-source": "<url>",
    "color": "<rgb()>|<rgba()>|<hsl()>|<hsla()>|<hwb()>|<lab()>|<lch()>|<hex-color>|<named-color>|currentcolor|<deprecated-system-color>",
    "color-stop": "<color-stop-length>|<color-stop-angle>",
    "color-stop-angle": "<angle-percentage>{1,2}",
    "color-stop-length": "<length-percentage>{1,2}",
    "color-stop-list": "[<linear-color-stop> [, <linear-color-hint>]?]# , <linear-color-stop>",
    "combinator": "'>'|'+'|'~'|['||']",
    "common-lig-values": "[common-ligatures|no-common-ligatures]",
    "compat-auto": "searchfield|textarea|push-button|slider-horizontal|checkbox|radio|square-button|menulist|listbox|meter|progress-bar|button",
    "composite-style": "clear|copy|source-over|source-in|source-out|source-atop|destination-over|destination-in|destination-out|destination-atop|xor",
    "compositing-operator": "add|subtract|intersect|exclude",
    "compound-selector": "[<type-selector>? <subclass-selector>* [<pseudo-element-selector> <pseudo-class-selector>*]*]!",
    "compound-selector-list": "<compound-selector>#",
    "complex-selector": "<compound-selector> [<combinator>? <compound-selector>]*",
    "complex-selector-list": "<complex-selector>#",
    "conic-gradient()": "conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )",
    "contextual-alt-values": "[contextual|no-contextual]",
    "content-distribution": "space-between|space-around|space-evenly|stretch",
    "content-list": "[<string>|contents|<image>|<counter>|<quote>|<target>|<leader()>|<attr()>]+",
    "content-position": "center|start|end|flex-start|flex-end",
    "content-replacement": "<image>",
    "contrast()": "contrast( [<number-percentage>] )",
    "counter": "<counter()>|<counters()>",
    "counter()": "counter( <counter-name> , <counter-style>? )",
    "counter-name": "<custom-ident>",
    "counter-style": "<counter-style-name>|symbols( )",
    "counter-style-name": "<custom-ident>",
    "counters()": "counters( <counter-name> , <string> , <counter-style>? )",
    "cross-fade()": "cross-fade( <cf-mixing-image> , <cf-final-image>? )",
    "cubic-bezier-timing-function": "ease|ease-in|ease-out|ease-in-out|cubic-bezier( <number [0,1]> , <number> , <number [0,1]> , <number> )",
    "deprecated-system-color": "ActiveBorder|ActiveCaption|AppWorkspace|Background|ButtonFace|ButtonHighlight|ButtonShadow|ButtonText|CaptionText|GrayText|Highlight|HighlightText|InactiveBorder|InactiveCaption|InactiveCaptionText|InfoBackground|InfoText|Menu|MenuText|Scrollbar|ThreeDDarkShadow|ThreeDFace|ThreeDHighlight|ThreeDLightShadow|ThreeDShadow|Window|WindowFrame|WindowText",
    "discretionary-lig-values": "[discretionary-ligatures|no-discretionary-ligatures]",
    "display-box": "contents|none",
    "display-inside": "flow|flow-root|table|flex|grid|ruby",
    "display-internal": "table-row-group|table-header-group|table-footer-group|table-row|table-cell|table-column-group|table-column|table-caption|ruby-base|ruby-text|ruby-base-container|ruby-text-container",
    "display-legacy": "inline-block|inline-list-item|inline-table|inline-flex|inline-grid",
    "display-listitem": "<display-outside>?&&[flow|flow-root]?&&list-item",
    "display-outside": "block|inline|run-in",
    "drop-shadow()": "drop-shadow( <length>{2,3} <color>? )",
    "east-asian-variant-values": "[jis78|jis83|jis90|jis04|simplified|traditional]",
    "east-asian-width-values": "[full-width|proportional-width]",
    "element()": "element( <custom-ident> , [first|start|last|first-except]? )|element( <id-selector> )",
    "ellipse()": "ellipse( [<shape-radius>{2}]? [at <position>]? )",
    "ending-shape": "circle|ellipse",
    "env()": "env( <custom-ident> , <declaration-value>? )",
    "explicit-track-list": "[<line-names>? <track-size>]+ <line-names>?",
    "family-name": "<string>|<custom-ident>+",
    "feature-tag-value": "<string> [<integer>|on|off]?",
    "feature-type": "@stylistic|@historical-forms|@styleset|@character-variant|@swash|@ornaments|@annotation",
    "feature-value-block": "<feature-type> '{' <feature-value-declaration-list> '}'",
    "feature-value-block-list": "<feature-value-block>+",
    "feature-value-declaration": "<custom-ident> : <integer>+ ;",
    "feature-value-declaration-list": "<feature-value-declaration>",
    "feature-value-name": "<custom-ident>",
    "fill-rule": "nonzero|evenodd",
    "filter-function": "<blur()>|<brightness()>|<contrast()>|<drop-shadow()>|<grayscale()>|<hue-rotate()>|<invert()>|<opacity()>|<saturate()>|<sepia()>",
    "filter-function-list": "[<filter-function>|<url>]+",
    "final-bg-layer": "<'background-color'>||<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>",
    "fit-content()": "fit-content( [<length>|<percentage>] )",
    "fixed-breadth": "<length-percentage>",
    "fixed-repeat": "repeat( [<integer [1,\u221E]>] , [<line-names>? <fixed-size>]+ <line-names>? )",
    "fixed-size": "<fixed-breadth>|minmax( <fixed-breadth> , <track-breadth> )|minmax( <inflexible-breadth> , <fixed-breadth> )",
    "font-stretch-absolute": "normal|ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded|<percentage>",
    "font-variant-css21": "[normal|small-caps]",
    "font-weight-absolute": "normal|bold|<number [1,1000]>",
    "frequency-percentage": "<frequency>|<percentage>",
    "general-enclosed": "[<function-token> <any-value> )]|( <ident> <any-value> )",
    "generic-family": "serif|sans-serif|cursive|fantasy|monospace|-apple-system",
    "generic-name": "serif|sans-serif|cursive|fantasy|monospace",
    "geometry-box": "<shape-box>|fill-box|stroke-box|view-box",
    "gradient": "<linear-gradient()>|<repeating-linear-gradient()>|<radial-gradient()>|<repeating-radial-gradient()>|<conic-gradient()>|<repeating-conic-gradient()>|<-legacy-gradient>",
    "grayscale()": "grayscale( <number-percentage> )",
    "grid-line": "auto|<custom-ident>|[<integer>&&<custom-ident>?]|[span&&[<integer>||<custom-ident>]]",
    "historical-lig-values": "[historical-ligatures|no-historical-ligatures]",
    "hsl()": "hsl( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsl( <hue> , <percentage> , <percentage> , <alpha-value>? )",
    "hsla()": "hsla( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsla( <hue> , <percentage> , <percentage> , <alpha-value>? )",
    "hue": "<number>|<angle>",
    "hue-rotate()": "hue-rotate( <angle> )",
    "hwb()": "hwb( [<hue>|none] [<percentage>|none] [<percentage>|none] [/ [<alpha-value>|none]]? )",
    "image": "<url>|<image()>|<image-set()>|<element()>|<paint()>|<cross-fade()>|<gradient>",
    "image()": "image( <image-tags>? [<image-src>? , <color>?]! )",
    "image-set()": "image-set( <image-set-option># )",
    "image-set-option": "[<image>|<string>] [<resolution>||type( <string> )]",
    "image-src": "<url>|<string>",
    "image-tags": "ltr|rtl",
    "inflexible-breadth": "<length>|<percentage>|min-content|max-content|auto",
    "inset()": "inset( <length-percentage>{1,4} [round <'border-radius'>]? )",
    "invert()": "invert( <number-percentage> )",
    "keyframes-name": "<custom-ident>|<string>",
    "keyframe-block": "<keyframe-selector># { <declaration-list> }",
    "keyframe-block-list": "<keyframe-block>+",
    "keyframe-selector": "from|to|<percentage>",
    "layer()": "layer( <layer-name> )",
    "layer-name": "<ident> ['.' <ident>]*",
    "leader()": "leader( <leader-type> )",
    "leader-type": "dotted|solid|space|<string>",
    "length-percentage": "<length>|<percentage>",
    "line-names": "'[' <custom-ident>* ']'",
    "line-name-list": "[<line-names>|<name-repeat>]+",
    "line-style": "none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset",
    "line-width": "<length>|thin|medium|thick",
    "linear-color-hint": "<length-percentage>",
    "linear-color-stop": "<color> <color-stop-length>?",
    "linear-gradient()": "linear-gradient( [<angle>|to <side-or-corner>]? , <color-stop-list> )",
    "mask-layer": "<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||<geometry-box>||[<geometry-box>|no-clip]||<compositing-operator>||<masking-mode>",
    "mask-position": "[<length-percentage>|left|center|right] [<length-percentage>|top|center|bottom]?",
    "mask-reference": "none|<image>|<mask-source>",
    "mask-source": "<url>",
    "masking-mode": "alpha|luminance|match-source",
    "matrix()": "matrix( <number>#{6} )",
    "matrix3d()": "matrix3d( <number>#{16} )",
    "max()": "max( <calc-sum># )",
    "media-and": "<media-in-parens> [and <media-in-parens>]+",
    "media-condition": "<media-not>|<media-and>|<media-or>|<media-in-parens>",
    "media-condition-without-or": "<media-not>|<media-and>|<media-in-parens>",
    "media-feature": "( [<mf-plain>|<mf-boolean>|<mf-range>] )",
    "media-in-parens": "( <media-condition> )|<media-feature>|<general-enclosed>",
    "media-not": "not <media-in-parens>",
    "media-or": "<media-in-parens> [or <media-in-parens>]+",
    "media-query": "<media-condition>|[not|only]? <media-type> [and <media-condition-without-or>]?",
    "media-query-list": "<media-query>#",
    "media-type": "<ident>",
    "mf-boolean": "<mf-name>",
    "mf-name": "<ident>",
    "mf-plain": "<mf-name> : <mf-value>",
    "mf-range": "<mf-name> ['<'|'>']? '='? <mf-value>|<mf-value> ['<'|'>']? '='? <mf-name>|<mf-value> '<' '='? <mf-name> '<' '='? <mf-value>|<mf-value> '>' '='? <mf-name> '>' '='? <mf-value>",
    "mf-value": "<number>|<dimension>|<ident>|<ratio>",
    "min()": "min( <calc-sum># )",
    "minmax()": "minmax( [<length>|<percentage>|min-content|max-content|auto] , [<length>|<percentage>|<flex>|min-content|max-content|auto] )",
    "name-repeat": "repeat( [<integer [1,\u221E]>|auto-fill] , <line-names>+ )",
    "named-color": "transparent|aliceblue|antiquewhite|aqua|aquamarine|azure|beige|bisque|black|blanchedalmond|blue|blueviolet|brown|burlywood|cadetblue|chartreuse|chocolate|coral|cornflowerblue|cornsilk|crimson|cyan|darkblue|darkcyan|darkgoldenrod|darkgray|darkgreen|darkgrey|darkkhaki|darkmagenta|darkolivegreen|darkorange|darkorchid|darkred|darksalmon|darkseagreen|darkslateblue|darkslategray|darkslategrey|darkturquoise|darkviolet|deeppink|deepskyblue|dimgray|dimgrey|dodgerblue|firebrick|floralwhite|forestgreen|fuchsia|gainsboro|ghostwhite|gold|goldenrod|gray|green|greenyellow|grey|honeydew|hotpink|indianred|indigo|ivory|khaki|lavender|lavenderblush|lawngreen|lemonchiffon|lightblue|lightcoral|lightcyan|lightgoldenrodyellow|lightgray|lightgreen|lightgrey|lightpink|lightsalmon|lightseagreen|lightskyblue|lightslategray|lightslategrey|lightsteelblue|lightyellow|lime|limegreen|linen|magenta|maroon|mediumaquamarine|mediumblue|mediumorchid|mediumpurple|mediumseagreen|mediumslateblue|mediumspringgreen|mediumturquoise|mediumvioletred|midnightblue|mintcream|mistyrose|moccasin|navajowhite|navy|oldlace|olive|olivedrab|orange|orangered|orchid|palegoldenrod|palegreen|paleturquoise|palevioletred|papayawhip|peachpuff|peru|pink|plum|powderblue|purple|rebeccapurple|red|rosybrown|royalblue|saddlebrown|salmon|sandybrown|seagreen|seashell|sienna|silver|skyblue|slateblue|slategray|slategrey|snow|springgreen|steelblue|tan|teal|thistle|tomato|turquoise|violet|wheat|white|whitesmoke|yellow|yellowgreen|<-non-standard-color>",
    "namespace-prefix": "<ident>",
    "ns-prefix": "[<ident-token>|'*']? '|'",
    "number-percentage": "<number>|<percentage>",
    "numeric-figure-values": "[lining-nums|oldstyle-nums]",
    "numeric-fraction-values": "[diagonal-fractions|stacked-fractions]",
    "numeric-spacing-values": "[proportional-nums|tabular-nums]",
    "nth": "<an-plus-b>|even|odd",
    "opacity()": "opacity( [<number-percentage>] )",
    "overflow-position": "unsafe|safe",
    "outline-radius": "<length>|<percentage>",
    "page-body": "<declaration>? [; <page-body>]?|<page-margin-box> <page-body>",
    "page-margin-box": "<page-margin-box-type> '{' <declaration-list> '}'",
    "page-margin-box-type": "@top-left-corner|@top-left|@top-center|@top-right|@top-right-corner|@bottom-left-corner|@bottom-left|@bottom-center|@bottom-right|@bottom-right-corner|@left-top|@left-middle|@left-bottom|@right-top|@right-middle|@right-bottom",
    "page-selector-list": "[<page-selector>#]?",
    "page-selector": "<pseudo-page>+|<ident> <pseudo-page>*",
    "page-size": "A5|A4|A3|B5|B4|JIS-B5|JIS-B4|letter|legal|ledger",
    "path()": "path( [<fill-rule> ,]? <string> )",
    "paint()": "paint( <ident> , <declaration-value>? )",
    "perspective()": "perspective( <length> )",
    "polygon()": "polygon( <fill-rule>? , [<length-percentage> <length-percentage>]# )",
    "position": "[[left|center|right]||[top|center|bottom]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]?|[[left|right] <length-percentage>]&&[[top|bottom] <length-percentage>]]",
    "pseudo-class-selector": "':' <ident-token>|':' <function-token> <any-value> ')'",
    "pseudo-element-selector": "':' <pseudo-class-selector>",
    "pseudo-page": ": [left|right|first|blank]",
    "quote": "open-quote|close-quote|no-open-quote|no-close-quote",
    "radial-gradient()": "radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )",
    "relative-selector": "<combinator>? <complex-selector>",
    "relative-selector-list": "<relative-selector>#",
    "relative-size": "larger|smaller",
    "repeat-style": "repeat-x|repeat-y|[repeat|space|round|no-repeat]{1,2}",
    "repeating-conic-gradient()": "repeating-conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )",
    "repeating-linear-gradient()": "repeating-linear-gradient( [<angle>|to <side-or-corner>]? , <color-stop-list> )",
    "repeating-radial-gradient()": "repeating-radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )",
    "rgb()": "rgb( <percentage>{3} [/ <alpha-value>]? )|rgb( <number>{3} [/ <alpha-value>]? )|rgb( <percentage>#{3} , <alpha-value>? )|rgb( <number>#{3} , <alpha-value>? )",
    "rgba()": "rgba( <percentage>{3} [/ <alpha-value>]? )|rgba( <number>{3} [/ <alpha-value>]? )|rgba( <percentage>#{3} , <alpha-value>? )|rgba( <number>#{3} , <alpha-value>? )",
    "rotate()": "rotate( [<angle>|<zero>] )",
    "rotate3d()": "rotate3d( <number> , <number> , <number> , [<angle>|<zero>] )",
    "rotateX()": "rotateX( [<angle>|<zero>] )",
    "rotateY()": "rotateY( [<angle>|<zero>] )",
    "rotateZ()": "rotateZ( [<angle>|<zero>] )",
    "saturate()": "saturate( <number-percentage> )",
    "scale()": "scale( <number> , <number>? )",
    "scale3d()": "scale3d( <number> , <number> , <number> )",
    "scaleX()": "scaleX( <number> )",
    "scaleY()": "scaleY( <number> )",
    "scaleZ()": "scaleZ( <number> )",
    "self-position": "center|start|end|self-start|self-end|flex-start|flex-end",
    "shape-radius": "<length-percentage>|closest-side|farthest-side",
    "skew()": "skew( [<angle>|<zero>] , [<angle>|<zero>]? )",
    "skewX()": "skewX( [<angle>|<zero>] )",
    "skewY()": "skewY( [<angle>|<zero>] )",
    "sepia()": "sepia( <number-percentage> )",
    "shadow": "inset?&&<length>{2,4}&&<color>?",
    "shadow-t": "[<length>{2,3}&&<color>?]",
    "shape": "rect( <top> , <right> , <bottom> , <left> )|rect( <top> <right> <bottom> <left> )",
    "shape-box": "<box>|margin-box",
    "side-or-corner": "[left|right]||[top|bottom]",
    "single-animation": "<time>||<easing-function>||<time>||<single-animation-iteration-count>||<single-animation-direction>||<single-animation-fill-mode>||<single-animation-play-state>||[none|<keyframes-name>]",
    "single-animation-direction": "normal|reverse|alternate|alternate-reverse",
    "single-animation-fill-mode": "none|forwards|backwards|both",
    "single-animation-iteration-count": "infinite|<number>",
    "single-animation-play-state": "running|paused",
    "single-animation-timeline": "auto|none|<timeline-name>",
    "single-transition": "[none|<single-transition-property>]||<time>||<easing-function>||<time>",
    "single-transition-property": "all|<custom-ident>",
    "size": "closest-side|farthest-side|closest-corner|farthest-corner|<length>|<length-percentage>{2}",
    "step-position": "jump-start|jump-end|jump-none|jump-both|start|end",
    "step-timing-function": "step-start|step-end|steps( <integer> [, <step-position>]? )",
    "subclass-selector": "<id-selector>|<class-selector>|<attribute-selector>|<pseudo-class-selector>",
    "supports-condition": "not <supports-in-parens>|<supports-in-parens> [and <supports-in-parens>]*|<supports-in-parens> [or <supports-in-parens>]*",
    "supports-in-parens": "( <supports-condition> )|<supports-feature>|<general-enclosed>",
    "supports-feature": "<supports-decl>|<supports-selector-fn>",
    "supports-decl": "( <declaration> )",
    "supports-selector-fn": "selector( <complex-selector> )",
    "symbol": "<string>|<image>|<custom-ident>",
    "target": "<target-counter()>|<target-counters()>|<target-text()>",
    "target-counter()": "target-counter( [<string>|<url>] , <custom-ident> , <counter-style>? )",
    "target-counters()": "target-counters( [<string>|<url>] , <custom-ident> , <string> , <counter-style>? )",
    "target-text()": "target-text( [<string>|<url>] , [content|before|after|first-letter]? )",
    "time-percentage": "<time>|<percentage>",
    "timeline-name": "<custom-ident>|<string>",
    "easing-function": "linear|<cubic-bezier-timing-function>|<step-timing-function>",
    "track-breadth": "<length-percentage>|<flex>|min-content|max-content|auto",
    "track-list": "[<line-names>? [<track-size>|<track-repeat>]]+ <line-names>?",
    "track-repeat": "repeat( [<integer [1,\u221E]>] , [<line-names>? <track-size>]+ <line-names>? )",
    "track-size": "<track-breadth>|minmax( <inflexible-breadth> , <track-breadth> )|fit-content( [<length>|<percentage>] )",
    "transform-function": "<matrix()>|<translate()>|<translateX()>|<translateY()>|<scale()>|<scaleX()>|<scaleY()>|<rotate()>|<skew()>|<skewX()>|<skewY()>|<matrix3d()>|<translate3d()>|<translateZ()>|<scale3d()>|<scaleZ()>|<rotate3d()>|<rotateX()>|<rotateY()>|<rotateZ()>|<perspective()>",
    "transform-list": "<transform-function>+",
    "translate()": "translate( <length-percentage> , <length-percentage>? )",
    "translate3d()": "translate3d( <length-percentage> , <length-percentage> , <length> )",
    "translateX()": "translateX( <length-percentage> )",
    "translateY()": "translateY( <length-percentage> )",
    "translateZ()": "translateZ( <length> )",
    "type-or-unit": "string|color|url|integer|number|length|angle|time|frequency|cap|ch|em|ex|ic|lh|rlh|rem|vb|vi|vw|vh|vmin|vmax|mm|Q|cm|in|pt|pc|px|deg|grad|rad|turn|ms|s|Hz|kHz|%",
    "type-selector": "<wq-name>|<ns-prefix>? '*'",
    "var()": "var( <custom-property-name> , <declaration-value>? )",
    "viewport-length": "auto|<length-percentage>",
    "visual-box": "content-box|padding-box|border-box",
    "wq-name": "<ns-prefix>? <ident-token>",
    "-legacy-gradient": "<-webkit-gradient()>|<-legacy-linear-gradient>|<-legacy-repeating-linear-gradient>|<-legacy-radial-gradient>|<-legacy-repeating-radial-gradient>",
    "-legacy-linear-gradient": "-moz-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-linear-gradient( <-legacy-linear-gradient-arguments> )",
    "-legacy-repeating-linear-gradient": "-moz-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )",
    "-legacy-linear-gradient-arguments": "[<angle>|<side-or-corner>]? , <color-stop-list>",
    "-legacy-radial-gradient": "-moz-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-radial-gradient( <-legacy-radial-gradient-arguments> )",
    "-legacy-repeating-radial-gradient": "-moz-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )",
    "-legacy-radial-gradient-arguments": "[<position> ,]? [[[<-legacy-radial-gradient-shape>||<-legacy-radial-gradient-size>]|[<length>|<percentage>]{2}] ,]? <color-stop-list>",
    "-legacy-radial-gradient-size": "closest-side|closest-corner|farthest-side|farthest-corner|contain|cover",
    "-legacy-radial-gradient-shape": "circle|ellipse",
    "-non-standard-font": "-apple-system-body|-apple-system-headline|-apple-system-subheadline|-apple-system-caption1|-apple-system-caption2|-apple-system-footnote|-apple-system-short-body|-apple-system-short-headline|-apple-system-short-subheadline|-apple-system-short-caption1|-apple-system-short-footnote|-apple-system-tall-body",
    "-non-standard-color": "-moz-ButtonDefault|-moz-ButtonHoverFace|-moz-ButtonHoverText|-moz-CellHighlight|-moz-CellHighlightText|-moz-Combobox|-moz-ComboboxText|-moz-Dialog|-moz-DialogText|-moz-dragtargetzone|-moz-EvenTreeRow|-moz-Field|-moz-FieldText|-moz-html-CellHighlight|-moz-html-CellHighlightText|-moz-mac-accentdarkestshadow|-moz-mac-accentdarkshadow|-moz-mac-accentface|-moz-mac-accentlightesthighlight|-moz-mac-accentlightshadow|-moz-mac-accentregularhighlight|-moz-mac-accentregularshadow|-moz-mac-chrome-active|-moz-mac-chrome-inactive|-moz-mac-focusring|-moz-mac-menuselect|-moz-mac-menushadow|-moz-mac-menutextselect|-moz-MenuHover|-moz-MenuHoverText|-moz-MenuBarText|-moz-MenuBarHoverText|-moz-nativehyperlinktext|-moz-OddTreeRow|-moz-win-communicationstext|-moz-win-mediatext|-moz-activehyperlinktext|-moz-default-background-color|-moz-default-color|-moz-hyperlinktext|-moz-visitedhyperlinktext|-webkit-activelink|-webkit-focus-ring-color|-webkit-link|-webkit-text",
    "-non-standard-image-rendering": "optimize-contrast|-moz-crisp-edges|-o-crisp-edges|-webkit-optimize-contrast",
    "-non-standard-overflow": "-moz-scrollbars-none|-moz-scrollbars-horizontal|-moz-scrollbars-vertical|-moz-hidden-unscrollable",
    "-non-standard-width": "fill-available|min-intrinsic|intrinsic|-moz-available|-moz-fit-content|-moz-min-content|-moz-max-content|-webkit-min-content|-webkit-max-content",
    "-webkit-gradient()": "-webkit-gradient( <-webkit-gradient-type> , <-webkit-gradient-point> [, <-webkit-gradient-point>|, <-webkit-gradient-radius> , <-webkit-gradient-point>] [, <-webkit-gradient-radius>]? [, <-webkit-gradient-color-stop>]* )",
    "-webkit-gradient-color-stop": "from( <color> )|color-stop( [<number-zero-one>|<percentage>] , <color> )|to( <color> )",
    "-webkit-gradient-point": "[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]",
    "-webkit-gradient-radius": "<length>|<percentage>",
    "-webkit-gradient-type": "linear|radial",
    "-webkit-mask-box-repeat": "repeat|stretch|round",
    "-webkit-mask-clip-style": "border|border-box|padding|padding-box|content|content-box|text",
    "-ms-filter-function-list": "<-ms-filter-function>+",
    "-ms-filter-function": "<-ms-filter-function-progid>|<-ms-filter-function-legacy>",
    "-ms-filter-function-progid": "'progid:' [<ident-token> '.']* [<ident-token>|<function-token> <any-value>? )]",
    "-ms-filter-function-legacy": "<ident-token>|<function-token> <any-value>? )",
    "-ms-filter": "<string>",
    "age": "child|young|old",
    "attr-name": "<wq-name>",
    "attr-fallback": "<any-value>",
    "bg-clip": "<box>|border|text",
    "border-radius": "<length-percentage>{1,2}",
    "bottom": "<length>|auto",
    "generic-voice": "[<age>? <gender> <integer>?]",
    "gender": "male|female|neutral",
    "lab()": "lab( [<percentage>|<number>|none] [<percentage>|<number>|none] [<percentage>|<number>|none] [/ [<alpha-value>|none]]? )",
    "lch()": "lch( [<percentage>|<number>|none] [<percentage>|<number>|none] [<hue>|none] [/ [<alpha-value>|none]]? )",
    "left": "<length>|auto",
    "mask-image": "<mask-reference>#",
    "paint": "none|<color>|<url> [none|<color>]?|context-fill|context-stroke",
    "ratio": "<number [0,\u221E]> [/ <number [0,\u221E]>]?",
    "reversed-counter-name": "reversed( <counter-name> )",
    "right": "<length>|auto",
    "svg-length": "<percentage>|<length>|<number>",
    "svg-writing-mode": "lr-tb|rl-tb|tb-rl|lr|rl|tb",
    "top": "<length>|auto",
    "track-group": "'(' [<string>* <track-minmax> <string>*]+ ')' ['[' <positive-integer> ']']?|<track-minmax>",
    "track-list-v0": "[<string>* <track-group> <string>*]+|none",
    "track-minmax": "minmax( <track-breadth> , <track-breadth> )|auto|<track-breadth>|fit-content",
    "x": "<number>",
    "y": "<number>",
    "declaration": "<ident-token> : <declaration-value>? ['!' important]?",
    "declaration-list": "[<declaration>? ';']* <declaration>?",
    "url": "url( <string> <url-modifier>* )|<url-token>",
    "url-modifier": "<ident>|<function-token> <any-value> )",
    "number-zero-one": "<number [0,1]>",
    "number-one-or-greater": "<number [1,\u221E]>",
    "positive-integer": "<integer [0,\u221E]>",
    "-non-standard-display": "-ms-inline-flexbox|-ms-grid|-ms-inline-grid|-webkit-flex|-webkit-inline-flex|-webkit-box|-webkit-inline-box|-moz-inline-stack|-moz-box|-moz-inline-box"
  },
  "properties": {
    "--*": "<declaration-value>",
    "-ms-accelerator": "false|true",
    "-ms-block-progression": "tb|rl|bt|lr",
    "-ms-content-zoom-chaining": "none|chained",
    "-ms-content-zooming": "none|zoom",
    "-ms-content-zoom-limit": "<'-ms-content-zoom-limit-min'> <'-ms-content-zoom-limit-max'>",
    "-ms-content-zoom-limit-max": "<percentage>",
    "-ms-content-zoom-limit-min": "<percentage>",
    "-ms-content-zoom-snap": "<'-ms-content-zoom-snap-type'>||<'-ms-content-zoom-snap-points'>",
    "-ms-content-zoom-snap-points": "snapInterval( <percentage> , <percentage> )|snapList( <percentage># )",
    "-ms-content-zoom-snap-type": "none|proximity|mandatory",
    "-ms-filter": "<string>",
    "-ms-flow-from": "[none|<custom-ident>]#",
    "-ms-flow-into": "[none|<custom-ident>]#",
    "-ms-grid-columns": "none|<track-list>|<auto-track-list>",
    "-ms-grid-rows": "none|<track-list>|<auto-track-list>",
    "-ms-high-contrast-adjust": "auto|none",
    "-ms-hyphenate-limit-chars": "auto|<integer>{1,3}",
    "-ms-hyphenate-limit-lines": "no-limit|<integer>",
    "-ms-hyphenate-limit-zone": "<percentage>|<length>",
    "-ms-ime-align": "auto|after",
    "-ms-overflow-style": "auto|none|scrollbar|-ms-autohiding-scrollbar",
    "-ms-scrollbar-3dlight-color": "<color>",
    "-ms-scrollbar-arrow-color": "<color>",
    "-ms-scrollbar-base-color": "<color>",
    "-ms-scrollbar-darkshadow-color": "<color>",
    "-ms-scrollbar-face-color": "<color>",
    "-ms-scrollbar-highlight-color": "<color>",
    "-ms-scrollbar-shadow-color": "<color>",
    "-ms-scrollbar-track-color": "<color>",
    "-ms-scroll-chaining": "chained|none",
    "-ms-scroll-limit": "<'-ms-scroll-limit-x-min'> <'-ms-scroll-limit-y-min'> <'-ms-scroll-limit-x-max'> <'-ms-scroll-limit-y-max'>",
    "-ms-scroll-limit-x-max": "auto|<length>",
    "-ms-scroll-limit-x-min": "<length>",
    "-ms-scroll-limit-y-max": "auto|<length>",
    "-ms-scroll-limit-y-min": "<length>",
    "-ms-scroll-rails": "none|railed",
    "-ms-scroll-snap-points-x": "snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )",
    "-ms-scroll-snap-points-y": "snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )",
    "-ms-scroll-snap-type": "none|proximity|mandatory",
    "-ms-scroll-snap-x": "<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-x'>",
    "-ms-scroll-snap-y": "<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-y'>",
    "-ms-scroll-translation": "none|vertical-to-horizontal",
    "-ms-text-autospace": "none|ideograph-alpha|ideograph-numeric|ideograph-parenthesis|ideograph-space",
    "-ms-touch-select": "grippers|none",
    "-ms-user-select": "none|element|text",
    "-ms-wrap-flow": "auto|both|start|end|maximum|clear",
    "-ms-wrap-margin": "<length>",
    "-ms-wrap-through": "wrap|none",
    "-moz-appearance": "none|button|button-arrow-down|button-arrow-next|button-arrow-previous|button-arrow-up|button-bevel|button-focus|caret|checkbox|checkbox-container|checkbox-label|checkmenuitem|dualbutton|groupbox|listbox|listitem|menuarrow|menubar|menucheckbox|menuimage|menuitem|menuitemtext|menulist|menulist-button|menulist-text|menulist-textfield|menupopup|menuradio|menuseparator|meterbar|meterchunk|progressbar|progressbar-vertical|progresschunk|progresschunk-vertical|radio|radio-container|radio-label|radiomenuitem|range|range-thumb|resizer|resizerpanel|scale-horizontal|scalethumbend|scalethumb-horizontal|scalethumbstart|scalethumbtick|scalethumb-vertical|scale-vertical|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|separator|sheet|spinner|spinner-downbutton|spinner-textfield|spinner-upbutton|splitter|statusbar|statusbarpanel|tab|tabpanel|tabpanels|tab-scroll-arrow-back|tab-scroll-arrow-forward|textfield|textfield-multiline|toolbar|toolbarbutton|toolbarbutton-dropdown|toolbargripper|toolbox|tooltip|treeheader|treeheadercell|treeheadersortarrow|treeitem|treeline|treetwisty|treetwistyopen|treeview|-moz-mac-unified-toolbar|-moz-win-borderless-glass|-moz-win-browsertabbar-toolbox|-moz-win-communicationstext|-moz-win-communications-toolbox|-moz-win-exclude-glass|-moz-win-glass|-moz-win-mediatext|-moz-win-media-toolbox|-moz-window-button-box|-moz-window-button-box-maximized|-moz-window-button-close|-moz-window-button-maximize|-moz-window-button-minimize|-moz-window-button-restore|-moz-window-frame-bottom|-moz-window-frame-left|-moz-window-frame-right|-moz-window-titlebar|-moz-window-titlebar-maximized",
    "-moz-binding": "<url>|none",
    "-moz-border-bottom-colors": "<color>+|none",
    "-moz-border-left-colors": "<color>+|none",
    "-moz-border-right-colors": "<color>+|none",
    "-moz-border-top-colors": "<color>+|none",
    "-moz-context-properties": "none|[fill|fill-opacity|stroke|stroke-opacity]#",
    "-moz-float-edge": "border-box|content-box|margin-box|padding-box",
    "-moz-force-broken-image-icon": "0|1",
    "-moz-image-region": "<shape>|auto",
    "-moz-orient": "inline|block|horizontal|vertical",
    "-moz-outline-radius": "<outline-radius>{1,4} [/ <outline-radius>{1,4}]?",
    "-moz-outline-radius-bottomleft": "<outline-radius>",
    "-moz-outline-radius-bottomright": "<outline-radius>",
    "-moz-outline-radius-topleft": "<outline-radius>",
    "-moz-outline-radius-topright": "<outline-radius>",
    "-moz-stack-sizing": "ignore|stretch-to-fit",
    "-moz-text-blink": "none|blink",
    "-moz-user-focus": "ignore|normal|select-after|select-before|select-menu|select-same|select-all|none",
    "-moz-user-input": "auto|none|enabled|disabled",
    "-moz-user-modify": "read-only|read-write|write-only",
    "-moz-window-dragging": "drag|no-drag",
    "-moz-window-shadow": "default|menu|tooltip|sheet|none",
    "-webkit-appearance": "none|button|button-bevel|caps-lock-indicator|caret|checkbox|default-button|inner-spin-button|listbox|listitem|media-controls-background|media-controls-fullscreen-background|media-current-time-display|media-enter-fullscreen-button|media-exit-fullscreen-button|media-fullscreen-button|media-mute-button|media-overlay-play-button|media-play-button|media-seek-back-button|media-seek-forward-button|media-slider|media-sliderthumb|media-time-remaining-display|media-toggle-closed-captions-button|media-volume-slider|media-volume-slider-container|media-volume-sliderthumb|menulist|menulist-button|menulist-text|menulist-textfield|meter|progress-bar|progress-bar-value|push-button|radio|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbargripper-horizontal|scrollbargripper-vertical|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|searchfield-cancel-button|searchfield-decoration|searchfield-results-button|searchfield-results-decoration|slider-horizontal|slider-vertical|sliderthumb-horizontal|sliderthumb-vertical|square-button|textarea|textfield|-apple-pay-button",
    "-webkit-border-before": "<'border-width'>||<'border-style'>||<color>",
    "-webkit-border-before-color": "<color>",
    "-webkit-border-before-style": "<'border-style'>",
    "-webkit-border-before-width": "<'border-width'>",
    "-webkit-box-reflect": "[above|below|right|left]? <length>? <image>?",
    "-webkit-line-clamp": "none|<integer>",
    "-webkit-mask": "[<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||[<box>|border|padding|content|text]||[<box>|border|padding|content]]#",
    "-webkit-mask-attachment": "<attachment>#",
    "-webkit-mask-clip": "[<box>|border|padding|content|text]#",
    "-webkit-mask-composite": "<composite-style>#",
    "-webkit-mask-image": "<mask-reference>#",
    "-webkit-mask-origin": "[<box>|border|padding|content]#",
    "-webkit-mask-position": "<position>#",
    "-webkit-mask-position-x": "[<length-percentage>|left|center|right]#",
    "-webkit-mask-position-y": "[<length-percentage>|top|center|bottom]#",
    "-webkit-mask-repeat": "<repeat-style>#",
    "-webkit-mask-repeat-x": "repeat|no-repeat|space|round",
    "-webkit-mask-repeat-y": "repeat|no-repeat|space|round",
    "-webkit-mask-size": "<bg-size>#",
    "-webkit-overflow-scrolling": "auto|touch",
    "-webkit-tap-highlight-color": "<color>",
    "-webkit-text-fill-color": "<color>",
    "-webkit-text-stroke": "<length>||<color>",
    "-webkit-text-stroke-color": "<color>",
    "-webkit-text-stroke-width": "<length>",
    "-webkit-touch-callout": "default|none",
    "-webkit-user-modify": "read-only|read-write|read-write-plaintext-only",
    "accent-color": "auto|<color>",
    "align-content": "normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>",
    "align-items": "normal|stretch|<baseline-position>|[<overflow-position>? <self-position>]",
    "align-self": "auto|normal|stretch|<baseline-position>|<overflow-position>? <self-position>",
    "align-tracks": "[normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>]#",
    "all": "initial|inherit|unset|revert|revert-layer",
    "animation": "<single-animation>#",
    "animation-delay": "<time>#",
    "animation-direction": "<single-animation-direction>#",
    "animation-duration": "<time>#",
    "animation-fill-mode": "<single-animation-fill-mode>#",
    "animation-iteration-count": "<single-animation-iteration-count>#",
    "animation-name": "[none|<keyframes-name>]#",
    "animation-play-state": "<single-animation-play-state>#",
    "animation-timing-function": "<easing-function>#",
    "animation-timeline": "<single-animation-timeline>#",
    "appearance": "none|auto|textfield|menulist-button|<compat-auto>",
    "aspect-ratio": "auto|<ratio>",
    "azimuth": "<angle>|[[left-side|far-left|left|center-left|center|center-right|right|far-right|right-side]||behind]|leftwards|rightwards",
    "backdrop-filter": "none|<filter-function-list>",
    "backface-visibility": "visible|hidden",
    "background": "[<bg-layer> ,]* <final-bg-layer>",
    "background-attachment": "<attachment>#",
    "background-blend-mode": "<blend-mode>#",
    "background-clip": "<bg-clip>#",
    "background-color": "<color>",
    "background-image": "<bg-image>#",
    "background-origin": "<box>#",
    "background-position": "<bg-position>#",
    "background-position-x": "[center|[[left|right|x-start|x-end]? <length-percentage>?]!]#",
    "background-position-y": "[center|[[top|bottom|y-start|y-end]? <length-percentage>?]!]#",
    "background-repeat": "<repeat-style>#",
    "background-size": "<bg-size>#",
    "block-overflow": "clip|ellipsis|<string>",
    "block-size": "<'width'>",
    "border": "<line-width>||<line-style>||<color>",
    "border-block": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-block-color": "<'border-top-color'>{1,2}",
    "border-block-style": "<'border-top-style'>",
    "border-block-width": "<'border-top-width'>",
    "border-block-end": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-block-end-color": "<'border-top-color'>",
    "border-block-end-style": "<'border-top-style'>",
    "border-block-end-width": "<'border-top-width'>",
    "border-block-start": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-block-start-color": "<'border-top-color'>",
    "border-block-start-style": "<'border-top-style'>",
    "border-block-start-width": "<'border-top-width'>",
    "border-bottom": "<line-width>||<line-style>||<color>",
    "border-bottom-color": "<'border-top-color'>",
    "border-bottom-left-radius": "<length-percentage>{1,2}",
    "border-bottom-right-radius": "<length-percentage>{1,2}",
    "border-bottom-style": "<line-style>",
    "border-bottom-width": "<line-width>",
    "border-collapse": "collapse|separate",
    "border-color": "<color>{1,4}",
    "border-end-end-radius": "<length-percentage>{1,2}",
    "border-end-start-radius": "<length-percentage>{1,2}",
    "border-image": "<'border-image-source'>||<'border-image-slice'> [/ <'border-image-width'>|/ <'border-image-width'>? / <'border-image-outset'>]?||<'border-image-repeat'>",
    "border-image-outset": "[<length>|<number>]{1,4}",
    "border-image-repeat": "[stretch|repeat|round|space]{1,2}",
    "border-image-slice": "<number-percentage>{1,4}&&fill?",
    "border-image-source": "none|<image>",
    "border-image-width": "[<length-percentage>|<number>|auto]{1,4}",
    "border-inline": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-inline-end": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-inline-color": "<'border-top-color'>{1,2}",
    "border-inline-style": "<'border-top-style'>",
    "border-inline-width": "<'border-top-width'>",
    "border-inline-end-color": "<'border-top-color'>",
    "border-inline-end-style": "<'border-top-style'>",
    "border-inline-end-width": "<'border-top-width'>",
    "border-inline-start": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-inline-start-color": "<'border-top-color'>",
    "border-inline-start-style": "<'border-top-style'>",
    "border-inline-start-width": "<'border-top-width'>",
    "border-left": "<line-width>||<line-style>||<color>",
    "border-left-color": "<color>",
    "border-left-style": "<line-style>",
    "border-left-width": "<line-width>",
    "border-radius": "<length-percentage>{1,4} [/ <length-percentage>{1,4}]?",
    "border-right": "<line-width>||<line-style>||<color>",
    "border-right-color": "<color>",
    "border-right-style": "<line-style>",
    "border-right-width": "<line-width>",
    "border-spacing": "<length> <length>?",
    "border-start-end-radius": "<length-percentage>{1,2}",
    "border-start-start-radius": "<length-percentage>{1,2}",
    "border-style": "<line-style>{1,4}",
    "border-top": "<line-width>||<line-style>||<color>",
    "border-top-color": "<color>",
    "border-top-left-radius": "<length-percentage>{1,2}",
    "border-top-right-radius": "<length-percentage>{1,2}",
    "border-top-style": "<line-style>",
    "border-top-width": "<line-width>",
    "border-width": "<line-width>{1,4}",
    "bottom": "<length>|<percentage>|auto",
    "box-align": "start|center|end|baseline|stretch",
    "box-decoration-break": "slice|clone",
    "box-direction": "normal|reverse|inherit",
    "box-flex": "<number>",
    "box-flex-group": "<integer>",
    "box-lines": "single|multiple",
    "box-ordinal-group": "<integer>",
    "box-orient": "horizontal|vertical|inline-axis|block-axis|inherit",
    "box-pack": "start|center|end|justify",
    "box-shadow": "none|<shadow>#",
    "box-sizing": "content-box|border-box",
    "break-after": "auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region",
    "break-before": "auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region",
    "break-inside": "auto|avoid|avoid-page|avoid-column|avoid-region",
    "caption-side": "top|bottom|block-start|block-end|inline-start|inline-end",
    "caret-color": "auto|<color>",
    "clear": "none|left|right|both|inline-start|inline-end",
    "clip": "<shape>|auto",
    "clip-path": "<clip-source>|[<basic-shape>||<geometry-box>]|none",
    "color": "<color>",
    "print-color-adjust": "economy|exact",
    "color-scheme": "normal|[light|dark|<custom-ident>]+&&only?",
    "column-count": "<integer>|auto",
    "column-fill": "auto|balance|balance-all",
    "column-gap": "normal|<length-percentage>",
    "column-rule": "<'column-rule-width'>||<'column-rule-style'>||<'column-rule-color'>",
    "column-rule-color": "<color>",
    "column-rule-style": "<'border-style'>",
    "column-rule-width": "<'border-width'>",
    "column-span": "none|all",
    "column-width": "<length>|auto",
    "columns": "<'column-width'>||<'column-count'>",
    "contain": "none|strict|content|[size||layout||style||paint]",
    "content": "normal|none|[<content-replacement>|<content-list>] [/ [<string>|<counter>]+]?",
    "content-visibility": "visible|auto|hidden",
    "counter-increment": "[<counter-name> <integer>?]+|none",
    "counter-reset": "[<counter-name> <integer>?|<reversed-counter-name> <integer>?]+|none",
    "counter-set": "[<counter-name> <integer>?]+|none",
    "cursor": "[[<url> [<x> <y>]? ,]* [auto|default|none|context-menu|help|pointer|progress|wait|cell|crosshair|text|vertical-text|alias|copy|move|no-drop|not-allowed|e-resize|n-resize|ne-resize|nw-resize|s-resize|se-resize|sw-resize|w-resize|ew-resize|ns-resize|nesw-resize|nwse-resize|col-resize|row-resize|all-scroll|zoom-in|zoom-out|grab|grabbing|hand|-webkit-grab|-webkit-grabbing|-webkit-zoom-in|-webkit-zoom-out|-moz-grab|-moz-grabbing|-moz-zoom-in|-moz-zoom-out]]",
    "direction": "ltr|rtl",
    "display": "[<display-outside>||<display-inside>]|<display-listitem>|<display-internal>|<display-box>|<display-legacy>|<-non-standard-display>",
    "empty-cells": "show|hide",
    "filter": "none|<filter-function-list>|<-ms-filter-function-list>",
    "flex": "none|[<'flex-grow'> <'flex-shrink'>?||<'flex-basis'>]",
    "flex-basis": "content|<'width'>",
    "flex-direction": "row|row-reverse|column|column-reverse",
    "flex-flow": "<'flex-direction'>||<'flex-wrap'>",
    "flex-grow": "<number>",
    "flex-shrink": "<number>",
    "flex-wrap": "nowrap|wrap|wrap-reverse",
    "float": "left|right|none|inline-start|inline-end",
    "font": "[[<'font-style'>||<font-variant-css21>||<'font-weight'>||<'font-stretch'>]? <'font-size'> [/ <'line-height'>]? <'font-family'>]|caption|icon|menu|message-box|small-caption|status-bar",
    "font-family": "[<family-name>|<generic-family>]#",
    "font-feature-settings": "normal|<feature-tag-value>#",
    "font-kerning": "auto|normal|none",
    "font-language-override": "normal|<string>",
    "font-optical-sizing": "auto|none",
    "font-variation-settings": "normal|[<string> <number>]#",
    "font-size": "<absolute-size>|<relative-size>|<length-percentage>",
    "font-size-adjust": "none|[ex-height|cap-height|ch-width|ic-width|ic-height]? [from-font|<number>]",
    "font-smooth": "auto|never|always|<absolute-size>|<length>",
    "font-stretch": "<font-stretch-absolute>",
    "font-style": "normal|italic|oblique <angle>?",
    "font-synthesis": "none|[weight||style||small-caps]",
    "font-variant": "normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>||stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )||[small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps]||<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero||<east-asian-variant-values>||<east-asian-width-values>||ruby]",
    "font-variant-alternates": "normal|[stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )]",
    "font-variant-caps": "normal|small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps",
    "font-variant-east-asian": "normal|[<east-asian-variant-values>||<east-asian-width-values>||ruby]",
    "font-variant-ligatures": "normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>]",
    "font-variant-numeric": "normal|[<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero]",
    "font-variant-position": "normal|sub|super",
    "font-weight": "<font-weight-absolute>|bolder|lighter",
    "forced-color-adjust": "auto|none",
    "gap": "<'row-gap'> <'column-gap'>?",
    "grid": "<'grid-template'>|<'grid-template-rows'> / [auto-flow&&dense?] <'grid-auto-columns'>?|[auto-flow&&dense?] <'grid-auto-rows'>? / <'grid-template-columns'>",
    "grid-area": "<grid-line> [/ <grid-line>]{0,3}",
    "grid-auto-columns": "<track-size>+",
    "grid-auto-flow": "[row|column]||dense",
    "grid-auto-rows": "<track-size>+",
    "grid-column": "<grid-line> [/ <grid-line>]?",
    "grid-column-end": "<grid-line>",
    "grid-column-gap": "<length-percentage>",
    "grid-column-start": "<grid-line>",
    "grid-gap": "<'grid-row-gap'> <'grid-column-gap'>?",
    "grid-row": "<grid-line> [/ <grid-line>]?",
    "grid-row-end": "<grid-line>",
    "grid-row-gap": "<length-percentage>",
    "grid-row-start": "<grid-line>",
    "grid-template": "none|[<'grid-template-rows'> / <'grid-template-columns'>]|[<line-names>? <string> <track-size>? <line-names>?]+ [/ <explicit-track-list>]?",
    "grid-template-areas": "none|<string>+",
    "grid-template-columns": "none|<track-list>|<auto-track-list>|subgrid <line-name-list>?",
    "grid-template-rows": "none|<track-list>|<auto-track-list>|subgrid <line-name-list>?",
    "hanging-punctuation": "none|[first||[force-end|allow-end]||last]",
    "height": "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )",
    "hyphenate-character": "auto|<string>",
    "hyphens": "none|manual|auto",
    "image-orientation": "from-image|<angle>|[<angle>? flip]",
    "image-rendering": "auto|crisp-edges|pixelated|optimizeSpeed|optimizeQuality|<-non-standard-image-rendering>",
    "image-resolution": "[from-image||<resolution>]&&snap?",
    "ime-mode": "auto|normal|active|inactive|disabled",
    "initial-letter": "normal|[<number> <integer>?]",
    "initial-letter-align": "[auto|alphabetic|hanging|ideographic]",
    "inline-size": "<'width'>",
    "input-security": "auto|none",
    "inset": "<'top'>{1,4}",
    "inset-block": "<'top'>{1,2}",
    "inset-block-end": "<'top'>",
    "inset-block-start": "<'top'>",
    "inset-inline": "<'top'>{1,2}",
    "inset-inline-end": "<'top'>",
    "inset-inline-start": "<'top'>",
    "isolation": "auto|isolate",
    "justify-content": "normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]",
    "justify-items": "normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]|legacy|legacy&&[left|right|center]",
    "justify-self": "auto|normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]",
    "justify-tracks": "[normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]]#",
    "left": "<length>|<percentage>|auto",
    "letter-spacing": "normal|<length-percentage>",
    "line-break": "auto|loose|normal|strict|anywhere",
    "line-clamp": "none|<integer>",
    "line-height": "normal|<number>|<length>|<percentage>",
    "line-height-step": "<length>",
    "list-style": "<'list-style-type'>||<'list-style-position'>||<'list-style-image'>",
    "list-style-image": "<image>|none",
    "list-style-position": "inside|outside",
    "list-style-type": "<counter-style>|<string>|none",
    "margin": "[<length>|<percentage>|auto]{1,4}",
    "margin-block": "<'margin-left'>{1,2}",
    "margin-block-end": "<'margin-left'>",
    "margin-block-start": "<'margin-left'>",
    "margin-bottom": "<length>|<percentage>|auto",
    "margin-inline": "<'margin-left'>{1,2}",
    "margin-inline-end": "<'margin-left'>",
    "margin-inline-start": "<'margin-left'>",
    "margin-left": "<length>|<percentage>|auto",
    "margin-right": "<length>|<percentage>|auto",
    "margin-top": "<length>|<percentage>|auto",
    "margin-trim": "none|in-flow|all",
    "mask": "<mask-layer>#",
    "mask-border": "<'mask-border-source'>||<'mask-border-slice'> [/ <'mask-border-width'>? [/ <'mask-border-outset'>]?]?||<'mask-border-repeat'>||<'mask-border-mode'>",
    "mask-border-mode": "luminance|alpha",
    "mask-border-outset": "[<length>|<number>]{1,4}",
    "mask-border-repeat": "[stretch|repeat|round|space]{1,2}",
    "mask-border-slice": "<number-percentage>{1,4} fill?",
    "mask-border-source": "none|<image>",
    "mask-border-width": "[<length-percentage>|<number>|auto]{1,4}",
    "mask-clip": "[<geometry-box>|no-clip]#",
    "mask-composite": "<compositing-operator>#",
    "mask-image": "<mask-reference>#",
    "mask-mode": "<masking-mode>#",
    "mask-origin": "<geometry-box>#",
    "mask-position": "<position>#",
    "mask-repeat": "<repeat-style>#",
    "mask-size": "<bg-size>#",
    "mask-type": "luminance|alpha",
    "masonry-auto-flow": "[pack|next]||[definite-first|ordered]",
    "math-style": "normal|compact",
    "max-block-size": "<'max-width'>",
    "max-height": "none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )",
    "max-inline-size": "<'max-width'>",
    "max-lines": "none|<integer>",
    "max-width": "none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|<-non-standard-width>",
    "min-block-size": "<'min-width'>",
    "min-height": "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )",
    "min-inline-size": "<'min-width'>",
    "min-width": "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|<-non-standard-width>",
    "mix-blend-mode": "<blend-mode>|plus-lighter",
    "object-fit": "fill|contain|cover|none|scale-down",
    "object-position": "<position>",
    "offset": "[<'offset-position'>? [<'offset-path'> [<'offset-distance'>||<'offset-rotate'>]?]?]! [/ <'offset-anchor'>]?",
    "offset-anchor": "auto|<position>",
    "offset-distance": "<length-percentage>",
    "offset-path": "none|ray( [<angle>&&<size>&&contain?] )|<path()>|<url>|[<basic-shape>||<geometry-box>]",
    "offset-position": "auto|<position>",
    "offset-rotate": "[auto|reverse]||<angle>",
    "opacity": "<alpha-value>",
    "order": "<integer>",
    "orphans": "<integer>",
    "outline": "[<'outline-color'>||<'outline-style'>||<'outline-width'>]",
    "outline-color": "<color>|invert",
    "outline-offset": "<length>",
    "outline-style": "auto|<'border-style'>",
    "outline-width": "<line-width>",
    "overflow": "[visible|hidden|clip|scroll|auto]{1,2}|<-non-standard-overflow>",
    "overflow-anchor": "auto|none",
    "overflow-block": "visible|hidden|clip|scroll|auto",
    "overflow-clip-box": "padding-box|content-box",
    "overflow-clip-margin": "<visual-box>||<length [0,\u221E]>",
    "overflow-inline": "visible|hidden|clip|scroll|auto",
    "overflow-wrap": "normal|break-word|anywhere",
    "overflow-x": "visible|hidden|clip|scroll|auto",
    "overflow-y": "visible|hidden|clip|scroll|auto",
    "overscroll-behavior": "[contain|none|auto]{1,2}",
    "overscroll-behavior-block": "contain|none|auto",
    "overscroll-behavior-inline": "contain|none|auto",
    "overscroll-behavior-x": "contain|none|auto",
    "overscroll-behavior-y": "contain|none|auto",
    "padding": "[<length>|<percentage>]{1,4}",
    "padding-block": "<'padding-left'>{1,2}",
    "padding-block-end": "<'padding-left'>",
    "padding-block-start": "<'padding-left'>",
    "padding-bottom": "<length>|<percentage>",
    "padding-inline": "<'padding-left'>{1,2}",
    "padding-inline-end": "<'padding-left'>",
    "padding-inline-start": "<'padding-left'>",
    "padding-left": "<length>|<percentage>",
    "padding-right": "<length>|<percentage>",
    "padding-top": "<length>|<percentage>",
    "page-break-after": "auto|always|avoid|left|right|recto|verso",
    "page-break-before": "auto|always|avoid|left|right|recto|verso",
    "page-break-inside": "auto|avoid",
    "paint-order": "normal|[fill||stroke||markers]",
    "perspective": "none|<length>",
    "perspective-origin": "<position>",
    "place-content": "<'align-content'> <'justify-content'>?",
    "place-items": "<'align-items'> <'justify-items'>?",
    "place-self": "<'align-self'> <'justify-self'>?",
    "pointer-events": "auto|none|visiblePainted|visibleFill|visibleStroke|visible|painted|fill|stroke|all|inherit",
    "position": "static|relative|absolute|sticky|fixed|-webkit-sticky",
    "quotes": "none|auto|[<string> <string>]+",
    "resize": "none|both|horizontal|vertical|block|inline",
    "right": "<length>|<percentage>|auto",
    "rotate": "none|<angle>|[x|y|z|<number>{3}]&&<angle>",
    "row-gap": "normal|<length-percentage>",
    "ruby-align": "start|center|space-between|space-around",
    "ruby-merge": "separate|collapse|auto",
    "ruby-position": "[alternate||[over|under]]|inter-character",
    "scale": "none|<number>{1,3}",
    "scrollbar-color": "auto|<color>{2}",
    "scrollbar-gutter": "auto|stable&&both-edges?",
    "scrollbar-width": "auto|thin|none",
    "scroll-behavior": "auto|smooth",
    "scroll-margin": "<length>{1,4}",
    "scroll-margin-block": "<length>{1,2}",
    "scroll-margin-block-start": "<length>",
    "scroll-margin-block-end": "<length>",
    "scroll-margin-bottom": "<length>",
    "scroll-margin-inline": "<length>{1,2}",
    "scroll-margin-inline-start": "<length>",
    "scroll-margin-inline-end": "<length>",
    "scroll-margin-left": "<length>",
    "scroll-margin-right": "<length>",
    "scroll-margin-top": "<length>",
    "scroll-padding": "[auto|<length-percentage>]{1,4}",
    "scroll-padding-block": "[auto|<length-percentage>]{1,2}",
    "scroll-padding-block-start": "auto|<length-percentage>",
    "scroll-padding-block-end": "auto|<length-percentage>",
    "scroll-padding-bottom": "auto|<length-percentage>",
    "scroll-padding-inline": "[auto|<length-percentage>]{1,2}",
    "scroll-padding-inline-start": "auto|<length-percentage>",
    "scroll-padding-inline-end": "auto|<length-percentage>",
    "scroll-padding-left": "auto|<length-percentage>",
    "scroll-padding-right": "auto|<length-percentage>",
    "scroll-padding-top": "auto|<length-percentage>",
    "scroll-snap-align": "[none|start|end|center]{1,2}",
    "scroll-snap-coordinate": "none|<position>#",
    "scroll-snap-destination": "<position>",
    "scroll-snap-points-x": "none|repeat( <length-percentage> )",
    "scroll-snap-points-y": "none|repeat( <length-percentage> )",
    "scroll-snap-stop": "normal|always",
    "scroll-snap-type": "none|[x|y|block|inline|both] [mandatory|proximity]?",
    "scroll-snap-type-x": "none|mandatory|proximity",
    "scroll-snap-type-y": "none|mandatory|proximity",
    "shape-image-threshold": "<alpha-value>",
    "shape-margin": "<length-percentage>",
    "shape-outside": "none|[<shape-box>||<basic-shape>]|<image>",
    "tab-size": "<integer>|<length>",
    "table-layout": "auto|fixed",
    "text-align": "start|end|left|right|center|justify|match-parent",
    "text-align-last": "auto|start|end|left|right|center|justify",
    "text-combine-upright": "none|all|[digits <integer>?]",
    "text-decoration": "<'text-decoration-line'>||<'text-decoration-style'>||<'text-decoration-color'>||<'text-decoration-thickness'>",
    "text-decoration-color": "<color>",
    "text-decoration-line": "none|[underline||overline||line-through||blink]|spelling-error|grammar-error",
    "text-decoration-skip": "none|[objects||[spaces|[leading-spaces||trailing-spaces]]||edges||box-decoration]",
    "text-decoration-skip-ink": "auto|all|none",
    "text-decoration-style": "solid|double|dotted|dashed|wavy",
    "text-decoration-thickness": "auto|from-font|<length>|<percentage>",
    "text-emphasis": "<'text-emphasis-style'>||<'text-emphasis-color'>",
    "text-emphasis-color": "<color>",
    "text-emphasis-position": "[over|under]&&[right|left]",
    "text-emphasis-style": "none|[[filled|open]||[dot|circle|double-circle|triangle|sesame]]|<string>",
    "text-indent": "<length-percentage>&&hanging?&&each-line?",
    "text-justify": "auto|inter-character|inter-word|none",
    "text-orientation": "mixed|upright|sideways",
    "text-overflow": "[clip|ellipsis|<string>]{1,2}",
    "text-rendering": "auto|optimizeSpeed|optimizeLegibility|geometricPrecision",
    "text-shadow": "none|<shadow-t>#",
    "text-size-adjust": "none|auto|<percentage>",
    "text-transform": "none|capitalize|uppercase|lowercase|full-width|full-size-kana",
    "text-underline-offset": "auto|<length>|<percentage>",
    "text-underline-position": "auto|from-font|[under||[left|right]]",
    "top": "<length>|<percentage>|auto",
    "touch-action": "auto|none|[[pan-x|pan-left|pan-right]||[pan-y|pan-up|pan-down]||pinch-zoom]|manipulation",
    "transform": "none|<transform-list>",
    "transform-box": "content-box|border-box|fill-box|stroke-box|view-box",
    "transform-origin": "[<length-percentage>|left|center|right|top|bottom]|[[<length-percentage>|left|center|right]&&[<length-percentage>|top|center|bottom]] <length>?",
    "transform-style": "flat|preserve-3d",
    "transition": "<single-transition>#",
    "transition-delay": "<time>#",
    "transition-duration": "<time>#",
    "transition-property": "none|<single-transition-property>#",
    "transition-timing-function": "<easing-function>#",
    "translate": "none|<length-percentage> [<length-percentage> <length>?]?",
    "unicode-bidi": "normal|embed|isolate|bidi-override|isolate-override|plaintext|-moz-isolate|-moz-isolate-override|-moz-plaintext|-webkit-isolate|-webkit-isolate-override|-webkit-plaintext",
    "user-select": "auto|text|none|contain|all",
    "vertical-align": "baseline|sub|super|text-top|text-bottom|middle|top|bottom|<percentage>|<length>",
    "visibility": "visible|hidden|collapse",
    "white-space": "normal|pre|nowrap|pre-wrap|pre-line|break-spaces",
    "widows": "<integer>",
    "width": "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|fill|stretch|intrinsic|-moz-max-content|-webkit-max-content|-moz-fit-content|-webkit-fit-content",
    "will-change": "auto|<animateable-feature>#",
    "word-break": "normal|break-all|keep-all|break-word",
    "word-spacing": "normal|<length>",
    "word-wrap": "normal|break-word",
    "writing-mode": "horizontal-tb|vertical-rl|vertical-lr|sideways-rl|sideways-lr|<svg-writing-mode>",
    "z-index": "auto|<integer>",
    "zoom": "normal|reset|<number>|<percentage>",
    "-moz-background-clip": "padding|border",
    "-moz-border-radius-bottomleft": "<'border-bottom-left-radius'>",
    "-moz-border-radius-bottomright": "<'border-bottom-right-radius'>",
    "-moz-border-radius-topleft": "<'border-top-left-radius'>",
    "-moz-border-radius-topright": "<'border-bottom-right-radius'>",
    "-moz-control-character-visibility": "visible|hidden",
    "-moz-osx-font-smoothing": "auto|grayscale",
    "-moz-user-select": "none|text|all|-moz-none",
    "-ms-flex-align": "start|end|center|baseline|stretch",
    "-ms-flex-item-align": "auto|start|end|center|baseline|stretch",
    "-ms-flex-line-pack": "start|end|center|justify|distribute|stretch",
    "-ms-flex-negative": "<'flex-shrink'>",
    "-ms-flex-pack": "start|end|center|justify|distribute",
    "-ms-flex-order": "<integer>",
    "-ms-flex-positive": "<'flex-grow'>",
    "-ms-flex-preferred-size": "<'flex-basis'>",
    "-ms-interpolation-mode": "nearest-neighbor|bicubic",
    "-ms-grid-column-align": "start|end|center|stretch",
    "-ms-grid-row-align": "start|end|center|stretch",
    "-ms-hyphenate-limit-last": "none|always|column|page|spread",
    "-webkit-background-clip": "[<box>|border|padding|content|text]#",
    "-webkit-column-break-after": "always|auto|avoid",
    "-webkit-column-break-before": "always|auto|avoid",
    "-webkit-column-break-inside": "always|auto|avoid",
    "-webkit-font-smoothing": "auto|none|antialiased|subpixel-antialiased",
    "-webkit-mask-box-image": "[<url>|<gradient>|none] [<length-percentage>{4} <-webkit-mask-box-repeat>{2}]?",
    "-webkit-print-color-adjust": "economy|exact",
    "-webkit-text-security": "none|circle|disc|square",
    "-webkit-user-drag": "none|element|auto",
    "-webkit-user-select": "auto|none|text|all",
    "alignment-baseline": "auto|baseline|before-edge|text-before-edge|middle|central|after-edge|text-after-edge|ideographic|alphabetic|hanging|mathematical",
    "baseline-shift": "baseline|sub|super|<svg-length>",
    "behavior": "<url>+",
    "clip-rule": "nonzero|evenodd",
    "cue": "<'cue-before'> <'cue-after'>?",
    "cue-after": "<url> <decibel>?|none",
    "cue-before": "<url> <decibel>?|none",
    "dominant-baseline": "auto|use-script|no-change|reset-size|ideographic|alphabetic|hanging|mathematical|central|middle|text-after-edge|text-before-edge",
    "fill": "<paint>",
    "fill-opacity": "<number-zero-one>",
    "fill-rule": "nonzero|evenodd",
    "glyph-orientation-horizontal": "<angle>",
    "glyph-orientation-vertical": "<angle>",
    "kerning": "auto|<svg-length>",
    "marker": "none|<url>",
    "marker-end": "none|<url>",
    "marker-mid": "none|<url>",
    "marker-start": "none|<url>",
    "pause": "<'pause-before'> <'pause-after'>?",
    "pause-after": "<time>|none|x-weak|weak|medium|strong|x-strong",
    "pause-before": "<time>|none|x-weak|weak|medium|strong|x-strong",
    "rest": "<'rest-before'> <'rest-after'>?",
    "rest-after": "<time>|none|x-weak|weak|medium|strong|x-strong",
    "rest-before": "<time>|none|x-weak|weak|medium|strong|x-strong",
    "shape-rendering": "auto|optimizeSpeed|crispEdges|geometricPrecision",
    "src": "[<url> [format( <string># )]?|local( <family-name> )]#",
    "speak": "auto|none|normal",
    "speak-as": "normal|spell-out||digits||[literal-punctuation|no-punctuation]",
    "stroke": "<paint>",
    "stroke-dasharray": "none|[<svg-length>+]#",
    "stroke-dashoffset": "<svg-length>",
    "stroke-linecap": "butt|round|square",
    "stroke-linejoin": "miter|round|bevel",
    "stroke-miterlimit": "<number-one-or-greater>",
    "stroke-opacity": "<number-zero-one>",
    "stroke-width": "<svg-length>",
    "text-anchor": "start|middle|end",
    "unicode-range": "<urange>#",
    "voice-balance": "<number>|left|center|right|leftwards|rightwards",
    "voice-duration": "auto|<time>",
    "voice-family": "[[<family-name>|<generic-voice>] ,]* [<family-name>|<generic-voice>]|preserve",
    "voice-pitch": "<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]",
    "voice-range": "<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]",
    "voice-rate": "[normal|x-slow|slow|medium|fast|x-fast]||<percentage>",
    "voice-stress": "normal|strong|moderate|none|reduced",
    "voice-volume": "silent|[[x-soft|soft|medium|loud|x-loud]||<decibel>]"
  },
  "atrules": {
    "charset": {
      "prelude": "<string>",
      "descriptors": null
    },
    "counter-style": {
      "prelude": "<counter-style-name>",
      "descriptors": {
        "additive-symbols": "[<integer>&&<symbol>]#",
        "fallback": "<counter-style-name>",
        "negative": "<symbol> <symbol>?",
        "pad": "<integer>&&<symbol>",
        "prefix": "<symbol>",
        "range": "[[<integer>|infinite]{2}]#|auto",
        "speak-as": "auto|bullets|numbers|words|spell-out|<counter-style-name>",
        "suffix": "<symbol>",
        "symbols": "<symbol>+",
        "system": "cyclic|numeric|alphabetic|symbolic|additive|[fixed <integer>?]|[extends <counter-style-name>]"
      }
    },
    "document": {
      "prelude": "[<url>|url-prefix( <string> )|domain( <string> )|media-document( <string> )|regexp( <string> )]#",
      "descriptors": null
    },
    "font-face": {
      "prelude": null,
      "descriptors": {
        "ascent-override": "normal|<percentage>",
        "descent-override": "normal|<percentage>",
        "font-display": "[auto|block|swap|fallback|optional]",
        "font-family": "<family-name>",
        "font-feature-settings": "normal|<feature-tag-value>#",
        "font-variation-settings": "normal|[<string> <number>]#",
        "font-stretch": "<font-stretch-absolute>{1,2}",
        "font-style": "normal|italic|oblique <angle>{0,2}",
        "font-weight": "<font-weight-absolute>{1,2}",
        "font-variant": "normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>||stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )||[small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps]||<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero||<east-asian-variant-values>||<east-asian-width-values>||ruby]",
        "line-gap-override": "normal|<percentage>",
        "size-adjust": "<percentage>",
        "src": "[<url> [format( <string># )]?|local( <family-name> )]#",
        "unicode-range": "<urange>#"
      }
    },
    "font-feature-values": {
      "prelude": "<family-name>#",
      "descriptors": null
    },
    "import": {
      "prelude": "[<string>|<url>] [layer|layer( <layer-name> )]? [supports( [<supports-condition>|<declaration>] )]? <media-query-list>?",
      "descriptors": null
    },
    "keyframes": {
      "prelude": "<keyframes-name>",
      "descriptors": null
    },
    "layer": {
      "prelude": "[<layer-name>#|<layer-name>?]",
      "descriptors": null
    },
    "media": {
      "prelude": "<media-query-list>",
      "descriptors": null
    },
    "namespace": {
      "prelude": "<namespace-prefix>? [<string>|<url>]",
      "descriptors": null
    },
    "page": {
      "prelude": "<page-selector-list>",
      "descriptors": {
        "bleed": "auto|<length>",
        "marks": "none|[crop||cross]",
        "size": "<length>{1,2}|auto|[<page-size>||[portrait|landscape]]"
      }
    },
    "property": {
      "prelude": "<custom-property-name>",
      "descriptors": {
        "syntax": "<string>",
        "inherits": "true|false",
        "initial-value": "<string>"
      }
    },
    "scroll-timeline": {
      "prelude": "<timeline-name>",
      "descriptors": null
    },
    "supports": {
      "prelude": "<supports-condition>",
      "descriptors": null
    },
    "viewport": {
      "prelude": null,
      "descriptors": {
        "height": "<viewport-length>{1,2}",
        "max-height": "<viewport-length>",
        "max-width": "<viewport-length>",
        "max-zoom": "auto|<number>|<percentage>",
        "min-height": "<viewport-length>",
        "min-width": "<viewport-length>",
        "min-zoom": "auto|<number>|<percentage>",
        "orientation": "auto|portrait|landscape",
        "user-zoom": "zoom|fixed",
        "viewport-fit": "auto|contain|cover",
        "width": "<viewport-length>{1,2}",
        "zoom": "auto|<number>|<percentage>"
      }
    }
  }
};
var node = {};
var AnPlusB$2 = {};
const types$G = types$R;
const charCodeDefinitions$5 = charCodeDefinitions$c;
const PLUSSIGN$5 = 43;
const HYPHENMINUS$2 = 45;
const N = 110;
const DISALLOW_SIGN = true;
const ALLOW_SIGN = false;
function checkInteger(offset, disallowSign) {
  let pos = this.tokenStart + offset;
  const code2 = this.charCodeAt(pos);
  if (code2 === PLUSSIGN$5 || code2 === HYPHENMINUS$2) {
    if (disallowSign) {
      this.error("Number sign is not allowed");
    }
    pos++;
  }
  for (; pos < this.tokenEnd; pos++) {
    if (!charCodeDefinitions$5.isDigit(this.charCodeAt(pos))) {
      this.error("Integer is expected", pos);
    }
  }
}
function checkTokenIsInteger(disallowSign) {
  return checkInteger.call(this, 0, disallowSign);
}
function expectCharCode(offset, code2) {
  if (!this.cmpChar(this.tokenStart + offset, code2)) {
    let msg = "";
    switch (code2) {
      case N:
        msg = "N is expected";
        break;
      case HYPHENMINUS$2:
        msg = "HyphenMinus is expected";
        break;
    }
    this.error(msg, this.tokenStart + offset);
  }
}
function consumeB() {
  let offset = 0;
  let sign = 0;
  let type = this.tokenType;
  while (type === types$G.WhiteSpace || type === types$G.Comment) {
    type = this.lookupType(++offset);
  }
  if (type !== types$G.Number) {
    if (this.isDelim(PLUSSIGN$5, offset) || this.isDelim(HYPHENMINUS$2, offset)) {
      sign = this.isDelim(PLUSSIGN$5, offset) ? PLUSSIGN$5 : HYPHENMINUS$2;
      do {
        type = this.lookupType(++offset);
      } while (type === types$G.WhiteSpace || type === types$G.Comment);
      if (type !== types$G.Number) {
        this.skip(offset);
        checkTokenIsInteger.call(this, DISALLOW_SIGN);
      }
    } else {
      return null;
    }
  }
  if (offset > 0) {
    this.skip(offset);
  }
  if (sign === 0) {
    type = this.charCodeAt(this.tokenStart);
    if (type !== PLUSSIGN$5 && type !== HYPHENMINUS$2) {
      this.error("Number sign is expected");
    }
  }
  checkTokenIsInteger.call(this, sign !== 0);
  return sign === HYPHENMINUS$2 ? "-" + this.consume(types$G.Number) : this.consume(types$G.Number);
}
const name$D = "AnPlusB";
const structure$D = {
  a: [String, null],
  b: [String, null]
};
function parse$H() {
  const start = this.tokenStart;
  let a = null;
  let b = null;
  if (this.tokenType === types$G.Number) {
    checkTokenIsInteger.call(this, ALLOW_SIGN);
    b = this.consume(types$G.Number);
  } else if (this.tokenType === types$G.Ident && this.cmpChar(this.tokenStart, HYPHENMINUS$2)) {
    a = "-1";
    expectCharCode.call(this, 1, N);
    switch (this.tokenEnd - this.tokenStart) {
      case 2:
        this.next();
        b = consumeB.call(this);
        break;
      case 3:
        expectCharCode.call(this, 2, HYPHENMINUS$2);
        this.next();
        this.skipSC();
        checkTokenIsInteger.call(this, DISALLOW_SIGN);
        b = "-" + this.consume(types$G.Number);
        break;
      default:
        expectCharCode.call(this, 2, HYPHENMINUS$2);
        checkInteger.call(this, 3, DISALLOW_SIGN);
        this.next();
        b = this.substrToCursor(start + 2);
    }
  } else if (this.tokenType === types$G.Ident || this.isDelim(PLUSSIGN$5) && this.lookupType(1) === types$G.Ident) {
    let sign = 0;
    a = "1";
    if (this.isDelim(PLUSSIGN$5)) {
      sign = 1;
      this.next();
    }
    expectCharCode.call(this, 0, N);
    switch (this.tokenEnd - this.tokenStart) {
      case 1:
        this.next();
        b = consumeB.call(this);
        break;
      case 2:
        expectCharCode.call(this, 1, HYPHENMINUS$2);
        this.next();
        this.skipSC();
        checkTokenIsInteger.call(this, DISALLOW_SIGN);
        b = "-" + this.consume(types$G.Number);
        break;
      default:
        expectCharCode.call(this, 1, HYPHENMINUS$2);
        checkInteger.call(this, 2, DISALLOW_SIGN);
        this.next();
        b = this.substrToCursor(start + sign + 1);
    }
  } else if (this.tokenType === types$G.Dimension) {
    const code2 = this.charCodeAt(this.tokenStart);
    const sign = code2 === PLUSSIGN$5 || code2 === HYPHENMINUS$2;
    let i = this.tokenStart + sign;
    for (; i < this.tokenEnd; i++) {
      if (!charCodeDefinitions$5.isDigit(this.charCodeAt(i))) {
        break;
      }
    }
    if (i === this.tokenStart + sign) {
      this.error("Integer is expected", this.tokenStart + sign);
    }
    expectCharCode.call(this, i - this.tokenStart, N);
    a = this.substring(start, i);
    if (i + 1 === this.tokenEnd) {
      this.next();
      b = consumeB.call(this);
    } else {
      expectCharCode.call(this, i - this.tokenStart + 1, HYPHENMINUS$2);
      if (i + 2 === this.tokenEnd) {
        this.next();
        this.skipSC();
        checkTokenIsInteger.call(this, DISALLOW_SIGN);
        b = "-" + this.consume(types$G.Number);
      } else {
        checkInteger.call(this, i - this.tokenStart + 2, DISALLOW_SIGN);
        this.next();
        b = this.substrToCursor(i + 1);
      }
    }
  } else {
    this.error();
  }
  if (a !== null && a.charCodeAt(0) === PLUSSIGN$5) {
    a = a.substr(1);
  }
  if (b !== null && b.charCodeAt(0) === PLUSSIGN$5) {
    b = b.substr(1);
  }
  return {
    type: "AnPlusB",
    loc: this.getLocation(start, this.tokenStart),
    a,
    b
  };
}
function generate$H(node2) {
  if (node2.a) {
    const a = node2.a === "+1" && "n" || node2.a === "1" && "n" || node2.a === "-1" && "-n" || node2.a + "n";
    if (node2.b) {
      const b = node2.b[0] === "-" || node2.b[0] === "+" ? node2.b : "+" + node2.b;
      this.tokenize(a + b);
    } else {
      this.tokenize(a);
    }
  } else {
    this.tokenize(node2.b);
  }
}
AnPlusB$2.generate = generate$H;
AnPlusB$2.name = name$D;
AnPlusB$2.parse = parse$H;
AnPlusB$2.structure = structure$D;
var Atrule$6 = {};
const types$F = types$R;
function consumeRaw$5(startToken) {
  return this.Raw(startToken, this.consumeUntilLeftCurlyBracketOrSemicolon, true);
}
function isDeclarationBlockAtrule() {
  for (let offset = 1, type; type = this.lookupType(offset); offset++) {
    if (type === types$F.RightCurlyBracket) {
      return true;
    }
    if (type === types$F.LeftCurlyBracket || type === types$F.AtKeyword) {
      return false;
    }
  }
  return false;
}
const name$C = "Atrule";
const walkContext$9 = "atrule";
const structure$C = {
  name: String,
  prelude: ["AtrulePrelude", "Raw", null],
  block: ["Block", null]
};
function parse$G() {
  const start = this.tokenStart;
  let name2;
  let nameLowerCase;
  let prelude = null;
  let block = null;
  this.eat(types$F.AtKeyword);
  name2 = this.substrToCursor(start + 1);
  nameLowerCase = name2.toLowerCase();
  this.skipSC();
  if (this.eof === false && this.tokenType !== types$F.LeftCurlyBracket && this.tokenType !== types$F.Semicolon) {
    if (this.parseAtrulePrelude) {
      prelude = this.parseWithFallback(this.AtrulePrelude.bind(this, name2), consumeRaw$5);
    } else {
      prelude = consumeRaw$5.call(this, this.tokenIndex);
    }
    this.skipSC();
  }
  switch (this.tokenType) {
    case types$F.Semicolon:
      this.next();
      break;
    case types$F.LeftCurlyBracket:
      if (hasOwnProperty.call(this.atrule, nameLowerCase) && typeof this.atrule[nameLowerCase].block === "function") {
        block = this.atrule[nameLowerCase].block.call(this);
      } else {
        block = this.Block(isDeclarationBlockAtrule.call(this));
      }
      break;
  }
  return {
    type: "Atrule",
    loc: this.getLocation(start, this.tokenStart),
    name: name2,
    prelude,
    block
  };
}
function generate$G(node2) {
  this.token(types$F.AtKeyword, "@" + node2.name);
  if (node2.prelude !== null) {
    this.node(node2.prelude);
  }
  if (node2.block) {
    this.node(node2.block);
  } else {
    this.token(types$F.Semicolon, ";");
  }
}
Atrule$6.generate = generate$G;
Atrule$6.name = name$C;
Atrule$6.parse = parse$G;
Atrule$6.structure = structure$C;
Atrule$6.walkContext = walkContext$9;
var AtrulePrelude$2 = {};
const types$E = types$R;
const name$B = "AtrulePrelude";
const walkContext$8 = "atrulePrelude";
const structure$B = {
  children: [[]]
};
function parse$F(name2) {
  let children = null;
  if (name2 !== null) {
    name2 = name2.toLowerCase();
  }
  this.skipSC();
  if (hasOwnProperty.call(this.atrule, name2) && typeof this.atrule[name2].prelude === "function") {
    children = this.atrule[name2].prelude.call(this);
  } else {
    children = this.readSequence(this.scope.AtrulePrelude);
  }
  this.skipSC();
  if (this.eof !== true && this.tokenType !== types$E.LeftCurlyBracket && this.tokenType !== types$E.Semicolon) {
    this.error("Semicolon or block is expected");
  }
  return {
    type: "AtrulePrelude",
    loc: this.getLocationFromList(children),
    children
  };
}
function generate$F(node2) {
  this.children(node2);
}
AtrulePrelude$2.generate = generate$F;
AtrulePrelude$2.name = name$B;
AtrulePrelude$2.parse = parse$F;
AtrulePrelude$2.structure = structure$B;
AtrulePrelude$2.walkContext = walkContext$8;
var AttributeSelector$4 = {};
const types$D = types$R;
const DOLLARSIGN$1 = 36;
const ASTERISK$5 = 42;
const EQUALSSIGN = 61;
const CIRCUMFLEXACCENT = 94;
const VERTICALLINE$2 = 124;
const TILDE$2 = 126;
function getAttributeName() {
  if (this.eof) {
    this.error("Unexpected end of input");
  }
  const start = this.tokenStart;
  let expectIdent = false;
  if (this.isDelim(ASTERISK$5)) {
    expectIdent = true;
    this.next();
  } else if (!this.isDelim(VERTICALLINE$2)) {
    this.eat(types$D.Ident);
  }
  if (this.isDelim(VERTICALLINE$2)) {
    if (this.charCodeAt(this.tokenStart + 1) !== EQUALSSIGN) {
      this.next();
      this.eat(types$D.Ident);
    } else if (expectIdent) {
      this.error("Identifier is expected", this.tokenEnd);
    }
  } else if (expectIdent) {
    this.error("Vertical line is expected");
  }
  return {
    type: "Identifier",
    loc: this.getLocation(start, this.tokenStart),
    name: this.substrToCursor(start)
  };
}
function getOperator() {
  const start = this.tokenStart;
  const code2 = this.charCodeAt(start);
  if (code2 !== EQUALSSIGN && code2 !== TILDE$2 && code2 !== CIRCUMFLEXACCENT && code2 !== DOLLARSIGN$1 && code2 !== ASTERISK$5 && code2 !== VERTICALLINE$2) {
    this.error("Attribute selector (=, ~=, ^=, $=, *=, |=) is expected");
  }
  this.next();
  if (code2 !== EQUALSSIGN) {
    if (!this.isDelim(EQUALSSIGN)) {
      this.error("Equal sign is expected");
    }
    this.next();
  }
  return this.substrToCursor(start);
}
const name$A = "AttributeSelector";
const structure$A = {
  name: "Identifier",
  matcher: [String, null],
  value: ["String", "Identifier", null],
  flags: [String, null]
};
function parse$E() {
  const start = this.tokenStart;
  let name2;
  let matcher = null;
  let value2 = null;
  let flags = null;
  this.eat(types$D.LeftSquareBracket);
  this.skipSC();
  name2 = getAttributeName.call(this);
  this.skipSC();
  if (this.tokenType !== types$D.RightSquareBracket) {
    if (this.tokenType !== types$D.Ident) {
      matcher = getOperator.call(this);
      this.skipSC();
      value2 = this.tokenType === types$D.String ? this.String() : this.Identifier();
      this.skipSC();
    }
    if (this.tokenType === types$D.Ident) {
      flags = this.consume(types$D.Ident);
      this.skipSC();
    }
  }
  this.eat(types$D.RightSquareBracket);
  return {
    type: "AttributeSelector",
    loc: this.getLocation(start, this.tokenStart),
    name: name2,
    matcher,
    value: value2,
    flags
  };
}
function generate$E(node2) {
  this.token(types$D.Delim, "[");
  this.node(node2.name);
  if (node2.matcher !== null) {
    this.tokenize(node2.matcher);
    this.node(node2.value);
  }
  if (node2.flags !== null) {
    this.token(types$D.Ident, node2.flags);
  }
  this.token(types$D.Delim, "]");
}
AttributeSelector$4.generate = generate$E;
AttributeSelector$4.name = name$A;
AttributeSelector$4.parse = parse$E;
AttributeSelector$4.structure = structure$A;
var Block$2 = {};
const types$C = types$R;
function consumeRaw$4(startToken) {
  return this.Raw(startToken, null, true);
}
function consumeRule() {
  return this.parseWithFallback(this.Rule, consumeRaw$4);
}
function consumeRawDeclaration(startToken) {
  return this.Raw(startToken, this.consumeUntilSemicolonIncluded, true);
}
function consumeDeclaration() {
  if (this.tokenType === types$C.Semicolon) {
    return consumeRawDeclaration.call(this, this.tokenIndex);
  }
  const node2 = this.parseWithFallback(this.Declaration, consumeRawDeclaration);
  if (this.tokenType === types$C.Semicolon) {
    this.next();
  }
  return node2;
}
const name$z = "Block";
const walkContext$7 = "block";
const structure$z = {
  children: [[
    "Atrule",
    "Rule",
    "Declaration"
  ]]
};
function parse$D(isDeclaration) {
  const consumer = isDeclaration ? consumeDeclaration : consumeRule;
  const start = this.tokenStart;
  let children = this.createList();
  this.eat(types$C.LeftCurlyBracket);
  scan:
    while (!this.eof) {
      switch (this.tokenType) {
        case types$C.RightCurlyBracket:
          break scan;
        case types$C.WhiteSpace:
        case types$C.Comment:
          this.next();
          break;
        case types$C.AtKeyword:
          children.push(this.parseWithFallback(this.Atrule, consumeRaw$4));
          break;
        default:
          children.push(consumer.call(this));
      }
    }
  if (!this.eof) {
    this.eat(types$C.RightCurlyBracket);
  }
  return {
    type: "Block",
    loc: this.getLocation(start, this.tokenStart),
    children
  };
}
function generate$D(node2) {
  this.token(types$C.LeftCurlyBracket, "{");
  this.children(node2, (prev) => {
    if (prev.type === "Declaration") {
      this.token(types$C.Semicolon, ";");
    }
  });
  this.token(types$C.RightCurlyBracket, "}");
}
Block$2.generate = generate$D;
Block$2.name = name$z;
Block$2.parse = parse$D;
Block$2.structure = structure$z;
Block$2.walkContext = walkContext$7;
var Brackets$2 = {};
const types$B = types$R;
const name$y = "Brackets";
const structure$y = {
  children: [[]]
};
function parse$C(readSequence2, recognizer) {
  const start = this.tokenStart;
  let children = null;
  this.eat(types$B.LeftSquareBracket);
  children = readSequence2.call(this, recognizer);
  if (!this.eof) {
    this.eat(types$B.RightSquareBracket);
  }
  return {
    type: "Brackets",
    loc: this.getLocation(start, this.tokenStart),
    children
  };
}
function generate$C(node2) {
  this.token(types$B.Delim, "[");
  this.children(node2);
  this.token(types$B.Delim, "]");
}
Brackets$2.generate = generate$C;
Brackets$2.name = name$y;
Brackets$2.parse = parse$C;
Brackets$2.structure = structure$y;
var CDC$2 = {};
const types$A = types$R;
const name$x = "CDC";
const structure$x = [];
function parse$B() {
  const start = this.tokenStart;
  this.eat(types$A.CDC);
  return {
    type: "CDC",
    loc: this.getLocation(start, this.tokenStart)
  };
}
function generate$B() {
  this.token(types$A.CDC, "-->");
}
CDC$2.generate = generate$B;
CDC$2.name = name$x;
CDC$2.parse = parse$B;
CDC$2.structure = structure$x;
var CDO$2 = {};
const types$z = types$R;
const name$w = "CDO";
const structure$w = [];
function parse$A() {
  const start = this.tokenStart;
  this.eat(types$z.CDO);
  return {
    type: "CDO",
    loc: this.getLocation(start, this.tokenStart)
  };
}
function generate$A() {
  this.token(types$z.CDO, "<!--");
}
CDO$2.generate = generate$A;
CDO$2.name = name$w;
CDO$2.parse = parse$A;
CDO$2.structure = structure$w;
var ClassSelector$2 = {};
const types$y = types$R;
const FULLSTOP$2 = 46;
const name$v = "ClassSelector";
const structure$v = {
  name: String
};
function parse$z() {
  this.eatDelim(FULLSTOP$2);
  return {
    type: "ClassSelector",
    loc: this.getLocation(this.tokenStart - 1, this.tokenEnd),
    name: this.consume(types$y.Ident)
  };
}
function generate$z(node2) {
  this.token(types$y.Delim, ".");
  this.token(types$y.Ident, node2.name);
}
ClassSelector$2.generate = generate$z;
ClassSelector$2.name = name$v;
ClassSelector$2.parse = parse$z;
ClassSelector$2.structure = structure$v;
var Combinator$2 = {};
const types$x = types$R;
const PLUSSIGN$4 = 43;
const SOLIDUS$5 = 47;
const GREATERTHANSIGN$1 = 62;
const TILDE$1 = 126;
const name$u = "Combinator";
const structure$u = {
  name: String
};
function parse$y() {
  const start = this.tokenStart;
  let name2;
  switch (this.tokenType) {
    case types$x.WhiteSpace:
      name2 = " ";
      break;
    case types$x.Delim:
      switch (this.charCodeAt(this.tokenStart)) {
        case GREATERTHANSIGN$1:
        case PLUSSIGN$4:
        case TILDE$1:
          this.next();
          break;
        case SOLIDUS$5:
          this.next();
          this.eatIdent("deep");
          this.eatDelim(SOLIDUS$5);
          break;
        default:
          this.error("Combinator is expected");
      }
      name2 = this.substrToCursor(start);
      break;
  }
  return {
    type: "Combinator",
    loc: this.getLocation(start, this.tokenStart),
    name: name2
  };
}
function generate$y(node2) {
  this.tokenize(node2.name);
}
Combinator$2.generate = generate$y;
Combinator$2.name = name$u;
Combinator$2.parse = parse$y;
Combinator$2.structure = structure$u;
var Comment$4 = {};
const types$w = types$R;
const ASTERISK$4 = 42;
const SOLIDUS$4 = 47;
const name$t = "Comment";
const structure$t = {
  value: String
};
function parse$x() {
  const start = this.tokenStart;
  let end = this.tokenEnd;
  this.eat(types$w.Comment);
  if (end - start + 2 >= 2 && this.charCodeAt(end - 2) === ASTERISK$4 && this.charCodeAt(end - 1) === SOLIDUS$4) {
    end -= 2;
  }
  return {
    type: "Comment",
    loc: this.getLocation(start, this.tokenStart),
    value: this.substring(start + 2, end)
  };
}
function generate$x(node2) {
  this.token(types$w.Comment, "/*" + node2.value + "*/");
}
Comment$4.generate = generate$x;
Comment$4.name = name$t;
Comment$4.parse = parse$x;
Comment$4.structure = structure$t;
var Declaration$4 = {};
const names$2 = names$4;
const types$v = types$R;
const EXCLAMATIONMARK$1 = 33;
const NUMBERSIGN$2 = 35;
const DOLLARSIGN = 36;
const AMPERSAND = 38;
const ASTERISK$3 = 42;
const PLUSSIGN$3 = 43;
const SOLIDUS$3 = 47;
function consumeValueRaw(startToken) {
  return this.Raw(startToken, this.consumeUntilExclamationMarkOrSemicolon, true);
}
function consumeCustomPropertyRaw(startToken) {
  return this.Raw(startToken, this.consumeUntilExclamationMarkOrSemicolon, false);
}
function consumeValue() {
  const startValueToken = this.tokenIndex;
  const value2 = this.Value();
  if (value2.type !== "Raw" && this.eof === false && this.tokenType !== types$v.Semicolon && this.isDelim(EXCLAMATIONMARK$1) === false && this.isBalanceEdge(startValueToken) === false) {
    this.error();
  }
  return value2;
}
const name$s = "Declaration";
const walkContext$6 = "declaration";
const structure$s = {
  important: [Boolean, String],
  property: String,
  value: ["Value", "Raw"]
};
function parse$w() {
  const start = this.tokenStart;
  const startToken = this.tokenIndex;
  const property2 = readProperty.call(this);
  const customProperty = names$2.isCustomProperty(property2);
  const parseValue = customProperty ? this.parseCustomProperty : this.parseValue;
  const consumeRaw2 = customProperty ? consumeCustomPropertyRaw : consumeValueRaw;
  let important = false;
  let value2;
  this.skipSC();
  this.eat(types$v.Colon);
  const valueStart = this.tokenIndex;
  if (!customProperty) {
    this.skipSC();
  }
  if (parseValue) {
    value2 = this.parseWithFallback(consumeValue, consumeRaw2);
  } else {
    value2 = consumeRaw2.call(this, this.tokenIndex);
  }
  if (customProperty && value2.type === "Value" && value2.children.isEmpty) {
    for (let offset = valueStart - this.tokenIndex; offset <= 0; offset++) {
      if (this.lookupType(offset) === types$v.WhiteSpace) {
        value2.children.appendData({
          type: "WhiteSpace",
          loc: null,
          value: " "
        });
        break;
      }
    }
  }
  if (this.isDelim(EXCLAMATIONMARK$1)) {
    important = getImportant.call(this);
    this.skipSC();
  }
  if (this.eof === false && this.tokenType !== types$v.Semicolon && this.isBalanceEdge(startToken) === false) {
    this.error();
  }
  return {
    type: "Declaration",
    loc: this.getLocation(start, this.tokenStart),
    important,
    property: property2,
    value: value2
  };
}
function generate$w(node2) {
  this.token(types$v.Ident, node2.property);
  this.token(types$v.Colon, ":");
  this.node(node2.value);
  if (node2.important) {
    this.token(types$v.Delim, "!");
    this.token(types$v.Ident, node2.important === true ? "important" : node2.important);
  }
}
function readProperty() {
  const start = this.tokenStart;
  if (this.tokenType === types$v.Delim) {
    switch (this.charCodeAt(this.tokenStart)) {
      case ASTERISK$3:
      case DOLLARSIGN:
      case PLUSSIGN$3:
      case NUMBERSIGN$2:
      case AMPERSAND:
        this.next();
        break;
      case SOLIDUS$3:
        this.next();
        if (this.isDelim(SOLIDUS$3)) {
          this.next();
        }
        break;
    }
  }
  if (this.tokenType === types$v.Hash) {
    this.eat(types$v.Hash);
  } else {
    this.eat(types$v.Ident);
  }
  return this.substrToCursor(start);
}
function getImportant() {
  this.eat(types$v.Delim);
  this.skipSC();
  const important = this.consume(types$v.Ident);
  return important === "important" ? true : important;
}
Declaration$4.generate = generate$w;
Declaration$4.name = name$s;
Declaration$4.parse = parse$w;
Declaration$4.structure = structure$s;
Declaration$4.walkContext = walkContext$6;
var DeclarationList$2 = {};
const types$u = types$R;
function consumeRaw$3(startToken) {
  return this.Raw(startToken, this.consumeUntilSemicolonIncluded, true);
}
const name$r = "DeclarationList";
const structure$r = {
  children: [[
    "Declaration"
  ]]
};
function parse$v() {
  const children = this.createList();
  while (!this.eof) {
    switch (this.tokenType) {
      case types$u.WhiteSpace:
      case types$u.Comment:
      case types$u.Semicolon:
        this.next();
        break;
      default:
        children.push(this.parseWithFallback(this.Declaration, consumeRaw$3));
    }
  }
  return {
    type: "DeclarationList",
    loc: this.getLocationFromList(children),
    children
  };
}
function generate$v(node2) {
  this.children(node2, (prev) => {
    if (prev.type === "Declaration") {
      this.token(types$u.Semicolon, ";");
    }
  });
}
DeclarationList$2.generate = generate$v;
DeclarationList$2.name = name$r;
DeclarationList$2.parse = parse$v;
DeclarationList$2.structure = structure$r;
var Dimension$4 = {};
const types$t = types$R;
const name$q = "Dimension";
const structure$q = {
  value: String,
  unit: String
};
function parse$u() {
  const start = this.tokenStart;
  const value2 = this.consumeNumber(types$t.Dimension);
  return {
    type: "Dimension",
    loc: this.getLocation(start, this.tokenStart),
    value: value2,
    unit: this.substring(start + value2.length, this.tokenStart)
  };
}
function generate$u(node2) {
  this.token(types$t.Dimension, node2.value + node2.unit);
}
Dimension$4.generate = generate$u;
Dimension$4.name = name$q;
Dimension$4.parse = parse$u;
Dimension$4.structure = structure$q;
var _Function = {};
const types$s = types$R;
const name$p = "Function";
const walkContext$5 = "function";
const structure$p = {
  name: String,
  children: [[]]
};
function parse$t(readSequence2, recognizer) {
  const start = this.tokenStart;
  const name2 = this.consumeFunctionName();
  const nameLowerCase = name2.toLowerCase();
  let children;
  children = recognizer.hasOwnProperty(nameLowerCase) ? recognizer[nameLowerCase].call(this, recognizer) : readSequence2.call(this, recognizer);
  if (!this.eof) {
    this.eat(types$s.RightParenthesis);
  }
  return {
    type: "Function",
    loc: this.getLocation(start, this.tokenStart),
    name: name2,
    children
  };
}
function generate$t(node2) {
  this.token(types$s.Function, node2.name + "(");
  this.children(node2);
  this.token(types$s.RightParenthesis, ")");
}
_Function.generate = generate$t;
_Function.name = name$p;
_Function.parse = parse$t;
_Function.structure = structure$p;
_Function.walkContext = walkContext$5;
var Hash$2 = {};
const types$r = types$R;
const xxx = "XXX";
const name$o = "Hash";
const structure$o = {
  value: String
};
function parse$s() {
  const start = this.tokenStart;
  this.eat(types$r.Hash);
  return {
    type: "Hash",
    loc: this.getLocation(start, this.tokenStart),
    value: this.substrToCursor(start + 1)
  };
}
function generate$s(node2) {
  this.token(types$r.Hash, "#" + node2.value);
}
Hash$2.generate = generate$s;
Hash$2.name = name$o;
Hash$2.parse = parse$s;
Hash$2.structure = structure$o;
Hash$2.xxx = xxx;
var Identifier$2 = {};
const types$q = types$R;
const name$n = "Identifier";
const structure$n = {
  name: String
};
function parse$r() {
  return {
    type: "Identifier",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    name: this.consume(types$q.Ident)
  };
}
function generate$r(node2) {
  this.token(types$q.Ident, node2.name);
}
Identifier$2.generate = generate$r;
Identifier$2.name = name$n;
Identifier$2.parse = parse$r;
Identifier$2.structure = structure$n;
var IdSelector$2 = {};
const types$p = types$R;
const name$m = "IdSelector";
const structure$m = {
  name: String
};
function parse$q() {
  const start = this.tokenStart;
  this.eat(types$p.Hash);
  return {
    type: "IdSelector",
    loc: this.getLocation(start, this.tokenStart),
    name: this.substrToCursor(start + 1)
  };
}
function generate$q(node2) {
  this.token(types$p.Delim, "#" + node2.name);
}
IdSelector$2.generate = generate$q;
IdSelector$2.name = name$m;
IdSelector$2.parse = parse$q;
IdSelector$2.structure = structure$m;
var MediaFeature$2 = {};
const types$o = types$R;
const name$l = "MediaFeature";
const structure$l = {
  name: String,
  value: ["Identifier", "Number", "Dimension", "Ratio", null]
};
function parse$p() {
  const start = this.tokenStart;
  let name2;
  let value2 = null;
  this.eat(types$o.LeftParenthesis);
  this.skipSC();
  name2 = this.consume(types$o.Ident);
  this.skipSC();
  if (this.tokenType !== types$o.RightParenthesis) {
    this.eat(types$o.Colon);
    this.skipSC();
    switch (this.tokenType) {
      case types$o.Number:
        if (this.lookupNonWSType(1) === types$o.Delim) {
          value2 = this.Ratio();
        } else {
          value2 = this.Number();
        }
        break;
      case types$o.Dimension:
        value2 = this.Dimension();
        break;
      case types$o.Ident:
        value2 = this.Identifier();
        break;
      default:
        this.error("Number, dimension, ratio or identifier is expected");
    }
    this.skipSC();
  }
  this.eat(types$o.RightParenthesis);
  return {
    type: "MediaFeature",
    loc: this.getLocation(start, this.tokenStart),
    name: name2,
    value: value2
  };
}
function generate$p(node2) {
  this.token(types$o.LeftParenthesis, "(");
  this.token(types$o.Ident, node2.name);
  if (node2.value !== null) {
    this.token(types$o.Colon, ":");
    this.node(node2.value);
  }
  this.token(types$o.RightParenthesis, ")");
}
MediaFeature$2.generate = generate$p;
MediaFeature$2.name = name$l;
MediaFeature$2.parse = parse$p;
MediaFeature$2.structure = structure$l;
var MediaQuery$2 = {};
const types$n = types$R;
const name$k = "MediaQuery";
const structure$k = {
  children: [[
    "Identifier",
    "MediaFeature",
    "WhiteSpace"
  ]]
};
function parse$o() {
  const children = this.createList();
  let child = null;
  this.skipSC();
  scan:
    while (!this.eof) {
      switch (this.tokenType) {
        case types$n.Comment:
        case types$n.WhiteSpace:
          this.next();
          continue;
        case types$n.Ident:
          child = this.Identifier();
          break;
        case types$n.LeftParenthesis:
          child = this.MediaFeature();
          break;
        default:
          break scan;
      }
      children.push(child);
    }
  if (child === null) {
    this.error("Identifier or parenthesis is expected");
  }
  return {
    type: "MediaQuery",
    loc: this.getLocationFromList(children),
    children
  };
}
function generate$o(node2) {
  this.children(node2);
}
MediaQuery$2.generate = generate$o;
MediaQuery$2.name = name$k;
MediaQuery$2.parse = parse$o;
MediaQuery$2.structure = structure$k;
var MediaQueryList$2 = {};
const types$m = types$R;
const name$j = "MediaQueryList";
const structure$j = {
  children: [[
    "MediaQuery"
  ]]
};
function parse$n() {
  const children = this.createList();
  this.skipSC();
  while (!this.eof) {
    children.push(this.MediaQuery());
    if (this.tokenType !== types$m.Comma) {
      break;
    }
    this.next();
  }
  return {
    type: "MediaQueryList",
    loc: this.getLocationFromList(children),
    children
  };
}
function generate$n(node2) {
  this.children(node2, () => this.token(types$m.Comma, ","));
}
MediaQueryList$2.generate = generate$n;
MediaQueryList$2.name = name$j;
MediaQueryList$2.parse = parse$n;
MediaQueryList$2.structure = structure$j;
var Nth$2 = {};
const types$l = types$R;
const name$i = "Nth";
const structure$i = {
  nth: ["AnPlusB", "Identifier"],
  selector: ["SelectorList", null]
};
function parse$m() {
  this.skipSC();
  const start = this.tokenStart;
  let end = start;
  let selector2 = null;
  let nth2;
  if (this.lookupValue(0, "odd") || this.lookupValue(0, "even")) {
    nth2 = this.Identifier();
  } else {
    nth2 = this.AnPlusB();
  }
  end = this.tokenStart;
  this.skipSC();
  if (this.lookupValue(0, "of")) {
    this.next();
    selector2 = this.SelectorList();
    end = this.tokenStart;
  }
  return {
    type: "Nth",
    loc: this.getLocation(start, end),
    nth: nth2,
    selector: selector2
  };
}
function generate$m(node2) {
  this.node(node2.nth);
  if (node2.selector !== null) {
    this.token(types$l.Ident, "of");
    this.node(node2.selector);
  }
}
Nth$2.generate = generate$m;
Nth$2.name = name$i;
Nth$2.parse = parse$m;
Nth$2.structure = structure$i;
var _Number$5 = {};
const types$k = types$R;
const name$h = "Number";
const structure$h = {
  value: String
};
function parse$l() {
  return {
    type: "Number",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    value: this.consume(types$k.Number)
  };
}
function generate$l(node2) {
  this.token(types$k.Number, node2.value);
}
_Number$5.generate = generate$l;
_Number$5.name = name$h;
_Number$5.parse = parse$l;
_Number$5.structure = structure$h;
var Operator$2 = {};
const name$g = "Operator";
const structure$g = {
  value: String
};
function parse$k() {
  const start = this.tokenStart;
  this.next();
  return {
    type: "Operator",
    loc: this.getLocation(start, this.tokenStart),
    value: this.substrToCursor(start)
  };
}
function generate$k(node2) {
  this.tokenize(node2.value);
}
Operator$2.generate = generate$k;
Operator$2.name = name$g;
Operator$2.parse = parse$k;
Operator$2.structure = structure$g;
var Parentheses$2 = {};
const types$j = types$R;
const name$f = "Parentheses";
const structure$f = {
  children: [[]]
};
function parse$j(readSequence2, recognizer) {
  const start = this.tokenStart;
  let children = null;
  this.eat(types$j.LeftParenthesis);
  children = readSequence2.call(this, recognizer);
  if (!this.eof) {
    this.eat(types$j.RightParenthesis);
  }
  return {
    type: "Parentheses",
    loc: this.getLocation(start, this.tokenStart),
    children
  };
}
function generate$j(node2) {
  this.token(types$j.LeftParenthesis, "(");
  this.children(node2);
  this.token(types$j.RightParenthesis, ")");
}
Parentheses$2.generate = generate$j;
Parentheses$2.name = name$f;
Parentheses$2.parse = parse$j;
Parentheses$2.structure = structure$f;
var Percentage$4 = {};
const types$i = types$R;
const name$e = "Percentage";
const structure$e = {
  value: String
};
function parse$i() {
  return {
    type: "Percentage",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    value: this.consumeNumber(types$i.Percentage)
  };
}
function generate$i(node2) {
  this.token(types$i.Percentage, node2.value + "%");
}
Percentage$4.generate = generate$i;
Percentage$4.name = name$e;
Percentage$4.parse = parse$i;
Percentage$4.structure = structure$e;
var PseudoClassSelector$2 = {};
const types$h = types$R;
const name$d = "PseudoClassSelector";
const walkContext$4 = "function";
const structure$d = {
  name: String,
  children: [["Raw"], null]
};
function parse$h() {
  const start = this.tokenStart;
  let children = null;
  let name2;
  let nameLowerCase;
  this.eat(types$h.Colon);
  if (this.tokenType === types$h.Function) {
    name2 = this.consumeFunctionName();
    nameLowerCase = name2.toLowerCase();
    if (hasOwnProperty.call(this.pseudo, nameLowerCase)) {
      this.skipSC();
      children = this.pseudo[nameLowerCase].call(this);
      this.skipSC();
    } else {
      children = this.createList();
      children.push(
        this.Raw(this.tokenIndex, null, false)
      );
    }
    this.eat(types$h.RightParenthesis);
  } else {
    name2 = this.consume(types$h.Ident);
  }
  return {
    type: "PseudoClassSelector",
    loc: this.getLocation(start, this.tokenStart),
    name: name2,
    children
  };
}
function generate$h(node2) {
  this.token(types$h.Colon, ":");
  if (node2.children === null) {
    this.token(types$h.Ident, node2.name);
  } else {
    this.token(types$h.Function, node2.name + "(");
    this.children(node2);
    this.token(types$h.RightParenthesis, ")");
  }
}
PseudoClassSelector$2.generate = generate$h;
PseudoClassSelector$2.name = name$d;
PseudoClassSelector$2.parse = parse$h;
PseudoClassSelector$2.structure = structure$d;
PseudoClassSelector$2.walkContext = walkContext$4;
var PseudoElementSelector$2 = {};
const types$g = types$R;
const name$c = "PseudoElementSelector";
const walkContext$3 = "function";
const structure$c = {
  name: String,
  children: [["Raw"], null]
};
function parse$g() {
  const start = this.tokenStart;
  let children = null;
  let name2;
  let nameLowerCase;
  this.eat(types$g.Colon);
  this.eat(types$g.Colon);
  if (this.tokenType === types$g.Function) {
    name2 = this.consumeFunctionName();
    nameLowerCase = name2.toLowerCase();
    if (hasOwnProperty.call(this.pseudo, nameLowerCase)) {
      this.skipSC();
      children = this.pseudo[nameLowerCase].call(this);
      this.skipSC();
    } else {
      children = this.createList();
      children.push(
        this.Raw(this.tokenIndex, null, false)
      );
    }
    this.eat(types$g.RightParenthesis);
  } else {
    name2 = this.consume(types$g.Ident);
  }
  return {
    type: "PseudoElementSelector",
    loc: this.getLocation(start, this.tokenStart),
    name: name2,
    children
  };
}
function generate$g(node2) {
  this.token(types$g.Colon, ":");
  this.token(types$g.Colon, ":");
  if (node2.children === null) {
    this.token(types$g.Ident, node2.name);
  } else {
    this.token(types$g.Function, node2.name + "(");
    this.children(node2);
    this.token(types$g.RightParenthesis, ")");
  }
}
PseudoElementSelector$2.generate = generate$g;
PseudoElementSelector$2.name = name$c;
PseudoElementSelector$2.parse = parse$g;
PseudoElementSelector$2.structure = structure$c;
PseudoElementSelector$2.walkContext = walkContext$3;
var Ratio$2 = {};
const types$f = types$R;
const charCodeDefinitions$4 = charCodeDefinitions$c;
const SOLIDUS$2 = 47;
const FULLSTOP$1 = 46;
function consumeNumber() {
  this.skipSC();
  const value2 = this.consume(types$f.Number);
  for (let i = 0; i < value2.length; i++) {
    const code2 = value2.charCodeAt(i);
    if (!charCodeDefinitions$4.isDigit(code2) && code2 !== FULLSTOP$1) {
      this.error("Unsigned number is expected", this.tokenStart - value2.length + i);
    }
  }
  if (Number(value2) === 0) {
    this.error("Zero number is not allowed", this.tokenStart - value2.length);
  }
  return value2;
}
const name$b = "Ratio";
const structure$b = {
  left: String,
  right: String
};
function parse$f() {
  const start = this.tokenStart;
  const left = consumeNumber.call(this);
  let right;
  this.skipSC();
  this.eatDelim(SOLIDUS$2);
  right = consumeNumber.call(this);
  return {
    type: "Ratio",
    loc: this.getLocation(start, this.tokenStart),
    left,
    right
  };
}
function generate$f(node2) {
  this.token(types$f.Number, node2.left);
  this.token(types$f.Delim, "/");
  this.token(types$f.Number, node2.right);
}
Ratio$2.generate = generate$f;
Ratio$2.name = name$b;
Ratio$2.parse = parse$f;
Ratio$2.structure = structure$b;
var Raw$4 = {};
const types$e = types$R;
function getOffsetExcludeWS() {
  if (this.tokenIndex > 0) {
    if (this.lookupType(-1) === types$e.WhiteSpace) {
      return this.tokenIndex > 1 ? this.getTokenStart(this.tokenIndex - 1) : this.firstCharOffset;
    }
  }
  return this.tokenStart;
}
const name$a = "Raw";
const structure$a = {
  value: String
};
function parse$e(startToken, consumeUntil, excludeWhiteSpace) {
  const startOffset = this.getTokenStart(startToken);
  let endOffset;
  this.skipUntilBalanced(startToken, consumeUntil || this.consumeUntilBalanceEnd);
  if (excludeWhiteSpace && this.tokenStart > startOffset) {
    endOffset = getOffsetExcludeWS.call(this);
  } else {
    endOffset = this.tokenStart;
  }
  return {
    type: "Raw",
    loc: this.getLocation(startOffset, endOffset),
    value: this.substring(startOffset, endOffset)
  };
}
function generate$e(node2) {
  this.tokenize(node2.value);
}
Raw$4.generate = generate$e;
Raw$4.name = name$a;
Raw$4.parse = parse$e;
Raw$4.structure = structure$a;
var Rule$4 = {};
const types$d = types$R;
function consumeRaw$2(startToken) {
  return this.Raw(startToken, this.consumeUntilLeftCurlyBracket, true);
}
function consumePrelude() {
  const prelude = this.SelectorList();
  if (prelude.type !== "Raw" && this.eof === false && this.tokenType !== types$d.LeftCurlyBracket) {
    this.error();
  }
  return prelude;
}
const name$9 = "Rule";
const walkContext$2 = "rule";
const structure$9 = {
  prelude: ["SelectorList", "Raw"],
  block: ["Block"]
};
function parse$d() {
  const startToken = this.tokenIndex;
  const startOffset = this.tokenStart;
  let prelude;
  let block;
  if (this.parseRulePrelude) {
    prelude = this.parseWithFallback(consumePrelude, consumeRaw$2);
  } else {
    prelude = consumeRaw$2.call(this, startToken);
  }
  block = this.Block(true);
  return {
    type: "Rule",
    loc: this.getLocation(startOffset, this.tokenStart),
    prelude,
    block
  };
}
function generate$d(node2) {
  this.node(node2.prelude);
  this.node(node2.block);
}
Rule$4.generate = generate$d;
Rule$4.name = name$9;
Rule$4.parse = parse$d;
Rule$4.structure = structure$9;
Rule$4.walkContext = walkContext$2;
var Selector$3 = {};
const name$8 = "Selector";
const structure$8 = {
  children: [[
    "TypeSelector",
    "IdSelector",
    "ClassSelector",
    "AttributeSelector",
    "PseudoClassSelector",
    "PseudoElementSelector",
    "Combinator",
    "WhiteSpace"
  ]]
};
function parse$c() {
  const children = this.readSequence(this.scope.Selector);
  if (this.getFirstListNode(children) === null) {
    this.error("Selector is expected");
  }
  return {
    type: "Selector",
    loc: this.getLocationFromList(children),
    children
  };
}
function generate$c(node2) {
  this.children(node2);
}
Selector$3.generate = generate$c;
Selector$3.name = name$8;
Selector$3.parse = parse$c;
Selector$3.structure = structure$8;
var SelectorList$2 = {};
const types$c = types$R;
const name$7 = "SelectorList";
const walkContext$1 = "selector";
const structure$7 = {
  children: [[
    "Selector",
    "Raw"
  ]]
};
function parse$b() {
  const children = this.createList();
  while (!this.eof) {
    children.push(this.Selector());
    if (this.tokenType === types$c.Comma) {
      this.next();
      continue;
    }
    break;
  }
  return {
    type: "SelectorList",
    loc: this.getLocationFromList(children),
    children
  };
}
function generate$b(node2) {
  this.children(node2, () => this.token(types$c.Comma, ","));
}
SelectorList$2.generate = generate$b;
SelectorList$2.name = name$7;
SelectorList$2.parse = parse$b;
SelectorList$2.structure = structure$7;
SelectorList$2.walkContext = walkContext$1;
var _String = {};
var string$3 = {};
const charCodeDefinitions$3 = charCodeDefinitions$c;
const utils$d = utils$k;
const REVERSE_SOLIDUS$2 = 92;
const QUOTATION_MARK$1 = 34;
const APOSTROPHE$1 = 39;
function decode$2(str) {
  const len = str.length;
  const firstChar = str.charCodeAt(0);
  const start = firstChar === QUOTATION_MARK$1 || firstChar === APOSTROPHE$1 ? 1 : 0;
  const end = start === 1 && len > 1 && str.charCodeAt(len - 1) === firstChar ? len - 2 : len - 1;
  let decoded = "";
  for (let i = start; i <= end; i++) {
    let code2 = str.charCodeAt(i);
    if (code2 === REVERSE_SOLIDUS$2) {
      if (i === end) {
        if (i !== len - 1) {
          decoded = str.substr(i + 1);
        }
        break;
      }
      code2 = str.charCodeAt(++i);
      if (charCodeDefinitions$3.isValidEscape(REVERSE_SOLIDUS$2, code2)) {
        const escapeStart = i - 1;
        const escapeEnd = utils$d.consumeEscaped(str, escapeStart);
        i = escapeEnd - 1;
        decoded += utils$d.decodeEscaped(str.substring(escapeStart + 1, escapeEnd));
      } else {
        if (code2 === 13 && str.charCodeAt(i + 1) === 10) {
          i++;
        }
      }
    } else {
      decoded += str[i];
    }
  }
  return decoded;
}
function encode$2(str, apostrophe) {
  const quote = apostrophe ? "'" : '"';
  const quoteCode = apostrophe ? APOSTROPHE$1 : QUOTATION_MARK$1;
  let encoded = "";
  let wsBeforeHexIsNeeded = false;
  for (let i = 0; i < str.length; i++) {
    const code2 = str.charCodeAt(i);
    if (code2 === 0) {
      encoded += "\uFFFD";
      continue;
    }
    if (code2 <= 31 || code2 === 127) {
      encoded += "\\" + code2.toString(16);
      wsBeforeHexIsNeeded = true;
      continue;
    }
    if (code2 === quoteCode || code2 === REVERSE_SOLIDUS$2) {
      encoded += "\\" + str.charAt(i);
      wsBeforeHexIsNeeded = false;
    } else {
      if (wsBeforeHexIsNeeded && (charCodeDefinitions$3.isHexDigit(code2) || charCodeDefinitions$3.isWhiteSpace(code2))) {
        encoded += " ";
      }
      encoded += str.charAt(i);
      wsBeforeHexIsNeeded = false;
    }
  }
  return quote + encoded + quote;
}
string$3.decode = decode$2;
string$3.encode = encode$2;
const string$2 = string$3;
const types$b = types$R;
const name$6 = "String";
const structure$6 = {
  value: String
};
function parse$a() {
  return {
    type: "String",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    value: string$2.decode(this.consume(types$b.String))
  };
}
function generate$a(node2) {
  this.token(types$b.String, string$2.encode(node2.value));
}
_String.generate = generate$a;
_String.name = name$6;
_String.parse = parse$a;
_String.structure = structure$6;
var StyleSheet$2 = {};
const types$a = types$R;
const EXCLAMATIONMARK = 33;
function consumeRaw$1(startToken) {
  return this.Raw(startToken, null, false);
}
const name$5 = "StyleSheet";
const walkContext = "stylesheet";
const structure$5 = {
  children: [[
    "Comment",
    "CDO",
    "CDC",
    "Atrule",
    "Rule",
    "Raw"
  ]]
};
function parse$9() {
  const start = this.tokenStart;
  const children = this.createList();
  let child;
  while (!this.eof) {
    switch (this.tokenType) {
      case types$a.WhiteSpace:
        this.next();
        continue;
      case types$a.Comment:
        if (this.charCodeAt(this.tokenStart + 2) !== EXCLAMATIONMARK) {
          this.next();
          continue;
        }
        child = this.Comment();
        break;
      case types$a.CDO:
        child = this.CDO();
        break;
      case types$a.CDC:
        child = this.CDC();
        break;
      case types$a.AtKeyword:
        child = this.parseWithFallback(this.Atrule, consumeRaw$1);
        break;
      default:
        child = this.parseWithFallback(this.Rule, consumeRaw$1);
    }
    children.push(child);
  }
  return {
    type: "StyleSheet",
    loc: this.getLocation(start, this.tokenStart),
    children
  };
}
function generate$9(node2) {
  this.children(node2);
}
StyleSheet$2.generate = generate$9;
StyleSheet$2.name = name$5;
StyleSheet$2.parse = parse$9;
StyleSheet$2.structure = structure$5;
StyleSheet$2.walkContext = walkContext;
var TypeSelector$4 = {};
const types$9 = types$R;
const ASTERISK$2 = 42;
const VERTICALLINE$1 = 124;
function eatIdentifierOrAsterisk() {
  if (this.tokenType !== types$9.Ident && this.isDelim(ASTERISK$2) === false) {
    this.error("Identifier or asterisk is expected");
  }
  this.next();
}
const name$4 = "TypeSelector";
const structure$4 = {
  name: String
};
function parse$8() {
  const start = this.tokenStart;
  if (this.isDelim(VERTICALLINE$1)) {
    this.next();
    eatIdentifierOrAsterisk.call(this);
  } else {
    eatIdentifierOrAsterisk.call(this);
    if (this.isDelim(VERTICALLINE$1)) {
      this.next();
      eatIdentifierOrAsterisk.call(this);
    }
  }
  return {
    type: "TypeSelector",
    loc: this.getLocation(start, this.tokenStart),
    name: this.substrToCursor(start)
  };
}
function generate$8(node2) {
  this.tokenize(node2.name);
}
TypeSelector$4.generate = generate$8;
TypeSelector$4.name = name$4;
TypeSelector$4.parse = parse$8;
TypeSelector$4.structure = structure$4;
var UnicodeRange$2 = {};
const types$8 = types$R;
const charCodeDefinitions$2 = charCodeDefinitions$c;
const PLUSSIGN$2 = 43;
const HYPHENMINUS$1 = 45;
const QUESTIONMARK = 63;
function eatHexSequence(offset, allowDash) {
  let len = 0;
  for (let pos = this.tokenStart + offset; pos < this.tokenEnd; pos++) {
    const code2 = this.charCodeAt(pos);
    if (code2 === HYPHENMINUS$1 && allowDash && len !== 0) {
      eatHexSequence.call(this, offset + len + 1, false);
      return -1;
    }
    if (!charCodeDefinitions$2.isHexDigit(code2)) {
      this.error(
        allowDash && len !== 0 ? "Hyphen minus" + (len < 6 ? " or hex digit" : "") + " is expected" : len < 6 ? "Hex digit is expected" : "Unexpected input",
        pos
      );
    }
    if (++len > 6) {
      this.error("Too many hex digits", pos);
    }
  }
  this.next();
  return len;
}
function eatQuestionMarkSequence(max) {
  let count = 0;
  while (this.isDelim(QUESTIONMARK)) {
    if (++count > max) {
      this.error("Too many question marks");
    }
    this.next();
  }
}
function startsWith(code2) {
  if (this.charCodeAt(this.tokenStart) !== code2) {
    this.error((code2 === PLUSSIGN$2 ? "Plus sign" : "Hyphen minus") + " is expected");
  }
}
function scanUnicodeRange() {
  let hexLength = 0;
  switch (this.tokenType) {
    case types$8.Number:
      hexLength = eatHexSequence.call(this, 1, true);
      if (this.isDelim(QUESTIONMARK)) {
        eatQuestionMarkSequence.call(this, 6 - hexLength);
        break;
      }
      if (this.tokenType === types$8.Dimension || this.tokenType === types$8.Number) {
        startsWith.call(this, HYPHENMINUS$1);
        eatHexSequence.call(this, 1, false);
        break;
      }
      break;
    case types$8.Dimension:
      hexLength = eatHexSequence.call(this, 1, true);
      if (hexLength > 0) {
        eatQuestionMarkSequence.call(this, 6 - hexLength);
      }
      break;
    default:
      this.eatDelim(PLUSSIGN$2);
      if (this.tokenType === types$8.Ident) {
        hexLength = eatHexSequence.call(this, 0, true);
        if (hexLength > 0) {
          eatQuestionMarkSequence.call(this, 6 - hexLength);
        }
        break;
      }
      if (this.isDelim(QUESTIONMARK)) {
        this.next();
        eatQuestionMarkSequence.call(this, 5);
        break;
      }
      this.error("Hex digit or question mark is expected");
  }
}
const name$3 = "UnicodeRange";
const structure$3 = {
  value: String
};
function parse$7() {
  const start = this.tokenStart;
  this.eatIdent("u");
  scanUnicodeRange.call(this);
  return {
    type: "UnicodeRange",
    loc: this.getLocation(start, this.tokenStart),
    value: this.substrToCursor(start)
  };
}
function generate$7(node2) {
  this.tokenize(node2.value);
}
UnicodeRange$2.generate = generate$7;
UnicodeRange$2.name = name$3;
UnicodeRange$2.parse = parse$7;
UnicodeRange$2.structure = structure$3;
var Url$4 = {};
var url$2 = {};
const charCodeDefinitions$1 = charCodeDefinitions$c;
const utils$c = utils$k;
const SPACE$1 = 32;
const REVERSE_SOLIDUS$1 = 92;
const QUOTATION_MARK = 34;
const APOSTROPHE = 39;
const LEFTPARENTHESIS = 40;
const RIGHTPARENTHESIS = 41;
function decode$1(str) {
  const len = str.length;
  let start = 4;
  let end = str.charCodeAt(len - 1) === RIGHTPARENTHESIS ? len - 2 : len - 1;
  let decoded = "";
  while (start < end && charCodeDefinitions$1.isWhiteSpace(str.charCodeAt(start))) {
    start++;
  }
  while (start < end && charCodeDefinitions$1.isWhiteSpace(str.charCodeAt(end))) {
    end--;
  }
  for (let i = start; i <= end; i++) {
    let code2 = str.charCodeAt(i);
    if (code2 === REVERSE_SOLIDUS$1) {
      if (i === end) {
        if (i !== len - 1) {
          decoded = str.substr(i + 1);
        }
        break;
      }
      code2 = str.charCodeAt(++i);
      if (charCodeDefinitions$1.isValidEscape(REVERSE_SOLIDUS$1, code2)) {
        const escapeStart = i - 1;
        const escapeEnd = utils$c.consumeEscaped(str, escapeStart);
        i = escapeEnd - 1;
        decoded += utils$c.decodeEscaped(str.substring(escapeStart + 1, escapeEnd));
      } else {
        if (code2 === 13 && str.charCodeAt(i + 1) === 10) {
          i++;
        }
      }
    } else {
      decoded += str[i];
    }
  }
  return decoded;
}
function encode$1(str) {
  let encoded = "";
  let wsBeforeHexIsNeeded = false;
  for (let i = 0; i < str.length; i++) {
    const code2 = str.charCodeAt(i);
    if (code2 === 0) {
      encoded += "\uFFFD";
      continue;
    }
    if (code2 <= 31 || code2 === 127) {
      encoded += "\\" + code2.toString(16);
      wsBeforeHexIsNeeded = true;
      continue;
    }
    if (code2 === SPACE$1 || code2 === REVERSE_SOLIDUS$1 || code2 === QUOTATION_MARK || code2 === APOSTROPHE || code2 === LEFTPARENTHESIS || code2 === RIGHTPARENTHESIS) {
      encoded += "\\" + str.charAt(i);
      wsBeforeHexIsNeeded = false;
    } else {
      if (wsBeforeHexIsNeeded && charCodeDefinitions$1.isHexDigit(code2)) {
        encoded += " ";
      }
      encoded += str.charAt(i);
      wsBeforeHexIsNeeded = false;
    }
  }
  return "url(" + encoded + ")";
}
url$2.decode = decode$1;
url$2.encode = encode$1;
const url$1 = url$2;
const string$1 = string$3;
const types$7 = types$R;
const name$2 = "Url";
const structure$2 = {
  value: String
};
function parse$6() {
  const start = this.tokenStart;
  let value2;
  switch (this.tokenType) {
    case types$7.Url:
      value2 = url$1.decode(this.consume(types$7.Url));
      break;
    case types$7.Function:
      if (!this.cmpStr(this.tokenStart, this.tokenEnd, "url(")) {
        this.error("Function name must be `url`");
      }
      this.eat(types$7.Function);
      this.skipSC();
      value2 = string$1.decode(this.consume(types$7.String));
      this.skipSC();
      if (!this.eof) {
        this.eat(types$7.RightParenthesis);
      }
      break;
    default:
      this.error("Url or Function is expected");
  }
  return {
    type: "Url",
    loc: this.getLocation(start, this.tokenStart),
    value: value2
  };
}
function generate$6(node2) {
  this.token(types$7.Url, url$1.encode(node2.value));
}
Url$4.generate = generate$6;
Url$4.name = name$2;
Url$4.parse = parse$6;
Url$4.structure = structure$2;
var Value$4 = {};
const name$1 = "Value";
const structure$1 = {
  children: [[]]
};
function parse$5() {
  const start = this.tokenStart;
  const children = this.readSequence(this.scope.Value);
  return {
    type: "Value",
    loc: this.getLocation(start, this.tokenStart),
    children
  };
}
function generate$5(node2) {
  this.children(node2);
}
Value$4.generate = generate$5;
Value$4.name = name$1;
Value$4.parse = parse$5;
Value$4.structure = structure$1;
var WhiteSpace$4 = {};
const types$6 = types$R;
const SPACE = Object.freeze({
  type: "WhiteSpace",
  loc: null,
  value: " "
});
const name = "WhiteSpace";
const structure = {
  value: String
};
function parse$4() {
  this.eat(types$6.WhiteSpace);
  return SPACE;
}
function generate$4(node2) {
  this.token(types$6.WhiteSpace, node2.value);
}
WhiteSpace$4.generate = generate$4;
WhiteSpace$4.name = name;
WhiteSpace$4.parse = parse$4;
WhiteSpace$4.structure = structure;
const AnPlusB$1 = AnPlusB$2;
const Atrule$5 = Atrule$6;
const AtrulePrelude$1 = AtrulePrelude$2;
const AttributeSelector$3 = AttributeSelector$4;
const Block$1 = Block$2;
const Brackets$1 = Brackets$2;
const CDC$1 = CDC$2;
const CDO$1 = CDO$2;
const ClassSelector$1 = ClassSelector$2;
const Combinator$1 = Combinator$2;
const Comment$3 = Comment$4;
const Declaration$3 = Declaration$4;
const DeclarationList$1 = DeclarationList$2;
const Dimension$3 = Dimension$4;
const Function$1 = _Function;
const Hash$1 = Hash$2;
const Identifier$1 = Identifier$2;
const IdSelector$1 = IdSelector$2;
const MediaFeature$1 = MediaFeature$2;
const MediaQuery$1 = MediaQuery$2;
const MediaQueryList$1 = MediaQueryList$2;
const Nth$1 = Nth$2;
const Number$1$1 = _Number$5;
const Operator$1 = Operator$2;
const Parentheses$1 = Parentheses$2;
const Percentage$3 = Percentage$4;
const PseudoClassSelector$1 = PseudoClassSelector$2;
const PseudoElementSelector$1 = PseudoElementSelector$2;
const Ratio$1 = Ratio$2;
const Raw$3 = Raw$4;
const Rule$3 = Rule$4;
const Selector$2 = Selector$3;
const SelectorList$1 = SelectorList$2;
const String$1$1 = _String;
const StyleSheet$1 = StyleSheet$2;
const TypeSelector$3 = TypeSelector$4;
const UnicodeRange$1 = UnicodeRange$2;
const Url$3 = Url$4;
const Value$3 = Value$4;
const WhiteSpace$3 = WhiteSpace$4;
node.AnPlusB = AnPlusB$1;
node.Atrule = Atrule$5;
node.AtrulePrelude = AtrulePrelude$1;
node.AttributeSelector = AttributeSelector$3;
node.Block = Block$1;
node.Brackets = Brackets$1;
node.CDC = CDC$1;
node.CDO = CDO$1;
node.ClassSelector = ClassSelector$1;
node.Combinator = Combinator$1;
node.Comment = Comment$3;
node.Declaration = Declaration$3;
node.DeclarationList = DeclarationList$1;
node.Dimension = Dimension$3;
node.Function = Function$1;
node.Hash = Hash$1;
node.Identifier = Identifier$1;
node.IdSelector = IdSelector$1;
node.MediaFeature = MediaFeature$1;
node.MediaQuery = MediaQuery$1;
node.MediaQueryList = MediaQueryList$1;
node.Nth = Nth$1;
node.Number = Number$1$1;
node.Operator = Operator$1;
node.Parentheses = Parentheses$1;
node.Percentage = Percentage$3;
node.PseudoClassSelector = PseudoClassSelector$1;
node.PseudoElementSelector = PseudoElementSelector$1;
node.Ratio = Ratio$1;
node.Raw = Raw$3;
node.Rule = Rule$3;
node.Selector = Selector$2;
node.SelectorList = SelectorList$1;
node.String = String$1$1;
node.StyleSheet = StyleSheet$1;
node.TypeSelector = TypeSelector$3;
node.UnicodeRange = UnicodeRange$1;
node.Url = Url$3;
node.Value = Value$3;
node.WhiteSpace = WhiteSpace$3;
const data = data$1;
const index$7 = node;
const lexerConfig = {
  generic: true,
  ...data,
  node: index$7
};
var lexer$3 = lexerConfig;
var scope = {};
const types$5 = types$R;
const NUMBERSIGN$1 = 35;
const ASTERISK$1 = 42;
const PLUSSIGN$1 = 43;
const HYPHENMINUS = 45;
const SOLIDUS$1 = 47;
const U = 117;
function defaultRecognizer(context) {
  switch (this.tokenType) {
    case types$5.Hash:
      return this.Hash();
    case types$5.Comma:
      return this.Operator();
    case types$5.LeftParenthesis:
      return this.Parentheses(this.readSequence, context.recognizer);
    case types$5.LeftSquareBracket:
      return this.Brackets(this.readSequence, context.recognizer);
    case types$5.String:
      return this.String();
    case types$5.Dimension:
      return this.Dimension();
    case types$5.Percentage:
      return this.Percentage();
    case types$5.Number:
      return this.Number();
    case types$5.Function:
      return this.cmpStr(this.tokenStart, this.tokenEnd, "url(") ? this.Url() : this.Function(this.readSequence, context.recognizer);
    case types$5.Url:
      return this.Url();
    case types$5.Ident:
      if (this.cmpChar(this.tokenStart, U) && this.cmpChar(this.tokenStart + 1, PLUSSIGN$1)) {
        return this.UnicodeRange();
      } else {
        return this.Identifier();
      }
    case types$5.Delim: {
      const code2 = this.charCodeAt(this.tokenStart);
      if (code2 === SOLIDUS$1 || code2 === ASTERISK$1 || code2 === PLUSSIGN$1 || code2 === HYPHENMINUS) {
        return this.Operator();
      }
      if (code2 === NUMBERSIGN$1) {
        this.error("Hex or identifier is expected", this.tokenStart + 1);
      }
      break;
    }
  }
}
var _default$2 = defaultRecognizer;
const _default$1 = _default$2;
const atrulePrelude$1 = {
  getNode: _default$1
};
var atrulePrelude_1 = atrulePrelude$1;
const types$4 = types$R;
const NUMBERSIGN = 35;
const ASTERISK = 42;
const PLUSSIGN = 43;
const SOLIDUS = 47;
const FULLSTOP = 46;
const GREATERTHANSIGN = 62;
const VERTICALLINE = 124;
const TILDE = 126;
function onWhiteSpace(next, children) {
  if (children.last !== null && children.last.type !== "Combinator" && next !== null && next.type !== "Combinator") {
    children.push({
      type: "Combinator",
      loc: null,
      name: " "
    });
  }
}
function getNode() {
  switch (this.tokenType) {
    case types$4.LeftSquareBracket:
      return this.AttributeSelector();
    case types$4.Hash:
      return this.IdSelector();
    case types$4.Colon:
      if (this.lookupType(1) === types$4.Colon) {
        return this.PseudoElementSelector();
      } else {
        return this.PseudoClassSelector();
      }
    case types$4.Ident:
      return this.TypeSelector();
    case types$4.Number:
    case types$4.Percentage:
      return this.Percentage();
    case types$4.Dimension:
      if (this.charCodeAt(this.tokenStart) === FULLSTOP) {
        this.error("Identifier is expected", this.tokenStart + 1);
      }
      break;
    case types$4.Delim: {
      const code2 = this.charCodeAt(this.tokenStart);
      switch (code2) {
        case PLUSSIGN:
        case GREATERTHANSIGN:
        case TILDE:
        case SOLIDUS:
          return this.Combinator();
        case FULLSTOP:
          return this.ClassSelector();
        case ASTERISK:
        case VERTICALLINE:
          return this.TypeSelector();
        case NUMBERSIGN:
          return this.IdSelector();
      }
      break;
    }
  }
}
const Selector$1 = {
  onWhiteSpace,
  getNode
};
var selector$2 = Selector$1;
function expressionFn() {
  return this.createSingleNodeList(
    this.Raw(this.tokenIndex, null, false)
  );
}
var expression$1 = expressionFn;
const types$3 = types$R;
function varFn() {
  const children = this.createList();
  this.skipSC();
  children.push(this.Identifier());
  this.skipSC();
  if (this.tokenType === types$3.Comma) {
    children.push(this.Operator());
    const startIndex = this.tokenIndex;
    const value2 = this.parseCustomProperty ? this.Value(null) : this.Raw(this.tokenIndex, this.consumeUntilExclamationMarkOrSemicolon, false);
    if (value2.type === "Value" && value2.children.isEmpty) {
      for (let offset = startIndex - this.tokenIndex; offset <= 0; offset++) {
        if (this.lookupType(offset) === types$3.WhiteSpace) {
          value2.children.appendData({
            type: "WhiteSpace",
            loc: null,
            value: " "
          });
          break;
        }
      }
    }
    children.push(value2);
  }
  return children;
}
var _var$1 = varFn;
const _default = _default$2;
const expression = expression$1;
const _var = _var$1;
function isPlusMinusOperator(node2) {
  return node2 !== null && node2.type === "Operator" && (node2.value[node2.value.length - 1] === "-" || node2.value[node2.value.length - 1] === "+");
}
const value$1 = {
  getNode: _default,
  onWhiteSpace(next, children) {
    if (isPlusMinusOperator(next)) {
      next.value = " " + next.value;
    }
    if (isPlusMinusOperator(children.last)) {
      children.last.value += " ";
    }
  },
  "expression": expression,
  "var": _var
};
var value_1 = value$1;
const atrulePrelude = atrulePrelude_1;
const selector$1 = selector$2;
const value = value_1;
scope.AtrulePrelude = atrulePrelude;
scope.Selector = selector$1;
scope.Value = value;
const fontFace$1 = {
  parse: {
    prelude: null,
    block() {
      return this.Block(true);
    }
  }
};
var fontFace_1 = fontFace$1;
const types$2 = types$R;
const importAtrule = {
  parse: {
    prelude() {
      const children = this.createList();
      this.skipSC();
      switch (this.tokenType) {
        case types$2.String:
          children.push(this.String());
          break;
        case types$2.Url:
        case types$2.Function:
          children.push(this.Url());
          break;
        default:
          this.error("String or url() is expected");
      }
      if (this.lookupNonWSType(0) === types$2.Ident || this.lookupNonWSType(0) === types$2.LeftParenthesis) {
        children.push(this.MediaQueryList());
      }
      return children;
    },
    block: null
  }
};
var _import$1 = importAtrule;
const media$1 = {
  parse: {
    prelude() {
      return this.createSingleNodeList(
        this.MediaQueryList()
      );
    },
    block() {
      return this.Block(false);
    }
  }
};
var media_1 = media$1;
const page$1 = {
  parse: {
    prelude() {
      return this.createSingleNodeList(
        this.SelectorList()
      );
    },
    block() {
      return this.Block(true);
    }
  }
};
var page_1 = page$1;
const types$1 = types$R;
function consumeRaw() {
  return this.createSingleNodeList(
    this.Raw(this.tokenIndex, null, false)
  );
}
function parentheses() {
  this.skipSC();
  if (this.tokenType === types$1.Ident && this.lookupNonWSType(1) === types$1.Colon) {
    return this.createSingleNodeList(
      this.Declaration()
    );
  }
  return readSequence.call(this);
}
function readSequence() {
  const children = this.createList();
  let child;
  this.skipSC();
  scan:
    while (!this.eof) {
      switch (this.tokenType) {
        case types$1.Comment:
        case types$1.WhiteSpace:
          this.next();
          continue;
        case types$1.Function:
          child = this.Function(consumeRaw, this.scope.AtrulePrelude);
          break;
        case types$1.Ident:
          child = this.Identifier();
          break;
        case types$1.LeftParenthesis:
          child = this.Parentheses(parentheses, this.scope.AtrulePrelude);
          break;
        default:
          break scan;
      }
      children.push(child);
    }
  return children;
}
const supports$1 = {
  parse: {
    prelude() {
      const children = readSequence.call(this);
      if (this.getFirstListNode(children) === null) {
        this.error("Condition is expected");
      }
      return children;
    },
    block() {
      return this.Block(false);
    }
  }
};
var supports_1 = supports$1;
const fontFace = fontFace_1;
const _import = _import$1;
const media = media_1;
const page = page_1;
const supports = supports_1;
const atrule = {
  "font-face": fontFace,
  "import": _import,
  media,
  page,
  supports
};
var atrule_1 = atrule;
const selectorList = {
  parse() {
    return this.createSingleNodeList(
      this.SelectorList()
    );
  }
};
const selector = {
  parse() {
    return this.createSingleNodeList(
      this.Selector()
    );
  }
};
const identList = {
  parse() {
    return this.createSingleNodeList(
      this.Identifier()
    );
  }
};
const nth = {
  parse() {
    return this.createSingleNodeList(
      this.Nth()
    );
  }
};
const pseudo = {
  "dir": identList,
  "has": selectorList,
  "lang": identList,
  "matches": selectorList,
  "is": selectorList,
  "-moz-any": selectorList,
  "-webkit-any": selectorList,
  "where": selectorList,
  "not": selectorList,
  "nth-child": nth,
  "nth-last-child": nth,
  "nth-last-of-type": nth,
  "nth-of-type": nth,
  "slotted": selector
};
var pseudo_1 = pseudo;
var indexParse$1 = {};
const AnPlusB = AnPlusB$2;
const Atrule$4 = Atrule$6;
const AtrulePrelude = AtrulePrelude$2;
const AttributeSelector$2 = AttributeSelector$4;
const Block = Block$2;
const Brackets = Brackets$2;
const CDC = CDC$2;
const CDO = CDO$2;
const ClassSelector = ClassSelector$2;
const Combinator = Combinator$2;
const Comment$2 = Comment$4;
const Declaration$2 = Declaration$4;
const DeclarationList = DeclarationList$2;
const Dimension$2 = Dimension$4;
const Function = _Function;
const Hash = Hash$2;
const Identifier = Identifier$2;
const IdSelector = IdSelector$2;
const MediaFeature = MediaFeature$2;
const MediaQuery = MediaQuery$2;
const MediaQueryList = MediaQueryList$2;
const Nth = Nth$2;
const Number$2 = _Number$5;
const Operator = Operator$2;
const Parentheses = Parentheses$2;
const Percentage$2 = Percentage$4;
const PseudoClassSelector = PseudoClassSelector$2;
const PseudoElementSelector = PseudoElementSelector$2;
const Ratio = Ratio$2;
const Raw$2 = Raw$4;
const Rule$2 = Rule$4;
const Selector = Selector$3;
const SelectorList = SelectorList$2;
const String$1 = _String;
const StyleSheet = StyleSheet$2;
const TypeSelector$2 = TypeSelector$4;
const UnicodeRange = UnicodeRange$2;
const Url$2 = Url$4;
const Value$2 = Value$4;
const WhiteSpace$2 = WhiteSpace$4;
indexParse$1.AnPlusB = AnPlusB.parse;
indexParse$1.Atrule = Atrule$4.parse;
indexParse$1.AtrulePrelude = AtrulePrelude.parse;
indexParse$1.AttributeSelector = AttributeSelector$2.parse;
indexParse$1.Block = Block.parse;
indexParse$1.Brackets = Brackets.parse;
indexParse$1.CDC = CDC.parse;
indexParse$1.CDO = CDO.parse;
indexParse$1.ClassSelector = ClassSelector.parse;
indexParse$1.Combinator = Combinator.parse;
indexParse$1.Comment = Comment$2.parse;
indexParse$1.Declaration = Declaration$2.parse;
indexParse$1.DeclarationList = DeclarationList.parse;
indexParse$1.Dimension = Dimension$2.parse;
indexParse$1.Function = Function.parse;
indexParse$1.Hash = Hash.parse;
indexParse$1.Identifier = Identifier.parse;
indexParse$1.IdSelector = IdSelector.parse;
indexParse$1.MediaFeature = MediaFeature.parse;
indexParse$1.MediaQuery = MediaQuery.parse;
indexParse$1.MediaQueryList = MediaQueryList.parse;
indexParse$1.Nth = Nth.parse;
indexParse$1.Number = Number$2.parse;
indexParse$1.Operator = Operator.parse;
indexParse$1.Parentheses = Parentheses.parse;
indexParse$1.Percentage = Percentage$2.parse;
indexParse$1.PseudoClassSelector = PseudoClassSelector.parse;
indexParse$1.PseudoElementSelector = PseudoElementSelector.parse;
indexParse$1.Ratio = Ratio.parse;
indexParse$1.Raw = Raw$2.parse;
indexParse$1.Rule = Rule$2.parse;
indexParse$1.Selector = Selector.parse;
indexParse$1.SelectorList = SelectorList.parse;
indexParse$1.String = String$1.parse;
indexParse$1.StyleSheet = StyleSheet.parse;
indexParse$1.TypeSelector = TypeSelector$2.parse;
indexParse$1.UnicodeRange = UnicodeRange.parse;
indexParse$1.Url = Url$2.parse;
indexParse$1.Value = Value$2.parse;
indexParse$1.WhiteSpace = WhiteSpace$2.parse;
const index$6 = scope;
const index$1$2 = atrule_1;
const index$2$1 = pseudo_1;
const indexParse = indexParse$1;
const config$2 = {
  parseContext: {
    default: "StyleSheet",
    stylesheet: "StyleSheet",
    atrule: "Atrule",
    atrulePrelude(options) {
      return this.AtrulePrelude(options.atrule ? String(options.atrule) : null);
    },
    mediaQueryList: "MediaQueryList",
    mediaQuery: "MediaQuery",
    rule: "Rule",
    selectorList: "SelectorList",
    selector: "Selector",
    block() {
      return this.Block(true);
    },
    declarationList: "DeclarationList",
    declaration: "Declaration",
    value: "Value"
  },
  scope: index$6,
  atrule: index$1$2,
  pseudo: index$2$1,
  node: indexParse
};
var parser$2 = config$2;
const index$5 = node;
const config$1 = {
  node: index$5
};
var walker$1 = config$1;
const create$1 = create_1;
const lexer$2 = lexer$3;
const parser$1 = parser$2;
const walker = walker$1;
const syntax$2 = create$1({
  ...lexer$2,
  ...parser$1,
  ...walker
});
var syntax_1 = syntax$2;
var version$3 = "2.2.1";
var definitionSyntax = {};
const SyntaxError$1 = _SyntaxError;
const generate$3 = generate$L;
const parse$3 = parse$L;
const walk$2 = walk$5;
definitionSyntax.SyntaxError = SyntaxError$1.SyntaxError;
definitionSyntax.generate = generate$3.generate;
definitionSyntax.parse = parse$3.parse;
definitionSyntax.walk = walk$2.walk;
var clone$2 = {};
const List$1 = List$7;
function clone$1(node2) {
  const result = {};
  for (const key in node2) {
    let value2 = node2[key];
    if (value2) {
      if (Array.isArray(value2) || value2 instanceof List$1.List) {
        value2 = value2.map(clone$1);
      } else if (value2.constructor === Object) {
        value2 = clone$1(value2);
      }
    }
    result[key] = value2;
  }
  return result;
}
clone$2.clone = clone$1;
var ident$1 = {};
const charCodeDefinitions = charCodeDefinitions$c;
const utils$b = utils$k;
const REVERSE_SOLIDUS = 92;
function decode(str) {
  const end = str.length - 1;
  let decoded = "";
  for (let i = 0; i < str.length; i++) {
    let code2 = str.charCodeAt(i);
    if (code2 === REVERSE_SOLIDUS) {
      if (i === end) {
        break;
      }
      code2 = str.charCodeAt(++i);
      if (charCodeDefinitions.isValidEscape(REVERSE_SOLIDUS, code2)) {
        const escapeStart = i - 1;
        const escapeEnd = utils$b.consumeEscaped(str, escapeStart);
        i = escapeEnd - 1;
        decoded += utils$b.decodeEscaped(str.substring(escapeStart + 1, escapeEnd));
      } else {
        if (code2 === 13 && str.charCodeAt(i + 1) === 10) {
          i++;
        }
      }
    } else {
      decoded += str[i];
    }
  }
  return decoded;
}
function encode(str) {
  let encoded = "";
  if (str.length === 1 && str.charCodeAt(0) === 45) {
    return "\\-";
  }
  for (let i = 0; i < str.length; i++) {
    const code2 = str.charCodeAt(i);
    if (code2 === 0) {
      encoded += "\uFFFD";
      continue;
    }
    if (code2 <= 31 || code2 === 127 || code2 >= 48 && code2 <= 57 && (i === 0 || i === 1 && str.charCodeAt(0) === 45)) {
      encoded += "\\" + code2.toString(16) + " ";
      continue;
    }
    if (charCodeDefinitions.isName(code2)) {
      encoded += str.charAt(i);
    } else {
      encoded += "\\" + str.charAt(i);
    }
  }
  return encoded;
}
ident$1.decode = decode;
ident$1.encode = encode;
const index$1$1 = syntax_1;
const version$2 = version$3;
const create = create_1;
const List = List$7;
const Lexer = Lexer$3;
const index$4 = definitionSyntax;
const clone = clone$2;
const names$1 = names$4;
const ident = ident$1;
const string = string$3;
const url = url$2;
const types = types$R;
const names = names$8;
const TokenStream = TokenStream$4;
const {
  tokenize: tokenize$1,
  parse: parse$2,
  generate: generate$2,
  lexer: lexer$1,
  createLexer,
  walk: walk$1,
  find: find$1,
  findLast: findLast$1,
  findAll: findAll$1,
  toPlainObject: toPlainObject$1,
  fromPlainObject: fromPlainObject$1,
  fork
} = index$1$1;
cjs$1.version = version$2.version;
cjs$1.createSyntax = create;
cjs$1.List = List.List;
cjs$1.Lexer = Lexer.Lexer;
cjs$1.definitionSyntax = index$4;
cjs$1.clone = clone.clone;
cjs$1.isCustomProperty = names$1.isCustomProperty;
cjs$1.keyword = names$1.keyword;
cjs$1.property = names$1.property;
cjs$1.vendorPrefix = names$1.vendorPrefix;
cjs$1.ident = ident;
cjs$1.string = string;
cjs$1.url = url;
cjs$1.tokenTypes = types;
cjs$1.tokenNames = names;
cjs$1.TokenStream = TokenStream.TokenStream;
cjs$1.createLexer = createLexer;
cjs$1.find = find$1;
cjs$1.findAll = findAll$1;
cjs$1.findLast = findLast$1;
cjs$1.fork = fork;
cjs$1.fromPlainObject = fromPlainObject$1;
cjs$1.generate = generate$2;
cjs$1.lexer = lexer$1;
cjs$1.parse = parse$2;
cjs$1.toPlainObject = toPlainObject$1;
cjs$1.tokenize = tokenize$1;
cjs$1.walk = walk$1;
var cjs = {};
var version$1 = "5.0.5";
var syntax$1 = {};
var usage$1 = {};
const { hasOwnProperty: hasOwnProperty$4 } = Object.prototype;
function buildMap(list, caseInsensitive) {
  const map = /* @__PURE__ */ Object.create(null);
  if (!Array.isArray(list)) {
    return null;
  }
  for (let name2 of list) {
    if (caseInsensitive) {
      name2 = name2.toLowerCase();
    }
    map[name2] = true;
  }
  return map;
}
function buildList(data2) {
  if (!data2) {
    return null;
  }
  const tags = buildMap(data2.tags, true);
  const ids = buildMap(data2.ids);
  const classes = buildMap(data2.classes);
  if (tags === null && ids === null && classes === null) {
    return null;
  }
  return {
    tags,
    ids,
    classes
  };
}
function buildIndex(data2) {
  let scopes = false;
  if (data2.scopes && Array.isArray(data2.scopes)) {
    scopes = /* @__PURE__ */ Object.create(null);
    for (let i = 0; i < data2.scopes.length; i++) {
      const list = data2.scopes[i];
      if (!list || !Array.isArray(list)) {
        throw new Error("Wrong usage format");
      }
      for (const name2 of list) {
        if (hasOwnProperty$4.call(scopes, name2)) {
          throw new Error(`Class can't be used for several scopes: ${name2}`);
        }
        scopes[name2] = i + 1;
      }
    }
  }
  return {
    whitelist: buildList(data2),
    blacklist: buildList(data2.blacklist),
    scopes
  };
}
usage$1.buildIndex = buildIndex;
var utils$a = {};
function hasNoChildren(node2) {
  return !node2 || !node2.children || node2.children.isEmpty;
}
function isNodeChildrenList(node2, list) {
  return node2 !== null && node2.children === list;
}
utils$a.hasNoChildren = hasNoChildren;
utils$a.isNodeChildrenList = isNodeChildrenList;
const cssTree$m = cjs$1;
const utils$9 = utils$a;
function cleanAtrule(node2, item, list) {
  if (node2.block) {
    if (this.stylesheet !== null) {
      this.stylesheet.firstAtrulesAllowed = false;
    }
    if (utils$9.hasNoChildren(node2.block)) {
      list.remove(item);
      return;
    }
  }
  switch (node2.name) {
    case "charset":
      if (utils$9.hasNoChildren(node2.prelude)) {
        list.remove(item);
        return;
      }
      if (item.prev) {
        list.remove(item);
        return;
      }
      break;
    case "import":
      if (this.stylesheet === null || !this.stylesheet.firstAtrulesAllowed) {
        list.remove(item);
        return;
      }
      list.prevUntil(item.prev, function(rule) {
        if (rule.type === "Atrule") {
          if (rule.name === "import" || rule.name === "charset") {
            return;
          }
        }
        this.root.firstAtrulesAllowed = false;
        list.remove(item);
        return true;
      }, this);
      break;
    default: {
      const name2 = cssTree$m.keyword(node2.name).basename;
      if (name2 === "keyframes" || name2 === "media" || name2 === "supports") {
        if (utils$9.hasNoChildren(node2.prelude) || utils$9.hasNoChildren(node2.block)) {
          list.remove(item);
        }
      }
    }
  }
}
var Atrule$3 = cleanAtrule;
function cleanComment(data2, item, list) {
  list.remove(item);
}
var Comment$1 = cleanComment;
const cssTree$l = cjs$1;
function cleanDeclartion(node2, item, list) {
  if (node2.value.children && node2.value.children.isEmpty) {
    list.remove(item);
    return;
  }
  if (cssTree$l.property(node2.property).custom) {
    if (/\S/.test(node2.value.value)) {
      node2.value.value = node2.value.value.trim();
    }
  }
}
var Declaration$1 = cleanDeclartion;
const utils$8 = utils$a;
function cleanRaw(node2, item, list) {
  if (utils$8.isNodeChildrenList(this.stylesheet, list) || utils$8.isNodeChildrenList(this.block, list)) {
    list.remove(item);
  }
}
var Raw$1 = cleanRaw;
const cssTree$k = cjs$1;
const utils$7 = utils$a;
const { hasOwnProperty: hasOwnProperty$3 } = Object.prototype;
const skipUsageFilteringAtrule = /* @__PURE__ */ new Set(["keyframes"]);
function cleanUnused(selectorList2, usageData) {
  selectorList2.children.forEach((selector2, item, list) => {
    let shouldRemove = false;
    cssTree$k.walk(selector2, function(node2) {
      if (this.selector === null || this.selector === selectorList2) {
        switch (node2.type) {
          case "SelectorList":
            if (this.function === null || this.function.name.toLowerCase() !== "not") {
              if (cleanUnused(node2, usageData)) {
                shouldRemove = true;
              }
            }
            break;
          case "ClassSelector":
            if (usageData.whitelist !== null && usageData.whitelist.classes !== null && !hasOwnProperty$3.call(usageData.whitelist.classes, node2.name)) {
              shouldRemove = true;
            }
            if (usageData.blacklist !== null && usageData.blacklist.classes !== null && hasOwnProperty$3.call(usageData.blacklist.classes, node2.name)) {
              shouldRemove = true;
            }
            break;
          case "IdSelector":
            if (usageData.whitelist !== null && usageData.whitelist.ids !== null && !hasOwnProperty$3.call(usageData.whitelist.ids, node2.name)) {
              shouldRemove = true;
            }
            if (usageData.blacklist !== null && usageData.blacklist.ids !== null && hasOwnProperty$3.call(usageData.blacklist.ids, node2.name)) {
              shouldRemove = true;
            }
            break;
          case "TypeSelector":
            if (node2.name.charAt(node2.name.length - 1) !== "*") {
              if (usageData.whitelist !== null && usageData.whitelist.tags !== null && !hasOwnProperty$3.call(usageData.whitelist.tags, node2.name.toLowerCase())) {
                shouldRemove = true;
              }
              if (usageData.blacklist !== null && usageData.blacklist.tags !== null && hasOwnProperty$3.call(usageData.blacklist.tags, node2.name.toLowerCase())) {
                shouldRemove = true;
              }
            }
            break;
        }
      }
    });
    if (shouldRemove) {
      list.remove(item);
    }
  });
  return selectorList2.children.isEmpty;
}
function cleanRule(node2, item, list, options) {
  if (utils$7.hasNoChildren(node2.prelude) || utils$7.hasNoChildren(node2.block)) {
    list.remove(item);
    return;
  }
  if (this.atrule && skipUsageFilteringAtrule.has(cssTree$k.keyword(this.atrule.name).basename)) {
    return;
  }
  const { usage: usage2 } = options;
  if (usage2 && (usage2.whitelist !== null || usage2.blacklist !== null)) {
    cleanUnused(node2.prelude, usage2);
    if (utils$7.hasNoChildren(node2.prelude)) {
      list.remove(item);
      return;
    }
  }
}
var Rule$1 = cleanRule;
function cleanTypeSelector(node2, item, list) {
  const name2 = item.data.name;
  if (name2 !== "*") {
    return;
  }
  const nextType = item.next && item.next.data.type;
  if (nextType === "IdSelector" || nextType === "ClassSelector" || nextType === "AttributeSelector" || nextType === "PseudoClassSelector" || nextType === "PseudoElementSelector") {
    list.remove(item);
  }
}
var TypeSelector$1 = cleanTypeSelector;
function cleanWhitespace(node2, item, list) {
  list.remove(item);
}
var WhiteSpace$1 = cleanWhitespace;
const cssTree$j = cjs$1;
const Atrule$2 = Atrule$3;
const Comment = Comment$1;
const Declaration = Declaration$1;
const Raw = Raw$1;
const Rule = Rule$1;
const TypeSelector = TypeSelector$1;
const WhiteSpace = WhiteSpace$1;
const handlers$2 = {
  Atrule: Atrule$2,
  Comment,
  Declaration,
  Raw,
  Rule,
  TypeSelector,
  WhiteSpace
};
function clean(ast, options) {
  cssTree$j.walk(ast, {
    leave(node2, item, list) {
      if (handlers$2.hasOwnProperty(node2.type)) {
        handlers$2[node2.type].call(this, node2, item, list, options);
      }
    }
  });
}
var clean_1 = clean;
function compressKeyframes(node2) {
  node2.block.children.forEach((rule) => {
    rule.prelude.children.forEach((simpleselector) => {
      simpleselector.children.forEach((data2, item) => {
        if (data2.type === "Percentage" && data2.value === "100") {
          item.data = {
            type: "TypeSelector",
            loc: data2.loc,
            name: "to"
          };
        } else if (data2.type === "TypeSelector" && data2.name === "from") {
          item.data = {
            type: "Percentage",
            loc: data2.loc,
            value: "0"
          };
        }
      });
    });
  });
}
var keyframes$1 = compressKeyframes;
const cssTree$i = cjs$1;
const keyframes = keyframes$1;
function Atrule$1(node2) {
  if (cssTree$i.keyword(node2.name).basename === "keyframes") {
    keyframes(node2);
  }
}
var Atrule_1 = Atrule$1;
const blockUnquoteRx = /^(-?\d|--)|[\u0000-\u002c\u002e\u002f\u003A-\u0040\u005B-\u005E\u0060\u007B-\u009f]/;
function canUnquote(value2) {
  if (value2 === "" || value2 === "-") {
    return false;
  }
  return !blockUnquoteRx.test(value2);
}
function AttributeSelector$1(node2) {
  const attrValue = node2.value;
  if (!attrValue || attrValue.type !== "String") {
    return;
  }
  if (canUnquote(attrValue.value)) {
    node2.value = {
      type: "Identifier",
      loc: attrValue.loc,
      name: attrValue.value
    };
  }
}
var AttributeSelector_1 = AttributeSelector$1;
function compressFont(node2) {
  const list = node2.children;
  list.forEachRight(function(node3, item) {
    if (node3.type === "Identifier") {
      if (node3.name === "bold") {
        item.data = {
          type: "Number",
          loc: node3.loc,
          value: "700"
        };
      } else if (node3.name === "normal") {
        const prev = item.prev;
        if (prev && prev.data.type === "Operator" && prev.data.value === "/") {
          this.remove(prev);
        }
        this.remove(item);
      }
    }
  });
  if (list.isEmpty) {
    list.insert(list.createItem({
      type: "Identifier",
      name: "normal"
    }));
  }
}
var font$1 = compressFont;
function compressFontWeight(node2) {
  const value2 = node2.children.head.data;
  if (value2.type === "Identifier") {
    switch (value2.name) {
      case "normal":
        node2.children.head.data = {
          type: "Number",
          loc: value2.loc,
          value: "400"
        };
        break;
      case "bold":
        node2.children.head.data = {
          type: "Number",
          loc: value2.loc,
          value: "700"
        };
        break;
    }
  }
}
var fontWeight$1 = compressFontWeight;
const cssTree$h = cjs$1;
function compressBackground(node2) {
  function flush() {
    if (!buffer.length) {
      buffer.unshift(
        {
          type: "Number",
          loc: null,
          value: "0"
        },
        {
          type: "Number",
          loc: null,
          value: "0"
        }
      );
    }
    newValue.push.apply(newValue, buffer);
    buffer = [];
  }
  let newValue = [];
  let buffer = [];
  node2.children.forEach((node3) => {
    if (node3.type === "Operator" && node3.value === ",") {
      flush();
      newValue.push(node3);
      return;
    }
    if (node3.type === "Identifier") {
      if (node3.name === "transparent" || node3.name === "none" || node3.name === "repeat" || node3.name === "scroll") {
        return;
      }
    }
    buffer.push(node3);
  });
  flush();
  node2.children = new cssTree$h.List().fromArray(newValue);
}
var background$1 = compressBackground;
function compressBorder(node2) {
  node2.children.forEach((node3, item, list) => {
    if (node3.type === "Identifier" && node3.name.toLowerCase() === "none") {
      if (list.head === list.tail) {
        item.data = {
          type: "Number",
          loc: node3.loc,
          value: "0"
        };
      } else {
        list.remove(item);
      }
    }
  });
}
var border$1 = compressBorder;
const cssTree$g = cjs$1;
const font = font$1;
const fontWeight = fontWeight$1;
const background = background$1;
const border = border$1;
const handlers$1 = {
  "font": font,
  "font-weight": fontWeight,
  "background": background,
  "border": border,
  "outline": border
};
function compressValue(node2) {
  if (!this.declaration) {
    return;
  }
  const property2 = cssTree$g.property(this.declaration.property);
  if (handlers$1.hasOwnProperty(property2.basename)) {
    handlers$1[property2.basename](node2);
  }
}
var Value$1 = compressValue;
var _Number$4 = {};
const OMIT_PLUSSIGN = /^(?:\+|(-))?0*(\d*)(?:\.0*|(\.\d*?)0*)?$/;
const KEEP_PLUSSIGN = /^([\+\-])?0*(\d*)(?:\.0*|(\.\d*?)0*)?$/;
const unsafeToRemovePlusSignAfter = /* @__PURE__ */ new Set([
  "Dimension",
  "Hash",
  "Identifier",
  "Number",
  "Raw",
  "UnicodeRange"
]);
function packNumber(value2, item) {
  const regexp = item && item.prev !== null && unsafeToRemovePlusSignAfter.has(item.prev.data.type) ? KEEP_PLUSSIGN : OMIT_PLUSSIGN;
  value2 = String(value2).replace(regexp, "$1$2$3");
  if (value2 === "" || value2 === "-") {
    value2 = "0";
  }
  return value2;
}
function Number$1(node2) {
  node2.value = packNumber(node2.value);
}
_Number$4.Number = Number$1;
_Number$4.packNumber = packNumber;
const _Number$3 = _Number$4;
const MATH_FUNCTIONS = /* @__PURE__ */ new Set([
  "calc",
  "min",
  "max",
  "clamp"
]);
const LENGTH_UNIT = /* @__PURE__ */ new Set([
  "px",
  "mm",
  "cm",
  "in",
  "pt",
  "pc",
  "em",
  "ex",
  "ch",
  "rem",
  "vh",
  "vw",
  "vmin",
  "vmax",
  "vm"
]);
function compressDimension(node2, item) {
  const value2 = _Number$3.packNumber(node2.value);
  node2.value = value2;
  if (value2 === "0" && this.declaration !== null && this.atrulePrelude === null) {
    const unit = node2.unit.toLowerCase();
    if (!LENGTH_UNIT.has(unit)) {
      return;
    }
    if (this.declaration.property === "-ms-flex" || this.declaration.property === "flex") {
      return;
    }
    if (this.function && MATH_FUNCTIONS.has(this.function.name)) {
      return;
    }
    item.data = {
      type: "Number",
      loc: node2.loc,
      value: value2
    };
  }
}
var Dimension$1 = compressDimension;
const cssTree$f = cjs$1;
const _Number$2 = _Number$4;
const blacklist = /* @__PURE__ */ new Set([
  "width",
  "min-width",
  "max-width",
  "height",
  "min-height",
  "max-height",
  "flex",
  "-ms-flex"
]);
function compressPercentage(node2, item) {
  node2.value = _Number$2.packNumber(node2.value);
  if (node2.value === "0" && this.declaration && !blacklist.has(this.declaration.property)) {
    item.data = {
      type: "Number",
      loc: node2.loc,
      value: node2.value
    };
    if (!cssTree$f.lexer.matchDeclaration(this.declaration).isType(item.data, "length")) {
      item.data = node2;
    }
  }
}
var Percentage$1 = compressPercentage;
function Url$1(node2) {
  node2.value = node2.value.replace(/\\/g, "/");
}
var Url_1 = Url$1;
var color$1 = {};
const cssTree$e = cjs$1;
const _Number$1 = _Number$4;
const NAME_TO_HEX = {
  "aliceblue": "f0f8ff",
  "antiquewhite": "faebd7",
  "aqua": "0ff",
  "aquamarine": "7fffd4",
  "azure": "f0ffff",
  "beige": "f5f5dc",
  "bisque": "ffe4c4",
  "black": "000",
  "blanchedalmond": "ffebcd",
  "blue": "00f",
  "blueviolet": "8a2be2",
  "brown": "a52a2a",
  "burlywood": "deb887",
  "cadetblue": "5f9ea0",
  "chartreuse": "7fff00",
  "chocolate": "d2691e",
  "coral": "ff7f50",
  "cornflowerblue": "6495ed",
  "cornsilk": "fff8dc",
  "crimson": "dc143c",
  "cyan": "0ff",
  "darkblue": "00008b",
  "darkcyan": "008b8b",
  "darkgoldenrod": "b8860b",
  "darkgray": "a9a9a9",
  "darkgrey": "a9a9a9",
  "darkgreen": "006400",
  "darkkhaki": "bdb76b",
  "darkmagenta": "8b008b",
  "darkolivegreen": "556b2f",
  "darkorange": "ff8c00",
  "darkorchid": "9932cc",
  "darkred": "8b0000",
  "darksalmon": "e9967a",
  "darkseagreen": "8fbc8f",
  "darkslateblue": "483d8b",
  "darkslategray": "2f4f4f",
  "darkslategrey": "2f4f4f",
  "darkturquoise": "00ced1",
  "darkviolet": "9400d3",
  "deeppink": "ff1493",
  "deepskyblue": "00bfff",
  "dimgray": "696969",
  "dimgrey": "696969",
  "dodgerblue": "1e90ff",
  "firebrick": "b22222",
  "floralwhite": "fffaf0",
  "forestgreen": "228b22",
  "fuchsia": "f0f",
  "gainsboro": "dcdcdc",
  "ghostwhite": "f8f8ff",
  "gold": "ffd700",
  "goldenrod": "daa520",
  "gray": "808080",
  "grey": "808080",
  "green": "008000",
  "greenyellow": "adff2f",
  "honeydew": "f0fff0",
  "hotpink": "ff69b4",
  "indianred": "cd5c5c",
  "indigo": "4b0082",
  "ivory": "fffff0",
  "khaki": "f0e68c",
  "lavender": "e6e6fa",
  "lavenderblush": "fff0f5",
  "lawngreen": "7cfc00",
  "lemonchiffon": "fffacd",
  "lightblue": "add8e6",
  "lightcoral": "f08080",
  "lightcyan": "e0ffff",
  "lightgoldenrodyellow": "fafad2",
  "lightgray": "d3d3d3",
  "lightgrey": "d3d3d3",
  "lightgreen": "90ee90",
  "lightpink": "ffb6c1",
  "lightsalmon": "ffa07a",
  "lightseagreen": "20b2aa",
  "lightskyblue": "87cefa",
  "lightslategray": "789",
  "lightslategrey": "789",
  "lightsteelblue": "b0c4de",
  "lightyellow": "ffffe0",
  "lime": "0f0",
  "limegreen": "32cd32",
  "linen": "faf0e6",
  "magenta": "f0f",
  "maroon": "800000",
  "mediumaquamarine": "66cdaa",
  "mediumblue": "0000cd",
  "mediumorchid": "ba55d3",
  "mediumpurple": "9370db",
  "mediumseagreen": "3cb371",
  "mediumslateblue": "7b68ee",
  "mediumspringgreen": "00fa9a",
  "mediumturquoise": "48d1cc",
  "mediumvioletred": "c71585",
  "midnightblue": "191970",
  "mintcream": "f5fffa",
  "mistyrose": "ffe4e1",
  "moccasin": "ffe4b5",
  "navajowhite": "ffdead",
  "navy": "000080",
  "oldlace": "fdf5e6",
  "olive": "808000",
  "olivedrab": "6b8e23",
  "orange": "ffa500",
  "orangered": "ff4500",
  "orchid": "da70d6",
  "palegoldenrod": "eee8aa",
  "palegreen": "98fb98",
  "paleturquoise": "afeeee",
  "palevioletred": "db7093",
  "papayawhip": "ffefd5",
  "peachpuff": "ffdab9",
  "peru": "cd853f",
  "pink": "ffc0cb",
  "plum": "dda0dd",
  "powderblue": "b0e0e6",
  "purple": "800080",
  "rebeccapurple": "639",
  "red": "f00",
  "rosybrown": "bc8f8f",
  "royalblue": "4169e1",
  "saddlebrown": "8b4513",
  "salmon": "fa8072",
  "sandybrown": "f4a460",
  "seagreen": "2e8b57",
  "seashell": "fff5ee",
  "sienna": "a0522d",
  "silver": "c0c0c0",
  "skyblue": "87ceeb",
  "slateblue": "6a5acd",
  "slategray": "708090",
  "slategrey": "708090",
  "snow": "fffafa",
  "springgreen": "00ff7f",
  "steelblue": "4682b4",
  "tan": "d2b48c",
  "teal": "008080",
  "thistle": "d8bfd8",
  "tomato": "ff6347",
  "turquoise": "40e0d0",
  "violet": "ee82ee",
  "wheat": "f5deb3",
  "white": "fff",
  "whitesmoke": "f5f5f5",
  "yellow": "ff0",
  "yellowgreen": "9acd32"
};
const HEX_TO_NAME = {
  "800000": "maroon",
  "800080": "purple",
  "808000": "olive",
  "808080": "gray",
  "00ffff": "cyan",
  "f0ffff": "azure",
  "f5f5dc": "beige",
  "ffe4c4": "bisque",
  "000000": "black",
  "0000ff": "blue",
  "a52a2a": "brown",
  "ff7f50": "coral",
  "ffd700": "gold",
  "008000": "green",
  "4b0082": "indigo",
  "fffff0": "ivory",
  "f0e68c": "khaki",
  "00ff00": "lime",
  "faf0e6": "linen",
  "000080": "navy",
  "ffa500": "orange",
  "da70d6": "orchid",
  "cd853f": "peru",
  "ffc0cb": "pink",
  "dda0dd": "plum",
  "f00": "red",
  "ff0000": "red",
  "fa8072": "salmon",
  "a0522d": "sienna",
  "c0c0c0": "silver",
  "fffafa": "snow",
  "d2b48c": "tan",
  "008080": "teal",
  "ff6347": "tomato",
  "ee82ee": "violet",
  "f5deb3": "wheat",
  "ffffff": "white",
  "ffff00": "yellow"
};
function hueToRgb(p, q, t) {
  if (t < 0) {
    t += 1;
  }
  if (t > 1) {
    t -= 1;
  }
  if (t < 1 / 6) {
    return p + (q - p) * 6 * t;
  }
  if (t < 1 / 2) {
    return q;
  }
  if (t < 2 / 3) {
    return p + (q - p) * (2 / 3 - t) * 6;
  }
  return p;
}
function hslToRgb(h, s, l, a) {
  let r;
  let g2;
  let b;
  if (s === 0) {
    r = g2 = b = l;
  } else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hueToRgb(p, q, h + 1 / 3);
    g2 = hueToRgb(p, q, h);
    b = hueToRgb(p, q, h - 1 / 3);
  }
  return [
    Math.round(r * 255),
    Math.round(g2 * 255),
    Math.round(b * 255),
    a
  ];
}
function toHex(value2) {
  value2 = value2.toString(16);
  return value2.length === 1 ? "0" + value2 : value2;
}
function parseFunctionArgs(functionArgs, count, rgb) {
  let cursor = functionArgs.head;
  let args = [];
  let wasValue = false;
  while (cursor !== null) {
    const { type, value: value2 } = cursor.data;
    switch (type) {
      case "Number":
      case "Percentage":
        if (wasValue) {
          return;
        }
        wasValue = true;
        args.push({
          type,
          value: Number(value2)
        });
        break;
      case "Operator":
        if (value2 === ",") {
          if (!wasValue) {
            return;
          }
          wasValue = false;
        } else if (wasValue || value2 !== "+") {
          return;
        }
        break;
      default:
        return;
    }
    cursor = cursor.next;
  }
  if (args.length !== count) {
    return;
  }
  if (args.length === 4) {
    if (args[3].type !== "Number") {
      return;
    }
    args[3].type = "Alpha";
  }
  if (rgb) {
    if (args[0].type !== args[1].type || args[0].type !== args[2].type) {
      return;
    }
  } else {
    if (args[0].type !== "Number" || args[1].type !== "Percentage" || args[2].type !== "Percentage") {
      return;
    }
    args[0].type = "Angle";
  }
  return args.map(function(arg) {
    let value2 = Math.max(0, arg.value);
    switch (arg.type) {
      case "Number":
        value2 = Math.min(value2, 255);
        break;
      case "Percentage":
        value2 = Math.min(value2, 100) / 100;
        if (!rgb) {
          return value2;
        }
        value2 = 255 * value2;
        break;
      case "Angle":
        return (value2 % 360 + 360) % 360 / 360;
      case "Alpha":
        return Math.min(value2, 1);
    }
    return Math.round(value2);
  });
}
function compressFunction(node2, item) {
  let functionName = node2.name;
  let args;
  if (functionName === "rgba" || functionName === "hsla") {
    args = parseFunctionArgs(node2.children, 4, functionName === "rgba");
    if (!args) {
      return;
    }
    if (functionName === "hsla") {
      args = hslToRgb(...args);
      node2.name = "rgba";
    }
    if (args[3] === 0) {
      const scopeFunctionName = this.function && this.function.name;
      if (args[0] === 0 && args[1] === 0 && args[2] === 0 || !/^(?:to|from|color-stop)$|gradient$/i.test(scopeFunctionName)) {
        item.data = {
          type: "Identifier",
          loc: node2.loc,
          name: "transparent"
        };
        return;
      }
    }
    if (args[3] !== 1) {
      node2.children.forEach((node3, item2, list) => {
        if (node3.type === "Operator") {
          if (node3.value !== ",") {
            list.remove(item2);
          }
          return;
        }
        item2.data = {
          type: "Number",
          loc: node3.loc,
          value: _Number$1.packNumber(args.shift())
        };
      });
      return;
    }
    functionName = "rgb";
  }
  if (functionName === "hsl") {
    args = args || parseFunctionArgs(node2.children, 3, false);
    if (!args) {
      return;
    }
    args = hslToRgb(...args);
    functionName = "rgb";
  }
  if (functionName === "rgb") {
    args = args || parseFunctionArgs(node2.children, 3, true);
    if (!args) {
      return;
    }
    item.data = {
      type: "Hash",
      loc: node2.loc,
      value: toHex(args[0]) + toHex(args[1]) + toHex(args[2])
    };
    compressHex(item.data, item);
  }
}
function compressIdent(node2, item) {
  if (this.declaration === null) {
    return;
  }
  let color2 = node2.name.toLowerCase();
  if (NAME_TO_HEX.hasOwnProperty(color2) && cssTree$e.lexer.matchDeclaration(this.declaration).isType(node2, "color")) {
    const hex = NAME_TO_HEX[color2];
    if (hex.length + 1 <= color2.length) {
      item.data = {
        type: "Hash",
        loc: node2.loc,
        value: hex
      };
    } else {
      if (color2 === "grey") {
        color2 = "gray";
      }
      node2.name = color2;
    }
  }
}
function compressHex(node2, item) {
  let color2 = node2.value.toLowerCase();
  if (color2.length === 6 && color2[0] === color2[1] && color2[2] === color2[3] && color2[4] === color2[5]) {
    color2 = color2[0] + color2[2] + color2[4];
  }
  if (HEX_TO_NAME[color2]) {
    item.data = {
      type: "Identifier",
      loc: node2.loc,
      name: HEX_TO_NAME[color2]
    };
  } else {
    node2.value = color2;
  }
}
color$1.compressFunction = compressFunction;
color$1.compressHex = compressHex;
color$1.compressIdent = compressIdent;
const cssTree$d = cjs$1;
const Atrule = Atrule_1;
const AttributeSelector = AttributeSelector_1;
const Value = Value$1;
const Dimension = Dimension$1;
const Percentage = Percentage$1;
const _Number = _Number$4;
const Url = Url_1;
const color = color$1;
const handlers = {
  Atrule,
  AttributeSelector,
  Value,
  Dimension,
  Percentage,
  Number: _Number.Number,
  Url,
  Hash: color.compressHex,
  Identifier: color.compressIdent,
  Function: color.compressFunction
};
function replace(ast) {
  cssTree$d.walk(ast, {
    leave(node2, item, list) {
      if (handlers.hasOwnProperty(node2.type)) {
        handlers[node2.type].call(this, node2, item, list);
      }
    }
  });
}
var replace_1 = replace;
const cssTree$c = cjs$1;
class Index {
  constructor() {
    this.map = /* @__PURE__ */ new Map();
  }
  resolve(str) {
    let index2 = this.map.get(str);
    if (index2 === void 0) {
      index2 = this.map.size + 1;
      this.map.set(str, index2);
    }
    return index2;
  }
}
function createDeclarationIndexer$1() {
  const ids = new Index();
  return function markDeclaration(node2) {
    const id = cssTree$c.generate(node2);
    node2.id = ids.resolve(id);
    node2.length = id.length;
    node2.fingerprint = null;
    return node2;
  };
}
var createDeclarationIndexer_1 = createDeclarationIndexer$1;
const cssTree$b = cjs$1;
function ensureSelectorList(node2) {
  if (node2.type === "Raw") {
    return cssTree$b.parse(node2.value, { context: "selectorList" });
  }
  return node2;
}
function maxSpecificity(a, b) {
  for (let i = 0; i < 3; i++) {
    if (a[i] !== b[i]) {
      return a[i] > b[i] ? a : b;
    }
  }
  return a;
}
function maxSelectorListSpecificity(selectorList2) {
  return ensureSelectorList(selectorList2).children.reduce(
    (result, node2) => maxSpecificity(specificity$4(node2), result),
    [0, 0, 0]
  );
}
function specificity$4(simpleSelector) {
  let A = 0;
  let B = 0;
  let C = 0;
  simpleSelector.children.forEach((node2) => {
    switch (node2.type) {
      case "IdSelector":
        A++;
        break;
      case "ClassSelector":
      case "AttributeSelector":
        B++;
        break;
      case "PseudoClassSelector":
        switch (node2.name.toLowerCase()) {
          case "not":
          case "has":
          case "is":
          case "matches":
          case "-webkit-any":
          case "-moz-any": {
            const [a, b, c] = maxSelectorListSpecificity(node2.children.first);
            A += a;
            B += b;
            C += c;
            break;
          }
          case "nth-child":
          case "nth-last-child": {
            const arg = node2.children.first;
            if (arg.type === "Nth" && arg.selector) {
              const [a, b, c] = maxSelectorListSpecificity(arg.selector);
              A += a;
              B += b + 1;
              C += c;
            } else {
              B++;
            }
            break;
          }
          case "where":
            break;
          case "before":
          case "after":
          case "first-line":
          case "first-letter":
            C++;
            break;
          default:
            B++;
        }
        break;
      case "TypeSelector":
        if (!node2.name.endsWith("*")) {
          C++;
        }
        break;
      case "PseudoElementSelector":
        C++;
        break;
    }
  });
  return [A, B, C];
}
var specificity_1 = specificity$4;
const cssTree$a = cjs$1;
const specificity$3 = specificity_1;
const nonFreezePseudoElements = /* @__PURE__ */ new Set([
  "first-letter",
  "first-line",
  "after",
  "before"
]);
const nonFreezePseudoClasses = /* @__PURE__ */ new Set([
  "link",
  "visited",
  "hover",
  "active",
  "first-letter",
  "first-line",
  "after",
  "before"
]);
function processSelector$2(node2, usageData) {
  const pseudos2 = /* @__PURE__ */ new Set();
  node2.prelude.children.forEach(function(simpleSelector) {
    let tagName = "*";
    let scope2 = 0;
    simpleSelector.children.forEach(function(node3) {
      switch (node3.type) {
        case "ClassSelector":
          if (usageData && usageData.scopes) {
            const classScope = usageData.scopes[node3.name] || 0;
            if (scope2 !== 0 && classScope !== scope2) {
              throw new Error("Selector can't has classes from different scopes: " + cssTree$a.generate(simpleSelector));
            }
            scope2 = classScope;
          }
          break;
        case "PseudoClassSelector": {
          const name2 = node3.name.toLowerCase();
          if (!nonFreezePseudoClasses.has(name2)) {
            pseudos2.add(`:${name2}`);
          }
          break;
        }
        case "PseudoElementSelector": {
          const name2 = node3.name.toLowerCase();
          if (!nonFreezePseudoElements.has(name2)) {
            pseudos2.add(`::${name2}`);
          }
          break;
        }
        case "TypeSelector":
          tagName = node3.name.toLowerCase();
          break;
        case "AttributeSelector":
          if (node3.flags) {
            pseudos2.add(`[${node3.flags.toLowerCase()}]`);
          }
          break;
        case "Combinator":
          tagName = "*";
          break;
      }
    });
    simpleSelector.compareMarker = specificity$3(simpleSelector).toString();
    simpleSelector.id = null;
    simpleSelector.id = cssTree$a.generate(simpleSelector);
    if (scope2) {
      simpleSelector.compareMarker += ":" + scope2;
    }
    if (tagName !== "*") {
      simpleSelector.compareMarker += "," + tagName;
    }
  });
  node2.pseudoSignature = pseudos2.size > 0 ? [...pseudos2].sort().join(",") : false;
}
var processSelector_1 = processSelector$2;
const cssTree$9 = cjs$1;
const createDeclarationIndexer = createDeclarationIndexer_1;
const processSelector$1 = processSelector_1;
function prepare(ast, options) {
  const markDeclaration = createDeclarationIndexer();
  cssTree$9.walk(ast, {
    visit: "Rule",
    enter(node2) {
      node2.block.children.forEach(markDeclaration);
      processSelector$1(node2, options.usage);
    }
  });
  cssTree$9.walk(ast, {
    visit: "Atrule",
    enter(node2) {
      if (node2.prelude) {
        node2.prelude.id = null;
        node2.prelude.id = cssTree$9.generate(node2.prelude);
      }
      if (cssTree$9.keyword(node2.name).basename === "keyframes") {
        node2.block.avoidRulesMerge = true;
        node2.block.children.forEach(function(rule) {
          rule.prelude.children.forEach(function(simpleselector) {
            simpleselector.compareMarker = simpleselector.id;
          });
        });
      }
    }
  });
  return {
    declaration: markDeclaration
  };
}
var prepare_1 = prepare;
const cssTree$8 = cjs$1;
const { hasOwnProperty: hasOwnProperty$2 } = Object.prototype;
function addRuleToMap(map, item, list, single) {
  const node2 = item.data;
  const name2 = cssTree$8.keyword(node2.name).basename;
  const id = node2.name.toLowerCase() + "/" + (node2.prelude ? node2.prelude.id : null);
  if (!hasOwnProperty$2.call(map, name2)) {
    map[name2] = /* @__PURE__ */ Object.create(null);
  }
  if (single) {
    delete map[name2][id];
  }
  if (!hasOwnProperty$2.call(map[name2], id)) {
    map[name2][id] = new cssTree$8.List();
  }
  map[name2][id].append(list.remove(item));
}
function relocateAtrules(ast, options) {
  const collected = /* @__PURE__ */ Object.create(null);
  let topInjectPoint = null;
  ast.children.forEach(function(node2, item, list) {
    if (node2.type === "Atrule") {
      const name2 = cssTree$8.keyword(node2.name).basename;
      switch (name2) {
        case "keyframes":
          addRuleToMap(collected, item, list, true);
          return;
        case "media":
          if (options.forceMediaMerge) {
            addRuleToMap(collected, item, list, false);
            return;
          }
          break;
      }
      if (topInjectPoint === null && name2 !== "charset" && name2 !== "import") {
        topInjectPoint = item;
      }
    } else {
      if (topInjectPoint === null) {
        topInjectPoint = item;
      }
    }
  });
  for (const atrule2 in collected) {
    for (const id in collected[atrule2]) {
      ast.children.insertList(
        collected[atrule2][id],
        atrule2 === "media" ? null : topInjectPoint
      );
    }
  }
}
function isMediaRule(node2) {
  return node2.type === "Atrule" && node2.name === "media";
}
function processAtrule(node2, item, list) {
  if (!isMediaRule(node2)) {
    return;
  }
  const prev = item.prev && item.prev.data;
  if (!prev || !isMediaRule(prev)) {
    return;
  }
  if (node2.prelude && prev.prelude && node2.prelude.id === prev.prelude.id) {
    prev.block.children.appendList(node2.block.children);
    list.remove(item);
  }
}
function rejoinAtrule(ast, options) {
  relocateAtrules(ast, options);
  cssTree$8.walk(ast, {
    visit: "Atrule",
    reverse: true,
    enter: processAtrule
  });
}
var _1MergeAtrule$1 = rejoinAtrule;
var utils$6 = {};
const { hasOwnProperty: hasOwnProperty$1 } = Object.prototype;
function isEqualSelectors(a, b) {
  let cursor1 = a.head;
  let cursor2 = b.head;
  while (cursor1 !== null && cursor2 !== null && cursor1.data.id === cursor2.data.id) {
    cursor1 = cursor1.next;
    cursor2 = cursor2.next;
  }
  return cursor1 === null && cursor2 === null;
}
function isEqualDeclarations(a, b) {
  let cursor1 = a.head;
  let cursor2 = b.head;
  while (cursor1 !== null && cursor2 !== null && cursor1.data.id === cursor2.data.id) {
    cursor1 = cursor1.next;
    cursor2 = cursor2.next;
  }
  return cursor1 === null && cursor2 === null;
}
function compareDeclarations(declarations1, declarations2) {
  const result = {
    eq: [],
    ne1: [],
    ne2: [],
    ne2overrided: []
  };
  const fingerprints = /* @__PURE__ */ Object.create(null);
  const declarations2hash = /* @__PURE__ */ Object.create(null);
  for (let cursor = declarations2.head; cursor; cursor = cursor.next) {
    declarations2hash[cursor.data.id] = true;
  }
  for (let cursor = declarations1.head; cursor; cursor = cursor.next) {
    const data2 = cursor.data;
    if (data2.fingerprint) {
      fingerprints[data2.fingerprint] = data2.important;
    }
    if (declarations2hash[data2.id]) {
      declarations2hash[data2.id] = false;
      result.eq.push(data2);
    } else {
      result.ne1.push(data2);
    }
  }
  for (let cursor = declarations2.head; cursor; cursor = cursor.next) {
    const data2 = cursor.data;
    if (declarations2hash[data2.id]) {
      if (!hasOwnProperty$1.call(fingerprints, data2.fingerprint) || !fingerprints[data2.fingerprint] && data2.important) {
        result.ne2.push(data2);
      }
      result.ne2overrided.push(data2);
    }
  }
  return result;
}
function addSelectors(dest, source) {
  source.forEach((sourceData) => {
    const newStr = sourceData.id;
    let cursor = dest.head;
    while (cursor) {
      const nextStr = cursor.data.id;
      if (nextStr === newStr) {
        return;
      }
      if (nextStr > newStr) {
        break;
      }
      cursor = cursor.next;
    }
    dest.insert(dest.createItem(sourceData), cursor);
  });
  return dest;
}
function hasSimilarSelectors(selectors1, selectors2) {
  let cursor1 = selectors1.head;
  while (cursor1 !== null) {
    let cursor2 = selectors2.head;
    while (cursor2 !== null) {
      if (cursor1.data.compareMarker === cursor2.data.compareMarker) {
        return true;
      }
      cursor2 = cursor2.next;
    }
    cursor1 = cursor1.next;
  }
  return false;
}
function unsafeToSkipNode(node2) {
  switch (node2.type) {
    case "Rule":
      return hasSimilarSelectors(node2.prelude.children, this);
    case "Atrule":
      if (node2.block) {
        return node2.block.children.some(unsafeToSkipNode, this);
      }
      break;
    case "Declaration":
      return false;
  }
  return true;
}
utils$6.addSelectors = addSelectors;
utils$6.compareDeclarations = compareDeclarations;
utils$6.hasSimilarSelectors = hasSimilarSelectors;
utils$6.isEqualDeclarations = isEqualDeclarations;
utils$6.isEqualSelectors = isEqualSelectors;
utils$6.unsafeToSkipNode = unsafeToSkipNode;
const cssTree$7 = cjs$1;
const utils$5 = utils$6;
function processRule$5(node2, item, list) {
  const selectors = node2.prelude.children;
  const declarations = node2.block.children;
  list.prevUntil(item.prev, function(prev) {
    if (prev.type !== "Rule") {
      return utils$5.unsafeToSkipNode.call(selectors, prev);
    }
    const prevSelectors = prev.prelude.children;
    const prevDeclarations = prev.block.children;
    if (node2.pseudoSignature === prev.pseudoSignature) {
      if (utils$5.isEqualSelectors(prevSelectors, selectors)) {
        prevDeclarations.appendList(declarations);
        list.remove(item);
        return true;
      }
      if (utils$5.isEqualDeclarations(declarations, prevDeclarations)) {
        utils$5.addSelectors(prevSelectors, selectors);
        list.remove(item);
        return true;
      }
    }
    return utils$5.hasSimilarSelectors(selectors, prevSelectors);
  });
}
function initialMergeRule(ast) {
  cssTree$7.walk(ast, {
    visit: "Rule",
    enter: processRule$5
  });
}
var _2InitialMergeRuleset$1 = initialMergeRule;
const cssTree$6 = cjs$1;
function processRule$4(node2, item, list) {
  const selectors = node2.prelude.children;
  while (selectors.head !== selectors.tail) {
    const newSelectors = new cssTree$6.List();
    newSelectors.insert(selectors.remove(selectors.head));
    list.insert(list.createItem({
      type: "Rule",
      loc: node2.loc,
      prelude: {
        type: "SelectorList",
        loc: node2.prelude.loc,
        children: newSelectors
      },
      block: {
        type: "Block",
        loc: node2.block.loc,
        children: node2.block.children.copy()
      },
      pseudoSignature: node2.pseudoSignature
    }), item);
  }
}
function disjoinRule(ast) {
  cssTree$6.walk(ast, {
    visit: "Rule",
    reverse: true,
    enter: processRule$4
  });
}
var _3DisjoinRuleset$1 = disjoinRule;
const cssTree$5 = cjs$1;
const REPLACE = 1;
const REMOVE = 2;
const TOP = 0;
const RIGHT = 1;
const BOTTOM = 2;
const LEFT = 3;
const SIDES = ["top", "right", "bottom", "left"];
const SIDE = {
  "margin-top": "top",
  "margin-right": "right",
  "margin-bottom": "bottom",
  "margin-left": "left",
  "padding-top": "top",
  "padding-right": "right",
  "padding-bottom": "bottom",
  "padding-left": "left",
  "border-top-color": "top",
  "border-right-color": "right",
  "border-bottom-color": "bottom",
  "border-left-color": "left",
  "border-top-width": "top",
  "border-right-width": "right",
  "border-bottom-width": "bottom",
  "border-left-width": "left",
  "border-top-style": "top",
  "border-right-style": "right",
  "border-bottom-style": "bottom",
  "border-left-style": "left"
};
const MAIN_PROPERTY = {
  "margin": "margin",
  "margin-top": "margin",
  "margin-right": "margin",
  "margin-bottom": "margin",
  "margin-left": "margin",
  "padding": "padding",
  "padding-top": "padding",
  "padding-right": "padding",
  "padding-bottom": "padding",
  "padding-left": "padding",
  "border-color": "border-color",
  "border-top-color": "border-color",
  "border-right-color": "border-color",
  "border-bottom-color": "border-color",
  "border-left-color": "border-color",
  "border-width": "border-width",
  "border-top-width": "border-width",
  "border-right-width": "border-width",
  "border-bottom-width": "border-width",
  "border-left-width": "border-width",
  "border-style": "border-style",
  "border-top-style": "border-style",
  "border-right-style": "border-style",
  "border-bottom-style": "border-style",
  "border-left-style": "border-style"
};
class TRBL {
  constructor(name2) {
    this.name = name2;
    this.loc = null;
    this.iehack = void 0;
    this.sides = {
      "top": null,
      "right": null,
      "bottom": null,
      "left": null
    };
  }
  getValueSequence(declaration, count) {
    const values = [];
    let iehack = "";
    const hasBadValues = declaration.value.type !== "Value" || declaration.value.children.some(function(child) {
      let special = false;
      switch (child.type) {
        case "Identifier":
          switch (child.name) {
            case "\\0":
            case "\\9":
              iehack = child.name;
              return;
            case "inherit":
            case "initial":
            case "unset":
            case "revert":
              special = child.name;
              break;
          }
          break;
        case "Dimension":
          switch (child.unit) {
            case "rem":
            case "vw":
            case "vh":
            case "vmin":
            case "vmax":
            case "vm":
              special = child.unit;
              break;
          }
          break;
        case "Hash":
        case "Number":
        case "Percentage":
          break;
        case "Function":
          if (child.name === "var") {
            return true;
          }
          special = child.name;
          break;
        default:
          return true;
      }
      values.push({
        node: child,
        special,
        important: declaration.important
      });
    });
    if (hasBadValues || values.length > count) {
      return false;
    }
    if (typeof this.iehack === "string" && this.iehack !== iehack) {
      return false;
    }
    this.iehack = iehack;
    return values;
  }
  canOverride(side, value2) {
    const currentValue = this.sides[side];
    return !currentValue || value2.important && !currentValue.important;
  }
  add(name2, declaration) {
    function attemptToAdd() {
      const sides = this.sides;
      const side = SIDE[name2];
      if (side) {
        if (side in sides === false) {
          return false;
        }
        const values = this.getValueSequence(declaration, 1);
        if (!values || !values.length) {
          return false;
        }
        for (const key in sides) {
          if (sides[key] !== null && sides[key].special !== values[0].special) {
            return false;
          }
        }
        if (!this.canOverride(side, values[0])) {
          return true;
        }
        sides[side] = values[0];
        return true;
      } else if (name2 === this.name) {
        const values = this.getValueSequence(declaration, 4);
        if (!values || !values.length) {
          return false;
        }
        switch (values.length) {
          case 1:
            values[RIGHT] = values[TOP];
            values[BOTTOM] = values[TOP];
            values[LEFT] = values[TOP];
            break;
          case 2:
            values[BOTTOM] = values[TOP];
            values[LEFT] = values[RIGHT];
            break;
          case 3:
            values[LEFT] = values[RIGHT];
            break;
        }
        for (let i = 0; i < 4; i++) {
          for (const key in sides) {
            if (sides[key] !== null && sides[key].special !== values[i].special) {
              return false;
            }
          }
        }
        for (let i = 0; i < 4; i++) {
          if (this.canOverride(SIDES[i], values[i])) {
            sides[SIDES[i]] = values[i];
          }
        }
        return true;
      }
    }
    if (!attemptToAdd.call(this)) {
      return false;
    }
    if (!this.loc) {
      this.loc = declaration.loc;
    }
    return true;
  }
  isOkToMinimize() {
    const top = this.sides.top;
    const right = this.sides.right;
    const bottom = this.sides.bottom;
    const left = this.sides.left;
    if (top && right && bottom && left) {
      const important = top.important + right.important + bottom.important + left.important;
      return important === 0 || important === 4;
    }
    return false;
  }
  getValue() {
    const result = new cssTree$5.List();
    const sides = this.sides;
    const values = [
      sides.top,
      sides.right,
      sides.bottom,
      sides.left
    ];
    const stringValues = [
      cssTree$5.generate(sides.top.node),
      cssTree$5.generate(sides.right.node),
      cssTree$5.generate(sides.bottom.node),
      cssTree$5.generate(sides.left.node)
    ];
    if (stringValues[LEFT] === stringValues[RIGHT]) {
      values.pop();
      if (stringValues[BOTTOM] === stringValues[TOP]) {
        values.pop();
        if (stringValues[RIGHT] === stringValues[TOP]) {
          values.pop();
        }
      }
    }
    for (let i = 0; i < values.length; i++) {
      result.appendData(values[i].node);
    }
    if (this.iehack) {
      result.appendData({
        type: "Identifier",
        loc: null,
        name: this.iehack
      });
    }
    return {
      type: "Value",
      loc: null,
      children: result
    };
  }
  getDeclaration() {
    return {
      type: "Declaration",
      loc: this.loc,
      important: this.sides.top.important,
      property: this.name,
      value: this.getValue()
    };
  }
}
function processRule$3(rule, shorts, shortDeclarations, lastShortSelector) {
  const declarations = rule.block.children;
  const selector2 = rule.prelude.children.first.id;
  rule.block.children.forEachRight(function(declaration, item) {
    const property2 = declaration.property;
    if (!MAIN_PROPERTY.hasOwnProperty(property2)) {
      return;
    }
    const key = MAIN_PROPERTY[property2];
    let shorthand;
    let operation;
    if (!lastShortSelector || selector2 === lastShortSelector) {
      if (key in shorts) {
        operation = REMOVE;
        shorthand = shorts[key];
      }
    }
    if (!shorthand || !shorthand.add(property2, declaration)) {
      operation = REPLACE;
      shorthand = new TRBL(key);
      if (!shorthand.add(property2, declaration)) {
        lastShortSelector = null;
        return;
      }
    }
    shorts[key] = shorthand;
    shortDeclarations.push({
      operation,
      block: declarations,
      item,
      shorthand
    });
    lastShortSelector = selector2;
  });
  return lastShortSelector;
}
function processShorthands(shortDeclarations, markDeclaration) {
  shortDeclarations.forEach(function(item) {
    const shorthand = item.shorthand;
    if (!shorthand.isOkToMinimize()) {
      return;
    }
    if (item.operation === REPLACE) {
      item.item.data = markDeclaration(shorthand.getDeclaration());
    } else {
      item.block.remove(item.item);
    }
  });
}
function restructBlock$1(ast, indexer) {
  const stylesheetMap = {};
  const shortDeclarations = [];
  cssTree$5.walk(ast, {
    visit: "Rule",
    reverse: true,
    enter(node2) {
      const stylesheet = this.block || this.stylesheet;
      const ruleId = (node2.pseudoSignature || "") + "|" + node2.prelude.children.first.id;
      let ruleMap;
      let shorts;
      if (!stylesheetMap.hasOwnProperty(stylesheet.id)) {
        ruleMap = {
          lastShortSelector: null
        };
        stylesheetMap[stylesheet.id] = ruleMap;
      } else {
        ruleMap = stylesheetMap[stylesheet.id];
      }
      if (ruleMap.hasOwnProperty(ruleId)) {
        shorts = ruleMap[ruleId];
      } else {
        shorts = {};
        ruleMap[ruleId] = shorts;
      }
      ruleMap.lastShortSelector = processRule$3.call(this, node2, shorts, shortDeclarations, ruleMap.lastShortSelector);
    }
  });
  processShorthands(shortDeclarations, indexer.declaration);
}
var _4RestructShorthand$1 = restructBlock$1;
const cssTree$4 = cjs$1;
let fingerprintId = 1;
const dontRestructure = /* @__PURE__ */ new Set([
  "src"
]);
const DONT_MIX_VALUE = {
  "display": /table|ruby|flex|-(flex)?box$|grid|contents|run-in/i,
  "text-align": /^(start|end|match-parent|justify-all)$/i
};
const SAFE_VALUES = {
  cursor: [
    "auto",
    "crosshair",
    "default",
    "move",
    "text",
    "wait",
    "help",
    "n-resize",
    "e-resize",
    "s-resize",
    "w-resize",
    "ne-resize",
    "nw-resize",
    "se-resize",
    "sw-resize",
    "pointer",
    "progress",
    "not-allowed",
    "no-drop",
    "vertical-text",
    "all-scroll",
    "col-resize",
    "row-resize"
  ],
  overflow: [
    "hidden",
    "visible",
    "scroll",
    "auto"
  ],
  position: [
    "static",
    "relative",
    "absolute",
    "fixed"
  ]
};
const NEEDLESS_TABLE = {
  "border-width": ["border"],
  "border-style": ["border"],
  "border-color": ["border"],
  "border-top": ["border"],
  "border-right": ["border"],
  "border-bottom": ["border"],
  "border-left": ["border"],
  "border-top-width": ["border-top", "border-width", "border"],
  "border-right-width": ["border-right", "border-width", "border"],
  "border-bottom-width": ["border-bottom", "border-width", "border"],
  "border-left-width": ["border-left", "border-width", "border"],
  "border-top-style": ["border-top", "border-style", "border"],
  "border-right-style": ["border-right", "border-style", "border"],
  "border-bottom-style": ["border-bottom", "border-style", "border"],
  "border-left-style": ["border-left", "border-style", "border"],
  "border-top-color": ["border-top", "border-color", "border"],
  "border-right-color": ["border-right", "border-color", "border"],
  "border-bottom-color": ["border-bottom", "border-color", "border"],
  "border-left-color": ["border-left", "border-color", "border"],
  "margin-top": ["margin"],
  "margin-right": ["margin"],
  "margin-bottom": ["margin"],
  "margin-left": ["margin"],
  "padding-top": ["padding"],
  "padding-right": ["padding"],
  "padding-bottom": ["padding"],
  "padding-left": ["padding"],
  "font-style": ["font"],
  "font-variant": ["font"],
  "font-weight": ["font"],
  "font-size": ["font"],
  "font-family": ["font"],
  "list-style-type": ["list-style"],
  "list-style-position": ["list-style"],
  "list-style-image": ["list-style"]
};
function getPropertyFingerprint(propertyName, declaration, fingerprints) {
  const realName = cssTree$4.property(propertyName).basename;
  if (realName === "background") {
    return propertyName + ":" + cssTree$4.generate(declaration.value);
  }
  const declarationId = declaration.id;
  let fingerprint = fingerprints[declarationId];
  if (!fingerprint) {
    switch (declaration.value.type) {
      case "Value":
        const special = {};
        let vendorId = "";
        let iehack = "";
        let raw = false;
        declaration.value.children.forEach(function walk2(node2) {
          switch (node2.type) {
            case "Value":
            case "Brackets":
            case "Parentheses":
              node2.children.forEach(walk2);
              break;
            case "Raw":
              raw = true;
              break;
            case "Identifier": {
              const { name: name2 } = node2;
              if (!vendorId) {
                vendorId = cssTree$4.keyword(name2).vendor;
              }
              if (/\\[09]/.test(name2)) {
                iehack = RegExp.lastMatch;
              }
              if (SAFE_VALUES.hasOwnProperty(realName)) {
                if (SAFE_VALUES[realName].indexOf(name2) === -1) {
                  special[name2] = true;
                }
              } else if (DONT_MIX_VALUE.hasOwnProperty(realName)) {
                if (DONT_MIX_VALUE[realName].test(name2)) {
                  special[name2] = true;
                }
              }
              break;
            }
            case "Function": {
              let { name: name2 } = node2;
              if (!vendorId) {
                vendorId = cssTree$4.keyword(name2).vendor;
              }
              if (name2 === "rect") {
                const hasComma = node2.children.some(
                  (node3) => node3.type === "Operator" && node3.value === ","
                );
                if (!hasComma) {
                  name2 = "rect-backward";
                }
              }
              special[name2 + "()"] = true;
              node2.children.forEach(walk2);
              break;
            }
            case "Dimension": {
              const { unit } = node2;
              if (/\\[09]/.test(unit)) {
                iehack = RegExp.lastMatch;
              }
              switch (unit) {
                case "rem":
                case "vw":
                case "vh":
                case "vmin":
                case "vmax":
                case "vm":
                  special[unit] = true;
                  break;
              }
              break;
            }
          }
        });
        fingerprint = raw ? "!" + fingerprintId++ : "!" + Object.keys(special).sort() + "|" + iehack + vendorId;
        break;
      case "Raw":
        fingerprint = "!" + declaration.value.value;
        break;
      default:
        fingerprint = cssTree$4.generate(declaration.value);
    }
    fingerprints[declarationId] = fingerprint;
  }
  return propertyName + fingerprint;
}
function needless(props, declaration, fingerprints) {
  const property2 = cssTree$4.property(declaration.property);
  if (NEEDLESS_TABLE.hasOwnProperty(property2.basename)) {
    const table = NEEDLESS_TABLE[property2.basename];
    for (const entry of table) {
      const ppre = getPropertyFingerprint(property2.prefix + entry, declaration, fingerprints);
      const prev = props.hasOwnProperty(ppre) ? props[ppre] : null;
      if (prev && (!declaration.important || prev.item.data.important)) {
        return prev;
      }
    }
  }
}
function processRule$2(rule, item, list, props, fingerprints) {
  const declarations = rule.block.children;
  declarations.forEachRight(function(declaration, declarationItem) {
    const { property: property2 } = declaration;
    const fingerprint = getPropertyFingerprint(property2, declaration, fingerprints);
    const prev = props[fingerprint];
    if (prev && !dontRestructure.has(property2)) {
      if (declaration.important && !prev.item.data.important) {
        props[fingerprint] = {
          block: declarations,
          item: declarationItem
        };
        prev.block.remove(prev.item);
      } else {
        declarations.remove(declarationItem);
      }
    } else {
      const prev2 = needless(props, declaration, fingerprints);
      if (prev2) {
        declarations.remove(declarationItem);
      } else {
        declaration.fingerprint = fingerprint;
        props[fingerprint] = {
          block: declarations,
          item: declarationItem
        };
      }
    }
  });
  if (declarations.isEmpty) {
    list.remove(item);
  }
}
function restructBlock(ast) {
  const stylesheetMap = {};
  const fingerprints = /* @__PURE__ */ Object.create(null);
  cssTree$4.walk(ast, {
    visit: "Rule",
    reverse: true,
    enter(node2, item, list) {
      const stylesheet = this.block || this.stylesheet;
      const ruleId = (node2.pseudoSignature || "") + "|" + node2.prelude.children.first.id;
      let ruleMap;
      let props;
      if (!stylesheetMap.hasOwnProperty(stylesheet.id)) {
        ruleMap = {};
        stylesheetMap[stylesheet.id] = ruleMap;
      } else {
        ruleMap = stylesheetMap[stylesheet.id];
      }
      if (ruleMap.hasOwnProperty(ruleId)) {
        props = ruleMap[ruleId];
      } else {
        props = {};
        ruleMap[ruleId] = props;
      }
      processRule$2.call(this, node2, item, list, props, fingerprints);
    }
  });
}
var _6RestructBlock$1 = restructBlock;
const cssTree$3 = cjs$1;
const utils$4 = utils$6;
function processRule$1(node2, item, list) {
  const selectors = node2.prelude.children;
  const declarations = node2.block.children;
  const nodeCompareMarker = selectors.first.compareMarker;
  const skippedCompareMarkers = {};
  list.nextUntil(item.next, function(next, nextItem) {
    if (next.type !== "Rule") {
      return utils$4.unsafeToSkipNode.call(selectors, next);
    }
    if (node2.pseudoSignature !== next.pseudoSignature) {
      return true;
    }
    const nextFirstSelector = next.prelude.children.head;
    const nextDeclarations = next.block.children;
    const nextCompareMarker = nextFirstSelector.data.compareMarker;
    if (nextCompareMarker in skippedCompareMarkers) {
      return true;
    }
    if (selectors.head === selectors.tail) {
      if (selectors.first.id === nextFirstSelector.data.id) {
        declarations.appendList(nextDeclarations);
        list.remove(nextItem);
        return;
      }
    }
    if (utils$4.isEqualDeclarations(declarations, nextDeclarations)) {
      const nextStr = nextFirstSelector.data.id;
      selectors.some((data2, item2) => {
        const curStr = data2.id;
        if (nextStr < curStr) {
          selectors.insert(nextFirstSelector, item2);
          return true;
        }
        if (!item2.next) {
          selectors.insert(nextFirstSelector);
          return true;
        }
      });
      list.remove(nextItem);
      return;
    }
    if (nextCompareMarker === nodeCompareMarker) {
      return true;
    }
    skippedCompareMarkers[nextCompareMarker] = true;
  });
}
function mergeRule(ast) {
  cssTree$3.walk(ast, {
    visit: "Rule",
    enter: processRule$1
  });
}
var _7MergeRuleset$1 = mergeRule;
const cssTree$2 = cjs$1;
const utils$3 = utils$6;
function calcSelectorLength(list) {
  return list.reduce((res, data2) => res + data2.id.length + 1, 0) - 1;
}
function calcDeclarationsLength(tokens) {
  let length = 0;
  for (const token of tokens) {
    length += token.length;
  }
  return length + tokens.length - 1;
}
function processRule(node2, item, list) {
  const avoidRulesMerge = this.block !== null ? this.block.avoidRulesMerge : false;
  const selectors = node2.prelude.children;
  const block = node2.block;
  const disallowDownMarkers = /* @__PURE__ */ Object.create(null);
  let allowMergeUp = true;
  let allowMergeDown = true;
  list.prevUntil(item.prev, function(prev, prevItem) {
    const prevBlock = prev.block;
    const prevType = prev.type;
    if (prevType !== "Rule") {
      const unsafe = utils$3.unsafeToSkipNode.call(selectors, prev);
      if (!unsafe && prevType === "Atrule" && prevBlock) {
        cssTree$2.walk(prevBlock, {
          visit: "Rule",
          enter(node3) {
            node3.prelude.children.forEach((data2) => {
              disallowDownMarkers[data2.compareMarker] = true;
            });
          }
        });
      }
      return unsafe;
    }
    if (node2.pseudoSignature !== prev.pseudoSignature) {
      return true;
    }
    const prevSelectors = prev.prelude.children;
    allowMergeDown = !prevSelectors.some(
      (selector2) => selector2.compareMarker in disallowDownMarkers
    );
    if (!allowMergeDown && !allowMergeUp) {
      return true;
    }
    if (allowMergeUp && utils$3.isEqualSelectors(prevSelectors, selectors)) {
      prevBlock.children.appendList(block.children);
      list.remove(item);
      return true;
    }
    const diff = utils$3.compareDeclarations(block.children, prevBlock.children);
    if (diff.eq.length) {
      if (!diff.ne1.length && !diff.ne2.length) {
        if (allowMergeDown) {
          utils$3.addSelectors(selectors, prevSelectors);
          list.remove(prevItem);
        }
        return true;
      } else if (!avoidRulesMerge) {
        if (diff.ne1.length && !diff.ne2.length) {
          const selectorLength = calcSelectorLength(selectors);
          const blockLength = calcDeclarationsLength(diff.eq);
          if (allowMergeUp && selectorLength < blockLength) {
            utils$3.addSelectors(prevSelectors, selectors);
            block.children.fromArray(diff.ne1);
          }
        } else if (!diff.ne1.length && diff.ne2.length) {
          const selectorLength = calcSelectorLength(prevSelectors);
          const blockLength = calcDeclarationsLength(diff.eq);
          if (allowMergeDown && selectorLength < blockLength) {
            utils$3.addSelectors(selectors, prevSelectors);
            prevBlock.children.fromArray(diff.ne2);
          }
        } else {
          const newSelector = {
            type: "SelectorList",
            loc: null,
            children: utils$3.addSelectors(prevSelectors.copy(), selectors)
          };
          const newBlockLength = calcSelectorLength(newSelector.children) + 2;
          const blockLength = calcDeclarationsLength(diff.eq);
          if (blockLength >= newBlockLength) {
            const newItem = list.createItem({
              type: "Rule",
              loc: null,
              prelude: newSelector,
              block: {
                type: "Block",
                loc: null,
                children: new cssTree$2.List().fromArray(diff.eq)
              },
              pseudoSignature: node2.pseudoSignature
            });
            block.children.fromArray(diff.ne1);
            prevBlock.children.fromArray(diff.ne2overrided);
            if (allowMergeUp) {
              list.insert(newItem, prevItem);
            } else {
              list.insert(newItem, item);
            }
            return true;
          }
        }
      }
    }
    if (allowMergeUp) {
      allowMergeUp = !prevSelectors.some(
        (prevSelector) => selectors.some(
          (selector2) => selector2.compareMarker === prevSelector.compareMarker
        )
      );
    }
    prevSelectors.forEach((data2) => {
      disallowDownMarkers[data2.compareMarker] = true;
    });
  });
}
function restructRule(ast) {
  cssTree$2.walk(ast, {
    visit: "Rule",
    reverse: true,
    enter: processRule
  });
}
var _8RestructRuleset$1 = restructRule;
const index$3 = prepare_1;
const _1MergeAtrule = _1MergeAtrule$1;
const _2InitialMergeRuleset = _2InitialMergeRuleset$1;
const _3DisjoinRuleset = _3DisjoinRuleset$1;
const _4RestructShorthand = _4RestructShorthand$1;
const _6RestructBlock = _6RestructBlock$1;
const _7MergeRuleset = _7MergeRuleset$1;
const _8RestructRuleset = _8RestructRuleset$1;
function restructure(ast, options) {
  const indexer = index$3(ast, options);
  options.logger("prepare", ast);
  _1MergeAtrule(ast, options);
  options.logger("mergeAtrule", ast);
  _2InitialMergeRuleset(ast);
  options.logger("initialMergeRuleset", ast);
  _3DisjoinRuleset(ast);
  options.logger("disjoinRuleset", ast);
  _4RestructShorthand(ast, indexer);
  options.logger("restructShorthand", ast);
  _6RestructBlock(ast);
  options.logger("restructBlock", ast);
  _7MergeRuleset(ast);
  options.logger("mergeRuleset", ast);
  _8RestructRuleset(ast);
  options.logger("restructRuleset", ast);
}
var restructure_1 = restructure;
const cssTree$1 = cjs$1;
const usage = usage$1;
const index = clean_1;
const index$1 = replace_1;
const index$2 = restructure_1;
function readChunk(input, specialComments) {
  const children = new cssTree$1.List();
  let nonSpaceTokenInBuffer = false;
  let protectedComment;
  input.nextUntil(input.head, (node2, item, list) => {
    if (node2.type === "Comment") {
      if (!specialComments || node2.value.charAt(0) !== "!") {
        list.remove(item);
        return;
      }
      if (nonSpaceTokenInBuffer || protectedComment) {
        return true;
      }
      list.remove(item);
      protectedComment = node2;
      return;
    }
    if (node2.type !== "WhiteSpace") {
      nonSpaceTokenInBuffer = true;
    }
    children.insert(list.remove(item));
  });
  return {
    comment: protectedComment,
    stylesheet: {
      type: "StyleSheet",
      loc: null,
      children
    }
  };
}
function compressChunk(ast, firstAtrulesAllowed, num, options) {
  options.logger(`Compress block #${num}`, null, true);
  let seed = 1;
  if (ast.type === "StyleSheet") {
    ast.firstAtrulesAllowed = firstAtrulesAllowed;
    ast.id = seed++;
  }
  cssTree$1.walk(ast, {
    visit: "Atrule",
    enter(node2) {
      if (node2.block !== null) {
        node2.block.id = seed++;
      }
    }
  });
  options.logger("init", ast);
  index(ast, options);
  options.logger("clean", ast);
  index$1(ast);
  options.logger("replace", ast);
  if (options.restructuring) {
    index$2(ast, options);
  }
  return ast;
}
function getCommentsOption(options) {
  let comments = "comments" in options ? options.comments : "exclamation";
  if (typeof comments === "boolean") {
    comments = comments ? "exclamation" : false;
  } else if (comments !== "exclamation" && comments !== "first-exclamation") {
    comments = false;
  }
  return comments;
}
function getRestructureOption(options) {
  if ("restructure" in options) {
    return options.restructure;
  }
  return "restructuring" in options ? options.restructuring : true;
}
function wrapBlock(block) {
  return new cssTree$1.List().appendData({
    type: "Rule",
    loc: null,
    prelude: {
      type: "SelectorList",
      loc: null,
      children: new cssTree$1.List().appendData({
        type: "Selector",
        loc: null,
        children: new cssTree$1.List().appendData({
          type: "TypeSelector",
          loc: null,
          name: "x"
        })
      })
    },
    block
  });
}
function compress$2(ast, options) {
  ast = ast || { type: "StyleSheet", loc: null, children: new cssTree$1.List() };
  options = options || {};
  const compressOptions = {
    logger: typeof options.logger === "function" ? options.logger : function() {
    },
    restructuring: getRestructureOption(options),
    forceMediaMerge: Boolean(options.forceMediaMerge),
    usage: options.usage ? usage.buildIndex(options.usage) : false
  };
  const output = new cssTree$1.List();
  let specialComments = getCommentsOption(options);
  let firstAtrulesAllowed = true;
  let input;
  let chunk;
  let chunkNum = 1;
  let chunkChildren;
  if (options.clone) {
    ast = cssTree$1.clone(ast);
  }
  if (ast.type === "StyleSheet") {
    input = ast.children;
    ast.children = output;
  } else {
    input = wrapBlock(ast);
  }
  do {
    chunk = readChunk(input, Boolean(specialComments));
    compressChunk(chunk.stylesheet, firstAtrulesAllowed, chunkNum++, compressOptions);
    chunkChildren = chunk.stylesheet.children;
    if (chunk.comment) {
      if (!output.isEmpty) {
        output.insert(cssTree$1.List.createItem({
          type: "Raw",
          value: "\n"
        }));
      }
      output.insert(cssTree$1.List.createItem(chunk.comment));
      if (!chunkChildren.isEmpty) {
        output.insert(cssTree$1.List.createItem({
          type: "Raw",
          value: "\n"
        }));
      }
    }
    if (firstAtrulesAllowed && !chunkChildren.isEmpty) {
      const lastRule = chunkChildren.last;
      if (lastRule.type !== "Atrule" || lastRule.name !== "import" && lastRule.name !== "charset") {
        firstAtrulesAllowed = false;
      }
    }
    if (specialComments !== "exclamation") {
      specialComments = false;
    }
    output.appendList(chunkChildren);
  } while (!input.isEmpty);
  return {
    ast
  };
}
var compress_1 = compress$2;
const cssTree = cjs$1;
const compress$1 = compress_1;
const specificity$2 = specificity_1;
function encodeString(value2) {
  const stringApostrophe = cssTree.string.encode(value2, true);
  const stringQuote = cssTree.string.encode(value2);
  return stringApostrophe.length < stringQuote.length ? stringApostrophe : stringQuote;
}
const {
  lexer,
  tokenize,
  parse: parse$1,
  generate: generate$1,
  walk,
  find,
  findLast,
  findAll,
  fromPlainObject,
  toPlainObject
} = cssTree.fork({
  node: {
    String: {
      generate(node2) {
        this.token(cssTree.tokenTypes.String, encodeString(node2.value));
      }
    },
    Url: {
      generate(node2) {
        const encodedUrl = cssTree.url.encode(node2.value);
        const string2 = encodeString(node2.value);
        this.token(
          cssTree.tokenTypes.Url,
          encodedUrl.length <= string2.length + 5 ? encodedUrl : "url(" + string2 + ")"
        );
      }
    }
  }
});
syntax$1.compress = compress$1;
syntax$1.specificity = specificity$2;
syntax$1.find = find;
syntax$1.findAll = findAll;
syntax$1.findLast = findLast;
syntax$1.fromPlainObject = fromPlainObject;
syntax$1.generate = generate$1;
syntax$1.lexer = lexer;
syntax$1.parse = parse$1;
syntax$1.toPlainObject = toPlainObject;
syntax$1.tokenize = tokenize;
syntax$1.walk = walk;
var utils$2 = {};
const processSelector = processSelector_1;
const utils$1 = utils$6;
utils$2.processSelector = processSelector;
utils$2.addSelectors = utils$1.addSelectors;
utils$2.compareDeclarations = utils$1.compareDeclarations;
utils$2.hasSimilarSelectors = utils$1.hasSimilarSelectors;
utils$2.isEqualDeclarations = utils$1.isEqualDeclarations;
utils$2.isEqualSelectors = utils$1.isEqualSelectors;
utils$2.unsafeToSkipNode = utils$1.unsafeToSkipNode;
const version = version$1;
const syntax = syntax$1;
const utils = utils$2;
const { parse, generate, compress } = syntax;
function debugOutput(name2, options, startTime, data2) {
  if (options.debug) {
    console.error(`## ${name2} done in %d ms
`, Date.now() - startTime);
  }
  return data2;
}
function createDefaultLogger(level) {
  let lastDebug;
  return function logger(title, ast) {
    let line = title;
    if (ast) {
      line = `[${((Date.now() - lastDebug) / 1e3).toFixed(3)}s] ${line}`;
    }
    if (level > 1 && ast) {
      let css = generate(ast);
      if (level === 2 && css.length > 256) {
        css = css.substr(0, 256) + "...";
      }
      line += `
  ${css}
`;
    }
    console.error(line);
    lastDebug = Date.now();
  };
}
function buildCompressOptions(options) {
  options = { ...options };
  if (typeof options.logger !== "function" && options.debug) {
    options.logger = createDefaultLogger(options.debug);
  }
  return options;
}
function runHandler(ast, options, handlers2) {
  if (!Array.isArray(handlers2)) {
    handlers2 = [handlers2];
  }
  handlers2.forEach((fn) => fn(ast, options));
}
function minify(context, source, options) {
  options = options || {};
  const filename = options.filename || "<unknown>";
  let result;
  const ast = debugOutput(
    "parsing",
    options,
    Date.now(),
    parse(source, {
      context,
      filename,
      positions: Boolean(options.sourceMap)
    })
  );
  if (options.beforeCompress) {
    debugOutput(
      "beforeCompress",
      options,
      Date.now(),
      runHandler(ast, options, options.beforeCompress)
    );
  }
  const compressResult = debugOutput(
    "compress",
    options,
    Date.now(),
    compress(ast, buildCompressOptions(options))
  );
  if (options.afterCompress) {
    debugOutput(
      "afterCompress",
      options,
      Date.now(),
      runHandler(compressResult, options, options.afterCompress)
    );
  }
  if (options.sourceMap) {
    result = debugOutput("generate(sourceMap: true)", options, Date.now(), (() => {
      const tmp = generate(compressResult.ast, { sourceMap: true });
      tmp.map._file = filename;
      tmp.map.setSourceContent(filename, source);
      return tmp;
    })());
  } else {
    result = debugOutput("generate", options, Date.now(), {
      css: generate(compressResult.ast),
      map: null
    });
  }
  return result;
}
function minifyStylesheet(source, options) {
  return minify("stylesheet", source, options);
}
function minifyBlock(source, options) {
  return minify("declarationList", source, options);
}
cjs.version = version.version;
cjs.syntax = syntax;
cjs.utils = utils;
cjs.minify = minifyStylesheet;
cjs.minifyBlock = minifyBlock;
const csstree$2 = cjs$1;
const {
  syntax: { specificity: specificity$1 }
} = cjs;
const {
  visitSkip: visitSkip$5,
  querySelectorAll: querySelectorAll$1,
  detachNodeFromParent: detachNodeFromParent$f
} = xast;
inlineStyles$1.type = "visitor";
inlineStyles$1.name = "inlineStyles";
inlineStyles$1.active = true;
inlineStyles$1.description = "inline styles (additional options)";
const compareSpecificity$1 = (a, b) => {
  for (var i = 0; i < 4; i += 1) {
    if (a[i] < b[i]) {
      return -1;
    } else if (a[i] > b[i]) {
      return 1;
    }
  }
  return 0;
};
const toAny$1 = (value2) => value2;
inlineStyles$1.fn = (root, params) => {
  const {
    onlyMatchedOnce = true,
    removeMatchedSelectors = true,
    useMqs = ["", "screen"],
    usePseudos = [""]
  } = params;
  const styles = [];
  let selectors = [];
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "foreignObject") {
          return visitSkip$5;
        }
        if (node2.name !== "style" || node2.children.length === 0) {
          return;
        }
        if (node2.attributes.type != null && node2.attributes.type !== "" && node2.attributes.type !== "text/css") {
          return;
        }
        let cssText = "";
        for (const child of node2.children) {
          if (child.type === "text" || child.type === "cdata") {
            cssText += child.value;
          }
        }
        let cssAst = null;
        try {
          cssAst = csstree$2.parse(cssText, {
            parseValue: false,
            parseCustomProperty: false
          });
        } catch {
          return;
        }
        if (cssAst.type === "StyleSheet") {
          styles.push({ node: node2, parentNode, cssAst });
        }
        csstree$2.walk(cssAst, {
          visit: "Selector",
          enter(node3, item) {
            const atrule2 = this.atrule;
            const rule = this.rule;
            if (rule == null) {
              return;
            }
            let mq = "";
            if (atrule2 != null) {
              mq = atrule2.name;
              if (atrule2.prelude != null) {
                mq += ` ${csstree$2.generate(atrule2.prelude)}`;
              }
            }
            if (useMqs.includes(mq) === false) {
              return;
            }
            const pseudos2 = [];
            if (node3.type === "Selector") {
              node3.children.forEach((childNode, childItem, childList) => {
                if (childNode.type === "PseudoClassSelector" || childNode.type === "PseudoElementSelector") {
                  pseudos2.push({ item: childItem, list: childList });
                }
              });
            }
            const pseudoSelectors2 = csstree$2.generate({
              type: "Selector",
              children: new csstree$2.List().fromArray(
                pseudos2.map((pseudo2) => pseudo2.item.data)
              )
            });
            if (usePseudos.includes(pseudoSelectors2) === false) {
              return;
            }
            for (const pseudo2 of pseudos2) {
              pseudo2.list.remove(pseudo2.item);
            }
            selectors.push({ node: node3, item, rule });
          }
        });
      }
    },
    root: {
      exit: () => {
        if (styles.length === 0) {
          return;
        }
        const sortedSelectors = [...selectors].sort((a, b) => {
          const aSpecificity = specificity$1(a.item.data);
          const bSpecificity = specificity$1(b.item.data);
          return compareSpecificity$1(aSpecificity, bSpecificity);
        }).reverse();
        for (const selector2 of sortedSelectors) {
          const selectorText = csstree$2.generate(selector2.item.data);
          const matchedElements = [];
          try {
            for (const node2 of querySelectorAll$1(root, selectorText)) {
              if (node2.type === "element") {
                matchedElements.push(node2);
              }
            }
          } catch (selectError) {
            continue;
          }
          if (matchedElements.length === 0) {
            continue;
          }
          if (onlyMatchedOnce && matchedElements.length > 1) {
            continue;
          }
          for (const selectedEl of matchedElements) {
            const styleDeclarationList = csstree$2.parse(
              selectedEl.attributes.style == null ? "" : selectedEl.attributes.style,
              {
                context: "declarationList",
                parseValue: false
              }
            );
            if (styleDeclarationList.type !== "DeclarationList") {
              continue;
            }
            const styleDeclarationItems = /* @__PURE__ */ new Map();
            csstree$2.walk(styleDeclarationList, {
              visit: "Declaration",
              enter(node2, item) {
                styleDeclarationItems.set(node2.property, item);
              }
            });
            csstree$2.walk(selector2.rule, {
              visit: "Declaration",
              enter(ruleDeclaration) {
                const matchedItem = styleDeclarationItems.get(
                  ruleDeclaration.property
                );
                const ruleDeclarationItem = styleDeclarationList.children.createItem(ruleDeclaration);
                if (matchedItem == null) {
                  styleDeclarationList.children.append(ruleDeclarationItem);
                } else if (matchedItem.data.important !== true && ruleDeclaration.important === true) {
                  styleDeclarationList.children.replace(
                    matchedItem,
                    ruleDeclarationItem
                  );
                  styleDeclarationItems.set(
                    ruleDeclaration.property,
                    ruleDeclarationItem
                  );
                }
              }
            });
            selectedEl.attributes.style = csstree$2.generate(styleDeclarationList);
          }
          if (removeMatchedSelectors && matchedElements.length !== 0 && selector2.rule.prelude.type === "SelectorList") {
            selector2.rule.prelude.children.remove(selector2.item);
          }
          selector2.matchedElements = matchedElements;
        }
        if (removeMatchedSelectors === false) {
          return;
        }
        for (const selector2 of sortedSelectors) {
          if (selector2.matchedElements == null) {
            continue;
          }
          if (onlyMatchedOnce && selector2.matchedElements.length > 1) {
            continue;
          }
          for (const selectedEl of selector2.matchedElements) {
            const classList = new Set(
              selectedEl.attributes.class == null ? null : selectedEl.attributes.class.split(" ")
            );
            const firstSubSelector = toAny$1(selector2.node.children.first);
            if (firstSubSelector != null && firstSubSelector.type === "ClassSelector") {
              classList.delete(firstSubSelector.name);
            }
            if (classList.size === 0) {
              delete selectedEl.attributes.class;
            } else {
              selectedEl.attributes.class = Array.from(classList).join(" ");
            }
            if (firstSubSelector != null && firstSubSelector.type === "IdSelector") {
              if (selectedEl.attributes.id === firstSubSelector.name) {
                delete selectedEl.attributes.id;
              }
            }
          }
        }
        for (const style2 of styles) {
          csstree$2.walk(style2.cssAst, {
            visit: "Rule",
            enter: function(node2, item, list) {
              if (node2.type === "Rule" && node2.prelude.type === "SelectorList" && toAny$1(node2.prelude.children.isEmpty)) {
                list.remove(item);
              }
            }
          });
          if (toAny$1(style2.cssAst.children.isEmpty)) {
            detachNodeFromParent$f(style2.node, style2.parentNode);
          } else {
            const firstChild = style2.node.children[0];
            if (firstChild.type === "text" || firstChild.type === "cdata") {
              firstChild.value = csstree$2.generate(style2.cssAst);
            }
          }
        }
      }
    }
  };
};
var minifyStyles$1 = {};
const csso = cjs;
minifyStyles$1.type = "visitor";
minifyStyles$1.name = "minifyStyles";
minifyStyles$1.active = true;
minifyStyles$1.description = "minifies styles and removes unused styles based on usage data";
minifyStyles$1.fn = (_root, { usage: usage2, ...params }) => {
  let enableTagsUsage = true;
  let enableIdsUsage = true;
  let enableClassesUsage = true;
  let forceUsageDeoptimized = false;
  if (typeof usage2 === "boolean") {
    enableTagsUsage = usage2;
    enableIdsUsage = usage2;
    enableClassesUsage = usage2;
  } else if (usage2) {
    enableTagsUsage = usage2.tags == null ? true : usage2.tags;
    enableIdsUsage = usage2.ids == null ? true : usage2.ids;
    enableClassesUsage = usage2.classes == null ? true : usage2.classes;
    forceUsageDeoptimized = usage2.force == null ? false : usage2.force;
  }
  const styleElements = [];
  const elementsWithStyleAttributes = [];
  let deoptimized = false;
  const tagsUsage = /* @__PURE__ */ new Set();
  const idsUsage = /* @__PURE__ */ new Set();
  const classesUsage = /* @__PURE__ */ new Set();
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "script") {
          deoptimized = true;
        }
        for (const name2 of Object.keys(node2.attributes)) {
          if (name2.startsWith("on")) {
            deoptimized = true;
          }
        }
        tagsUsage.add(node2.name);
        if (node2.attributes.id != null) {
          idsUsage.add(node2.attributes.id);
        }
        if (node2.attributes.class != null) {
          for (const className of node2.attributes.class.split(/\s+/)) {
            classesUsage.add(className);
          }
        }
        if (node2.name === "style" && node2.children.length !== 0) {
          styleElements.push(node2);
        } else if (node2.attributes.style != null) {
          elementsWithStyleAttributes.push(node2);
        }
      }
    },
    root: {
      exit: () => {
        const cssoUsage = {};
        if (deoptimized === false || forceUsageDeoptimized === true) {
          if (enableTagsUsage && tagsUsage.size !== 0) {
            cssoUsage.tags = Array.from(tagsUsage);
          }
          if (enableIdsUsage && idsUsage.size !== 0) {
            cssoUsage.ids = Array.from(idsUsage);
          }
          if (enableClassesUsage && classesUsage.size !== 0) {
            cssoUsage.classes = Array.from(classesUsage);
          }
        }
        for (const node2 of styleElements) {
          if (node2.children[0].type === "text" || node2.children[0].type === "cdata") {
            const cssText = node2.children[0].value;
            const minified = csso.minify(cssText, {
              ...params,
              usage: cssoUsage
            }).css;
            if (cssText.indexOf(">") >= 0 || cssText.indexOf("<") >= 0) {
              node2.children[0].type = "cdata";
              node2.children[0].value = minified;
            } else {
              node2.children[0].type = "text";
              node2.children[0].value = minified;
            }
          }
        }
        for (const node2 of elementsWithStyleAttributes) {
          const elemStyle = node2.attributes.style;
          node2.attributes.style = csso.minifyBlock(elemStyle, {
            ...params
          }).css;
        }
      }
    }
  };
};
var cleanupIDs$1 = {};
const { visitSkip: visitSkip$4 } = xast;
const { referencesProps: referencesProps$3 } = _collections;
cleanupIDs$1.type = "visitor";
cleanupIDs$1.name = "cleanupIDs";
cleanupIDs$1.active = true;
cleanupIDs$1.description = "removes unused IDs and minifies used";
const regReferencesUrl = /\burl\(("|')?#(.+?)\1\)/;
const regReferencesHref = /^#(.+?)$/;
const regReferencesBegin = /(\w+)\./;
const generateIDchars = [
  "a",
  "b",
  "c",
  "d",
  "e",
  "f",
  "g",
  "h",
  "i",
  "j",
  "k",
  "l",
  "m",
  "n",
  "o",
  "p",
  "q",
  "r",
  "s",
  "t",
  "u",
  "v",
  "w",
  "x",
  "y",
  "z",
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z"
];
const maxIDindex = generateIDchars.length - 1;
const hasStringPrefix = (string2, prefixes) => {
  for (const prefix of prefixes) {
    if (string2.startsWith(prefix)) {
      return true;
    }
  }
  return false;
};
const generateID = (currentID) => {
  if (currentID == null) {
    return [0];
  }
  currentID[currentID.length - 1] += 1;
  for (let i = currentID.length - 1; i > 0; i--) {
    if (currentID[i] > maxIDindex) {
      currentID[i] = 0;
      if (currentID[i - 1] !== void 0) {
        currentID[i - 1]++;
      }
    }
  }
  if (currentID[0] > maxIDindex) {
    currentID[0] = 0;
    currentID.unshift(0);
  }
  return currentID;
};
const getIDstring = (arr, prefix) => {
  return prefix + arr.map((i) => generateIDchars[i]).join("");
};
cleanupIDs$1.fn = (_root, params) => {
  const {
    remove = true,
    minify: minify2 = true,
    prefix = "",
    preserve = [],
    preservePrefixes = [],
    force = false
  } = params;
  const preserveIDs = new Set(
    Array.isArray(preserve) ? preserve : preserve ? [preserve] : []
  );
  const preserveIDPrefixes = Array.isArray(preservePrefixes) ? preservePrefixes : preservePrefixes ? [preservePrefixes] : [];
  const nodeById = /* @__PURE__ */ new Map();
  const referencesById = /* @__PURE__ */ new Map();
  let deoptimized = false;
  return {
    element: {
      enter: (node2) => {
        if (force == false) {
          if ((node2.name === "style" || node2.name === "script") && node2.children.length !== 0) {
            deoptimized = true;
            return;
          }
          if (node2.name === "svg") {
            let hasDefsOnly = true;
            for (const child of node2.children) {
              if (child.type !== "element" || child.name !== "defs") {
                hasDefsOnly = false;
                break;
              }
            }
            if (hasDefsOnly) {
              return visitSkip$4;
            }
          }
        }
        for (const [name2, value2] of Object.entries(node2.attributes)) {
          if (name2 === "id") {
            const id = value2;
            if (nodeById.has(id)) {
              delete node2.attributes.id;
            } else {
              nodeById.set(id, node2);
            }
          } else {
            let id = null;
            if (referencesProps$3.includes(name2)) {
              const match2 = value2.match(regReferencesUrl);
              if (match2 != null) {
                id = match2[2];
              }
            }
            if (name2 === "href" || name2.endsWith(":href")) {
              const match2 = value2.match(regReferencesHref);
              if (match2 != null) {
                id = match2[1];
              }
            }
            if (name2 === "begin") {
              const match2 = value2.match(regReferencesBegin);
              if (match2 != null) {
                id = match2[1];
              }
            }
            if (id != null) {
              let refs = referencesById.get(id);
              if (refs == null) {
                refs = [];
                referencesById.set(id, refs);
              }
              refs.push({ element: node2, name: name2, value: value2 });
            }
          }
        }
      }
    },
    root: {
      exit: () => {
        if (deoptimized) {
          return;
        }
        const isIdPreserved = (id) => preserveIDs.has(id) || hasStringPrefix(id, preserveIDPrefixes);
        let currentID = null;
        for (const [id, refs] of referencesById) {
          const node2 = nodeById.get(id);
          if (node2 != null) {
            if (minify2 && isIdPreserved(id) === false) {
              let currentIDString = null;
              do {
                currentID = generateID(currentID);
                currentIDString = getIDstring(currentID, prefix);
              } while (isIdPreserved(currentIDString));
              node2.attributes.id = currentIDString;
              for (const { element, name: name2, value: value2 } of refs) {
                if (value2.includes("#")) {
                  element.attributes[name2] = value2.replace(
                    `#${id}`,
                    `#${currentIDString}`
                  );
                } else {
                  element.attributes[name2] = value2.replace(
                    `${id}.`,
                    `${currentIDString}.`
                  );
                }
              }
            }
            nodeById.delete(id);
          }
        }
        if (remove) {
          for (const [id, node2] of nodeById) {
            if (isIdPreserved(id) === false) {
              delete node2.attributes.id;
            }
          }
        }
      }
    }
  };
};
var removeUselessDefs$1 = {};
const { detachNodeFromParent: detachNodeFromParent$e } = xast;
const { elemsGroups: elemsGroups$4 } = _collections;
removeUselessDefs$1.type = "visitor";
removeUselessDefs$1.name = "removeUselessDefs";
removeUselessDefs$1.active = true;
removeUselessDefs$1.description = "removes elements in <defs> without id";
removeUselessDefs$1.fn = () => {
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "defs") {
          const usefulNodes = [];
          collectUsefulNodes(node2, usefulNodes);
          if (usefulNodes.length === 0) {
            detachNodeFromParent$e(node2, parentNode);
          }
          for (const usefulNode of usefulNodes) {
            Object.defineProperty(usefulNode, "parentNode", {
              writable: true,
              value: node2
            });
          }
          node2.children = usefulNodes;
        } else if (elemsGroups$4.nonRendering.includes(node2.name) && node2.attributes.id == null) {
          detachNodeFromParent$e(node2, parentNode);
        }
      }
    }
  };
};
const collectUsefulNodes = (node2, usefulNodes) => {
  for (const child of node2.children) {
    if (child.type === "element") {
      if (child.attributes.id != null || child.name === "style") {
        usefulNodes.push(child);
      } else {
        collectUsefulNodes(child, usefulNodes);
      }
    }
  }
};
var cleanupNumericValues$1 = {};
var tools = {};
tools.encodeSVGDatauri = (str, type) => {
  var prefix = "data:image/svg+xml";
  if (!type || type === "base64") {
    prefix += ";base64,";
    str = prefix + Buffer.from(str).toString("base64");
  } else if (type === "enc") {
    str = prefix + "," + encodeURIComponent(str);
  } else if (type === "unenc") {
    str = prefix + "," + str;
  }
  return str;
};
tools.decodeSVGDatauri = (str) => {
  var regexp = /data:image\/svg\+xml(;charset=[^;,]*)?(;base64)?,(.*)/;
  var match2 = regexp.exec(str);
  if (!match2)
    return str;
  var data2 = match2[3];
  if (match2[2]) {
    str = Buffer.from(data2, "base64").toString("utf8");
  } else if (data2.charAt(0) === "%") {
    str = decodeURIComponent(data2);
  } else if (data2.charAt(0) === "<") {
    str = data2;
  }
  return str;
};
tools.cleanupOutData = (data2, params, command) => {
  let str = "";
  let delimiter;
  let prev;
  data2.forEach((item, i) => {
    delimiter = " ";
    if (i == 0)
      delimiter = "";
    if (params.noSpaceAfterFlags && (command == "A" || command == "a")) {
      var pos = i % 7;
      if (pos == 4 || pos == 5)
        delimiter = "";
    }
    const itemStr = params.leadingZero ? removeLeadingZero$3(item) : item.toString();
    if (params.negativeExtraSpace && delimiter != "" && (item < 0 || itemStr.charAt(0) === "." && prev % 1 !== 0)) {
      delimiter = "";
    }
    prev = item;
    str += delimiter + itemStr;
  });
  return str;
};
const removeLeadingZero$3 = (num) => {
  var strNum = num.toString();
  if (0 < num && num < 1 && strNum.charAt(0) === "0") {
    strNum = strNum.slice(1);
  } else if (-1 < num && num < 0 && strNum.charAt(1) === "0") {
    strNum = strNum.charAt(0) + strNum.slice(2);
  }
  return strNum;
};
tools.removeLeadingZero = removeLeadingZero$3;
const { removeLeadingZero: removeLeadingZero$2 } = tools;
cleanupNumericValues$1.name = "cleanupNumericValues";
cleanupNumericValues$1.type = "visitor";
cleanupNumericValues$1.active = true;
cleanupNumericValues$1.description = "rounds numeric values to the fixed precision, removes default \u2018px\u2019 units";
const regNumericValues$3 = /^([-+]?\d*\.?\d+([eE][-+]?\d+)?)(px|pt|pc|mm|cm|m|in|ft|em|ex|%)?$/;
const absoluteLengths$1 = {
  cm: 96 / 2.54,
  mm: 96 / 25.4,
  in: 96,
  pt: 4 / 3,
  pc: 16,
  px: 1
};
cleanupNumericValues$1.fn = (_root, params) => {
  const {
    floatPrecision = 3,
    leadingZero = true,
    defaultPx = true,
    convertToPx = true
  } = params;
  return {
    element: {
      enter: (node2) => {
        if (node2.attributes.viewBox != null) {
          const nums = node2.attributes.viewBox.split(/\s,?\s*|,\s*/g);
          node2.attributes.viewBox = nums.map((value2) => {
            const num = Number(value2);
            return Number.isNaN(num) ? value2 : Number(num.toFixed(floatPrecision));
          }).join(" ");
        }
        for (const [name2, value2] of Object.entries(node2.attributes)) {
          if (name2 === "version") {
            continue;
          }
          const match2 = value2.match(regNumericValues$3);
          if (match2) {
            let num = Number(Number(match2[1]).toFixed(floatPrecision));
            let matchedUnit = match2[3] || "";
            let units = matchedUnit;
            if (convertToPx && units !== "" && units in absoluteLengths$1) {
              const pxNum = Number(
                (absoluteLengths$1[units] * Number(match2[1])).toFixed(
                  floatPrecision
                )
              );
              if (pxNum.toString().length < match2[0].length) {
                num = pxNum;
                units = "px";
              }
            }
            let str;
            if (leadingZero) {
              str = removeLeadingZero$2(num);
            } else {
              str = num.toString();
            }
            if (defaultPx && units === "px") {
              units = "";
            }
            node2.attributes[name2] = str + units;
          }
        }
      }
    }
  };
};
var convertColors$1 = {};
const collections = _collections;
convertColors$1.type = "visitor";
convertColors$1.name = "convertColors";
convertColors$1.active = true;
convertColors$1.description = "converts colors: rgb() to #rrggbb and #rrggbb to #rgb";
const rNumber = "([+-]?(?:\\d*\\.\\d+|\\d+\\.?)%?)";
const rComma = "\\s*,\\s*";
const regRGB = new RegExp(
  "^rgb\\(\\s*" + rNumber + rComma + rNumber + rComma + rNumber + "\\s*\\)$"
);
const regHEX = /^#(([a-fA-F0-9])\2){3}$/;
const convertRgbToHex = ([r, g2, b]) => {
  const hexNumber = (256 + r << 8 | g2) << 8 | b;
  return "#" + hexNumber.toString(16).slice(1).toUpperCase();
};
convertColors$1.fn = (_root, params) => {
  const {
    currentColor = false,
    names2hex = true,
    rgb2hex = true,
    shorthex = true,
    shortname = true
  } = params;
  return {
    element: {
      enter: (node2) => {
        for (const [name2, value2] of Object.entries(node2.attributes)) {
          if (collections.colorsProps.includes(name2)) {
            let val = value2;
            if (currentColor) {
              let matched;
              if (typeof currentColor === "string") {
                matched = val === currentColor;
              } else if (currentColor instanceof RegExp) {
                matched = currentColor.exec(val) != null;
              } else {
                matched = val !== "none";
              }
              if (matched) {
                val = "currentColor";
              }
            }
            if (names2hex) {
              const colorName = val.toLowerCase();
              if (collections.colorsNames[colorName] != null) {
                val = collections.colorsNames[colorName];
              }
            }
            if (rgb2hex) {
              let match2 = val.match(regRGB);
              if (match2 != null) {
                let nums = match2.slice(1, 4).map((m) => {
                  let n;
                  if (m.indexOf("%") > -1) {
                    n = Math.round(parseFloat(m) * 2.55);
                  } else {
                    n = Number(m);
                  }
                  return Math.max(0, Math.min(n, 255));
                });
                val = convertRgbToHex(nums);
              }
            }
            if (shorthex) {
              let match2 = val.match(regHEX);
              if (match2 != null) {
                val = "#" + match2[0][1] + match2[0][3] + match2[0][5];
              }
            }
            if (shortname) {
              const colorName = val.toLowerCase();
              if (collections.colorsShortNames[colorName] != null) {
                val = collections.colorsShortNames[colorName];
              }
            }
            node2.attributes[name2] = val;
          }
        }
      }
    }
  };
};
var removeUnknownsAndDefaults$1 = {};
var style = {};
const csstree$1 = cjs$1;
const {
  syntax: { specificity }
} = cjs;
const { visit: visit$5, matches } = xast;
const {
  attrsGroups: attrsGroups$4,
  inheritableAttrs: inheritableAttrs$3,
  presentationNonInheritableGroupAttrs: presentationNonInheritableGroupAttrs$2
} = _collections;
const csstreeWalkSkip = csstree$1.walk.skip;
const parseRule = (ruleNode, dynamic) => {
  const declarations = [];
  ruleNode.block.children.forEach((cssNode) => {
    if (cssNode.type === "Declaration") {
      declarations.push({
        name: cssNode.property,
        value: csstree$1.generate(cssNode.value),
        important: cssNode.important === true
      });
    }
  });
  const rules = [];
  csstree$1.walk(ruleNode.prelude, (node2) => {
    if (node2.type === "Selector") {
      const newNode = csstree$1.clone(node2);
      let hasPseudoClasses = false;
      csstree$1.walk(newNode, (pseudoClassNode, item, list) => {
        if (pseudoClassNode.type === "PseudoClassSelector") {
          hasPseudoClasses = true;
          list.remove(item);
        }
      });
      rules.push({
        specificity: specificity(node2),
        dynamic: hasPseudoClasses || dynamic,
        selector: csstree$1.generate(newNode),
        declarations
      });
    }
  });
  return rules;
};
const parseStylesheet = (css, dynamic) => {
  const rules = [];
  const ast = csstree$1.parse(css, {
    parseValue: false,
    parseAtrulePrelude: false
  });
  csstree$1.walk(ast, (cssNode) => {
    if (cssNode.type === "Rule") {
      rules.push(...parseRule(cssNode, dynamic || false));
      return csstreeWalkSkip;
    }
    if (cssNode.type === "Atrule") {
      if (cssNode.name === "keyframes") {
        return csstreeWalkSkip;
      }
      csstree$1.walk(cssNode, (ruleNode) => {
        if (ruleNode.type === "Rule") {
          rules.push(...parseRule(ruleNode, dynamic || true));
          return csstreeWalkSkip;
        }
      });
      return csstreeWalkSkip;
    }
  });
  return rules;
};
const parseStyleDeclarations = (css) => {
  const declarations = [];
  const ast = csstree$1.parse(css, {
    context: "declarationList",
    parseValue: false
  });
  csstree$1.walk(ast, (cssNode) => {
    if (cssNode.type === "Declaration") {
      declarations.push({
        name: cssNode.property,
        value: csstree$1.generate(cssNode.value),
        important: cssNode.important === true
      });
    }
  });
  return declarations;
};
const computeOwnStyle = (stylesheet, node2) => {
  const computedStyle = {};
  const importantStyles = /* @__PURE__ */ new Map();
  for (const [name2, value2] of Object.entries(node2.attributes)) {
    if (attrsGroups$4.presentation.includes(name2)) {
      computedStyle[name2] = { type: "static", inherited: false, value: value2 };
      importantStyles.set(name2, false);
    }
  }
  for (const { selector: selector2, declarations, dynamic } of stylesheet.rules) {
    if (matches(node2, selector2)) {
      for (const { name: name2, value: value2, important } of declarations) {
        const computed = computedStyle[name2];
        if (computed && computed.type === "dynamic") {
          continue;
        }
        if (dynamic) {
          computedStyle[name2] = { type: "dynamic", inherited: false };
          continue;
        }
        if (computed == null || important === true || importantStyles.get(name2) === false) {
          computedStyle[name2] = { type: "static", inherited: false, value: value2 };
          importantStyles.set(name2, important);
        }
      }
    }
  }
  const styleDeclarations = node2.attributes.style == null ? [] : parseStyleDeclarations(node2.attributes.style);
  for (const { name: name2, value: value2, important } of styleDeclarations) {
    const computed = computedStyle[name2];
    if (computed && computed.type === "dynamic") {
      continue;
    }
    if (computed == null || important === true || importantStyles.get(name2) === false) {
      computedStyle[name2] = { type: "static", inherited: false, value: value2 };
      importantStyles.set(name2, important);
    }
  }
  return computedStyle;
};
const compareSpecificity = (a, b) => {
  for (let i = 0; i < 4; i += 1) {
    if (a[i] < b[i]) {
      return -1;
    } else if (a[i] > b[i]) {
      return 1;
    }
  }
  return 0;
};
const collectStylesheet$6 = (root) => {
  const rules = [];
  const parents = /* @__PURE__ */ new Map();
  visit$5(root, {
    element: {
      enter: (node2, parentNode) => {
        parents.set(node2, parentNode);
        if (node2.name === "style") {
          const dynamic = node2.attributes.media != null && node2.attributes.media !== "all";
          if (node2.attributes.type == null || node2.attributes.type === "" || node2.attributes.type === "text/css") {
            const children = node2.children;
            for (const child of children) {
              if (child.type === "text" || child.type === "cdata") {
                rules.push(...parseStylesheet(child.value, dynamic));
              }
            }
          }
        }
      }
    }
  });
  rules.sort((a, b) => compareSpecificity(a.specificity, b.specificity));
  return { rules, parents };
};
style.collectStylesheet = collectStylesheet$6;
const computeStyle$6 = (stylesheet, node2) => {
  const { parents } = stylesheet;
  const computedStyles = computeOwnStyle(stylesheet, node2);
  let parent = parents.get(node2);
  while (parent != null && parent.type !== "root") {
    const inheritedStyles = computeOwnStyle(stylesheet, parent);
    for (const [name2, computed] of Object.entries(inheritedStyles)) {
      if (computedStyles[name2] == null && inheritableAttrs$3.includes(name2) === true && presentationNonInheritableGroupAttrs$2.includes(name2) === false) {
        computedStyles[name2] = { ...computed, inherited: true };
      }
    }
    parent = parents.get(parent);
  }
  return computedStyles;
};
style.computeStyle = computeStyle$6;
const { visitSkip: visitSkip$3, detachNodeFromParent: detachNodeFromParent$d } = xast;
const { collectStylesheet: collectStylesheet$5, computeStyle: computeStyle$5 } = style;
const {
  elems,
  attrsGroups: attrsGroups$3,
  elemsGroups: elemsGroups$3,
  attrsGroupsDefaults: attrsGroupsDefaults$1,
  presentationNonInheritableGroupAttrs: presentationNonInheritableGroupAttrs$1
} = _collections;
removeUnknownsAndDefaults$1.type = "visitor";
removeUnknownsAndDefaults$1.name = "removeUnknownsAndDefaults";
removeUnknownsAndDefaults$1.active = true;
removeUnknownsAndDefaults$1.description = "removes unknown elements content and attributes, removes attrs with default values";
const allowedChildrenPerElement = /* @__PURE__ */ new Map();
const allowedAttributesPerElement = /* @__PURE__ */ new Map();
const attributesDefaultsPerElement = /* @__PURE__ */ new Map();
for (const [name2, config2] of Object.entries(elems)) {
  const allowedChildren = /* @__PURE__ */ new Set();
  if (config2.content) {
    for (const elementName of config2.content) {
      allowedChildren.add(elementName);
    }
  }
  if (config2.contentGroups) {
    for (const contentGroupName of config2.contentGroups) {
      const elemsGroup = elemsGroups$3[contentGroupName];
      if (elemsGroup) {
        for (const elementName of elemsGroup) {
          allowedChildren.add(elementName);
        }
      }
    }
  }
  const allowedAttributes = /* @__PURE__ */ new Set();
  if (config2.attrs) {
    for (const attrName of config2.attrs) {
      allowedAttributes.add(attrName);
    }
  }
  const attributesDefaults = /* @__PURE__ */ new Map();
  if (config2.defaults) {
    for (const [attrName, defaultValue] of Object.entries(config2.defaults)) {
      attributesDefaults.set(attrName, defaultValue);
    }
  }
  for (const attrsGroupName of config2.attrsGroups) {
    const attrsGroup = attrsGroups$3[attrsGroupName];
    if (attrsGroup) {
      for (const attrName of attrsGroup) {
        allowedAttributes.add(attrName);
      }
    }
    const groupDefaults = attrsGroupsDefaults$1[attrsGroupName];
    if (groupDefaults) {
      for (const [attrName, defaultValue] of Object.entries(groupDefaults)) {
        attributesDefaults.set(attrName, defaultValue);
      }
    }
  }
  allowedChildrenPerElement.set(name2, allowedChildren);
  allowedAttributesPerElement.set(name2, allowedAttributes);
  attributesDefaultsPerElement.set(name2, attributesDefaults);
}
removeUnknownsAndDefaults$1.fn = (root, params) => {
  const {
    unknownContent = true,
    unknownAttrs = true,
    defaultAttrs = true,
    uselessOverrides = true,
    keepDataAttrs = true,
    keepAriaAttrs = true,
    keepRoleAttr = false
  } = params;
  const stylesheet = collectStylesheet$5(root);
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name.includes(":")) {
          return;
        }
        if (node2.name === "foreignObject") {
          return visitSkip$3;
        }
        if (unknownContent && parentNode.type === "element") {
          const allowedChildren = allowedChildrenPerElement.get(
            parentNode.name
          );
          if (allowedChildren == null || allowedChildren.size === 0) {
            if (allowedChildrenPerElement.get(node2.name) == null) {
              detachNodeFromParent$d(node2, parentNode);
              return;
            }
          } else {
            if (allowedChildren.has(node2.name) === false) {
              detachNodeFromParent$d(node2, parentNode);
              return;
            }
          }
        }
        const allowedAttributes = allowedAttributesPerElement.get(node2.name);
        const attributesDefaults = attributesDefaultsPerElement.get(node2.name);
        const computedParentStyle = parentNode.type === "element" ? computeStyle$5(stylesheet, parentNode) : null;
        for (const [name2, value2] of Object.entries(node2.attributes)) {
          if (keepDataAttrs && name2.startsWith("data-")) {
            continue;
          }
          if (keepAriaAttrs && name2.startsWith("aria-")) {
            continue;
          }
          if (keepRoleAttr && name2 === "role") {
            continue;
          }
          if (name2 === "xmlns") {
            continue;
          }
          if (name2.includes(":")) {
            const [prefix] = name2.split(":");
            if (prefix !== "xml" && prefix !== "xlink") {
              continue;
            }
          }
          if (unknownAttrs && allowedAttributes && allowedAttributes.has(name2) === false) {
            delete node2.attributes[name2];
          }
          if (defaultAttrs && node2.attributes.id == null && attributesDefaults && attributesDefaults.get(name2) === value2) {
            if (computedParentStyle == null || computedParentStyle[name2] == null) {
              delete node2.attributes[name2];
            }
          }
          if (uselessOverrides && node2.attributes.id == null) {
            const style2 = computedParentStyle == null ? null : computedParentStyle[name2];
            if (presentationNonInheritableGroupAttrs$1.includes(name2) === false && style2 != null && style2.type === "static" && style2.value === value2) {
              delete node2.attributes[name2];
            }
          }
        }
      }
    }
  };
};
var removeNonInheritableGroupAttrs$1 = {};
const {
  inheritableAttrs: inheritableAttrs$2,
  attrsGroups: attrsGroups$2,
  presentationNonInheritableGroupAttrs
} = _collections;
removeNonInheritableGroupAttrs$1.type = "visitor";
removeNonInheritableGroupAttrs$1.name = "removeNonInheritableGroupAttrs";
removeNonInheritableGroupAttrs$1.active = true;
removeNonInheritableGroupAttrs$1.description = "removes non-inheritable group\u2019s presentational attributes";
removeNonInheritableGroupAttrs$1.fn = () => {
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "g") {
          for (const name2 of Object.keys(node2.attributes)) {
            if (attrsGroups$2.presentation.includes(name2) === true && inheritableAttrs$2.includes(name2) === false && presentationNonInheritableGroupAttrs.includes(name2) === false) {
              delete node2.attributes[name2];
            }
          }
        }
      }
    }
  };
};
var removeUselessStrokeAndFill$1 = {};
const { visit: visit$4, visitSkip: visitSkip$2, detachNodeFromParent: detachNodeFromParent$c } = xast;
const { collectStylesheet: collectStylesheet$4, computeStyle: computeStyle$4 } = style;
const { elemsGroups: elemsGroups$2 } = _collections;
removeUselessStrokeAndFill$1.type = "visitor";
removeUselessStrokeAndFill$1.name = "removeUselessStrokeAndFill";
removeUselessStrokeAndFill$1.active = true;
removeUselessStrokeAndFill$1.description = "removes useless stroke and fill attributes";
removeUselessStrokeAndFill$1.fn = (root, params) => {
  const {
    stroke: removeStroke = true,
    fill: removeFill = true,
    removeNone = false
  } = params;
  let hasStyleOrScript = false;
  visit$4(root, {
    element: {
      enter: (node2) => {
        if (node2.name === "style" || node2.name === "script") {
          hasStyleOrScript = true;
        }
      }
    }
  });
  if (hasStyleOrScript) {
    return null;
  }
  const stylesheet = collectStylesheet$4(root);
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.attributes.id != null) {
          return visitSkip$2;
        }
        if (elemsGroups$2.shape.includes(node2.name) == false) {
          return;
        }
        const computedStyle = computeStyle$4(stylesheet, node2);
        const stroke = computedStyle.stroke;
        const strokeOpacity = computedStyle["stroke-opacity"];
        const strokeWidth = computedStyle["stroke-width"];
        const markerEnd = computedStyle["marker-end"];
        const fill = computedStyle.fill;
        const fillOpacity = computedStyle["fill-opacity"];
        const computedParentStyle = parentNode.type === "element" ? computeStyle$4(stylesheet, parentNode) : null;
        const parentStroke = computedParentStyle == null ? null : computedParentStyle.stroke;
        if (removeStroke) {
          if (stroke == null || stroke.type === "static" && stroke.value == "none" || strokeOpacity != null && strokeOpacity.type === "static" && strokeOpacity.value === "0" || strokeWidth != null && strokeWidth.type === "static" && strokeWidth.value === "0") {
            if (strokeWidth != null && strokeWidth.type === "static" && strokeWidth.value === "0" || markerEnd == null) {
              for (const name2 of Object.keys(node2.attributes)) {
                if (name2.startsWith("stroke")) {
                  delete node2.attributes[name2];
                }
              }
              if (parentStroke != null && parentStroke.type === "static" && parentStroke.value !== "none") {
                node2.attributes.stroke = "none";
              }
            }
          }
        }
        if (removeFill) {
          if (fill != null && fill.type === "static" && fill.value === "none" || fillOpacity != null && fillOpacity.type === "static" && fillOpacity.value === "0") {
            for (const name2 of Object.keys(node2.attributes)) {
              if (name2.startsWith("fill-")) {
                delete node2.attributes[name2];
              }
            }
            if (fill == null || fill.type === "static" && fill.value !== "none") {
              node2.attributes.fill = "none";
            }
          }
        }
        if (removeNone) {
          if ((stroke == null || node2.attributes.stroke === "none") && (fill != null && fill.type === "static" && fill.value === "none" || node2.attributes.fill === "none")) {
            detachNodeFromParent$c(node2, parentNode);
          }
        }
      }
    }
  };
};
var removeViewBox$1 = {};
removeViewBox$1.type = "visitor";
removeViewBox$1.name = "removeViewBox";
removeViewBox$1.active = true;
removeViewBox$1.description = "removes viewBox attribute when possible";
const viewBoxElems = ["svg", "pattern", "symbol"];
removeViewBox$1.fn = () => {
  return {
    element: {
      enter: (node2, parentNode) => {
        if (viewBoxElems.includes(node2.name) && node2.attributes.viewBox != null && node2.attributes.width != null && node2.attributes.height != null) {
          if (node2.name === "svg" && parentNode.type !== "root") {
            return;
          }
          const nums = node2.attributes.viewBox.split(/[ ,]+/g);
          if (nums[0] === "0" && nums[1] === "0" && node2.attributes.width.replace(/px$/, "") === nums[2] && node2.attributes.height.replace(/px$/, "") === nums[3]) {
            delete node2.attributes.viewBox;
          }
        }
      }
    }
  };
};
var cleanupEnableBackground$1 = {};
const { visit: visit$3 } = xast;
cleanupEnableBackground$1.type = "visitor";
cleanupEnableBackground$1.name = "cleanupEnableBackground";
cleanupEnableBackground$1.active = true;
cleanupEnableBackground$1.description = "remove or cleanup enable-background attribute when possible";
cleanupEnableBackground$1.fn = (root) => {
  const regEnableBackground = /^new\s0\s0\s([-+]?\d*\.?\d+([eE][-+]?\d+)?)\s([-+]?\d*\.?\d+([eE][-+]?\d+)?)$/;
  let hasFilter = false;
  visit$3(root, {
    element: {
      enter: (node2) => {
        if (node2.name === "filter") {
          hasFilter = true;
        }
      }
    }
  });
  return {
    element: {
      enter: (node2) => {
        if (node2.attributes["enable-background"] == null) {
          return;
        }
        if (hasFilter) {
          if ((node2.name === "svg" || node2.name === "mask" || node2.name === "pattern") && node2.attributes.width != null && node2.attributes.height != null) {
            const match2 = node2.attributes["enable-background"].match(regEnableBackground);
            if (match2 != null && node2.attributes.width === match2[1] && node2.attributes.height === match2[3]) {
              if (node2.name === "svg") {
                delete node2.attributes["enable-background"];
              } else {
                node2.attributes["enable-background"] = "new";
              }
            }
          }
        } else {
          delete node2.attributes["enable-background"];
        }
      }
    }
  };
};
var removeHiddenElems$1 = {};
var path = {};
const argsCountPerCommand = {
  M: 2,
  m: 2,
  Z: 0,
  z: 0,
  L: 2,
  l: 2,
  H: 1,
  h: 1,
  V: 1,
  v: 1,
  C: 6,
  c: 6,
  S: 4,
  s: 4,
  Q: 4,
  q: 4,
  T: 2,
  t: 2,
  A: 7,
  a: 7
};
const isCommand = (c) => {
  return c in argsCountPerCommand;
};
const isWsp = (c) => {
  const codePoint = c.codePointAt(0);
  return codePoint === 32 || codePoint === 9 || codePoint === 13 || codePoint === 10;
};
const isDigit = (c) => {
  const codePoint = c.codePointAt(0);
  if (codePoint == null) {
    return false;
  }
  return 48 <= codePoint && codePoint <= 57;
};
const readNumber = (string2, cursor) => {
  let i = cursor;
  let value2 = "";
  let state = "none";
  for (; i < string2.length; i += 1) {
    const c = string2[i];
    if (c === "+" || c === "-") {
      if (state === "none") {
        state = "sign";
        value2 += c;
        continue;
      }
      if (state === "e") {
        state = "exponent_sign";
        value2 += c;
        continue;
      }
    }
    if (isDigit(c)) {
      if (state === "none" || state === "sign" || state === "whole") {
        state = "whole";
        value2 += c;
        continue;
      }
      if (state === "decimal_point" || state === "decimal") {
        state = "decimal";
        value2 += c;
        continue;
      }
      if (state === "e" || state === "exponent_sign" || state === "exponent") {
        state = "exponent";
        value2 += c;
        continue;
      }
    }
    if (c === ".") {
      if (state === "none" || state === "sign" || state === "whole") {
        state = "decimal_point";
        value2 += c;
        continue;
      }
    }
    if (c === "E" || c == "e") {
      if (state === "whole" || state === "decimal_point" || state === "decimal") {
        state = "e";
        value2 += c;
        continue;
      }
    }
    break;
  }
  const number2 = Number.parseFloat(value2);
  if (Number.isNaN(number2)) {
    return [cursor, null];
  } else {
    return [i - 1, number2];
  }
};
const parsePathData$3 = (string2) => {
  const pathData = [];
  let command = null;
  let args = [];
  let argsCount = 0;
  let canHaveComma = false;
  let hadComma = false;
  for (let i = 0; i < string2.length; i += 1) {
    const c = string2.charAt(i);
    if (isWsp(c)) {
      continue;
    }
    if (canHaveComma && c === ",") {
      if (hadComma) {
        break;
      }
      hadComma = true;
      continue;
    }
    if (isCommand(c)) {
      if (hadComma) {
        return pathData;
      }
      if (command == null) {
        if (c !== "M" && c !== "m") {
          return pathData;
        }
      } else {
        if (args.length !== 0) {
          return pathData;
        }
      }
      command = c;
      args = [];
      argsCount = argsCountPerCommand[command];
      canHaveComma = false;
      if (argsCount === 0) {
        pathData.push({ command, args });
      }
      continue;
    }
    if (command == null) {
      return pathData;
    }
    let newCursor = i;
    let number2 = null;
    if (command === "A" || command === "a") {
      const position = args.length;
      if (position === 0 || position === 1) {
        if (c !== "+" && c !== "-") {
          [newCursor, number2] = readNumber(string2, i);
        }
      }
      if (position === 2 || position === 5 || position === 6) {
        [newCursor, number2] = readNumber(string2, i);
      }
      if (position === 3 || position === 4) {
        if (c === "0") {
          number2 = 0;
        }
        if (c === "1") {
          number2 = 1;
        }
      }
    } else {
      [newCursor, number2] = readNumber(string2, i);
    }
    if (number2 == null) {
      return pathData;
    }
    args.push(number2);
    canHaveComma = true;
    hadComma = false;
    i = newCursor;
    if (args.length === argsCount) {
      pathData.push({ command, args });
      if (command === "M") {
        command = "L";
      }
      if (command === "m") {
        command = "l";
      }
      args = [];
    }
  }
  return pathData;
};
path.parsePathData = parsePathData$3;
const stringifyNumber = (number2, precision2) => {
  if (precision2 != null) {
    const ratio = 10 ** precision2;
    number2 = Math.round(number2 * ratio) / ratio;
  }
  return number2.toString().replace(/^0\./, ".").replace(/^-0\./, "-.");
};
const stringifyArgs = (command, args, precision2, disableSpaceAfterFlags) => {
  let result = "";
  let prev = "";
  for (let i = 0; i < args.length; i += 1) {
    const number2 = args[i];
    const numberString = stringifyNumber(number2, precision2);
    if (disableSpaceAfterFlags && (command === "A" || command === "a") && (i % 7 === 4 || i % 7 === 5)) {
      result += numberString;
    } else if (i === 0 || numberString.startsWith("-")) {
      result += numberString;
    } else if (prev.includes(".") && numberString.startsWith(".")) {
      result += numberString;
    } else {
      result += ` ${numberString}`;
    }
    prev = numberString;
  }
  return result;
};
const stringifyPathData$2 = ({ pathData, precision: precision2, disableSpaceAfterFlags }) => {
  let combined = [];
  for (let i = 0; i < pathData.length; i += 1) {
    const { command, args } = pathData[i];
    if (i === 0) {
      combined.push({ command, args });
    } else {
      const last = combined[combined.length - 1];
      if (i === 1) {
        if (command === "L") {
          last.command = "M";
        }
        if (command === "l") {
          last.command = "m";
        }
      }
      if (last.command === command && last.command !== "M" && last.command !== "m" || last.command === "M" && command === "L" || last.command === "m" && command === "l") {
        last.args = [...last.args, ...args];
      } else {
        combined.push({ command, args });
      }
    }
  }
  let result = "";
  for (const { command, args } of combined) {
    result += command + stringifyArgs(command, args, precision2, disableSpaceAfterFlags);
  }
  return result;
};
path.stringifyPathData = stringifyPathData$2;
const {
  visit: visit$2,
  visitSkip: visitSkip$1,
  querySelector,
  detachNodeFromParent: detachNodeFromParent$b
} = xast;
const { collectStylesheet: collectStylesheet$3, computeStyle: computeStyle$3 } = style;
const { parsePathData: parsePathData$2 } = path;
removeHiddenElems$1.name = "removeHiddenElems";
removeHiddenElems$1.type = "visitor";
removeHiddenElems$1.active = true;
removeHiddenElems$1.description = "removes hidden elements (zero sized, with absent attributes)";
removeHiddenElems$1.fn = (root, params) => {
  const {
    isHidden = true,
    displayNone = true,
    opacity0 = true,
    circleR0 = true,
    ellipseRX0 = true,
    ellipseRY0 = true,
    rectWidth0 = true,
    rectHeight0 = true,
    patternWidth0 = true,
    patternHeight0 = true,
    imageWidth0 = true,
    imageHeight0 = true,
    pathEmptyD = true,
    polylineEmptyPoints = true,
    polygonEmptyPoints = true
  } = params;
  const stylesheet = collectStylesheet$3(root);
  visit$2(root, {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "clipPath") {
          return visitSkip$1;
        }
        const computedStyle = computeStyle$3(stylesheet, node2);
        if (opacity0 && computedStyle.opacity && computedStyle.opacity.type === "static" && computedStyle.opacity.value === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
      }
    }
  });
  return {
    element: {
      enter: (node2, parentNode) => {
        const computedStyle = computeStyle$3(stylesheet, node2);
        if (isHidden && computedStyle.visibility && computedStyle.visibility.type === "static" && computedStyle.visibility.value === "hidden" && querySelector(node2, "[visibility=visible]") == null) {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (displayNone && computedStyle.display && computedStyle.display.type === "static" && computedStyle.display.value === "none" && node2.name !== "marker") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (circleR0 && node2.name === "circle" && node2.children.length === 0 && node2.attributes.r === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (ellipseRX0 && node2.name === "ellipse" && node2.children.length === 0 && node2.attributes.rx === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (ellipseRY0 && node2.name === "ellipse" && node2.children.length === 0 && node2.attributes.ry === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (rectWidth0 && node2.name === "rect" && node2.children.length === 0 && node2.attributes.width === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (rectHeight0 && rectWidth0 && node2.name === "rect" && node2.children.length === 0 && node2.attributes.height === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (patternWidth0 && node2.name === "pattern" && node2.attributes.width === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (patternHeight0 && node2.name === "pattern" && node2.attributes.height === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (imageWidth0 && node2.name === "image" && node2.attributes.width === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (imageHeight0 && node2.name === "image" && node2.attributes.height === "0") {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (pathEmptyD && node2.name === "path") {
          if (node2.attributes.d == null) {
            detachNodeFromParent$b(node2, parentNode);
            return;
          }
          const pathData = parsePathData$2(node2.attributes.d);
          if (pathData.length === 0) {
            detachNodeFromParent$b(node2, parentNode);
            return;
          }
          if (pathData.length === 1 && computedStyle["marker-start"] == null && computedStyle["marker-end"] == null) {
            detachNodeFromParent$b(node2, parentNode);
            return;
          }
          return;
        }
        if (polylineEmptyPoints && node2.name === "polyline" && node2.attributes.points == null) {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
        if (polygonEmptyPoints && node2.name === "polygon" && node2.attributes.points == null) {
          detachNodeFromParent$b(node2, parentNode);
          return;
        }
      }
    }
  };
};
var removeEmptyText$1 = {};
const { detachNodeFromParent: detachNodeFromParent$a } = xast;
removeEmptyText$1.name = "removeEmptyText";
removeEmptyText$1.type = "visitor";
removeEmptyText$1.active = true;
removeEmptyText$1.description = "removes empty <text> elements";
removeEmptyText$1.fn = (root, params) => {
  const { text = true, tspan = true, tref = true } = params;
  return {
    element: {
      enter: (node2, parentNode) => {
        if (text && node2.name === "text" && node2.children.length === 0) {
          detachNodeFromParent$a(node2, parentNode);
        }
        if (tspan && node2.name === "tspan" && node2.children.length === 0) {
          detachNodeFromParent$a(node2, parentNode);
        }
        if (tref && node2.name === "tref" && node2.attributes["xlink:href"] == null) {
          detachNodeFromParent$a(node2, parentNode);
        }
      }
    }
  };
};
var convertShapeToPath$1 = {};
const { stringifyPathData: stringifyPathData$1 } = path;
const { detachNodeFromParent: detachNodeFromParent$9 } = xast;
convertShapeToPath$1.name = "convertShapeToPath";
convertShapeToPath$1.type = "visitor";
convertShapeToPath$1.active = true;
convertShapeToPath$1.description = "converts basic shapes to more compact path form";
const regNumber = /[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g;
convertShapeToPath$1.fn = (root, params) => {
  const { convertArcs = false, floatPrecision: precision2 } = params;
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "rect" && node2.attributes.width != null && node2.attributes.height != null && node2.attributes.rx == null && node2.attributes.ry == null) {
          const x = Number(node2.attributes.x || "0");
          const y = Number(node2.attributes.y || "0");
          const width = Number(node2.attributes.width);
          const height = Number(node2.attributes.height);
          if (Number.isNaN(x - y + width - height))
            return;
          const pathData = [
            { command: "M", args: [x, y] },
            { command: "H", args: [x + width] },
            { command: "V", args: [y + height] },
            { command: "H", args: [x] },
            { command: "z", args: [] }
          ];
          node2.name = "path";
          node2.attributes.d = stringifyPathData$1({ pathData, precision: precision2 });
          delete node2.attributes.x;
          delete node2.attributes.y;
          delete node2.attributes.width;
          delete node2.attributes.height;
        }
        if (node2.name === "line") {
          const x1 = Number(node2.attributes.x1 || "0");
          const y1 = Number(node2.attributes.y1 || "0");
          const x2 = Number(node2.attributes.x2 || "0");
          const y2 = Number(node2.attributes.y2 || "0");
          if (Number.isNaN(x1 - y1 + x2 - y2))
            return;
          const pathData = [
            { command: "M", args: [x1, y1] },
            { command: "L", args: [x2, y2] }
          ];
          node2.name = "path";
          node2.attributes.d = stringifyPathData$1({ pathData, precision: precision2 });
          delete node2.attributes.x1;
          delete node2.attributes.y1;
          delete node2.attributes.x2;
          delete node2.attributes.y2;
        }
        if ((node2.name === "polyline" || node2.name === "polygon") && node2.attributes.points != null) {
          const coords = (node2.attributes.points.match(regNumber) || []).map(
            Number
          );
          if (coords.length < 4) {
            detachNodeFromParent$9(node2, parentNode);
            return;
          }
          const pathData = [];
          for (let i = 0; i < coords.length; i += 2) {
            pathData.push({
              command: i === 0 ? "M" : "L",
              args: coords.slice(i, i + 2)
            });
          }
          if (node2.name === "polygon") {
            pathData.push({ command: "z", args: [] });
          }
          node2.name = "path";
          node2.attributes.d = stringifyPathData$1({ pathData, precision: precision2 });
          delete node2.attributes.points;
        }
        if (node2.name === "circle" && convertArcs) {
          const cx = Number(node2.attributes.cx || "0");
          const cy = Number(node2.attributes.cy || "0");
          const r = Number(node2.attributes.r || "0");
          if (Number.isNaN(cx - cy + r)) {
            return;
          }
          const pathData = [
            { command: "M", args: [cx, cy - r] },
            { command: "A", args: [r, r, 0, 1, 0, cx, cy + r] },
            { command: "A", args: [r, r, 0, 1, 0, cx, cy - r] },
            { command: "z", args: [] }
          ];
          node2.name = "path";
          node2.attributes.d = stringifyPathData$1({ pathData, precision: precision2 });
          delete node2.attributes.cx;
          delete node2.attributes.cy;
          delete node2.attributes.r;
        }
        if (node2.name === "ellipse" && convertArcs) {
          const ecx = Number(node2.attributes.cx || "0");
          const ecy = Number(node2.attributes.cy || "0");
          const rx = Number(node2.attributes.rx || "0");
          const ry = Number(node2.attributes.ry || "0");
          if (Number.isNaN(ecx - ecy + rx - ry)) {
            return;
          }
          const pathData = [
            { command: "M", args: [ecx, ecy - ry] },
            { command: "A", args: [rx, ry, 0, 1, 0, ecx, ecy + ry] },
            { command: "A", args: [rx, ry, 0, 1, 0, ecx, ecy - ry] },
            { command: "z", args: [] }
          ];
          node2.name = "path";
          node2.attributes.d = stringifyPathData$1({ pathData, precision: precision2 });
          delete node2.attributes.cx;
          delete node2.attributes.cy;
          delete node2.attributes.rx;
          delete node2.attributes.ry;
        }
      }
    }
  };
};
var convertEllipseToCircle$1 = {};
convertEllipseToCircle$1.name = "convertEllipseToCircle";
convertEllipseToCircle$1.type = "visitor";
convertEllipseToCircle$1.active = true;
convertEllipseToCircle$1.description = "converts non-eccentric <ellipse>s to <circle>s";
convertEllipseToCircle$1.fn = () => {
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "ellipse") {
          const rx = node2.attributes.rx || "0";
          const ry = node2.attributes.ry || "0";
          if (rx === ry || rx === "auto" || ry === "auto") {
            node2.name = "circle";
            const radius = rx === "auto" ? ry : rx;
            delete node2.attributes.rx;
            delete node2.attributes.ry;
            node2.attributes.r = radius;
          }
        }
      }
    }
  };
};
var moveElemsAttrsToGroup$1 = {};
const { visit: visit$1 } = xast;
const { inheritableAttrs: inheritableAttrs$1, pathElems: pathElems$2 } = _collections;
moveElemsAttrsToGroup$1.type = "visitor";
moveElemsAttrsToGroup$1.name = "moveElemsAttrsToGroup";
moveElemsAttrsToGroup$1.active = true;
moveElemsAttrsToGroup$1.description = "Move common attributes of group children to the group";
moveElemsAttrsToGroup$1.fn = (root) => {
  let deoptimizedWithStyles = false;
  visit$1(root, {
    element: {
      enter: (node2) => {
        if (node2.name === "style") {
          deoptimizedWithStyles = true;
        }
      }
    }
  });
  return {
    element: {
      exit: (node2) => {
        if (node2.name !== "g" || node2.children.length <= 1) {
          return;
        }
        if (deoptimizedWithStyles) {
          return;
        }
        const commonAttributes = /* @__PURE__ */ new Map();
        let initial = true;
        let everyChildIsPath = true;
        for (const child of node2.children) {
          if (child.type === "element") {
            if (pathElems$2.includes(child.name) === false) {
              everyChildIsPath = false;
            }
            if (initial) {
              initial = false;
              for (const [name2, value2] of Object.entries(child.attributes)) {
                if (inheritableAttrs$1.includes(name2)) {
                  commonAttributes.set(name2, value2);
                }
              }
            } else {
              for (const [name2, value2] of commonAttributes) {
                if (child.attributes[name2] !== value2) {
                  commonAttributes.delete(name2);
                }
              }
            }
          }
        }
        if (node2.attributes["clip-path"] != null || node2.attributes.mask != null) {
          commonAttributes.delete("transform");
        }
        if (everyChildIsPath) {
          commonAttributes.delete("transform");
        }
        for (const [name2, value2] of commonAttributes) {
          if (name2 === "transform") {
            if (node2.attributes.transform != null) {
              node2.attributes.transform = `${node2.attributes.transform} ${value2}`;
            } else {
              node2.attributes.transform = value2;
            }
          } else {
            node2.attributes[name2] = value2;
          }
        }
        for (const child of node2.children) {
          if (child.type === "element") {
            for (const [name2] of commonAttributes) {
              delete child.attributes[name2];
            }
          }
        }
      }
    }
  };
};
var moveGroupAttrsToElems$1 = {};
const { pathElems: pathElems$1, referencesProps: referencesProps$2 } = _collections;
moveGroupAttrsToElems$1.type = "visitor";
moveGroupAttrsToElems$1.name = "moveGroupAttrsToElems";
moveGroupAttrsToElems$1.active = true;
moveGroupAttrsToElems$1.description = "moves some group attributes to the content elements";
const pathElemsWithGroupsAndText = [...pathElems$1, "g", "text"];
moveGroupAttrsToElems$1.fn = () => {
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "g" && node2.children.length !== 0 && node2.attributes.transform != null && Object.entries(node2.attributes).some(
          ([name2, value2]) => referencesProps$2.includes(name2) && value2.includes("url(")
        ) === false && node2.children.every(
          (child) => child.type === "element" && pathElemsWithGroupsAndText.includes(child.name) && child.attributes.id == null
        )) {
          for (const child of node2.children) {
            const value2 = node2.attributes.transform;
            if (child.type === "element") {
              if (child.attributes.transform != null) {
                child.attributes.transform = `${value2} ${child.attributes.transform}`;
              } else {
                child.attributes.transform = value2;
              }
            }
          }
          delete node2.attributes.transform;
        }
      }
    }
  };
};
var collapseGroups$1 = {};
const { inheritableAttrs, elemsGroups: elemsGroups$1 } = _collections;
collapseGroups$1.type = "visitor";
collapseGroups$1.name = "collapseGroups";
collapseGroups$1.active = true;
collapseGroups$1.description = "collapses useless groups";
const hasAnimatedAttr = (node2, name2) => {
  if (node2.type === "element") {
    if (elemsGroups$1.animation.includes(node2.name) && node2.attributes.attributeName === name2) {
      return true;
    }
    for (const child of node2.children) {
      if (hasAnimatedAttr(child, name2)) {
        return true;
      }
    }
  }
  return false;
};
collapseGroups$1.fn = () => {
  return {
    element: {
      exit: (node2, parentNode) => {
        if (parentNode.type === "root" || parentNode.name === "switch") {
          return;
        }
        if (node2.name !== "g" || node2.children.length === 0) {
          return;
        }
        if (Object.keys(node2.attributes).length !== 0 && node2.children.length === 1) {
          const firstChild = node2.children[0];
          if (firstChild.type === "element" && firstChild.attributes.id == null && node2.attributes.filter == null && (node2.attributes.class == null || firstChild.attributes.class == null) && (node2.attributes["clip-path"] == null && node2.attributes.mask == null || firstChild.name === "g" && node2.attributes.transform == null && firstChild.attributes.transform == null)) {
            for (const [name2, value2] of Object.entries(node2.attributes)) {
              if (hasAnimatedAttr(firstChild, name2)) {
                return;
              }
              if (firstChild.attributes[name2] == null) {
                firstChild.attributes[name2] = value2;
              } else if (name2 === "transform") {
                firstChild.attributes[name2] = value2 + " " + firstChild.attributes[name2];
              } else if (firstChild.attributes[name2] === "inherit") {
                firstChild.attributes[name2] = value2;
              } else if (inheritableAttrs.includes(name2) === false && firstChild.attributes[name2] !== value2) {
                return;
              }
              delete node2.attributes[name2];
            }
          }
        }
        if (Object.keys(node2.attributes).length === 0) {
          for (const child of node2.children) {
            if (child.type === "element" && elemsGroups$1.animation.includes(child.name)) {
              return;
            }
          }
          const index2 = parentNode.children.indexOf(node2);
          parentNode.children.splice(index2, 1, ...node2.children);
          for (const child of node2.children) {
            Object.defineProperty(child, "parentNode", {
              writable: true,
              value: parentNode
            });
          }
        }
      }
    }
  };
};
var convertPathData$1 = {};
var _path = {};
const { parsePathData: parsePathData$1, stringifyPathData } = path;
var prevCtrlPoint;
const path2js$3 = (path2) => {
  if (path2.pathJS)
    return path2.pathJS;
  const pathData = [];
  const newPathData = parsePathData$1(path2.attributes.d);
  for (const { command, args } of newPathData) {
    pathData.push({ command, args });
  }
  if (pathData.length && pathData[0].command == "m") {
    pathData[0].command = "M";
  }
  path2.pathJS = pathData;
  return pathData;
};
_path.path2js = path2js$3;
const convertRelativeToAbsolute = (data2) => {
  const newData = [];
  let start = [0, 0];
  let cursor = [0, 0];
  for (let { command, args } of data2) {
    args = args.slice();
    if (command === "m") {
      args[0] += cursor[0];
      args[1] += cursor[1];
      command = "M";
    }
    if (command === "M") {
      cursor[0] = args[0];
      cursor[1] = args[1];
      start[0] = cursor[0];
      start[1] = cursor[1];
    }
    if (command === "h") {
      args[0] += cursor[0];
      command = "H";
    }
    if (command === "H") {
      cursor[0] = args[0];
    }
    if (command === "v") {
      args[0] += cursor[1];
      command = "V";
    }
    if (command === "V") {
      cursor[1] = args[0];
    }
    if (command === "l") {
      args[0] += cursor[0];
      args[1] += cursor[1];
      command = "L";
    }
    if (command === "L") {
      cursor[0] = args[0];
      cursor[1] = args[1];
    }
    if (command === "c") {
      args[0] += cursor[0];
      args[1] += cursor[1];
      args[2] += cursor[0];
      args[3] += cursor[1];
      args[4] += cursor[0];
      args[5] += cursor[1];
      command = "C";
    }
    if (command === "C") {
      cursor[0] = args[4];
      cursor[1] = args[5];
    }
    if (command === "s") {
      args[0] += cursor[0];
      args[1] += cursor[1];
      args[2] += cursor[0];
      args[3] += cursor[1];
      command = "S";
    }
    if (command === "S") {
      cursor[0] = args[2];
      cursor[1] = args[3];
    }
    if (command === "q") {
      args[0] += cursor[0];
      args[1] += cursor[1];
      args[2] += cursor[0];
      args[3] += cursor[1];
      command = "Q";
    }
    if (command === "Q") {
      cursor[0] = args[2];
      cursor[1] = args[3];
    }
    if (command === "t") {
      args[0] += cursor[0];
      args[1] += cursor[1];
      command = "T";
    }
    if (command === "T") {
      cursor[0] = args[0];
      cursor[1] = args[1];
    }
    if (command === "a") {
      args[5] += cursor[0];
      args[6] += cursor[1];
      command = "A";
    }
    if (command === "A") {
      cursor[0] = args[5];
      cursor[1] = args[6];
    }
    if (command === "z" || command === "Z") {
      cursor[0] = start[0];
      cursor[1] = start[1];
      command = "z";
    }
    newData.push({ command, args });
  }
  return newData;
};
_path.js2path = function(path2, data2, params) {
  path2.pathJS = data2;
  const pathData = [];
  for (const item of data2) {
    if (pathData.length !== 0 && (item.command === "M" || item.command === "m")) {
      const last = pathData[pathData.length - 1];
      if (last.command === "M" || last.command === "m") {
        pathData.pop();
      }
    }
    pathData.push({
      command: item.command,
      args: item.args
    });
  }
  path2.attributes.d = stringifyPathData({
    pathData,
    precision: params.floatPrecision,
    disableSpaceAfterFlags: params.noSpaceAfterFlags
  });
};
function set(dest, source) {
  dest[0] = source[source.length - 2];
  dest[1] = source[source.length - 1];
  return dest;
}
_path.intersects = function(path1, path2) {
  const points1 = gatherPoints(convertRelativeToAbsolute(path1));
  const points2 = gatherPoints(convertRelativeToAbsolute(path2));
  if (points1.maxX <= points2.minX || points2.maxX <= points1.minX || points1.maxY <= points2.minY || points2.maxY <= points1.minY || points1.list.every((set1) => {
    return points2.list.every((set2) => {
      return set1.list[set1.maxX][0] <= set2.list[set2.minX][0] || set2.list[set2.maxX][0] <= set1.list[set1.minX][0] || set1.list[set1.maxY][1] <= set2.list[set2.minY][1] || set2.list[set2.maxY][1] <= set1.list[set1.minY][1];
    });
  }))
    return false;
  const hullNest1 = points1.list.map(convexHull);
  const hullNest2 = points2.list.map(convexHull);
  return hullNest1.some(function(hull1) {
    if (hull1.list.length < 3)
      return false;
    return hullNest2.some(function(hull2) {
      if (hull2.list.length < 3)
        return false;
      var simplex = [getSupport(hull1, hull2, [1, 0])], direction = minus(simplex[0]);
      var iterations = 1e4;
      while (true) {
        if (iterations-- == 0) {
          console.error(
            "Error: infinite loop while processing mergePaths plugin."
          );
          return true;
        }
        simplex.push(getSupport(hull1, hull2, direction));
        if (dot(direction, simplex[simplex.length - 1]) <= 0)
          return false;
        if (processSimplex(simplex, direction))
          return true;
      }
    });
  });
  function getSupport(a, b, direction) {
    return sub(supportPoint(a, direction), supportPoint(b, minus(direction)));
  }
  function supportPoint(polygon, direction) {
    var index2 = direction[1] >= 0 ? direction[0] < 0 ? polygon.maxY : polygon.maxX : direction[0] < 0 ? polygon.minX : polygon.minY, max = -Infinity, value2;
    while ((value2 = dot(polygon.list[index2], direction)) > max) {
      max = value2;
      index2 = ++index2 % polygon.list.length;
    }
    return polygon.list[(index2 || polygon.list.length) - 1];
  }
};
function processSimplex(simplex, direction) {
  if (simplex.length == 2) {
    let a = simplex[1], b = simplex[0], AO = minus(simplex[1]), AB = sub(b, a);
    if (dot(AO, AB) > 0) {
      set(direction, orth(AB, a));
    } else {
      set(direction, AO);
      simplex.shift();
    }
  } else {
    let a = simplex[2], b = simplex[1], c = simplex[0], AB = sub(b, a), AC = sub(c, a), AO = minus(a), ACB = orth(AB, AC), ABC = orth(AC, AB);
    if (dot(ACB, AO) > 0) {
      if (dot(AB, AO) > 0) {
        set(direction, ACB);
        simplex.shift();
      } else {
        set(direction, AO);
        simplex.splice(0, 2);
      }
    } else if (dot(ABC, AO) > 0) {
      if (dot(AC, AO) > 0) {
        set(direction, ABC);
        simplex.splice(1, 1);
      } else {
        set(direction, AO);
        simplex.splice(0, 2);
      }
    } else
      return true;
  }
  return false;
}
function minus(v) {
  return [-v[0], -v[1]];
}
function sub(v1, v2) {
  return [v1[0] - v2[0], v1[1] - v2[1]];
}
function dot(v1, v2) {
  return v1[0] * v2[0] + v1[1] * v2[1];
}
function orth(v, from) {
  var o = [-v[1], v[0]];
  return dot(o, minus(from)) < 0 ? minus(o) : o;
}
function gatherPoints(pathData) {
  const points = { list: [], minX: 0, minY: 0, maxX: 0, maxY: 0 };
  const addPoint = (path2, point) => {
    if (!path2.list.length || point[1] > path2.list[path2.maxY][1]) {
      path2.maxY = path2.list.length;
      points.maxY = points.list.length ? Math.max(point[1], points.maxY) : point[1];
    }
    if (!path2.list.length || point[0] > path2.list[path2.maxX][0]) {
      path2.maxX = path2.list.length;
      points.maxX = points.list.length ? Math.max(point[0], points.maxX) : point[0];
    }
    if (!path2.list.length || point[1] < path2.list[path2.minY][1]) {
      path2.minY = path2.list.length;
      points.minY = points.list.length ? Math.min(point[1], points.minY) : point[1];
    }
    if (!path2.list.length || point[0] < path2.list[path2.minX][0]) {
      path2.minX = path2.list.length;
      points.minX = points.list.length ? Math.min(point[0], points.minX) : point[0];
    }
    path2.list.push(point);
  };
  for (let i = 0; i < pathData.length; i += 1) {
    const pathDataItem = pathData[i];
    let subPath = points.list.length === 0 ? { list: [], minX: 0, minY: 0, maxX: 0, maxY: 0 } : points.list[points.list.length - 1];
    let prev = i === 0 ? null : pathData[i - 1];
    let basePoint = subPath.list.length === 0 ? null : subPath.list[subPath.list.length - 1];
    let data2 = pathDataItem.args;
    let ctrlPoint = basePoint;
    const toAbsolute = (n, i2) => n + (basePoint == null ? 0 : basePoint[i2 % 2]);
    switch (pathDataItem.command) {
      case "M":
        subPath = { list: [], minX: 0, minY: 0, maxX: 0, maxY: 0 };
        points.list.push(subPath);
        break;
      case "H":
        if (basePoint != null) {
          addPoint(subPath, [data2[0], basePoint[1]]);
        }
        break;
      case "V":
        if (basePoint != null) {
          addPoint(subPath, [basePoint[0], data2[0]]);
        }
        break;
      case "Q":
        addPoint(subPath, data2.slice(0, 2));
        prevCtrlPoint = [data2[2] - data2[0], data2[3] - data2[1]];
        break;
      case "T":
        if (basePoint != null && prev != null && (prev.command == "Q" || prev.command == "T")) {
          ctrlPoint = [
            basePoint[0] + prevCtrlPoint[0],
            basePoint[1] + prevCtrlPoint[1]
          ];
          addPoint(subPath, ctrlPoint);
          prevCtrlPoint = [data2[0] - ctrlPoint[0], data2[1] - ctrlPoint[1]];
        }
        break;
      case "C":
        if (basePoint != null) {
          addPoint(subPath, [
            0.5 * (basePoint[0] + data2[0]),
            0.5 * (basePoint[1] + data2[1])
          ]);
        }
        addPoint(subPath, [
          0.5 * (data2[0] + data2[2]),
          0.5 * (data2[1] + data2[3])
        ]);
        addPoint(subPath, [
          0.5 * (data2[2] + data2[4]),
          0.5 * (data2[3] + data2[5])
        ]);
        prevCtrlPoint = [data2[4] - data2[2], data2[5] - data2[3]];
        break;
      case "S":
        if (basePoint != null && prev != null && (prev.command == "C" || prev.command == "S")) {
          addPoint(subPath, [
            basePoint[0] + 0.5 * prevCtrlPoint[0],
            basePoint[1] + 0.5 * prevCtrlPoint[1]
          ]);
          ctrlPoint = [
            basePoint[0] + prevCtrlPoint[0],
            basePoint[1] + prevCtrlPoint[1]
          ];
        }
        if (ctrlPoint != null) {
          addPoint(subPath, [
            0.5 * (ctrlPoint[0] + data2[0]),
            0.5 * (ctrlPoint[1] + data2[1])
          ]);
        }
        addPoint(subPath, [
          0.5 * (data2[0] + data2[2]),
          0.5 * (data2[1] + data2[3])
        ]);
        prevCtrlPoint = [data2[2] - data2[0], data2[3] - data2[1]];
        break;
      case "A":
        if (basePoint != null) {
          var curves = a2c.apply(0, basePoint.concat(data2));
          for (var cData; (cData = curves.splice(0, 6).map(toAbsolute)).length; ) {
            if (basePoint != null) {
              addPoint(subPath, [
                0.5 * (basePoint[0] + cData[0]),
                0.5 * (basePoint[1] + cData[1])
              ]);
            }
            addPoint(subPath, [
              0.5 * (cData[0] + cData[2]),
              0.5 * (cData[1] + cData[3])
            ]);
            addPoint(subPath, [
              0.5 * (cData[2] + cData[4]),
              0.5 * (cData[3] + cData[5])
            ]);
            if (curves.length)
              addPoint(subPath, basePoint = cData.slice(-2));
          }
        }
        break;
    }
    if (data2.length >= 2)
      addPoint(subPath, data2.slice(-2));
  }
  return points;
}
function convexHull(points) {
  points.list.sort(function(a, b) {
    return a[0] == b[0] ? a[1] - b[1] : a[0] - b[0];
  });
  var lower = [], minY = 0, bottom = 0;
  for (let i = 0; i < points.list.length; i++) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], points.list[i]) <= 0) {
      lower.pop();
    }
    if (points.list[i][1] < points.list[minY][1]) {
      minY = i;
      bottom = lower.length;
    }
    lower.push(points.list[i]);
  }
  var upper = [], maxY = points.list.length - 1, top = 0;
  for (let i = points.list.length; i--; ) {
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], points.list[i]) <= 0) {
      upper.pop();
    }
    if (points.list[i][1] > points.list[maxY][1]) {
      maxY = i;
      top = upper.length;
    }
    upper.push(points.list[i]);
  }
  upper.pop();
  lower.pop();
  const hullList = lower.concat(upper);
  const hull = {
    list: hullList,
    minX: 0,
    maxX: lower.length,
    minY: bottom,
    maxY: (lower.length + top) % hullList.length
  };
  return hull;
}
function cross(o, a, b) {
  return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
}
const a2c = (x1, y1, rx, ry, angle, large_arc_flag, sweep_flag, x2, y2, recursive) => {
  const _120 = Math.PI * 120 / 180;
  const rad = Math.PI / 180 * (+angle || 0);
  let res = [];
  const rotateX = (x3, y3, rad2) => {
    return x3 * Math.cos(rad2) - y3 * Math.sin(rad2);
  };
  const rotateY = (x3, y3, rad2) => {
    return x3 * Math.sin(rad2) + y3 * Math.cos(rad2);
  };
  if (!recursive) {
    x1 = rotateX(x1, y1, -rad);
    y1 = rotateY(x1, y1, -rad);
    x2 = rotateX(x2, y2, -rad);
    y2 = rotateY(x2, y2, -rad);
    var x = (x1 - x2) / 2, y = (y1 - y2) / 2;
    var h = x * x / (rx * rx) + y * y / (ry * ry);
    if (h > 1) {
      h = Math.sqrt(h);
      rx = h * rx;
      ry = h * ry;
    }
    var rx2 = rx * rx;
    var ry2 = ry * ry;
    var k = (large_arc_flag == sweep_flag ? -1 : 1) * Math.sqrt(
      Math.abs(
        (rx2 * ry2 - rx2 * y * y - ry2 * x * x) / (rx2 * y * y + ry2 * x * x)
      )
    );
    var cx = k * rx * y / ry + (x1 + x2) / 2;
    var cy = k * -ry * x / rx + (y1 + y2) / 2;
    var f1 = Math.asin(Number(((y1 - cy) / ry).toFixed(9)));
    var f2 = Math.asin(Number(((y2 - cy) / ry).toFixed(9)));
    f1 = x1 < cx ? Math.PI - f1 : f1;
    f2 = x2 < cx ? Math.PI - f2 : f2;
    f1 < 0 && (f1 = Math.PI * 2 + f1);
    f2 < 0 && (f2 = Math.PI * 2 + f2);
    if (sweep_flag && f1 > f2) {
      f1 = f1 - Math.PI * 2;
    }
    if (!sweep_flag && f2 > f1) {
      f2 = f2 - Math.PI * 2;
    }
  } else {
    f1 = recursive[0];
    f2 = recursive[1];
    cx = recursive[2];
    cy = recursive[3];
  }
  var df = f2 - f1;
  if (Math.abs(df) > _120) {
    var f2old = f2, x2old = x2, y2old = y2;
    f2 = f1 + _120 * (sweep_flag && f2 > f1 ? 1 : -1);
    x2 = cx + rx * Math.cos(f2);
    y2 = cy + ry * Math.sin(f2);
    res = a2c(x2, y2, rx, ry, angle, 0, sweep_flag, x2old, y2old, [
      f2,
      f2old,
      cx,
      cy
    ]);
  }
  df = f2 - f1;
  var c1 = Math.cos(f1), s1 = Math.sin(f1), c2 = Math.cos(f2), s2 = Math.sin(f2), t = Math.tan(df / 4), hx = 4 / 3 * rx * t, hy = 4 / 3 * ry * t, m = [
    -hx * s1,
    hy * c1,
    x2 + hx * s2 - x1,
    y2 - hy * c2 - y1,
    x2 - x1,
    y2 - y1
  ];
  if (recursive) {
    return m.concat(res);
  } else {
    res = m.concat(res);
    var newres = [];
    for (var i = 0, n = res.length; i < n; i++) {
      newres[i] = i % 2 ? rotateY(res[i - 1], res[i], rad) : rotateX(res[i], res[i + 1], rad);
    }
    return newres;
  }
};
var applyTransforms$2 = {};
var _transforms = {};
const regTransformTypes = /matrix|translate|scale|rotate|skewX|skewY/;
const regTransformSplit = /\s*(matrix|translate|scale|rotate|skewX|skewY)\s*\(\s*(.+?)\s*\)[\s,]*/;
const regNumericValues$2 = /[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g;
_transforms.transform2js = (transformString) => {
  const transforms = [];
  let current = null;
  for (const item of transformString.split(regTransformSplit)) {
    var num;
    if (item) {
      if (regTransformTypes.test(item)) {
        current = { name: item, data: [] };
        transforms.push(current);
      } else {
        while (num = regNumericValues$2.exec(item)) {
          num = Number(num);
          if (current != null) {
            current.data.push(num);
          }
        }
      }
    }
  }
  return current == null || current.data.length == 0 ? [] : transforms;
};
_transforms.transformsMultiply = (transforms) => {
  const matrixData = transforms.map((transform) => {
    if (transform.name === "matrix") {
      return transform.data;
    }
    return transformToMatrix(transform);
  });
  const matrixTransform = {
    name: "matrix",
    data: matrixData.length > 0 ? matrixData.reduce(multiplyTransformMatrices) : []
  };
  return matrixTransform;
};
const mth = {
  rad: (deg) => {
    return deg * Math.PI / 180;
  },
  deg: (rad) => {
    return rad * 180 / Math.PI;
  },
  cos: (deg) => {
    return Math.cos(mth.rad(deg));
  },
  acos: (val, floatPrecision) => {
    return Number(mth.deg(Math.acos(val)).toFixed(floatPrecision));
  },
  sin: (deg) => {
    return Math.sin(mth.rad(deg));
  },
  asin: (val, floatPrecision) => {
    return Number(mth.deg(Math.asin(val)).toFixed(floatPrecision));
  },
  tan: (deg) => {
    return Math.tan(mth.rad(deg));
  },
  atan: (val, floatPrecision) => {
    return Number(mth.deg(Math.atan(val)).toFixed(floatPrecision));
  }
};
_transforms.matrixToTransform = (transform, params) => {
  let floatPrecision = params.floatPrecision;
  let data2 = transform.data;
  let transforms = [];
  let sx = Number(
    Math.hypot(data2[0], data2[1]).toFixed(params.transformPrecision)
  );
  let sy = Number(
    ((data2[0] * data2[3] - data2[1] * data2[2]) / sx).toFixed(
      params.transformPrecision
    )
  );
  let colsSum = data2[0] * data2[2] + data2[1] * data2[3];
  let rowsSum = data2[0] * data2[1] + data2[2] * data2[3];
  let scaleBefore = rowsSum != 0 || sx == sy;
  if (data2[4] || data2[5]) {
    transforms.push({
      name: "translate",
      data: data2.slice(4, data2[5] ? 6 : 5)
    });
  }
  if (!data2[1] && data2[2]) {
    transforms.push({
      name: "skewX",
      data: [mth.atan(data2[2] / sy, floatPrecision)]
    });
  } else if (data2[1] && !data2[2]) {
    transforms.push({
      name: "skewY",
      data: [mth.atan(data2[1] / data2[0], floatPrecision)]
    });
    sx = data2[0];
    sy = data2[3];
  } else if (!colsSum || sx == 1 && sy == 1 || !scaleBefore) {
    if (!scaleBefore) {
      sx = (data2[0] < 0 ? -1 : 1) * Math.hypot(data2[0], data2[2]);
      sy = (data2[3] < 0 ? -1 : 1) * Math.hypot(data2[1], data2[3]);
      transforms.push({ name: "scale", data: [sx, sy] });
    }
    var angle = Math.min(Math.max(-1, data2[0] / sx), 1), rotate = [
      mth.acos(angle, floatPrecision) * ((scaleBefore ? 1 : sy) * data2[1] < 0 ? -1 : 1)
    ];
    if (rotate[0])
      transforms.push({ name: "rotate", data: rotate });
    if (rowsSum && colsSum)
      transforms.push({
        name: "skewX",
        data: [mth.atan(colsSum / (sx * sx), floatPrecision)]
      });
    if (rotate[0] && (data2[4] || data2[5])) {
      transforms.shift();
      var cos = data2[0] / sx, sin = data2[1] / (scaleBefore ? sx : sy), x = data2[4] * (scaleBefore ? 1 : sy), y = data2[5] * (scaleBefore ? 1 : sx), denom = (Math.pow(1 - cos, 2) + Math.pow(sin, 2)) * (scaleBefore ? 1 : sx * sy);
      rotate.push(((1 - cos) * x - sin * y) / denom);
      rotate.push(((1 - cos) * y + sin * x) / denom);
    }
  } else if (data2[1] || data2[2]) {
    return [transform];
  }
  if (scaleBefore && (sx != 1 || sy != 1) || !transforms.length)
    transforms.push({
      name: "scale",
      data: sx == sy ? [sx] : [sx, sy]
    });
  return transforms;
};
const transformToMatrix = (transform) => {
  if (transform.name === "matrix") {
    return transform.data;
  }
  switch (transform.name) {
    case "translate":
      return [1, 0, 0, 1, transform.data[0], transform.data[1] || 0];
    case "scale":
      return [
        transform.data[0],
        0,
        0,
        transform.data[1] || transform.data[0],
        0,
        0
      ];
    case "rotate":
      var cos = mth.cos(transform.data[0]), sin = mth.sin(transform.data[0]), cx = transform.data[1] || 0, cy = transform.data[2] || 0;
      return [
        cos,
        sin,
        -sin,
        cos,
        (1 - cos) * cx + sin * cy,
        (1 - cos) * cy - sin * cx
      ];
    case "skewX":
      return [1, 0, mth.tan(transform.data[0]), 1, 0, 0];
    case "skewY":
      return [1, mth.tan(transform.data[0]), 0, 1, 0, 0];
    default:
      throw Error(`Unknown transform ${transform.name}`);
  }
};
_transforms.transformArc = (cursor, arc, transform) => {
  const x = arc[5] - cursor[0];
  const y = arc[6] - cursor[1];
  let a = arc[0];
  let b = arc[1];
  const rot = arc[2] * Math.PI / 180;
  const cos = Math.cos(rot);
  const sin = Math.sin(rot);
  if (a > 0 && b > 0) {
    let h = Math.pow(x * cos + y * sin, 2) / (4 * a * a) + Math.pow(y * cos - x * sin, 2) / (4 * b * b);
    if (h > 1) {
      h = Math.sqrt(h);
      a *= h;
      b *= h;
    }
  }
  const ellipse = [a * cos, a * sin, -b * sin, b * cos, 0, 0];
  const m = multiplyTransformMatrices(transform, ellipse);
  const lastCol = m[2] * m[2] + m[3] * m[3];
  const squareSum = m[0] * m[0] + m[1] * m[1] + lastCol;
  const root = Math.hypot(m[0] - m[3], m[1] + m[2]) * Math.hypot(m[0] + m[3], m[1] - m[2]);
  if (!root) {
    arc[0] = arc[1] = Math.sqrt(squareSum / 2);
    arc[2] = 0;
  } else {
    const majorAxisSqr = (squareSum + root) / 2;
    const minorAxisSqr = (squareSum - root) / 2;
    const major = Math.abs(majorAxisSqr - lastCol) > 1e-6;
    const sub2 = (major ? majorAxisSqr : minorAxisSqr) - lastCol;
    const rowsSum = m[0] * m[2] + m[1] * m[3];
    const term1 = m[0] * sub2 + m[2] * rowsSum;
    const term2 = m[1] * sub2 + m[3] * rowsSum;
    arc[0] = Math.sqrt(majorAxisSqr);
    arc[1] = Math.sqrt(minorAxisSqr);
    arc[2] = ((major ? term2 < 0 : term1 > 0) ? -1 : 1) * Math.acos((major ? term1 : term2) / Math.hypot(term1, term2)) * 180 / Math.PI;
  }
  if (transform[0] < 0 !== transform[3] < 0) {
    arc[4] = 1 - arc[4];
  }
  return arc;
};
const multiplyTransformMatrices = (a, b) => {
  return [
    a[0] * b[0] + a[2] * b[1],
    a[1] * b[0] + a[3] * b[1],
    a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3],
    a[0] * b[4] + a[2] * b[5] + a[4],
    a[1] * b[4] + a[3] * b[5] + a[5]
  ];
};
const { collectStylesheet: collectStylesheet$2, computeStyle: computeStyle$2 } = style;
const {
  transformsMultiply: transformsMultiply$1,
  transform2js: transform2js$1,
  transformArc
} = _transforms;
const { path2js: path2js$2 } = _path;
const { removeLeadingZero: removeLeadingZero$1 } = tools;
const { referencesProps: referencesProps$1, attrsGroupsDefaults } = _collections;
const regNumericValues$1 = /[-+]?(\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g;
const applyTransforms$1 = (root, params) => {
  const stylesheet = collectStylesheet$2(root);
  return {
    element: {
      enter: (node2) => {
        const computedStyle = computeStyle$2(stylesheet, node2);
        if (node2.attributes.d == null) {
          return;
        }
        if (node2.attributes.id != null) {
          return;
        }
        if (node2.attributes.transform == null || node2.attributes.transform === "" || node2.attributes.style != null || Object.entries(node2.attributes).some(
          ([name2, value2]) => referencesProps$1.includes(name2) && value2.includes("url(")
        )) {
          return;
        }
        const matrix = transformsMultiply$1(
          transform2js$1(node2.attributes.transform)
        );
        const stroke = computedStyle.stroke != null && computedStyle.stroke.type === "static" ? computedStyle.stroke.value : null;
        const strokeWidth = computedStyle["stroke-width"] != null && computedStyle["stroke-width"].type === "static" ? computedStyle["stroke-width"].value : null;
        const transformPrecision = params.transformPrecision;
        if (computedStyle.stroke != null && computedStyle.stroke.type === "dynamic" || computedStyle.strokeWidth != null && computedStyle["stroke-width"].type === "dynamic") {
          return;
        }
        const scale = Number(
          Math.sqrt(
            matrix.data[0] * matrix.data[0] + matrix.data[1] * matrix.data[1]
          ).toFixed(transformPrecision)
        );
        if (stroke && stroke != "none") {
          if (params.applyTransformsStroked === false) {
            return;
          }
          if ((matrix.data[0] !== matrix.data[3] || matrix.data[1] !== -matrix.data[2]) && (matrix.data[0] !== -matrix.data[3] || matrix.data[1] !== matrix.data[2])) {
            return;
          }
          if (scale !== 1) {
            if (node2.attributes["vector-effect"] !== "non-scaling-stroke") {
              node2.attributes["stroke-width"] = (strokeWidth || attrsGroupsDefaults.presentation["stroke-width"]).trim().replace(
                regNumericValues$1,
                (num) => removeLeadingZero$1(Number(num) * scale)
              );
              if (node2.attributes["stroke-dashoffset"] != null) {
                node2.attributes["stroke-dashoffset"] = node2.attributes["stroke-dashoffset"].trim().replace(
                  regNumericValues$1,
                  (num) => removeLeadingZero$1(Number(num) * scale)
                );
              }
              if (node2.attributes["stroke-dasharray"] != null) {
                node2.attributes["stroke-dasharray"] = node2.attributes["stroke-dasharray"].trim().replace(
                  regNumericValues$1,
                  (num) => removeLeadingZero$1(Number(num) * scale)
                );
              }
            }
          }
        }
        const pathData = path2js$2(node2);
        applyMatrixToPathData(pathData, matrix.data);
        delete node2.attributes.transform;
      }
    }
  };
};
applyTransforms$2.applyTransforms = applyTransforms$1;
const transformAbsolutePoint = (matrix, x, y) => {
  const newX = matrix[0] * x + matrix[2] * y + matrix[4];
  const newY = matrix[1] * x + matrix[3] * y + matrix[5];
  return [newX, newY];
};
const transformRelativePoint = (matrix, x, y) => {
  const newX = matrix[0] * x + matrix[2] * y;
  const newY = matrix[1] * x + matrix[3] * y;
  return [newX, newY];
};
const applyMatrixToPathData = (pathData, matrix) => {
  const start = [0, 0];
  const cursor = [0, 0];
  for (const pathItem of pathData) {
    let { command, args } = pathItem;
    if (command === "M") {
      cursor[0] = args[0];
      cursor[1] = args[1];
      start[0] = cursor[0];
      start[1] = cursor[1];
      const [x, y] = transformAbsolutePoint(matrix, args[0], args[1]);
      args[0] = x;
      args[1] = y;
    }
    if (command === "m") {
      cursor[0] += args[0];
      cursor[1] += args[1];
      start[0] = cursor[0];
      start[1] = cursor[1];
      const [x, y] = transformRelativePoint(matrix, args[0], args[1]);
      args[0] = x;
      args[1] = y;
    }
    if (command === "H") {
      command = "L";
      args = [args[0], cursor[1]];
    }
    if (command === "h") {
      command = "l";
      args = [args[0], 0];
    }
    if (command === "V") {
      command = "L";
      args = [cursor[0], args[0]];
    }
    if (command === "v") {
      command = "l";
      args = [0, args[0]];
    }
    if (command === "L") {
      cursor[0] = args[0];
      cursor[1] = args[1];
      const [x, y] = transformAbsolutePoint(matrix, args[0], args[1]);
      args[0] = x;
      args[1] = y;
    }
    if (command === "l") {
      cursor[0] += args[0];
      cursor[1] += args[1];
      const [x, y] = transformRelativePoint(matrix, args[0], args[1]);
      args[0] = x;
      args[1] = y;
    }
    if (command === "C") {
      cursor[0] = args[4];
      cursor[1] = args[5];
      const [x1, y1] = transformAbsolutePoint(matrix, args[0], args[1]);
      const [x2, y2] = transformAbsolutePoint(matrix, args[2], args[3]);
      const [x, y] = transformAbsolutePoint(matrix, args[4], args[5]);
      args[0] = x1;
      args[1] = y1;
      args[2] = x2;
      args[3] = y2;
      args[4] = x;
      args[5] = y;
    }
    if (command === "c") {
      cursor[0] += args[4];
      cursor[1] += args[5];
      const [x1, y1] = transformRelativePoint(matrix, args[0], args[1]);
      const [x2, y2] = transformRelativePoint(matrix, args[2], args[3]);
      const [x, y] = transformRelativePoint(matrix, args[4], args[5]);
      args[0] = x1;
      args[1] = y1;
      args[2] = x2;
      args[3] = y2;
      args[4] = x;
      args[5] = y;
    }
    if (command === "S") {
      cursor[0] = args[2];
      cursor[1] = args[3];
      const [x2, y2] = transformAbsolutePoint(matrix, args[0], args[1]);
      const [x, y] = transformAbsolutePoint(matrix, args[2], args[3]);
      args[0] = x2;
      args[1] = y2;
      args[2] = x;
      args[3] = y;
    }
    if (command === "s") {
      cursor[0] += args[2];
      cursor[1] += args[3];
      const [x2, y2] = transformRelativePoint(matrix, args[0], args[1]);
      const [x, y] = transformRelativePoint(matrix, args[2], args[3]);
      args[0] = x2;
      args[1] = y2;
      args[2] = x;
      args[3] = y;
    }
    if (command === "Q") {
      cursor[0] = args[2];
      cursor[1] = args[3];
      const [x1, y1] = transformAbsolutePoint(matrix, args[0], args[1]);
      const [x, y] = transformAbsolutePoint(matrix, args[2], args[3]);
      args[0] = x1;
      args[1] = y1;
      args[2] = x;
      args[3] = y;
    }
    if (command === "q") {
      cursor[0] += args[2];
      cursor[1] += args[3];
      const [x1, y1] = transformRelativePoint(matrix, args[0], args[1]);
      const [x, y] = transformRelativePoint(matrix, args[2], args[3]);
      args[0] = x1;
      args[1] = y1;
      args[2] = x;
      args[3] = y;
    }
    if (command === "T") {
      cursor[0] = args[0];
      cursor[1] = args[1];
      const [x, y] = transformAbsolutePoint(matrix, args[0], args[1]);
      args[0] = x;
      args[1] = y;
    }
    if (command === "t") {
      cursor[0] += args[0];
      cursor[1] += args[1];
      const [x, y] = transformRelativePoint(matrix, args[0], args[1]);
      args[0] = x;
      args[1] = y;
    }
    if (command === "A") {
      transformArc(cursor, args, matrix);
      cursor[0] = args[5];
      cursor[1] = args[6];
      if (Math.abs(args[2]) > 80) {
        const a = args[0];
        const rotation = args[2];
        args[0] = args[1];
        args[1] = a;
        args[2] = rotation + (rotation > 0 ? -90 : 90);
      }
      const [x, y] = transformAbsolutePoint(matrix, args[5], args[6]);
      args[5] = x;
      args[6] = y;
    }
    if (command === "a") {
      transformArc([0, 0], args, matrix);
      cursor[0] += args[5];
      cursor[1] += args[6];
      if (Math.abs(args[2]) > 80) {
        const a = args[0];
        const rotation = args[2];
        args[0] = args[1];
        args[1] = a;
        args[2] = rotation + (rotation > 0 ? -90 : 90);
      }
      const [x, y] = transformRelativePoint(matrix, args[5], args[6]);
      args[5] = x;
      args[6] = y;
    }
    if (command === "z" || command === "Z") {
      cursor[0] = start[0];
      cursor[1] = start[1];
    }
    pathItem.command = command;
    pathItem.args = args;
  }
};
const { collectStylesheet: collectStylesheet$1, computeStyle: computeStyle$1 } = style;
const { visit } = xast;
const { pathElems } = _collections;
const { path2js: path2js$1, js2path: js2path$1 } = _path;
const { applyTransforms } = applyTransforms$2;
const { cleanupOutData: cleanupOutData$1 } = tools;
convertPathData$1.name = "convertPathData";
convertPathData$1.type = "visitor";
convertPathData$1.active = true;
convertPathData$1.description = "optimizes path data: writes in shorter form, applies transformations";
let roundData;
let precision;
let error;
let arcThreshold;
let arcTolerance;
convertPathData$1.fn = (root, params) => {
  const {
    applyTransforms: _applyTransforms = true,
    applyTransformsStroked = true,
    makeArcs = {
      threshold: 2.5,
      tolerance: 0.5
    },
    straightCurves = true,
    lineShorthands = true,
    curveSmoothShorthands = true,
    floatPrecision = 3,
    transformPrecision = 5,
    removeUseless: removeUseless2 = true,
    collapseRepeated = true,
    utilizeAbsolute = true,
    leadingZero = true,
    negativeExtraSpace = true,
    noSpaceAfterFlags = false,
    forceAbsolutePath = false
  } = params;
  const newParams = {
    applyTransforms,
    applyTransformsStroked,
    makeArcs,
    straightCurves,
    lineShorthands,
    curveSmoothShorthands,
    floatPrecision,
    transformPrecision,
    removeUseless: removeUseless2,
    collapseRepeated,
    utilizeAbsolute,
    leadingZero,
    negativeExtraSpace,
    noSpaceAfterFlags,
    forceAbsolutePath
  };
  if (_applyTransforms) {
    visit(
      root,
      applyTransforms(root, {
        transformPrecision,
        applyTransformsStroked
      })
    );
  }
  const stylesheet = collectStylesheet$1(root);
  return {
    element: {
      enter: (node2) => {
        if (pathElems.includes(node2.name) && node2.attributes.d != null) {
          const computedStyle = computeStyle$1(stylesheet, node2);
          precision = floatPrecision;
          error = precision !== false ? +Math.pow(0.1, precision).toFixed(precision) : 0.01;
          roundData = precision > 0 && precision < 20 ? strongRound : round$1;
          if (makeArcs) {
            arcThreshold = makeArcs.threshold;
            arcTolerance = makeArcs.tolerance;
          }
          const hasMarkerMid = computedStyle["marker-mid"] != null;
          const maybeHasStroke = computedStyle.stroke && (computedStyle.stroke.type === "dynamic" || computedStyle.stroke.value !== "none");
          const maybeHasLinecap = computedStyle["stroke-linecap"] && (computedStyle["stroke-linecap"].type === "dynamic" || computedStyle["stroke-linecap"].value !== "butt");
          const maybeHasStrokeAndLinecap = maybeHasStroke && maybeHasLinecap;
          var data2 = path2js$1(node2);
          if (data2.length) {
            convertToRelative(data2);
            data2 = filters(data2, newParams, {
              maybeHasStrokeAndLinecap,
              hasMarkerMid
            });
            if (utilizeAbsolute) {
              data2 = convertToMixed(data2, newParams);
            }
            js2path$1(node2, data2, newParams);
          }
        }
      }
    }
  };
};
const convertToRelative = (pathData) => {
  let start = [0, 0];
  let cursor = [0, 0];
  let prevCoords = [0, 0];
  for (let i = 0; i < pathData.length; i += 1) {
    const pathItem = pathData[i];
    let { command, args } = pathItem;
    if (command === "m") {
      cursor[0] += args[0];
      cursor[1] += args[1];
      start[0] = cursor[0];
      start[1] = cursor[1];
    }
    if (command === "M") {
      if (i !== 0) {
        command = "m";
      }
      args[0] -= cursor[0];
      args[1] -= cursor[1];
      cursor[0] += args[0];
      cursor[1] += args[1];
      start[0] = cursor[0];
      start[1] = cursor[1];
    }
    if (command === "l") {
      cursor[0] += args[0];
      cursor[1] += args[1];
    }
    if (command === "L") {
      command = "l";
      args[0] -= cursor[0];
      args[1] -= cursor[1];
      cursor[0] += args[0];
      cursor[1] += args[1];
    }
    if (command === "h") {
      cursor[0] += args[0];
    }
    if (command === "H") {
      command = "h";
      args[0] -= cursor[0];
      cursor[0] += args[0];
    }
    if (command === "v") {
      cursor[1] += args[0];
    }
    if (command === "V") {
      command = "v";
      args[0] -= cursor[1];
      cursor[1] += args[0];
    }
    if (command === "c") {
      cursor[0] += args[4];
      cursor[1] += args[5];
    }
    if (command === "C") {
      command = "c";
      args[0] -= cursor[0];
      args[1] -= cursor[1];
      args[2] -= cursor[0];
      args[3] -= cursor[1];
      args[4] -= cursor[0];
      args[5] -= cursor[1];
      cursor[0] += args[4];
      cursor[1] += args[5];
    }
    if (command === "s") {
      cursor[0] += args[2];
      cursor[1] += args[3];
    }
    if (command === "S") {
      command = "s";
      args[0] -= cursor[0];
      args[1] -= cursor[1];
      args[2] -= cursor[0];
      args[3] -= cursor[1];
      cursor[0] += args[2];
      cursor[1] += args[3];
    }
    if (command === "q") {
      cursor[0] += args[2];
      cursor[1] += args[3];
    }
    if (command === "Q") {
      command = "q";
      args[0] -= cursor[0];
      args[1] -= cursor[1];
      args[2] -= cursor[0];
      args[3] -= cursor[1];
      cursor[0] += args[2];
      cursor[1] += args[3];
    }
    if (command === "t") {
      cursor[0] += args[0];
      cursor[1] += args[1];
    }
    if (command === "T") {
      command = "t";
      args[0] -= cursor[0];
      args[1] -= cursor[1];
      cursor[0] += args[0];
      cursor[1] += args[1];
    }
    if (command === "a") {
      cursor[0] += args[5];
      cursor[1] += args[6];
    }
    if (command === "A") {
      command = "a";
      args[5] -= cursor[0];
      args[6] -= cursor[1];
      cursor[0] += args[5];
      cursor[1] += args[6];
    }
    if (command === "Z" || command === "z") {
      cursor[0] = start[0];
      cursor[1] = start[1];
    }
    pathItem.command = command;
    pathItem.args = args;
    pathItem.base = prevCoords;
    pathItem.coords = [cursor[0], cursor[1]];
    prevCoords = pathItem.coords;
  }
  return pathData;
};
function filters(path2, params, { maybeHasStrokeAndLinecap, hasMarkerMid }) {
  var stringify2 = data2Path.bind(null, params), relSubpoint = [0, 0], pathBase = [0, 0], prev = {};
  path2 = path2.filter(function(item, index2, path3) {
    let command = item.command;
    let data2 = item.args;
    let next = path3[index2 + 1];
    if (command !== "Z" && command !== "z") {
      var sdata = data2, circle;
      if (command === "s") {
        sdata = [0, 0].concat(data2);
        if (command === "c" || command === "s") {
          var pdata = prev.args, n = pdata.length;
          sdata[0] = pdata[n - 2] - pdata[n - 4];
          sdata[1] = pdata[n - 1] - pdata[n - 3];
        }
      }
      if (params.makeArcs && (command == "c" || command == "s") && isConvex(sdata) && (circle = findCircle(sdata))) {
        var r = roundData([circle.radius])[0], angle = findArcAngle(sdata, circle), sweep = sdata[5] * sdata[0] - sdata[4] * sdata[1] > 0 ? 1 : 0, arc = {
          command: "a",
          args: [r, r, 0, 0, sweep, sdata[4], sdata[5]],
          coords: item.coords.slice(),
          base: item.base
        }, output = [arc], relCenter = [
          circle.center[0] - sdata[4],
          circle.center[1] - sdata[5]
        ], relCircle = { center: relCenter, radius: circle.radius }, arcCurves = [item], hasPrev = 0, suffix = "", nextLonghand;
        if (prev.command == "c" && isConvex(prev.args) && isArcPrev(prev.args, circle) || prev.command == "a" && prev.sdata && isArcPrev(prev.sdata, circle)) {
          arcCurves.unshift(prev);
          arc.base = prev.base;
          arc.args[5] = arc.coords[0] - arc.base[0];
          arc.args[6] = arc.coords[1] - arc.base[1];
          var prevData = prev.command == "a" ? prev.sdata : prev.args;
          var prevAngle = findArcAngle(prevData, {
            center: [
              prevData[4] + circle.center[0],
              prevData[5] + circle.center[1]
            ],
            radius: circle.radius
          });
          angle += prevAngle;
          if (angle > Math.PI)
            arc.args[3] = 1;
          hasPrev = 1;
        }
        for (var j = index2; (next = path3[++j]) && ~"cs".indexOf(next.command); ) {
          var nextData = next.args;
          if (next.command == "s") {
            nextLonghand = makeLonghand(
              { command: "s", args: next.args.slice() },
              path3[j - 1].args
            );
            nextData = nextLonghand.args;
            nextLonghand.args = nextData.slice(0, 2);
            suffix = stringify2([nextLonghand]);
          }
          if (isConvex(nextData) && isArc(nextData, relCircle)) {
            angle += findArcAngle(nextData, relCircle);
            if (angle - 2 * Math.PI > 1e-3)
              break;
            if (angle > Math.PI)
              arc.args[3] = 1;
            arcCurves.push(next);
            if (2 * Math.PI - angle > 1e-3) {
              arc.coords = next.coords;
              arc.args[5] = arc.coords[0] - arc.base[0];
              arc.args[6] = arc.coords[1] - arc.base[1];
            } else {
              arc.args[5] = 2 * (relCircle.center[0] - nextData[4]);
              arc.args[6] = 2 * (relCircle.center[1] - nextData[5]);
              arc.coords = [
                arc.base[0] + arc.args[5],
                arc.base[1] + arc.args[6]
              ];
              arc = {
                command: "a",
                args: [
                  r,
                  r,
                  0,
                  0,
                  sweep,
                  next.coords[0] - arc.coords[0],
                  next.coords[1] - arc.coords[1]
                ],
                coords: next.coords,
                base: arc.coords
              };
              output.push(arc);
              j++;
              break;
            }
            relCenter[0] -= nextData[4];
            relCenter[1] -= nextData[5];
          } else
            break;
        }
        if ((stringify2(output) + suffix).length < stringify2(arcCurves).length) {
          if (path3[j] && path3[j].command == "s") {
            makeLonghand(path3[j], path3[j - 1].args);
          }
          if (hasPrev) {
            var prevArc = output.shift();
            roundData(prevArc.args);
            relSubpoint[0] += prevArc.args[5] - prev.args[prev.args.length - 2];
            relSubpoint[1] += prevArc.args[6] - prev.args[prev.args.length - 1];
            prev.command = "a";
            prev.args = prevArc.args;
            item.base = prev.coords = prevArc.coords;
          }
          arc = output.shift();
          if (arcCurves.length == 1) {
            item.sdata = sdata.slice();
          } else if (arcCurves.length - 1 - hasPrev > 0) {
            path3.splice.apply(
              path3,
              [index2 + 1, arcCurves.length - 1 - hasPrev].concat(output)
            );
          }
          if (!arc)
            return false;
          command = "a";
          data2 = arc.args;
          item.coords = arc.coords;
        }
      }
      if (precision !== false) {
        if (command === "m" || command === "l" || command === "t" || command === "q" || command === "s" || command === "c") {
          for (var i = data2.length; i--; ) {
            data2[i] += item.base[i % 2] - relSubpoint[i % 2];
          }
        } else if (command == "h") {
          data2[0] += item.base[0] - relSubpoint[0];
        } else if (command == "v") {
          data2[0] += item.base[1] - relSubpoint[1];
        } else if (command == "a") {
          data2[5] += item.base[0] - relSubpoint[0];
          data2[6] += item.base[1] - relSubpoint[1];
        }
        roundData(data2);
        if (command == "h")
          relSubpoint[0] += data2[0];
        else if (command == "v")
          relSubpoint[1] += data2[0];
        else {
          relSubpoint[0] += data2[data2.length - 2];
          relSubpoint[1] += data2[data2.length - 1];
        }
        roundData(relSubpoint);
        if (command === "M" || command === "m") {
          pathBase[0] = relSubpoint[0];
          pathBase[1] = relSubpoint[1];
        }
      }
      if (params.straightCurves) {
        if (command === "c" && isCurveStraightLine(data2) || command === "s" && isCurveStraightLine(sdata)) {
          if (next && next.command == "s")
            makeLonghand(next, data2);
          command = "l";
          data2 = data2.slice(-2);
        } else if (command === "q" && isCurveStraightLine(data2)) {
          if (next && next.command == "t")
            makeLonghand(next, data2);
          command = "l";
          data2 = data2.slice(-2);
        } else if (command === "t" && prev.command !== "q" && prev.command !== "t") {
          command = "l";
          data2 = data2.slice(-2);
        } else if (command === "a" && (data2[0] === 0 || data2[1] === 0)) {
          command = "l";
          data2 = data2.slice(-2);
        }
      }
      if (params.lineShorthands && command === "l") {
        if (data2[1] === 0) {
          command = "h";
          data2.pop();
        } else if (data2[0] === 0) {
          command = "v";
          data2.shift();
        }
      }
      if (params.collapseRepeated && hasMarkerMid === false && (command === "m" || command === "h" || command === "v") && prev.command && command == prev.command.toLowerCase() && (command != "h" && command != "v" || prev.args[0] >= 0 == data2[0] >= 0)) {
        prev.args[0] += data2[0];
        if (command != "h" && command != "v") {
          prev.args[1] += data2[1];
        }
        prev.coords = item.coords;
        path3[index2] = prev;
        return false;
      }
      if (params.curveSmoothShorthands && prev.command) {
        if (command === "c") {
          if (prev.command === "c" && data2[0] === -(prev.args[2] - prev.args[4]) && data2[1] === -(prev.args[3] - prev.args[5])) {
            command = "s";
            data2 = data2.slice(2);
          } else if (prev.command === "s" && data2[0] === -(prev.args[0] - prev.args[2]) && data2[1] === -(prev.args[1] - prev.args[3])) {
            command = "s";
            data2 = data2.slice(2);
          } else if (prev.command !== "c" && prev.command !== "s" && data2[0] === 0 && data2[1] === 0) {
            command = "s";
            data2 = data2.slice(2);
          }
        } else if (command === "q") {
          if (prev.command === "q" && data2[0] === prev.args[2] - prev.args[0] && data2[1] === prev.args[3] - prev.args[1]) {
            command = "t";
            data2 = data2.slice(2);
          } else if (prev.command === "t" && data2[2] === prev.args[0] && data2[3] === prev.args[1]) {
            command = "t";
            data2 = data2.slice(2);
          }
        }
      }
      if (params.removeUseless && !maybeHasStrokeAndLinecap) {
        if ((command === "l" || command === "h" || command === "v" || command === "q" || command === "t" || command === "c" || command === "s") && data2.every(function(i2) {
          return i2 === 0;
        })) {
          path3[index2] = prev;
          return false;
        }
        if (command === "a" && data2[5] === 0 && data2[6] === 0) {
          path3[index2] = prev;
          return false;
        }
      }
      item.command = command;
      item.args = data2;
      prev = item;
    } else {
      relSubpoint[0] = pathBase[0];
      relSubpoint[1] = pathBase[1];
      if (prev.command === "Z" || prev.command === "z")
        return false;
      prev = item;
    }
    return true;
  });
  return path2;
}
function convertToMixed(path2, params) {
  var prev = path2[0];
  path2 = path2.filter(function(item, index2) {
    if (index2 == 0)
      return true;
    if (item.command === "Z" || item.command === "z") {
      prev = item;
      return true;
    }
    var command = item.command, data2 = item.args, adata = data2.slice();
    if (command === "m" || command === "l" || command === "t" || command === "q" || command === "s" || command === "c") {
      for (var i = adata.length; i--; ) {
        adata[i] += item.base[i % 2];
      }
    } else if (command == "h") {
      adata[0] += item.base[0];
    } else if (command == "v") {
      adata[0] += item.base[1];
    } else if (command == "a") {
      adata[5] += item.base[0];
      adata[6] += item.base[1];
    }
    roundData(adata);
    var absoluteDataStr = cleanupOutData$1(adata, params), relativeDataStr = cleanupOutData$1(data2, params);
    if (params.forceAbsolutePath || absoluteDataStr.length < relativeDataStr.length && !(params.negativeExtraSpace && command == prev.command && prev.command.charCodeAt(0) > 96 && absoluteDataStr.length == relativeDataStr.length - 1 && (data2[0] < 0 || /^0\./.test(data2[0]) && prev.args[prev.args.length - 1] % 1))) {
      item.command = command.toUpperCase();
      item.args = adata;
    }
    prev = item;
    return true;
  });
  return path2;
}
function isConvex(data2) {
  var center = getIntersection([
    0,
    0,
    data2[2],
    data2[3],
    data2[0],
    data2[1],
    data2[4],
    data2[5]
  ]);
  return center && data2[2] < center[0] == center[0] < 0 && data2[3] < center[1] == center[1] < 0 && data2[4] < center[0] == center[0] < data2[0] && data2[5] < center[1] == center[1] < data2[1];
}
function getIntersection(coords) {
  var a1 = coords[1] - coords[3], b1 = coords[2] - coords[0], c1 = coords[0] * coords[3] - coords[2] * coords[1], a2 = coords[5] - coords[7], b2 = coords[6] - coords[4], c2 = coords[4] * coords[7] - coords[5] * coords[6], denom = a1 * b2 - a2 * b1;
  if (!denom)
    return;
  var cross2 = [(b1 * c2 - b2 * c1) / denom, (a1 * c2 - a2 * c1) / -denom];
  if (!isNaN(cross2[0]) && !isNaN(cross2[1]) && isFinite(cross2[0]) && isFinite(cross2[1])) {
    return cross2;
  }
}
function strongRound(data2) {
  for (var i = data2.length; i-- > 0; ) {
    if (data2[i].toFixed(precision) != data2[i]) {
      var rounded = +data2[i].toFixed(precision - 1);
      data2[i] = +Math.abs(rounded - data2[i]).toFixed(precision + 1) >= error ? +data2[i].toFixed(precision) : rounded;
    }
  }
  return data2;
}
function round$1(data2) {
  for (var i = data2.length; i-- > 0; ) {
    data2[i] = Math.round(data2[i]);
  }
  return data2;
}
function isCurveStraightLine(data2) {
  var i = data2.length - 2, a = -data2[i + 1], b = data2[i], d = 1 / (a * a + b * b);
  if (i <= 1 || !isFinite(d))
    return false;
  while ((i -= 2) >= 0) {
    if (Math.sqrt(Math.pow(a * data2[i] + b * data2[i + 1], 2) * d) > error)
      return false;
  }
  return true;
}
function makeLonghand(item, data2) {
  switch (item.command) {
    case "s":
      item.command = "c";
      break;
    case "t":
      item.command = "q";
      break;
  }
  item.args.unshift(
    data2[data2.length - 2] - data2[data2.length - 4],
    data2[data2.length - 1] - data2[data2.length - 3]
  );
  return item;
}
function getDistance(point1, point2) {
  return Math.hypot(point1[0] - point2[0], point1[1] - point2[1]);
}
function getCubicBezierPoint(curve, t) {
  var sqrT = t * t, cubT = sqrT * t, mt = 1 - t, sqrMt = mt * mt;
  return [
    3 * sqrMt * t * curve[0] + 3 * mt * sqrT * curve[2] + cubT * curve[4],
    3 * sqrMt * t * curve[1] + 3 * mt * sqrT * curve[3] + cubT * curve[5]
  ];
}
function findCircle(curve) {
  var midPoint = getCubicBezierPoint(curve, 1 / 2), m1 = [midPoint[0] / 2, midPoint[1] / 2], m2 = [(midPoint[0] + curve[4]) / 2, (midPoint[1] + curve[5]) / 2], center = getIntersection([
    m1[0],
    m1[1],
    m1[0] + m1[1],
    m1[1] - m1[0],
    m2[0],
    m2[1],
    m2[0] + (m2[1] - midPoint[1]),
    m2[1] - (m2[0] - midPoint[0])
  ]), radius = center && getDistance([0, 0], center), tolerance = Math.min(arcThreshold * error, arcTolerance * radius / 100);
  if (center && radius < 1e15 && [1 / 4, 3 / 4].every(function(point) {
    return Math.abs(
      getDistance(getCubicBezierPoint(curve, point), center) - radius
    ) <= tolerance;
  }))
    return { center, radius };
}
function isArc(curve, circle) {
  var tolerance = Math.min(
    arcThreshold * error,
    arcTolerance * circle.radius / 100
  );
  return [0, 1 / 4, 1 / 2, 3 / 4, 1].every(function(point) {
    return Math.abs(
      getDistance(getCubicBezierPoint(curve, point), circle.center) - circle.radius
    ) <= tolerance;
  });
}
function isArcPrev(curve, circle) {
  return isArc(curve, {
    center: [circle.center[0] + curve[4], circle.center[1] + curve[5]],
    radius: circle.radius
  });
}
function findArcAngle(curve, relCircle) {
  var x1 = -relCircle.center[0], y1 = -relCircle.center[1], x2 = curve[4] - relCircle.center[0], y2 = curve[5] - relCircle.center[1];
  return Math.acos(
    (x1 * x2 + y1 * y2) / Math.sqrt((x1 * x1 + y1 * y1) * (x2 * x2 + y2 * y2))
  );
}
function data2Path(params, pathData) {
  return pathData.reduce(function(pathString, item) {
    var strData = "";
    if (item.args) {
      strData = cleanupOutData$1(roundData(item.args.slice()), params);
    }
    return pathString + item.command + strData;
  }, "");
}
var convertTransform$2 = {};
const { cleanupOutData } = tools;
const {
  transform2js,
  transformsMultiply,
  matrixToTransform
} = _transforms;
convertTransform$2.type = "visitor";
convertTransform$2.name = "convertTransform";
convertTransform$2.active = true;
convertTransform$2.description = "collapses multiple transformations and optimizes it";
convertTransform$2.fn = (_root, params) => {
  const {
    convertToShorts: convertToShorts2 = true,
    degPrecision,
    floatPrecision = 3,
    transformPrecision = 5,
    matrixToTransform: matrixToTransform2 = true,
    shortTranslate = true,
    shortScale = true,
    shortRotate = true,
    removeUseless: removeUseless2 = true,
    collapseIntoOne = true,
    leadingZero = true,
    negativeExtraSpace = false
  } = params;
  const newParams = {
    convertToShorts: convertToShorts2,
    degPrecision,
    floatPrecision,
    transformPrecision,
    matrixToTransform: matrixToTransform2,
    shortTranslate,
    shortScale,
    shortRotate,
    removeUseless: removeUseless2,
    collapseIntoOne,
    leadingZero,
    negativeExtraSpace
  };
  return {
    element: {
      enter: (node2) => {
        if (node2.attributes.transform != null) {
          convertTransform$1(node2, "transform", newParams);
        }
        if (node2.attributes.gradientTransform != null) {
          convertTransform$1(node2, "gradientTransform", newParams);
        }
        if (node2.attributes.patternTransform != null) {
          convertTransform$1(node2, "patternTransform", newParams);
        }
      }
    }
  };
};
const convertTransform$1 = (item, attrName, params) => {
  let data2 = transform2js(item.attributes[attrName]);
  params = definePrecision(data2, params);
  if (params.collapseIntoOne && data2.length > 1) {
    data2 = [transformsMultiply(data2)];
  }
  if (params.convertToShorts) {
    data2 = convertToShorts(data2, params);
  } else {
    data2.forEach((item2) => roundTransform(item2, params));
  }
  if (params.removeUseless) {
    data2 = removeUseless(data2);
  }
  if (data2.length) {
    item.attributes[attrName] = js2transform(data2, params);
  } else {
    delete item.attributes[attrName];
  }
};
const definePrecision = (data2, { ...newParams }) => {
  const matrixData = [];
  for (const item of data2) {
    if (item.name == "matrix") {
      matrixData.push(...item.data.slice(0, 4));
    }
  }
  let significantDigits = newParams.transformPrecision;
  if (matrixData.length) {
    newParams.transformPrecision = Math.min(
      newParams.transformPrecision,
      Math.max.apply(Math, matrixData.map(floatDigits)) || newParams.transformPrecision
    );
    significantDigits = Math.max.apply(
      Math,
      matrixData.map(
        (n) => n.toString().replace(/\D+/g, "").length
      )
    );
  }
  if (newParams.degPrecision == null) {
    newParams.degPrecision = Math.max(
      0,
      Math.min(newParams.floatPrecision, significantDigits - 2)
    );
  }
  return newParams;
};
const degRound = (data2, params) => {
  if (params.degPrecision != null && params.degPrecision >= 1 && params.floatPrecision < 20) {
    return smartRound(params.degPrecision, data2);
  } else {
    return round(data2);
  }
};
const floatRound = (data2, params) => {
  if (params.floatPrecision >= 1 && params.floatPrecision < 20) {
    return smartRound(params.floatPrecision, data2);
  } else {
    return round(data2);
  }
};
const transformRound = (data2, params) => {
  if (params.transformPrecision >= 1 && params.floatPrecision < 20) {
    return smartRound(params.transformPrecision, data2);
  } else {
    return round(data2);
  }
};
const floatDigits = (n) => {
  const str = n.toString();
  return str.slice(str.indexOf(".")).length - 1;
};
const convertToShorts = (transforms, params) => {
  for (var i = 0; i < transforms.length; i++) {
    var transform = transforms[i];
    if (params.matrixToTransform && transform.name === "matrix") {
      var decomposed = matrixToTransform(transform, params);
      if (js2transform(decomposed, params).length <= js2transform([transform], params).length) {
        transforms.splice(i, 1, ...decomposed);
      }
      transform = transforms[i];
    }
    roundTransform(transform, params);
    if (params.shortTranslate && transform.name === "translate" && transform.data.length === 2 && !transform.data[1]) {
      transform.data.pop();
    }
    if (params.shortScale && transform.name === "scale" && transform.data.length === 2 && transform.data[0] === transform.data[1]) {
      transform.data.pop();
    }
    if (params.shortRotate && transforms[i - 2] && transforms[i - 2].name === "translate" && transforms[i - 1].name === "rotate" && transforms[i].name === "translate" && transforms[i - 2].data[0] === -transforms[i].data[0] && transforms[i - 2].data[1] === -transforms[i].data[1]) {
      transforms.splice(i - 2, 3, {
        name: "rotate",
        data: [
          transforms[i - 1].data[0],
          transforms[i - 2].data[0],
          transforms[i - 2].data[1]
        ]
      });
      i -= 2;
    }
  }
  return transforms;
};
const removeUseless = (transforms) => {
  return transforms.filter((transform) => {
    if (["translate", "rotate", "skewX", "skewY"].indexOf(transform.name) > -1 && (transform.data.length == 1 || transform.name == "rotate") && !transform.data[0] || transform.name == "translate" && !transform.data[0] && !transform.data[1] || transform.name == "scale" && transform.data[0] == 1 && (transform.data.length < 2 || transform.data[1] == 1) || transform.name == "matrix" && transform.data[0] == 1 && transform.data[3] == 1 && !(transform.data[1] || transform.data[2] || transform.data[4] || transform.data[5])) {
      return false;
    }
    return true;
  });
};
const js2transform = (transformJS, params) => {
  var transformString = "";
  transformJS.forEach((transform) => {
    roundTransform(transform, params);
    transformString += (transformString && " ") + transform.name + "(" + cleanupOutData(transform.data, params) + ")";
  });
  return transformString;
};
const roundTransform = (transform, params) => {
  switch (transform.name) {
    case "translate":
      transform.data = floatRound(transform.data, params);
      break;
    case "rotate":
      transform.data = [
        ...degRound(transform.data.slice(0, 1), params),
        ...floatRound(transform.data.slice(1), params)
      ];
      break;
    case "skewX":
    case "skewY":
      transform.data = degRound(transform.data, params);
      break;
    case "scale":
      transform.data = transformRound(transform.data, params);
      break;
    case "matrix":
      transform.data = [
        ...transformRound(transform.data.slice(0, 4), params),
        ...floatRound(transform.data.slice(4), params)
      ];
      break;
  }
  return transform;
};
const round = (data2) => {
  return data2.map(Math.round);
};
const smartRound = (precision2, data2) => {
  for (var i = data2.length, tolerance = +Math.pow(0.1, precision2).toFixed(precision2); i--; ) {
    if (Number(data2[i].toFixed(precision2)) !== data2[i]) {
      var rounded = +data2[i].toFixed(precision2 - 1);
      data2[i] = +Math.abs(rounded - data2[i]).toFixed(precision2 + 1) >= tolerance ? +data2[i].toFixed(precision2) : rounded;
    }
  }
  return data2;
};
var removeEmptyAttrs$1 = {};
const { attrsGroups: attrsGroups$1 } = _collections;
removeEmptyAttrs$1.type = "visitor";
removeEmptyAttrs$1.name = "removeEmptyAttrs";
removeEmptyAttrs$1.active = true;
removeEmptyAttrs$1.description = "removes empty attributes";
removeEmptyAttrs$1.fn = () => {
  return {
    element: {
      enter: (node2) => {
        for (const [name2, value2] of Object.entries(node2.attributes)) {
          if (value2 === "" && attrsGroups$1.conditionalProcessing.includes(name2) === false) {
            delete node2.attributes[name2];
          }
        }
      }
    }
  };
};
var removeEmptyContainers$1 = {};
const { detachNodeFromParent: detachNodeFromParent$8 } = xast;
const { elemsGroups } = _collections;
removeEmptyContainers$1.type = "visitor";
removeEmptyContainers$1.name = "removeEmptyContainers";
removeEmptyContainers$1.active = true;
removeEmptyContainers$1.description = "removes empty container elements";
removeEmptyContainers$1.fn = () => {
  return {
    element: {
      exit: (node2, parentNode) => {
        if (node2.name === "svg" || elemsGroups.container.includes(node2.name) === false || node2.children.length !== 0) {
          return;
        }
        if (node2.name === "pattern" && Object.keys(node2.attributes).length !== 0) {
          return;
        }
        if (node2.name === "g" && node2.attributes.filter != null) {
          return;
        }
        if (node2.name === "mask" && node2.attributes.id != null) {
          return;
        }
        detachNodeFromParent$8(node2, parentNode);
      }
    }
  };
};
var mergePaths$1 = {};
const { detachNodeFromParent: detachNodeFromParent$7 } = xast;
const { collectStylesheet, computeStyle } = style;
const { path2js, js2path, intersects: intersects$1 } = _path;
mergePaths$1.type = "visitor";
mergePaths$1.name = "mergePaths";
mergePaths$1.active = true;
mergePaths$1.description = "merges multiple paths in one if possible";
mergePaths$1.fn = (root, params) => {
  const {
    force = false,
    floatPrecision,
    noSpaceAfterFlags = false
  } = params;
  const stylesheet = collectStylesheet(root);
  return {
    element: {
      enter: (node2) => {
        let prevChild = null;
        for (const child of node2.children) {
          if (prevChild == null || prevChild.type !== "element" || prevChild.name !== "path" || prevChild.children.length !== 0 || prevChild.attributes.d == null) {
            prevChild = child;
            continue;
          }
          if (child.type !== "element" || child.name !== "path" || child.children.length !== 0 || child.attributes.d == null) {
            prevChild = child;
            continue;
          }
          const computedStyle = computeStyle(stylesheet, child);
          if (computedStyle["marker-start"] || computedStyle["marker-mid"] || computedStyle["marker-end"]) {
            prevChild = child;
            continue;
          }
          const prevChildAttrs = Object.keys(prevChild.attributes);
          const childAttrs = Object.keys(child.attributes);
          let attributesAreEqual = prevChildAttrs.length === childAttrs.length;
          for (const name2 of childAttrs) {
            if (name2 !== "d") {
              if (prevChild.attributes[name2] == null || prevChild.attributes[name2] !== child.attributes[name2]) {
                attributesAreEqual = false;
              }
            }
          }
          const prevPathJS = path2js(prevChild);
          const curPathJS = path2js(child);
          if (attributesAreEqual && (force || !intersects$1(prevPathJS, curPathJS))) {
            js2path(prevChild, prevPathJS.concat(curPathJS), {
              floatPrecision,
              noSpaceAfterFlags
            });
            detachNodeFromParent$7(child, node2);
            continue;
          }
          prevChild = child;
        }
      }
    }
  };
};
var removeUnusedNS$1 = {};
removeUnusedNS$1.type = "visitor";
removeUnusedNS$1.name = "removeUnusedNS";
removeUnusedNS$1.active = true;
removeUnusedNS$1.description = "removes unused namespaces declaration";
removeUnusedNS$1.fn = () => {
  const unusedNamespaces = /* @__PURE__ */ new Set();
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "svg" && parentNode.type === "root") {
          for (const name2 of Object.keys(node2.attributes)) {
            if (name2.startsWith("xmlns:")) {
              const local = name2.slice("xmlns:".length);
              unusedNamespaces.add(local);
            }
          }
        }
        if (unusedNamespaces.size !== 0) {
          if (node2.name.includes(":")) {
            const [ns] = node2.name.split(":");
            if (unusedNamespaces.has(ns)) {
              unusedNamespaces.delete(ns);
            }
          }
          for (const name2 of Object.keys(node2.attributes)) {
            if (name2.includes(":")) {
              const [ns] = name2.split(":");
              unusedNamespaces.delete(ns);
            }
          }
        }
      },
      exit: (node2, parentNode) => {
        if (node2.name === "svg" && parentNode.type === "root") {
          for (const name2 of unusedNamespaces) {
            delete node2.attributes[`xmlns:${name2}`];
          }
        }
      }
    }
  };
};
var sortDefsChildren$1 = {};
sortDefsChildren$1.type = "visitor";
sortDefsChildren$1.name = "sortDefsChildren";
sortDefsChildren$1.active = true;
sortDefsChildren$1.description = "Sorts children of <defs> to improve compression";
sortDefsChildren$1.fn = () => {
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "defs") {
          const frequencies = /* @__PURE__ */ new Map();
          for (const child of node2.children) {
            if (child.type === "element") {
              const frequency = frequencies.get(child.name);
              if (frequency == null) {
                frequencies.set(child.name, 1);
              } else {
                frequencies.set(child.name, frequency + 1);
              }
            }
          }
          node2.children.sort((a, b) => {
            if (a.type !== "element" || b.type !== "element") {
              return 0;
            }
            const aFrequency = frequencies.get(a.name);
            const bFrequency = frequencies.get(b.name);
            if (aFrequency != null && bFrequency != null) {
              const frequencyComparison = bFrequency - aFrequency;
              if (frequencyComparison !== 0) {
                return frequencyComparison;
              }
            }
            const lengthComparison = b.name.length - a.name.length;
            if (lengthComparison !== 0) {
              return lengthComparison;
            }
            if (a.name !== b.name) {
              return a.name > b.name ? -1 : 1;
            }
            return 0;
          });
        }
      }
    }
  };
};
var removeTitle$1 = {};
const { detachNodeFromParent: detachNodeFromParent$6 } = xast;
removeTitle$1.name = "removeTitle";
removeTitle$1.type = "visitor";
removeTitle$1.active = true;
removeTitle$1.description = "removes <title>";
removeTitle$1.fn = () => {
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "title") {
          detachNodeFromParent$6(node2, parentNode);
        }
      }
    }
  };
};
var removeDesc$1 = {};
const { detachNodeFromParent: detachNodeFromParent$5 } = xast;
removeDesc$1.name = "removeDesc";
removeDesc$1.type = "visitor";
removeDesc$1.active = true;
removeDesc$1.description = "removes <desc>";
const standardDescs = /^(Created with|Created using)/;
removeDesc$1.fn = (root, params) => {
  const { removeAny = true } = params;
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "desc") {
          if (removeAny || node2.children.length === 0 || node2.children[0].type === "text" && standardDescs.test(node2.children[0].value)) {
            detachNodeFromParent$5(node2, parentNode);
          }
        }
      }
    }
  };
};
const { createPreset } = plugins;
const removeDoctype = removeDoctype$1;
const removeXMLProcInst = removeXMLProcInst$1;
const removeComments = removeComments$1;
const removeMetadata = removeMetadata$1;
const removeEditorsNSData = removeEditorsNSData$1;
const cleanupAttrs = cleanupAttrs$1;
const mergeStyles = mergeStyles$1;
const inlineStyles = inlineStyles$1;
const minifyStyles = minifyStyles$1;
const cleanupIDs = cleanupIDs$1;
const removeUselessDefs = removeUselessDefs$1;
const cleanupNumericValues = cleanupNumericValues$1;
const convertColors = convertColors$1;
const removeUnknownsAndDefaults = removeUnknownsAndDefaults$1;
const removeNonInheritableGroupAttrs = removeNonInheritableGroupAttrs$1;
const removeUselessStrokeAndFill = removeUselessStrokeAndFill$1;
const removeViewBox = removeViewBox$1;
const cleanupEnableBackground = cleanupEnableBackground$1;
const removeHiddenElems = removeHiddenElems$1;
const removeEmptyText = removeEmptyText$1;
const convertShapeToPath = convertShapeToPath$1;
const convertEllipseToCircle = convertEllipseToCircle$1;
const moveElemsAttrsToGroup = moveElemsAttrsToGroup$1;
const moveGroupAttrsToElems = moveGroupAttrsToElems$1;
const collapseGroups = collapseGroups$1;
const convertPathData = convertPathData$1;
const convertTransform = convertTransform$2;
const removeEmptyAttrs = removeEmptyAttrs$1;
const removeEmptyContainers = removeEmptyContainers$1;
const mergePaths = mergePaths$1;
const removeUnusedNS = removeUnusedNS$1;
const sortDefsChildren = sortDefsChildren$1;
const removeTitle = removeTitle$1;
const removeDesc = removeDesc$1;
const presetDefault = createPreset({
  name: "preset-default",
  plugins: [
    removeDoctype,
    removeXMLProcInst,
    removeComments,
    removeMetadata,
    removeEditorsNSData,
    cleanupAttrs,
    mergeStyles,
    inlineStyles,
    minifyStyles,
    cleanupIDs,
    removeUselessDefs,
    cleanupNumericValues,
    convertColors,
    removeUnknownsAndDefaults,
    removeNonInheritableGroupAttrs,
    removeUselessStrokeAndFill,
    removeViewBox,
    cleanupEnableBackground,
    removeHiddenElems,
    removeEmptyText,
    convertShapeToPath,
    convertEllipseToCircle,
    moveElemsAttrsToGroup,
    moveGroupAttrsToElems,
    collapseGroups,
    convertPathData,
    convertTransform,
    removeEmptyAttrs,
    removeEmptyContainers,
    mergePaths,
    removeUnusedNS,
    sortDefsChildren,
    removeTitle,
    removeDesc
  ]
});
var presetDefault_1 = presetDefault;
var addAttributesToSVGElement = {};
addAttributesToSVGElement.name = "addAttributesToSVGElement";
addAttributesToSVGElement.type = "visitor";
addAttributesToSVGElement.active = false;
addAttributesToSVGElement.description = "adds attributes to an outer <svg> element";
var ENOCLS$1 = `Error in plugin "addAttributesToSVGElement": absent parameters.
It should have a list of "attributes" or one "attribute".
Config example:

plugins: [
  {
    name: 'addAttributesToSVGElement',
    params: {
      attribute: "mySvg"
    }
  }
]

plugins: [
  {
    name: 'addAttributesToSVGElement',
    params: {
      attributes: ["mySvg", "size-big"]
    }
  }
]

plugins: [
  {
    name: 'addAttributesToSVGElement',
    params: {
      attributes: [
        {
          focusable: false
        },
        {
          'data-image': icon
        }
      ]
    }
  }
]
`;
addAttributesToSVGElement.fn = (root, params) => {
  if (!Array.isArray(params.attributes) && !params.attribute) {
    console.error(ENOCLS$1);
    return null;
  }
  const attributes2 = params.attributes || [params.attribute];
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "svg" && parentNode.type === "root") {
          for (const attribute of attributes2) {
            if (typeof attribute === "string") {
              if (node2.attributes[attribute] == null) {
                node2.attributes[attribute] = void 0;
              }
            }
            if (typeof attribute === "object") {
              for (const key of Object.keys(attribute)) {
                if (node2.attributes[key] == null) {
                  node2.attributes[key] = attribute[key];
                }
              }
            }
          }
        }
      }
    }
  };
};
var addClassesToSVGElement = {};
addClassesToSVGElement.name = "addClassesToSVGElement";
addClassesToSVGElement.type = "visitor";
addClassesToSVGElement.active = false;
addClassesToSVGElement.description = "adds classnames to an outer <svg> element";
var ENOCLS = `Error in plugin "addClassesToSVGElement": absent parameters.
It should have a list of classes in "classNames" or one "className".
Config example:

plugins: [
  {
    name: "addClassesToSVGElement",
    params: {
      className: "mySvg"
    }
  }
]

plugins: [
  {
    name: "addClassesToSVGElement",
    params: {
      classNames: ["mySvg", "size-big"]
    }
  }
]
`;
addClassesToSVGElement.fn = (root, params) => {
  if (!(Array.isArray(params.classNames) && params.classNames.some(String)) && !params.className) {
    console.error(ENOCLS);
    return null;
  }
  const classNames = params.classNames || [params.className];
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "svg" && parentNode.type === "root") {
          const classList = new Set(
            node2.attributes.class == null ? null : node2.attributes.class.split(" ")
          );
          for (const className of classNames) {
            if (className != null) {
              classList.add(className);
            }
          }
          node2.attributes.class = Array.from(classList).join(" ");
        }
      }
    }
  };
};
var cleanupListOfValues = {};
const { removeLeadingZero } = tools;
cleanupListOfValues.name = "cleanupListOfValues";
cleanupListOfValues.type = "visitor";
cleanupListOfValues.active = false;
cleanupListOfValues.description = "rounds list of values to the fixed precision";
const regNumericValues = /^([-+]?\d*\.?\d+([eE][-+]?\d+)?)(px|pt|pc|mm|cm|m|in|ft|em|ex|%)?$/;
const regSeparator = /\s+,?\s*|,\s*/;
const absoluteLengths = {
  cm: 96 / 2.54,
  mm: 96 / 25.4,
  in: 96,
  pt: 4 / 3,
  pc: 16,
  px: 1
};
cleanupListOfValues.fn = (_root, params) => {
  const {
    floatPrecision = 3,
    leadingZero = true,
    defaultPx = true,
    convertToPx = true
  } = params;
  const roundValues = (lists) => {
    const roundedList = [];
    for (const elem of lists.split(regSeparator)) {
      const match2 = elem.match(regNumericValues);
      const matchNew = elem.match(/new/);
      if (match2) {
        let num = Number(Number(match2[1]).toFixed(floatPrecision));
        let matchedUnit = match2[3] || "";
        let units = matchedUnit;
        if (convertToPx && units && units in absoluteLengths) {
          const pxNum = Number(
            (absoluteLengths[units] * Number(match2[1])).toFixed(floatPrecision)
          );
          if (pxNum.toString().length < match2[0].length) {
            num = pxNum;
            units = "px";
          }
        }
        let str;
        if (leadingZero) {
          str = removeLeadingZero(num);
        } else {
          str = num.toString();
        }
        if (defaultPx && units === "px") {
          units = "";
        }
        roundedList.push(str + units);
      } else if (matchNew) {
        roundedList.push("new");
      } else if (elem) {
        roundedList.push(elem);
      }
    }
    return roundedList.join(" ");
  };
  return {
    element: {
      enter: (node2) => {
        if (node2.attributes.points != null) {
          node2.attributes.points = roundValues(node2.attributes.points);
        }
        if (node2.attributes["enable-background"] != null) {
          node2.attributes["enable-background"] = roundValues(
            node2.attributes["enable-background"]
          );
        }
        if (node2.attributes.viewBox != null) {
          node2.attributes.viewBox = roundValues(node2.attributes.viewBox);
        }
        if (node2.attributes["stroke-dasharray"] != null) {
          node2.attributes["stroke-dasharray"] = roundValues(
            node2.attributes["stroke-dasharray"]
          );
        }
        if (node2.attributes.dx != null) {
          node2.attributes.dx = roundValues(node2.attributes.dx);
        }
        if (node2.attributes.dy != null) {
          node2.attributes.dy = roundValues(node2.attributes.dy);
        }
        if (node2.attributes.x != null) {
          node2.attributes.x = roundValues(node2.attributes.x);
        }
        if (node2.attributes.y != null) {
          node2.attributes.y = roundValues(node2.attributes.y);
        }
      }
    }
  };
};
var convertStyleToAttrs = {};
const { attrsGroups } = _collections;
convertStyleToAttrs.type = "visitor";
convertStyleToAttrs.name = "convertStyleToAttrs";
convertStyleToAttrs.active = false;
convertStyleToAttrs.description = "converts style to attributes";
const g = (...args) => {
  return "(?:" + args.join("|") + ")";
};
const stylingProps = attrsGroups.presentation;
const rEscape = "\\\\(?:[0-9a-f]{1,6}\\s?|\\r\\n|.)";
const rAttr = "\\s*(" + g("[^:;\\\\]", rEscape) + "*?)\\s*";
const rSingleQuotes = "'(?:[^'\\n\\r\\\\]|" + rEscape + ")*?(?:'|$)";
const rQuotes = '"(?:[^"\\n\\r\\\\]|' + rEscape + ')*?(?:"|$)';
const rQuotedString = new RegExp("^" + g(rSingleQuotes, rQuotes) + "$");
const rParenthesis = "\\(" + g(`[^'"()\\\\]+`, rEscape, rSingleQuotes, rQuotes) + "*?\\)";
const rValue = "\\s*(" + g(
  `[^!'"();\\\\]+?`,
  rEscape,
  rSingleQuotes,
  rQuotes,
  rParenthesis,
  "[^;]*?"
) + "*?)";
const rDeclEnd = "\\s*(?:;\\s*|$)";
const rImportant = "(\\s*!important(?![-(\\w]))?";
const regDeclarationBlock = new RegExp(
  rAttr + ":" + rValue + rImportant + rDeclEnd,
  "ig"
);
const regStripComments = new RegExp(
  g(rEscape, rSingleQuotes, rQuotes, "/\\*[^]*?\\*/"),
  "ig"
);
convertStyleToAttrs.fn = (_root, params) => {
  const { keepImportant = false } = params;
  return {
    element: {
      enter: (node2) => {
        if (node2.attributes.style != null) {
          let styles = [];
          const newAttributes = {};
          const styleValue = node2.attributes.style.replace(
            regStripComments,
            (match2) => {
              return match2[0] == "/" ? "" : match2[0] == "\\" && /[-g-z]/i.test(match2[1]) ? match2[1] : match2;
            }
          );
          regDeclarationBlock.lastIndex = 0;
          for (var rule; rule = regDeclarationBlock.exec(styleValue); ) {
            if (!keepImportant || !rule[3]) {
              styles.push([rule[1], rule[2]]);
            }
          }
          if (styles.length) {
            styles = styles.filter(function(style2) {
              if (style2[0]) {
                var prop = style2[0].toLowerCase(), val = style2[1];
                if (rQuotedString.test(val)) {
                  val = val.slice(1, -1);
                }
                if (stylingProps.includes(prop)) {
                  newAttributes[prop] = val;
                  return false;
                }
              }
              return true;
            });
            Object.assign(node2.attributes, newAttributes);
            if (styles.length) {
              node2.attributes.style = styles.map((declaration) => declaration.join(":")).join(";");
            } else {
              delete node2.attributes.style;
            }
          }
        }
      }
    }
  };
};
var prefixIds = {};
const csstree = cjs$1;
const { referencesProps } = _collections;
prefixIds.type = "visitor";
prefixIds.name = "prefixIds";
prefixIds.active = false;
prefixIds.description = "prefix IDs";
const getBasename = (path2) => {
  const matched = path2.match(/[/\\]?([^/\\]+)$/);
  if (matched) {
    return matched[1];
  }
  return "";
};
const escapeIdentifierName = (str) => {
  return str.replace(/[. ]/g, "_");
};
const unquote = (string2) => {
  if (string2.startsWith('"') && string2.endsWith('"') || string2.startsWith("'") && string2.endsWith("'")) {
    return string2.slice(1, -1);
  }
  return string2;
};
const prefixId = (prefix, value2) => {
  if (value2.startsWith(prefix)) {
    return value2;
  }
  return prefix + value2;
};
const prefixReference = (prefix, value2) => {
  if (value2.startsWith("#")) {
    return "#" + prefixId(prefix, value2.slice(1));
  }
  return null;
};
const toAny = (value2) => value2;
prefixIds.fn = (_root, params, info) => {
  const { delim = "__", prefixIds: prefixIds2 = true, prefixClassNames = true } = params;
  return {
    element: {
      enter: (node2) => {
        let prefix = "prefix" + delim;
        if (typeof params.prefix === "function") {
          prefix = params.prefix(node2, info) + delim;
        } else if (typeof params.prefix === "string") {
          prefix = params.prefix + delim;
        } else if (params.prefix === false) {
          prefix = "";
        } else if (info.path != null && info.path.length > 0) {
          prefix = escapeIdentifierName(getBasename(info.path)) + delim;
        }
        if (node2.name === "style") {
          if (node2.children.length === 0) {
            return;
          }
          let cssText = "";
          if (node2.children[0].type === "text" || node2.children[0].type === "cdata") {
            cssText = node2.children[0].value;
          }
          let cssAst = null;
          try {
            cssAst = csstree.parse(cssText, {
              parseValue: true,
              parseCustomProperty: false
            });
          } catch {
            return;
          }
          csstree.walk(cssAst, (node3) => {
            if (prefixIds2 && node3.type === "IdSelector" || prefixClassNames && node3.type === "ClassSelector") {
              node3.name = prefixId(prefix, node3.name);
              return;
            }
            if (node3.type === "Url" && toAny(node3.value).length > 0) {
              const prefixed = prefixReference(
                prefix,
                unquote(toAny(node3.value))
              );
              if (prefixed != null) {
                toAny(node3).value = prefixed;
              }
            }
          });
          if (node2.children[0].type === "text" || node2.children[0].type === "cdata") {
            node2.children[0].value = csstree.generate(cssAst);
          }
          return;
        }
        if (prefixIds2 && node2.attributes.id != null && node2.attributes.id.length !== 0) {
          node2.attributes.id = prefixId(prefix, node2.attributes.id);
        }
        if (prefixClassNames && node2.attributes.class != null && node2.attributes.class.length !== 0) {
          node2.attributes.class = node2.attributes.class.split(/\s+/).map((name2) => prefixId(prefix, name2)).join(" ");
        }
        for (const name2 of ["href", "xlink:href"]) {
          if (node2.attributes[name2] != null && node2.attributes[name2].length !== 0) {
            const prefixed = prefixReference(prefix, node2.attributes[name2]);
            if (prefixed != null) {
              node2.attributes[name2] = prefixed;
            }
          }
        }
        for (const name2 of referencesProps) {
          if (node2.attributes[name2] != null && node2.attributes[name2].length !== 0) {
            node2.attributes[name2] = node2.attributes[name2].replace(
              /url\((.*?)\)/gi,
              (match2, url2) => {
                const prefixed = prefixReference(prefix, url2);
                if (prefixed == null) {
                  return match2;
                }
                return `url(${prefixed})`;
              }
            );
          }
        }
        for (const name2 of ["begin", "end"]) {
          if (node2.attributes[name2] != null && node2.attributes[name2].length !== 0) {
            const parts = node2.attributes[name2].split(/\s*;\s+/).map((val) => {
              if (val.endsWith(".end") || val.endsWith(".start")) {
                const [id, postfix] = val.split(".");
                return `${prefixId(prefix, id)}.${postfix}`;
              }
              return val;
            });
            node2.attributes[name2] = parts.join("; ");
          }
        }
      }
    }
  };
};
var removeAttributesBySelector = {};
const { querySelectorAll } = xast;
removeAttributesBySelector.name = "removeAttributesBySelector";
removeAttributesBySelector.type = "visitor";
removeAttributesBySelector.active = false;
removeAttributesBySelector.description = "removes attributes of elements that match a css selector";
removeAttributesBySelector.fn = (root, params) => {
  const selectors = Array.isArray(params.selectors) ? params.selectors : [params];
  for (const { selector: selector2, attributes: attributes2 } of selectors) {
    const nodes = querySelectorAll(root, selector2);
    for (const node2 of nodes) {
      if (node2.type === "element") {
        if (Array.isArray(attributes2)) {
          for (const name2 of attributes2) {
            delete node2.attributes[name2];
          }
        } else {
          delete node2.attributes[attributes2];
        }
      }
    }
  }
  return {};
};
var removeAttrs = {};
removeAttrs.name = "removeAttrs";
removeAttrs.type = "visitor";
removeAttrs.active = false;
removeAttrs.description = "removes specified attributes";
const DEFAULT_SEPARATOR = ":";
const ENOATTRS = `Warning: The plugin "removeAttrs" requires the "attrs" parameter.
It should have a pattern to remove, otherwise the plugin is a noop.
Config example:

plugins: [
  {
    name: "removeAttrs",
    params: {
      attrs: "(fill|stroke)"
    }
  }
]
`;
removeAttrs.fn = (root, params) => {
  if (typeof params.attrs == "undefined") {
    console.warn(ENOATTRS);
    return null;
  }
  const elemSeparator = typeof params.elemSeparator == "string" ? params.elemSeparator : DEFAULT_SEPARATOR;
  const preserveCurrentColor = typeof params.preserveCurrentColor == "boolean" ? params.preserveCurrentColor : false;
  const attrs = Array.isArray(params.attrs) ? params.attrs : [params.attrs];
  return {
    element: {
      enter: (node2) => {
        for (let pattern of attrs) {
          if (pattern.includes(elemSeparator) === false) {
            pattern = [".*", elemSeparator, pattern, elemSeparator, ".*"].join(
              ""
            );
          } else if (pattern.split(elemSeparator).length < 3) {
            pattern = [pattern, elemSeparator, ".*"].join("");
          }
          const list = pattern.split(elemSeparator).map((value2) => {
            if (value2 === "*") {
              value2 = ".*";
            }
            return new RegExp(["^", value2, "$"].join(""), "i");
          });
          if (list[0].test(node2.name)) {
            for (const [name2, value2] of Object.entries(node2.attributes)) {
              const isFillCurrentColor = preserveCurrentColor && name2 == "fill" && value2 == "currentColor";
              const isStrokeCurrentColor = preserveCurrentColor && name2 == "stroke" && value2 == "currentColor";
              if (!isFillCurrentColor && !isStrokeCurrentColor && list[1].test(name2) && list[2].test(value2)) {
                delete node2.attributes[name2];
              }
            }
          }
        }
      }
    }
  };
};
var removeDimensions = {};
removeDimensions.type = "visitor";
removeDimensions.name = "removeDimensions";
removeDimensions.active = false;
removeDimensions.description = "removes width and height in presence of viewBox (opposite to removeViewBox, disable it first)";
removeDimensions.fn = () => {
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "svg") {
          if (node2.attributes.viewBox != null) {
            delete node2.attributes.width;
            delete node2.attributes.height;
          } else if (node2.attributes.width != null && node2.attributes.height != null && Number.isNaN(Number(node2.attributes.width)) === false && Number.isNaN(Number(node2.attributes.height)) === false) {
            const width = Number(node2.attributes.width);
            const height = Number(node2.attributes.height);
            node2.attributes.viewBox = `0 0 ${width} ${height}`;
            delete node2.attributes.width;
            delete node2.attributes.height;
          }
        }
      }
    }
  };
};
var removeElementsByAttr = {};
const { detachNodeFromParent: detachNodeFromParent$4 } = xast;
removeElementsByAttr.name = "removeElementsByAttr";
removeElementsByAttr.type = "visitor";
removeElementsByAttr.active = false;
removeElementsByAttr.description = "removes arbitrary elements by ID or className (disabled by default)";
removeElementsByAttr.fn = (root, params) => {
  const ids = params.id == null ? [] : Array.isArray(params.id) ? params.id : [params.id];
  const classes = params.class == null ? [] : Array.isArray(params.class) ? params.class : [params.class];
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.attributes.id != null && ids.length !== 0) {
          if (ids.includes(node2.attributes.id)) {
            detachNodeFromParent$4(node2, parentNode);
          }
        }
        if (node2.attributes.class && classes.length !== 0) {
          const classList = node2.attributes.class.split(" ");
          for (const item of classes) {
            if (classList.includes(item)) {
              detachNodeFromParent$4(node2, parentNode);
              break;
            }
          }
        }
      }
    }
  };
};
var removeOffCanvasPaths = {};
const { visitSkip, detachNodeFromParent: detachNodeFromParent$3 } = xast;
const { parsePathData } = path;
const { intersects } = _path;
removeOffCanvasPaths.type = "visitor";
removeOffCanvasPaths.name = "removeOffCanvasPaths";
removeOffCanvasPaths.active = false;
removeOffCanvasPaths.description = "removes elements that are drawn outside of the viewbox (disabled by default)";
removeOffCanvasPaths.fn = () => {
  let viewBoxData = null;
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "svg" && parentNode.type === "root") {
          let viewBox = "";
          if (node2.attributes.viewBox != null) {
            viewBox = node2.attributes.viewBox;
          } else if (node2.attributes.height != null && node2.attributes.width != null) {
            viewBox = `0 0 ${node2.attributes.width} ${node2.attributes.height}`;
          }
          viewBox = viewBox.replace(/[,+]|px/g, " ").replace(/\s+/g, " ").replace(/^\s*|\s*$/g, "");
          const m = /^(-?\d*\.?\d+) (-?\d*\.?\d+) (\d*\.?\d+) (\d*\.?\d+)$/.exec(
            viewBox
          );
          if (m == null) {
            return;
          }
          const left = Number.parseFloat(m[1]);
          const top = Number.parseFloat(m[2]);
          const width = Number.parseFloat(m[3]);
          const height = Number.parseFloat(m[4]);
          viewBoxData = {
            left,
            top,
            right: left + width,
            bottom: top + height,
            width,
            height
          };
        }
        if (node2.attributes.transform != null) {
          return visitSkip;
        }
        if (node2.name === "path" && node2.attributes.d != null && viewBoxData != null) {
          const pathData = parsePathData(node2.attributes.d);
          let visible = false;
          for (const pathDataItem of pathData) {
            if (pathDataItem.command === "M") {
              const [x, y] = pathDataItem.args;
              if (x >= viewBoxData.left && x <= viewBoxData.right && y >= viewBoxData.top && y <= viewBoxData.bottom) {
                visible = true;
              }
            }
          }
          if (visible) {
            return;
          }
          if (pathData.length === 2) {
            pathData.push({ command: "z", args: [] });
          }
          const { left, top, width, height } = viewBoxData;
          const viewBoxPathData = [
            { command: "M", args: [left, top] },
            { command: "h", args: [width] },
            { command: "v", args: [height] },
            { command: "H", args: [left] },
            { command: "z", args: [] }
          ];
          if (intersects(viewBoxPathData, pathData) === false) {
            detachNodeFromParent$3(node2, parentNode);
          }
        }
      }
    }
  };
};
var removeRasterImages = {};
const { detachNodeFromParent: detachNodeFromParent$2 } = xast;
removeRasterImages.name = "removeRasterImages";
removeRasterImages.type = "visitor";
removeRasterImages.active = false;
removeRasterImages.description = "removes raster images (disabled by default)";
removeRasterImages.fn = () => {
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "image" && node2.attributes["xlink:href"] != null && /(\.|image\/)(jpg|png|gif)/.test(node2.attributes["xlink:href"])) {
          detachNodeFromParent$2(node2, parentNode);
        }
      }
    }
  };
};
var removeScriptElement = {};
const { detachNodeFromParent: detachNodeFromParent$1 } = xast;
removeScriptElement.name = "removeScriptElement";
removeScriptElement.type = "visitor";
removeScriptElement.active = false;
removeScriptElement.description = "removes <script> elements (disabled by default)";
removeScriptElement.fn = () => {
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "script") {
          detachNodeFromParent$1(node2, parentNode);
        }
      }
    }
  };
};
var removeStyleElement = {};
const { detachNodeFromParent } = xast;
removeStyleElement.name = "removeStyleElement";
removeStyleElement.type = "visitor";
removeStyleElement.active = false;
removeStyleElement.description = "removes <style> element (disabled by default)";
removeStyleElement.fn = () => {
  return {
    element: {
      enter: (node2, parentNode) => {
        if (node2.name === "style") {
          detachNodeFromParent(node2, parentNode);
        }
      }
    }
  };
};
var removeXMLNS = {};
removeXMLNS.type = "visitor";
removeXMLNS.name = "removeXMLNS";
removeXMLNS.active = false;
removeXMLNS.description = "removes xmlns attribute (for inline svg, disabled by default)";
removeXMLNS.fn = () => {
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "svg") {
          delete node2.attributes.xmlns;
          delete node2.attributes["xmlns:xlink"];
        }
      }
    }
  };
};
var reusePaths = {};
reusePaths.type = "visitor";
reusePaths.name = "reusePaths";
reusePaths.active = false;
reusePaths.description = "Finds <path> elements with the same d, fill, and stroke, and converts them to <use> elements referencing a single <path> def.";
reusePaths.fn = () => {
  const paths = /* @__PURE__ */ new Map();
  return {
    element: {
      enter: (node2) => {
        if (node2.name === "path" && node2.attributes.d != null) {
          const d = node2.attributes.d;
          const fill = node2.attributes.fill || "";
          const stroke = node2.attributes.stroke || "";
          const key = d + ";s:" + stroke + ";f:" + fill;
          let list = paths.get(key);
          if (list == null) {
            list = [];
            paths.set(key, list);
          }
          list.push(node2);
        }
      },
      exit: (node2, parentNode) => {
        if (node2.name === "svg" && parentNode.type === "root") {
          const defsTag = {
            type: "element",
            name: "defs",
            attributes: {},
            children: []
          };
          Object.defineProperty(defsTag, "parentNode", {
            writable: true,
            value: node2
          });
          let index2 = 0;
          for (const list of paths.values()) {
            if (list.length > 1) {
              const reusablePath = {
                type: "element",
                name: "path",
                attributes: { ...list[0].attributes },
                children: []
              };
              delete reusablePath.attributes.transform;
              let id;
              if (reusablePath.attributes.id == null) {
                id = "reuse-" + index2;
                index2 += 1;
                reusablePath.attributes.id = id;
              } else {
                id = reusablePath.attributes.id;
                delete list[0].attributes.id;
              }
              Object.defineProperty(reusablePath, "parentNode", {
                writable: true,
                value: defsTag
              });
              defsTag.children.push(reusablePath);
              for (const pathNode of list) {
                pathNode.name = "use";
                pathNode.attributes["xlink:href"] = "#" + id;
                delete pathNode.attributes.d;
                delete pathNode.attributes.stroke;
                delete pathNode.attributes.fill;
              }
            }
          }
          if (defsTag.children.length !== 0) {
            if (node2.attributes["xmlns:xlink"] == null) {
              node2.attributes["xmlns:xlink"] = "http://www.w3.org/1999/xlink";
            }
            node2.children.unshift(defsTag);
          }
        }
      }
    }
  };
};
var sortAttrs = {};
sortAttrs.type = "visitor";
sortAttrs.name = "sortAttrs";
sortAttrs.active = false;
sortAttrs.description = "Sort element attributes for better compression";
sortAttrs.fn = (_root, params) => {
  const {
    order = [
      "id",
      "width",
      "height",
      "x",
      "x1",
      "x2",
      "y",
      "y1",
      "y2",
      "cx",
      "cy",
      "r",
      "fill",
      "stroke",
      "marker",
      "d",
      "points"
    ],
    xmlnsOrder = "front"
  } = params;
  const getNsPriority = (name2) => {
    if (xmlnsOrder === "front") {
      if (name2 === "xmlns") {
        return 3;
      }
      if (name2.startsWith("xmlns:")) {
        return 2;
      }
    }
    if (name2.includes(":")) {
      return 1;
    }
    return 0;
  };
  const compareAttrs = ([aName], [bName]) => {
    const aPriority = getNsPriority(aName);
    const bPriority = getNsPriority(bName);
    const priorityNs = bPriority - aPriority;
    if (priorityNs !== 0) {
      return priorityNs;
    }
    const [aPart] = aName.split("-");
    const [bPart] = bName.split("-");
    if (aPart !== bPart) {
      const aInOrderFlag = order.includes(aPart) ? 1 : 0;
      const bInOrderFlag = order.includes(bPart) ? 1 : 0;
      if (aInOrderFlag === 1 && bInOrderFlag === 1) {
        return order.indexOf(aPart) - order.indexOf(bPart);
      }
      const priorityOrder = bInOrderFlag - aInOrderFlag;
      if (priorityOrder !== 0) {
        return priorityOrder;
      }
    }
    return aName < bName ? -1 : 1;
  };
  return {
    element: {
      enter: (node2) => {
        const attrs = Object.entries(node2.attributes);
        attrs.sort(compareAttrs);
        const sortedAttributes = {};
        for (const [name2, value2] of attrs) {
          sortedAttributes[name2] = value2;
        }
        node2.attributes = sortedAttributes;
      }
    }
  };
};
builtin$1.builtin = [
  presetDefault_1,
  addAttributesToSVGElement,
  addClassesToSVGElement,
  cleanupAttrs$1,
  cleanupEnableBackground$1,
  cleanupIDs$1,
  cleanupListOfValues,
  cleanupNumericValues$1,
  collapseGroups$1,
  convertColors$1,
  convertEllipseToCircle$1,
  convertPathData$1,
  convertShapeToPath$1,
  convertStyleToAttrs,
  convertTransform$2,
  mergeStyles$1,
  inlineStyles$1,
  mergePaths$1,
  minifyStyles$1,
  moveElemsAttrsToGroup$1,
  moveGroupAttrsToElems$1,
  prefixIds,
  removeAttributesBySelector,
  removeAttrs,
  removeComments$1,
  removeDesc$1,
  removeDimensions,
  removeDoctype$1,
  removeEditorsNSData$1,
  removeElementsByAttr,
  removeEmptyAttrs$1,
  removeEmptyContainers$1,
  removeEmptyText$1,
  removeHiddenElems$1,
  removeMetadata$1,
  removeNonInheritableGroupAttrs$1,
  removeOffCanvasPaths,
  removeRasterImages,
  removeScriptElement,
  removeStyleElement,
  removeTitle$1,
  removeUnknownsAndDefaults$1,
  removeUnusedNS$1,
  removeUselessDefs$1,
  removeUselessStrokeAndFill$1,
  removeViewBox$1,
  removeXMLNS,
  removeXMLProcInst$1,
  reusePaths,
  sortAttrs,
  sortDefsChildren$1
];
const { builtin } = builtin$1;
const pluginsMap = {};
for (const plugin of builtin) {
  pluginsMap[plugin.name] = plugin;
}
const resolvePluginConfig$1 = (plugin) => {
  var _a;
  if (typeof plugin === "string") {
    const builtinPlugin = pluginsMap[plugin];
    if (builtinPlugin == null) {
      throw Error(`Unknown builtin plugin "${plugin}" specified.`);
    }
    return {
      name: plugin,
      active: true,
      params: {},
      fn: builtinPlugin.fn
    };
  }
  if (typeof plugin === "object" && plugin != null) {
    if (plugin.name == null) {
      throw Error(`Plugin name should be specified`);
    }
    let fn = plugin.fn;
    if (fn == null) {
      const builtinPlugin = pluginsMap[plugin.name];
      if (builtinPlugin == null) {
        throw Error(`Unknown builtin plugin "${plugin.name}" specified.`);
      }
      fn = builtinPlugin.fn;
    }
    return {
      name: plugin.name,
      active: (_a = plugin.active) != null ? _a : true,
      params: plugin.params,
      fn
    };
  }
  return null;
};
config$3.resolvePluginConfig = resolvePluginConfig$1;
var parser = {};
var sax = {};
(function(exports) {
  (function(sax2) {
    sax2.parser = function(strict, opt) {
      return new SAXParser(strict, opt);
    };
    sax2.SAXParser = SAXParser;
    sax2.MAX_BUFFER_LENGTH = 64 * 1024;
    var buffers = [
      "comment",
      "sgmlDecl",
      "textNode",
      "tagName",
      "doctype",
      "procInstName",
      "procInstBody",
      "entity",
      "attribName",
      "attribValue",
      "cdata",
      "script"
    ];
    sax2.EVENTS = [
      "text",
      "processinginstruction",
      "sgmldeclaration",
      "doctype",
      "comment",
      "opentagstart",
      "attribute",
      "opentag",
      "closetag",
      "opencdata",
      "cdata",
      "closecdata",
      "error",
      "end",
      "ready",
      "script",
      "opennamespace",
      "closenamespace"
    ];
    function SAXParser(strict, opt) {
      if (!(this instanceof SAXParser)) {
        return new SAXParser(strict, opt);
      }
      var parser2 = this;
      clearBuffers(parser2);
      parser2.q = parser2.c = "";
      parser2.bufferCheckPosition = sax2.MAX_BUFFER_LENGTH;
      parser2.opt = opt || {};
      parser2.opt.lowercase = parser2.opt.lowercase || parser2.opt.lowercasetags;
      parser2.looseCase = parser2.opt.lowercase ? "toLowerCase" : "toUpperCase";
      parser2.tags = [];
      parser2.closed = parser2.closedRoot = parser2.sawRoot = false;
      parser2.tag = parser2.error = null;
      parser2.strict = !!strict;
      parser2.noscript = !!(strict || parser2.opt.noscript);
      parser2.state = S.BEGIN;
      parser2.strictEntities = parser2.opt.strictEntities;
      parser2.ENTITIES = parser2.strictEntities ? Object.create(sax2.XML_ENTITIES) : Object.create(sax2.ENTITIES);
      parser2.attribList = [];
      if (parser2.opt.xmlns) {
        parser2.ns = Object.create(rootNS);
      }
      parser2.trackPosition = parser2.opt.position !== false;
      if (parser2.trackPosition) {
        parser2.position = parser2.line = parser2.column = 0;
      }
      emit(parser2, "onready");
    }
    if (!Object.create) {
      Object.create = function(o) {
        function F2() {
        }
        F2.prototype = o;
        var newf = new F2();
        return newf;
      };
    }
    if (!Object.keys) {
      Object.keys = function(o) {
        var a = [];
        for (var i in o)
          if (o.hasOwnProperty(i))
            a.push(i);
        return a;
      };
    }
    function checkBufferLength(parser2) {
      var maxAllowed = Math.max(sax2.MAX_BUFFER_LENGTH, 10);
      var maxActual = 0;
      for (var i = 0, l = buffers.length; i < l; i++) {
        var len = parser2[buffers[i]].length;
        if (len > maxAllowed) {
          switch (buffers[i]) {
            case "textNode":
              closeText(parser2);
              break;
            case "cdata":
              emitNode(parser2, "oncdata", parser2.cdata);
              parser2.cdata = "";
              break;
            case "script":
              emitNode(parser2, "onscript", parser2.script);
              parser2.script = "";
              break;
            default:
              error2(parser2, "Max buffer length exceeded: " + buffers[i]);
          }
        }
        maxActual = Math.max(maxActual, len);
      }
      var m = sax2.MAX_BUFFER_LENGTH - maxActual;
      parser2.bufferCheckPosition = m + parser2.position;
    }
    function clearBuffers(parser2) {
      for (var i = 0, l = buffers.length; i < l; i++) {
        parser2[buffers[i]] = "";
      }
    }
    function flushBuffers(parser2) {
      closeText(parser2);
      if (parser2.cdata !== "") {
        emitNode(parser2, "oncdata", parser2.cdata);
        parser2.cdata = "";
      }
      if (parser2.script !== "") {
        emitNode(parser2, "onscript", parser2.script);
        parser2.script = "";
      }
    }
    SAXParser.prototype = {
      end: function() {
        end(this);
      },
      write,
      resume: function() {
        this.error = null;
        return this;
      },
      close: function() {
        return this.write(null);
      },
      flush: function() {
        flushBuffers(this);
      }
    };
    var CDATA2 = "[CDATA[";
    var DOCTYPE = "DOCTYPE";
    var XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";
    var XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/";
    var rootNS = { xml: XML_NAMESPACE, xmlns: XMLNS_NAMESPACE };
    var nameStart = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
    var nameBody = /[:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
    var entityStart = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD]/;
    var entityBody = /[#:_A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u00B7\u0300-\u036F\u203F-\u2040.\d-]/;
    function isWhitespace2(c) {
      return c === " " || c === "\n" || c === "\r" || c === "	";
    }
    function isQuote2(c) {
      return c === '"' || c === "'";
    }
    function isAttribEnd(c) {
      return c === ">" || isWhitespace2(c);
    }
    function isMatch(regex, c) {
      return regex.test(c);
    }
    function notMatch(regex, c) {
      return !isMatch(regex, c);
    }
    var S = 0;
    sax2.STATE = {
      BEGIN: S++,
      BEGIN_WHITESPACE: S++,
      TEXT: S++,
      TEXT_ENTITY: S++,
      OPEN_WAKA: S++,
      SGML_DECL: S++,
      SGML_DECL_QUOTED: S++,
      DOCTYPE: S++,
      DOCTYPE_QUOTED: S++,
      DOCTYPE_DTD: S++,
      DOCTYPE_DTD_QUOTED: S++,
      COMMENT_STARTING: S++,
      COMMENT: S++,
      COMMENT_ENDING: S++,
      COMMENT_ENDED: S++,
      CDATA: S++,
      CDATA_ENDING: S++,
      CDATA_ENDING_2: S++,
      PROC_INST: S++,
      PROC_INST_BODY: S++,
      PROC_INST_ENDING: S++,
      OPEN_TAG: S++,
      OPEN_TAG_SLASH: S++,
      ATTRIB: S++,
      ATTRIB_NAME: S++,
      ATTRIB_NAME_SAW_WHITE: S++,
      ATTRIB_VALUE: S++,
      ATTRIB_VALUE_QUOTED: S++,
      ATTRIB_VALUE_CLOSED: S++,
      ATTRIB_VALUE_UNQUOTED: S++,
      ATTRIB_VALUE_ENTITY_Q: S++,
      ATTRIB_VALUE_ENTITY_U: S++,
      CLOSE_TAG: S++,
      CLOSE_TAG_SAW_WHITE: S++,
      SCRIPT: S++,
      SCRIPT_ENDING: S++
    };
    sax2.XML_ENTITIES = {
      "amp": "&",
      "gt": ">",
      "lt": "<",
      "quot": '"',
      "apos": "'"
    };
    sax2.ENTITIES = {
      "amp": "&",
      "gt": ">",
      "lt": "<",
      "quot": '"',
      "apos": "'",
      "AElig": 198,
      "Aacute": 193,
      "Acirc": 194,
      "Agrave": 192,
      "Aring": 197,
      "Atilde": 195,
      "Auml": 196,
      "Ccedil": 199,
      "ETH": 208,
      "Eacute": 201,
      "Ecirc": 202,
      "Egrave": 200,
      "Euml": 203,
      "Iacute": 205,
      "Icirc": 206,
      "Igrave": 204,
      "Iuml": 207,
      "Ntilde": 209,
      "Oacute": 211,
      "Ocirc": 212,
      "Ograve": 210,
      "Oslash": 216,
      "Otilde": 213,
      "Ouml": 214,
      "THORN": 222,
      "Uacute": 218,
      "Ucirc": 219,
      "Ugrave": 217,
      "Uuml": 220,
      "Yacute": 221,
      "aacute": 225,
      "acirc": 226,
      "aelig": 230,
      "agrave": 224,
      "aring": 229,
      "atilde": 227,
      "auml": 228,
      "ccedil": 231,
      "eacute": 233,
      "ecirc": 234,
      "egrave": 232,
      "eth": 240,
      "euml": 235,
      "iacute": 237,
      "icirc": 238,
      "igrave": 236,
      "iuml": 239,
      "ntilde": 241,
      "oacute": 243,
      "ocirc": 244,
      "ograve": 242,
      "oslash": 248,
      "otilde": 245,
      "ouml": 246,
      "szlig": 223,
      "thorn": 254,
      "uacute": 250,
      "ucirc": 251,
      "ugrave": 249,
      "uuml": 252,
      "yacute": 253,
      "yuml": 255,
      "copy": 169,
      "reg": 174,
      "nbsp": 160,
      "iexcl": 161,
      "cent": 162,
      "pound": 163,
      "curren": 164,
      "yen": 165,
      "brvbar": 166,
      "sect": 167,
      "uml": 168,
      "ordf": 170,
      "laquo": 171,
      "not": 172,
      "shy": 173,
      "macr": 175,
      "deg": 176,
      "plusmn": 177,
      "sup1": 185,
      "sup2": 178,
      "sup3": 179,
      "acute": 180,
      "micro": 181,
      "para": 182,
      "middot": 183,
      "cedil": 184,
      "ordm": 186,
      "raquo": 187,
      "frac14": 188,
      "frac12": 189,
      "frac34": 190,
      "iquest": 191,
      "times": 215,
      "divide": 247,
      "OElig": 338,
      "oelig": 339,
      "Scaron": 352,
      "scaron": 353,
      "Yuml": 376,
      "fnof": 402,
      "circ": 710,
      "tilde": 732,
      "Alpha": 913,
      "Beta": 914,
      "Gamma": 915,
      "Delta": 916,
      "Epsilon": 917,
      "Zeta": 918,
      "Eta": 919,
      "Theta": 920,
      "Iota": 921,
      "Kappa": 922,
      "Lambda": 923,
      "Mu": 924,
      "Nu": 925,
      "Xi": 926,
      "Omicron": 927,
      "Pi": 928,
      "Rho": 929,
      "Sigma": 931,
      "Tau": 932,
      "Upsilon": 933,
      "Phi": 934,
      "Chi": 935,
      "Psi": 936,
      "Omega": 937,
      "alpha": 945,
      "beta": 946,
      "gamma": 947,
      "delta": 948,
      "epsilon": 949,
      "zeta": 950,
      "eta": 951,
      "theta": 952,
      "iota": 953,
      "kappa": 954,
      "lambda": 955,
      "mu": 956,
      "nu": 957,
      "xi": 958,
      "omicron": 959,
      "pi": 960,
      "rho": 961,
      "sigmaf": 962,
      "sigma": 963,
      "tau": 964,
      "upsilon": 965,
      "phi": 966,
      "chi": 967,
      "psi": 968,
      "omega": 969,
      "thetasym": 977,
      "upsih": 978,
      "piv": 982,
      "ensp": 8194,
      "emsp": 8195,
      "thinsp": 8201,
      "zwnj": 8204,
      "zwj": 8205,
      "lrm": 8206,
      "rlm": 8207,
      "ndash": 8211,
      "mdash": 8212,
      "lsquo": 8216,
      "rsquo": 8217,
      "sbquo": 8218,
      "ldquo": 8220,
      "rdquo": 8221,
      "bdquo": 8222,
      "dagger": 8224,
      "Dagger": 8225,
      "bull": 8226,
      "hellip": 8230,
      "permil": 8240,
      "prime": 8242,
      "Prime": 8243,
      "lsaquo": 8249,
      "rsaquo": 8250,
      "oline": 8254,
      "frasl": 8260,
      "euro": 8364,
      "image": 8465,
      "weierp": 8472,
      "real": 8476,
      "trade": 8482,
      "alefsym": 8501,
      "larr": 8592,
      "uarr": 8593,
      "rarr": 8594,
      "darr": 8595,
      "harr": 8596,
      "crarr": 8629,
      "lArr": 8656,
      "uArr": 8657,
      "rArr": 8658,
      "dArr": 8659,
      "hArr": 8660,
      "forall": 8704,
      "part": 8706,
      "exist": 8707,
      "empty": 8709,
      "nabla": 8711,
      "isin": 8712,
      "notin": 8713,
      "ni": 8715,
      "prod": 8719,
      "sum": 8721,
      "minus": 8722,
      "lowast": 8727,
      "radic": 8730,
      "prop": 8733,
      "infin": 8734,
      "ang": 8736,
      "and": 8743,
      "or": 8744,
      "cap": 8745,
      "cup": 8746,
      "int": 8747,
      "there4": 8756,
      "sim": 8764,
      "cong": 8773,
      "asymp": 8776,
      "ne": 8800,
      "equiv": 8801,
      "le": 8804,
      "ge": 8805,
      "sub": 8834,
      "sup": 8835,
      "nsub": 8836,
      "sube": 8838,
      "supe": 8839,
      "oplus": 8853,
      "otimes": 8855,
      "perp": 8869,
      "sdot": 8901,
      "lceil": 8968,
      "rceil": 8969,
      "lfloor": 8970,
      "rfloor": 8971,
      "lang": 9001,
      "rang": 9002,
      "loz": 9674,
      "spades": 9824,
      "clubs": 9827,
      "hearts": 9829,
      "diams": 9830
    };
    Object.keys(sax2.ENTITIES).forEach(function(key) {
      var e = sax2.ENTITIES[key];
      var s2 = typeof e === "number" ? String.fromCharCode(e) : e;
      sax2.ENTITIES[key] = s2;
    });
    for (var s in sax2.STATE) {
      sax2.STATE[sax2.STATE[s]] = s;
    }
    S = sax2.STATE;
    function emit(parser2, event, data2) {
      parser2[event] && parser2[event](data2);
    }
    function emitNode(parser2, nodeType, data2) {
      if (parser2.textNode)
        closeText(parser2);
      emit(parser2, nodeType, data2);
    }
    function closeText(parser2) {
      parser2.textNode = textopts(parser2.opt, parser2.textNode);
      if (parser2.textNode)
        emit(parser2, "ontext", parser2.textNode);
      parser2.textNode = "";
    }
    function textopts(opt, text) {
      if (opt.trim)
        text = text.trim();
      if (opt.normalize)
        text = text.replace(/\s+/g, " ");
      return text;
    }
    function error2(parser2, reason) {
      closeText(parser2);
      const message = reason + "\nLine: " + parser2.line + "\nColumn: " + parser2.column + "\nChar: " + parser2.c;
      const error3 = new Error(message);
      error3.reason = reason;
      error3.line = parser2.line;
      error3.column = parser2.column;
      parser2.error = error3;
      emit(parser2, "onerror", error3);
      return parser2;
    }
    function end(parser2) {
      if (parser2.sawRoot && !parser2.closedRoot)
        strictFail(parser2, "Unclosed root tag");
      if (parser2.state !== S.BEGIN && parser2.state !== S.BEGIN_WHITESPACE && parser2.state !== S.TEXT) {
        error2(parser2, "Unexpected end");
      }
      closeText(parser2);
      parser2.c = "";
      parser2.closed = true;
      emit(parser2, "onend");
      SAXParser.call(parser2, parser2.strict, parser2.opt);
      return parser2;
    }
    function strictFail(parser2, message) {
      if (typeof parser2 !== "object" || !(parser2 instanceof SAXParser)) {
        throw new Error("bad call to strictFail");
      }
      if (parser2.strict) {
        error2(parser2, message);
      }
    }
    function newTag(parser2) {
      if (!parser2.strict)
        parser2.tagName = parser2.tagName[parser2.looseCase]();
      var parent = parser2.tags[parser2.tags.length - 1] || parser2;
      var tag = parser2.tag = { name: parser2.tagName, attributes: {} };
      if (parser2.opt.xmlns) {
        tag.ns = parent.ns;
      }
      parser2.attribList.length = 0;
      emitNode(parser2, "onopentagstart", tag);
    }
    function qname(name2, attribute) {
      var i = name2.indexOf(":");
      var qualName = i < 0 ? ["", name2] : name2.split(":");
      var prefix = qualName[0];
      var local = qualName[1];
      if (attribute && name2 === "xmlns") {
        prefix = "xmlns";
        local = "";
      }
      return { prefix, local };
    }
    function attrib(parser2) {
      if (!parser2.strict) {
        parser2.attribName = parser2.attribName[parser2.looseCase]();
      }
      if (parser2.attribList.indexOf(parser2.attribName) !== -1 || parser2.tag.attributes.hasOwnProperty(parser2.attribName)) {
        parser2.attribName = parser2.attribValue = "";
        return;
      }
      if (parser2.opt.xmlns) {
        var qn = qname(parser2.attribName, true);
        var prefix = qn.prefix;
        var local = qn.local;
        if (prefix === "xmlns") {
          if (local === "xml" && parser2.attribValue !== XML_NAMESPACE) {
            strictFail(
              parser2,
              "xml: prefix must be bound to " + XML_NAMESPACE + "\nActual: " + parser2.attribValue
            );
          } else if (local === "xmlns" && parser2.attribValue !== XMLNS_NAMESPACE) {
            strictFail(
              parser2,
              "xmlns: prefix must be bound to " + XMLNS_NAMESPACE + "\nActual: " + parser2.attribValue
            );
          } else {
            var tag = parser2.tag;
            var parent = parser2.tags[parser2.tags.length - 1] || parser2;
            if (tag.ns === parent.ns) {
              tag.ns = Object.create(parent.ns);
            }
            tag.ns[local] = parser2.attribValue;
          }
        }
        parser2.attribList.push([parser2.attribName, parser2.attribValue]);
      } else {
        parser2.tag.attributes[parser2.attribName] = parser2.attribValue;
        emitNode(parser2, "onattribute", {
          name: parser2.attribName,
          value: parser2.attribValue
        });
      }
      parser2.attribName = parser2.attribValue = "";
    }
    function openTag(parser2, selfClosing) {
      if (parser2.opt.xmlns) {
        var tag = parser2.tag;
        var qn = qname(parser2.tagName);
        tag.prefix = qn.prefix;
        tag.local = qn.local;
        tag.uri = tag.ns[qn.prefix] || "";
        if (tag.prefix && !tag.uri) {
          strictFail(parser2, "Unbound namespace prefix: " + JSON.stringify(parser2.tagName));
          tag.uri = qn.prefix;
        }
        var parent = parser2.tags[parser2.tags.length - 1] || parser2;
        if (tag.ns && parent.ns !== tag.ns) {
          Object.keys(tag.ns).forEach(function(p) {
            emitNode(parser2, "onopennamespace", {
              prefix: p,
              uri: tag.ns[p]
            });
          });
        }
        for (var i = 0, l = parser2.attribList.length; i < l; i++) {
          var nv = parser2.attribList[i];
          var name2 = nv[0];
          var value2 = nv[1];
          var qualName = qname(name2, true);
          var prefix = qualName.prefix;
          var local = qualName.local;
          var uri = prefix === "" ? "" : tag.ns[prefix] || "";
          var a = {
            name: name2,
            value: value2,
            prefix,
            local,
            uri
          };
          if (prefix && prefix !== "xmlns" && !uri) {
            strictFail(parser2, "Unbound namespace prefix: " + JSON.stringify(prefix));
            a.uri = prefix;
          }
          parser2.tag.attributes[name2] = a;
          emitNode(parser2, "onattribute", a);
        }
        parser2.attribList.length = 0;
      }
      parser2.tag.isSelfClosing = !!selfClosing;
      parser2.sawRoot = true;
      parser2.tags.push(parser2.tag);
      emitNode(parser2, "onopentag", parser2.tag);
      if (!selfClosing) {
        if (!parser2.noscript && parser2.tagName.toLowerCase() === "script") {
          parser2.state = S.SCRIPT;
        } else {
          parser2.state = S.TEXT;
        }
        parser2.tag = null;
        parser2.tagName = "";
      }
      parser2.attribName = parser2.attribValue = "";
      parser2.attribList.length = 0;
    }
    function closeTag(parser2) {
      if (!parser2.tagName) {
        strictFail(parser2, "Weird empty close tag.");
        parser2.textNode += "</>";
        parser2.state = S.TEXT;
        return;
      }
      if (parser2.script) {
        if (parser2.tagName !== "script") {
          parser2.script += "</" + parser2.tagName + ">";
          parser2.tagName = "";
          parser2.state = S.SCRIPT;
          return;
        }
        emitNode(parser2, "onscript", parser2.script);
        parser2.script = "";
      }
      var t = parser2.tags.length;
      var tagName = parser2.tagName;
      if (!parser2.strict) {
        tagName = tagName[parser2.looseCase]();
      }
      var closeTo = tagName;
      while (t--) {
        var close = parser2.tags[t];
        if (close.name !== closeTo) {
          strictFail(parser2, "Unexpected close tag");
        } else {
          break;
        }
      }
      if (t < 0) {
        strictFail(parser2, "Unmatched closing tag: " + parser2.tagName);
        parser2.textNode += "</" + parser2.tagName + ">";
        parser2.state = S.TEXT;
        return;
      }
      parser2.tagName = tagName;
      var s2 = parser2.tags.length;
      while (s2-- > t) {
        var tag = parser2.tag = parser2.tags.pop();
        parser2.tagName = parser2.tag.name;
        emitNode(parser2, "onclosetag", parser2.tagName);
        var x = {};
        for (var i in tag.ns) {
          x[i] = tag.ns[i];
        }
        var parent = parser2.tags[parser2.tags.length - 1] || parser2;
        if (parser2.opt.xmlns && tag.ns !== parent.ns) {
          Object.keys(tag.ns).forEach(function(p) {
            var n = tag.ns[p];
            emitNode(parser2, "onclosenamespace", { prefix: p, uri: n });
          });
        }
      }
      if (t === 0)
        parser2.closedRoot = true;
      parser2.tagName = parser2.attribValue = parser2.attribName = "";
      parser2.attribList.length = 0;
      parser2.state = S.TEXT;
    }
    function parseEntity(parser2) {
      var entity = parser2.entity;
      var entityLC = entity.toLowerCase();
      var num;
      var numStr = "";
      if (parser2.ENTITIES[entity]) {
        return parser2.ENTITIES[entity];
      }
      if (parser2.ENTITIES[entityLC]) {
        return parser2.ENTITIES[entityLC];
      }
      entity = entityLC;
      if (entity.charAt(0) === "#") {
        if (entity.charAt(1) === "x") {
          entity = entity.slice(2);
          num = parseInt(entity, 16);
          numStr = num.toString(16);
        } else {
          entity = entity.slice(1);
          num = parseInt(entity, 10);
          numStr = num.toString(10);
        }
      }
      entity = entity.replace(/^0+/, "");
      if (isNaN(num) || numStr.toLowerCase() !== entity) {
        strictFail(parser2, "Invalid character entity");
        return "&" + parser2.entity + ";";
      }
      return String.fromCodePoint(num);
    }
    function beginWhiteSpace(parser2, c) {
      if (c === "<") {
        parser2.state = S.OPEN_WAKA;
        parser2.startTagPosition = parser2.position;
      } else if (!isWhitespace2(c)) {
        strictFail(parser2, "Non-whitespace before first tag.");
        parser2.textNode = c;
        parser2.state = S.TEXT;
      }
    }
    function charAt(chunk, i) {
      var result = "";
      if (i < chunk.length) {
        result = chunk.charAt(i);
      }
      return result;
    }
    function write(chunk) {
      var parser2 = this;
      if (this.error) {
        throw this.error;
      }
      if (parser2.closed) {
        return error2(
          parser2,
          "Cannot write after close. Assign an onready handler."
        );
      }
      if (chunk === null) {
        return end(parser2);
      }
      if (typeof chunk === "object") {
        chunk = chunk.toString();
      }
      var i = 0;
      var c = "";
      while (true) {
        c = charAt(chunk, i++);
        parser2.c = c;
        if (!c) {
          break;
        }
        if (parser2.trackPosition) {
          parser2.position++;
          if (c === "\n") {
            parser2.line++;
            parser2.column = 0;
          } else {
            parser2.column++;
          }
        }
        switch (parser2.state) {
          case S.BEGIN:
            parser2.state = S.BEGIN_WHITESPACE;
            if (c === "\uFEFF") {
              continue;
            }
            beginWhiteSpace(parser2, c);
            continue;
          case S.BEGIN_WHITESPACE:
            beginWhiteSpace(parser2, c);
            continue;
          case S.TEXT:
            if (parser2.sawRoot && !parser2.closedRoot) {
              var starti = i - 1;
              while (c && c !== "<" && c !== "&") {
                c = charAt(chunk, i++);
                if (c && parser2.trackPosition) {
                  parser2.position++;
                  if (c === "\n") {
                    parser2.line++;
                    parser2.column = 0;
                  } else {
                    parser2.column++;
                  }
                }
              }
              parser2.textNode += chunk.substring(starti, i - 1);
            }
            if (c === "<" && !(parser2.sawRoot && parser2.closedRoot && !parser2.strict)) {
              parser2.state = S.OPEN_WAKA;
              parser2.startTagPosition = parser2.position;
            } else {
              if (!isWhitespace2(c) && (!parser2.sawRoot || parser2.closedRoot)) {
                strictFail(parser2, "Text data outside of root node.");
              }
              if (c === "&") {
                parser2.state = S.TEXT_ENTITY;
              } else {
                parser2.textNode += c;
              }
            }
            continue;
          case S.SCRIPT:
            if (c === "<") {
              parser2.state = S.SCRIPT_ENDING;
            } else {
              parser2.script += c;
            }
            continue;
          case S.SCRIPT_ENDING:
            if (c === "/") {
              parser2.state = S.CLOSE_TAG;
            } else {
              parser2.script += "<" + c;
              parser2.state = S.SCRIPT;
            }
            continue;
          case S.OPEN_WAKA:
            if (c === "!") {
              parser2.state = S.SGML_DECL;
              parser2.sgmlDecl = "";
            } else if (isWhitespace2(c))
              ;
            else if (isMatch(nameStart, c)) {
              parser2.state = S.OPEN_TAG;
              parser2.tagName = c;
            } else if (c === "/") {
              parser2.state = S.CLOSE_TAG;
              parser2.tagName = "";
            } else if (c === "?") {
              parser2.state = S.PROC_INST;
              parser2.procInstName = parser2.procInstBody = "";
            } else {
              strictFail(parser2, "Unencoded <");
              if (parser2.startTagPosition + 1 < parser2.position) {
                var pad = parser2.position - parser2.startTagPosition;
                c = new Array(pad).join(" ") + c;
              }
              parser2.textNode += "<" + c;
              parser2.state = S.TEXT;
            }
            continue;
          case S.SGML_DECL:
            if ((parser2.sgmlDecl + c).toUpperCase() === CDATA2) {
              emitNode(parser2, "onopencdata");
              parser2.state = S.CDATA;
              parser2.sgmlDecl = "";
              parser2.cdata = "";
            } else if (parser2.sgmlDecl + c === "--") {
              parser2.state = S.COMMENT;
              parser2.comment = "";
              parser2.sgmlDecl = "";
            } else if ((parser2.sgmlDecl + c).toUpperCase() === DOCTYPE) {
              parser2.state = S.DOCTYPE;
              if (parser2.doctype || parser2.sawRoot) {
                strictFail(
                  parser2,
                  "Inappropriately located doctype declaration"
                );
              }
              parser2.doctype = "";
              parser2.sgmlDecl = "";
            } else if (c === ">") {
              emitNode(parser2, "onsgmldeclaration", parser2.sgmlDecl);
              parser2.sgmlDecl = "";
              parser2.state = S.TEXT;
            } else if (isQuote2(c)) {
              parser2.state = S.SGML_DECL_QUOTED;
              parser2.sgmlDecl += c;
            } else {
              parser2.sgmlDecl += c;
            }
            continue;
          case S.SGML_DECL_QUOTED:
            if (c === parser2.q) {
              parser2.state = S.SGML_DECL;
              parser2.q = "";
            }
            parser2.sgmlDecl += c;
            continue;
          case S.DOCTYPE:
            if (c === ">") {
              parser2.state = S.TEXT;
              emitNode(parser2, "ondoctype", parser2.doctype);
              parser2.doctype = true;
            } else {
              parser2.doctype += c;
              if (c === "[") {
                parser2.state = S.DOCTYPE_DTD;
              } else if (isQuote2(c)) {
                parser2.state = S.DOCTYPE_QUOTED;
                parser2.q = c;
              }
            }
            continue;
          case S.DOCTYPE_QUOTED:
            parser2.doctype += c;
            if (c === parser2.q) {
              parser2.q = "";
              parser2.state = S.DOCTYPE;
            }
            continue;
          case S.DOCTYPE_DTD:
            parser2.doctype += c;
            if (c === "]") {
              parser2.state = S.DOCTYPE;
            } else if (isQuote2(c)) {
              parser2.state = S.DOCTYPE_DTD_QUOTED;
              parser2.q = c;
            }
            continue;
          case S.DOCTYPE_DTD_QUOTED:
            parser2.doctype += c;
            if (c === parser2.q) {
              parser2.state = S.DOCTYPE_DTD;
              parser2.q = "";
            }
            continue;
          case S.COMMENT:
            if (c === "-") {
              parser2.state = S.COMMENT_ENDING;
            } else {
              parser2.comment += c;
            }
            continue;
          case S.COMMENT_ENDING:
            if (c === "-") {
              parser2.state = S.COMMENT_ENDED;
              parser2.comment = textopts(parser2.opt, parser2.comment);
              if (parser2.comment) {
                emitNode(parser2, "oncomment", parser2.comment);
              }
              parser2.comment = "";
            } else {
              parser2.comment += "-" + c;
              parser2.state = S.COMMENT;
            }
            continue;
          case S.COMMENT_ENDED:
            if (c !== ">") {
              strictFail(parser2, "Malformed comment");
              parser2.comment += "--" + c;
              parser2.state = S.COMMENT;
            } else {
              parser2.state = S.TEXT;
            }
            continue;
          case S.CDATA:
            if (c === "]") {
              parser2.state = S.CDATA_ENDING;
            } else {
              parser2.cdata += c;
            }
            continue;
          case S.CDATA_ENDING:
            if (c === "]") {
              parser2.state = S.CDATA_ENDING_2;
            } else {
              parser2.cdata += "]" + c;
              parser2.state = S.CDATA;
            }
            continue;
          case S.CDATA_ENDING_2:
            if (c === ">") {
              if (parser2.cdata) {
                emitNode(parser2, "oncdata", parser2.cdata);
              }
              emitNode(parser2, "onclosecdata");
              parser2.cdata = "";
              parser2.state = S.TEXT;
            } else if (c === "]") {
              parser2.cdata += "]";
            } else {
              parser2.cdata += "]]" + c;
              parser2.state = S.CDATA;
            }
            continue;
          case S.PROC_INST:
            if (c === "?") {
              parser2.state = S.PROC_INST_ENDING;
            } else if (isWhitespace2(c)) {
              parser2.state = S.PROC_INST_BODY;
            } else {
              parser2.procInstName += c;
            }
            continue;
          case S.PROC_INST_BODY:
            if (!parser2.procInstBody && isWhitespace2(c)) {
              continue;
            } else if (c === "?") {
              parser2.state = S.PROC_INST_ENDING;
            } else {
              parser2.procInstBody += c;
            }
            continue;
          case S.PROC_INST_ENDING:
            if (c === ">") {
              emitNode(parser2, "onprocessinginstruction", {
                name: parser2.procInstName,
                body: parser2.procInstBody
              });
              parser2.procInstName = parser2.procInstBody = "";
              parser2.state = S.TEXT;
            } else {
              parser2.procInstBody += "?" + c;
              parser2.state = S.PROC_INST_BODY;
            }
            continue;
          case S.OPEN_TAG:
            if (isMatch(nameBody, c)) {
              parser2.tagName += c;
            } else {
              newTag(parser2);
              if (c === ">") {
                openTag(parser2);
              } else if (c === "/") {
                parser2.state = S.OPEN_TAG_SLASH;
              } else {
                if (!isWhitespace2(c)) {
                  strictFail(parser2, "Invalid character in tag name");
                }
                parser2.state = S.ATTRIB;
              }
            }
            continue;
          case S.OPEN_TAG_SLASH:
            if (c === ">") {
              openTag(parser2, true);
              closeTag(parser2);
            } else {
              strictFail(parser2, "Forward-slash in opening tag not followed by >");
              parser2.state = S.ATTRIB;
            }
            continue;
          case S.ATTRIB:
            if (isWhitespace2(c)) {
              continue;
            } else if (c === ">") {
              openTag(parser2);
            } else if (c === "/") {
              parser2.state = S.OPEN_TAG_SLASH;
            } else if (isMatch(nameStart, c)) {
              parser2.attribName = c;
              parser2.attribValue = "";
              parser2.state = S.ATTRIB_NAME;
            } else {
              strictFail(parser2, "Invalid attribute name");
            }
            continue;
          case S.ATTRIB_NAME:
            if (c === "=") {
              parser2.state = S.ATTRIB_VALUE;
            } else if (c === ">") {
              strictFail(parser2, "Attribute without value");
              parser2.attribValue = parser2.attribName;
              attrib(parser2);
              openTag(parser2);
            } else if (isWhitespace2(c)) {
              parser2.state = S.ATTRIB_NAME_SAW_WHITE;
            } else if (isMatch(nameBody, c)) {
              parser2.attribName += c;
            } else {
              strictFail(parser2, "Invalid attribute name");
            }
            continue;
          case S.ATTRIB_NAME_SAW_WHITE:
            if (c === "=") {
              parser2.state = S.ATTRIB_VALUE;
            } else if (isWhitespace2(c)) {
              continue;
            } else {
              strictFail(parser2, "Attribute without value");
              parser2.tag.attributes[parser2.attribName] = "";
              parser2.attribValue = "";
              emitNode(parser2, "onattribute", {
                name: parser2.attribName,
                value: ""
              });
              parser2.attribName = "";
              if (c === ">") {
                openTag(parser2);
              } else if (isMatch(nameStart, c)) {
                parser2.attribName = c;
                parser2.state = S.ATTRIB_NAME;
              } else {
                strictFail(parser2, "Invalid attribute name");
                parser2.state = S.ATTRIB;
              }
            }
            continue;
          case S.ATTRIB_VALUE:
            if (isWhitespace2(c)) {
              continue;
            } else if (isQuote2(c)) {
              parser2.q = c;
              parser2.state = S.ATTRIB_VALUE_QUOTED;
            } else {
              strictFail(parser2, "Unquoted attribute value");
              parser2.state = S.ATTRIB_VALUE_UNQUOTED;
              parser2.attribValue = c;
            }
            continue;
          case S.ATTRIB_VALUE_QUOTED:
            if (c !== parser2.q) {
              if (c === "&") {
                parser2.state = S.ATTRIB_VALUE_ENTITY_Q;
              } else {
                parser2.attribValue += c;
              }
              continue;
            }
            attrib(parser2);
            parser2.q = "";
            parser2.state = S.ATTRIB_VALUE_CLOSED;
            continue;
          case S.ATTRIB_VALUE_CLOSED:
            if (isWhitespace2(c)) {
              parser2.state = S.ATTRIB;
            } else if (c === ">") {
              openTag(parser2);
            } else if (c === "/") {
              parser2.state = S.OPEN_TAG_SLASH;
            } else if (isMatch(nameStart, c)) {
              strictFail(parser2, "No whitespace between attributes");
              parser2.attribName = c;
              parser2.attribValue = "";
              parser2.state = S.ATTRIB_NAME;
            } else {
              strictFail(parser2, "Invalid attribute name");
            }
            continue;
          case S.ATTRIB_VALUE_UNQUOTED:
            if (!isAttribEnd(c)) {
              if (c === "&") {
                parser2.state = S.ATTRIB_VALUE_ENTITY_U;
              } else {
                parser2.attribValue += c;
              }
              continue;
            }
            attrib(parser2);
            if (c === ">") {
              openTag(parser2);
            } else {
              parser2.state = S.ATTRIB;
            }
            continue;
          case S.CLOSE_TAG:
            if (!parser2.tagName) {
              if (isWhitespace2(c)) {
                continue;
              } else if (notMatch(nameStart, c)) {
                if (parser2.script) {
                  parser2.script += "</" + c;
                  parser2.state = S.SCRIPT;
                } else {
                  strictFail(parser2, "Invalid tagname in closing tag.");
                }
              } else {
                parser2.tagName = c;
              }
            } else if (c === ">") {
              closeTag(parser2);
            } else if (isMatch(nameBody, c)) {
              parser2.tagName += c;
            } else if (parser2.script) {
              parser2.script += "</" + parser2.tagName;
              parser2.tagName = "";
              parser2.state = S.SCRIPT;
            } else {
              if (!isWhitespace2(c)) {
                strictFail(parser2, "Invalid tagname in closing tag");
              }
              parser2.state = S.CLOSE_TAG_SAW_WHITE;
            }
            continue;
          case S.CLOSE_TAG_SAW_WHITE:
            if (isWhitespace2(c)) {
              continue;
            }
            if (c === ">") {
              closeTag(parser2);
            } else {
              strictFail(parser2, "Invalid characters in closing tag");
            }
            continue;
          case S.TEXT_ENTITY:
          case S.ATTRIB_VALUE_ENTITY_Q:
          case S.ATTRIB_VALUE_ENTITY_U:
            var returnState;
            var buffer;
            switch (parser2.state) {
              case S.TEXT_ENTITY:
                returnState = S.TEXT;
                buffer = "textNode";
                break;
              case S.ATTRIB_VALUE_ENTITY_Q:
                returnState = S.ATTRIB_VALUE_QUOTED;
                buffer = "attribValue";
                break;
              case S.ATTRIB_VALUE_ENTITY_U:
                returnState = S.ATTRIB_VALUE_UNQUOTED;
                buffer = "attribValue";
                break;
            }
            if (c === ";") {
              var parsedEntity = parseEntity(parser2);
              if (parser2.state === S.TEXT_ENTITY && !sax2.ENTITIES[parser2.entity] && parsedEntity !== "&" + parser2.entity + ";") {
                chunk = chunk.slice(0, i) + parsedEntity + chunk.slice(i);
              } else {
                parser2[buffer] += parsedEntity;
              }
              parser2.entity = "";
              parser2.state = returnState;
            } else if (isMatch(parser2.entity.length ? entityBody : entityStart, c)) {
              parser2.entity += c;
            } else {
              strictFail(parser2, "Invalid character in entity name");
              parser2[buffer] += "&" + parser2.entity + c;
              parser2.entity = "";
              parser2.state = returnState;
            }
            continue;
          default:
            throw new Error(parser2, "Unknown state: " + parser2.state);
        }
      }
      if (parser2.position >= parser2.bufferCheckPosition) {
        checkBufferLength(parser2);
      }
      return parser2;
    }
  })(exports);
})(sax);
const SAX = sax;
const { textElems: textElems$1 } = _collections;
class SvgoParserError extends Error {
  constructor(message, line, column, source, file) {
    super(message);
    this.name = "SvgoParserError";
    this.message = `${file || "<input>"}:${line}:${column}: ${message}`;
    this.reason = message;
    this.line = line;
    this.column = column;
    this.source = source;
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, SvgoParserError);
    }
  }
  toString() {
    const lines = this.source.split(/\r?\n/);
    const startLine = Math.max(this.line - 3, 0);
    const endLine = Math.min(this.line + 2, lines.length);
    const lineNumberWidth = String(endLine).length;
    const startColumn = Math.max(this.column - 54, 0);
    const endColumn = Math.max(this.column + 20, 80);
    const code2 = lines.slice(startLine, endLine).map((line, index2) => {
      const lineSlice = line.slice(startColumn, endColumn);
      let ellipsisPrefix = "";
      let ellipsisSuffix = "";
      if (startColumn !== 0) {
        ellipsisPrefix = startColumn > line.length - 1 ? " " : "\u2026";
      }
      if (endColumn < line.length - 1) {
        ellipsisSuffix = "\u2026";
      }
      const number2 = startLine + 1 + index2;
      const gutter = ` ${number2.toString().padStart(lineNumberWidth)} | `;
      if (number2 === this.line) {
        const gutterSpacing = gutter.replace(/[^|]/g, " ");
        const lineSpacing = (ellipsisPrefix + line.slice(startColumn, this.column - 1)).replace(/[^\t]/g, " ");
        const spacing = gutterSpacing + lineSpacing;
        return `>${gutter}${ellipsisPrefix}${lineSlice}${ellipsisSuffix}
 ${spacing}^`;
      }
      return ` ${gutter}${ellipsisPrefix}${lineSlice}${ellipsisSuffix}`;
    }).join("\n");
    return `${this.name}: ${this.message}

${code2}
`;
  }
}
const entityDeclaration = /<!ENTITY\s+(\S+)\s+(?:'([^']+)'|"([^"]+)")\s*>/g;
const config = {
  strict: true,
  trim: false,
  normalize: false,
  lowercase: true,
  xmlns: true,
  position: true
};
const parseSvg$1 = (data2, from) => {
  const sax2 = SAX.parser(config.strict, config);
  const root = { type: "root", children: [] };
  let current = root;
  const stack = [root];
  const pushToContent = (node2) => {
    Object.defineProperty(node2, "parentNode", {
      writable: true,
      value: current
    });
    current.children.push(node2);
  };
  sax2.ondoctype = (doctype) => {
    const node2 = {
      type: "doctype",
      name: "svg",
      data: {
        doctype
      }
    };
    pushToContent(node2);
    const subsetStart = doctype.indexOf("[");
    if (subsetStart >= 0) {
      entityDeclaration.lastIndex = subsetStart;
      let entityMatch = entityDeclaration.exec(data2);
      while (entityMatch != null) {
        sax2.ENTITIES[entityMatch[1]] = entityMatch[2] || entityMatch[3];
        entityMatch = entityDeclaration.exec(data2);
      }
    }
  };
  sax2.onprocessinginstruction = (data3) => {
    const node2 = {
      type: "instruction",
      name: data3.name,
      value: data3.body
    };
    pushToContent(node2);
  };
  sax2.oncomment = (comment) => {
    const node2 = {
      type: "comment",
      value: comment.trim()
    };
    pushToContent(node2);
  };
  sax2.oncdata = (cdata) => {
    const node2 = {
      type: "cdata",
      value: cdata
    };
    pushToContent(node2);
  };
  sax2.onopentag = (data3) => {
    let element = {
      type: "element",
      name: data3.name,
      attributes: {},
      children: []
    };
    for (const [name2, attr] of Object.entries(data3.attributes)) {
      element.attributes[name2] = attr.value;
    }
    pushToContent(element);
    current = element;
    stack.push(element);
  };
  sax2.ontext = (text) => {
    if (current.type === "element") {
      if (textElems$1.includes(current.name)) {
        const node2 = {
          type: "text",
          value: text
        };
        pushToContent(node2);
      } else if (/\S/.test(text)) {
        const node2 = {
          type: "text",
          value: text.trim()
        };
        pushToContent(node2);
      }
    }
  };
  sax2.onclosetag = () => {
    stack.pop();
    current = stack[stack.length - 1];
  };
  sax2.onerror = (e) => {
    const error2 = new SvgoParserError(
      e.reason,
      e.line + 1,
      e.column,
      data2,
      from
    );
    if (e.message.indexOf("Unexpected end") === -1) {
      throw error2;
    }
  };
  sax2.write(data2).close();
  return root;
};
parser.parseSvg = parseSvg$1;
var stringifier = {};
const { textElems } = _collections;
const encodeEntity = (char) => {
  return entities[char];
};
const defaults = {
  doctypeStart: "<!DOCTYPE",
  doctypeEnd: ">",
  procInstStart: "<?",
  procInstEnd: "?>",
  tagOpenStart: "<",
  tagOpenEnd: ">",
  tagCloseStart: "</",
  tagCloseEnd: ">",
  tagShortStart: "<",
  tagShortEnd: "/>",
  attrStart: '="',
  attrEnd: '"',
  commentStart: "<!--",
  commentEnd: "-->",
  cdataStart: "<![CDATA[",
  cdataEnd: "]]>",
  textStart: "",
  textEnd: "",
  indent: 4,
  regEntities: /[&'"<>]/g,
  regValEntities: /[&"<>]/g,
  encodeEntity,
  pretty: false,
  useShortTags: true,
  eol: "lf",
  finalNewline: false
};
const entities = {
  "&": "&amp;",
  "'": "&apos;",
  '"': "&quot;",
  ">": "&gt;",
  "<": "&lt;"
};
const stringifySvg$1 = (data2, userOptions = {}) => {
  const config2 = { ...defaults, ...userOptions };
  const indent = config2.indent;
  let newIndent = "    ";
  if (typeof indent === "number" && Number.isNaN(indent) === false) {
    newIndent = indent < 0 ? "	" : " ".repeat(indent);
  } else if (typeof indent === "string") {
    newIndent = indent;
  }
  const state = {
    width: void 0,
    height: void 0,
    indent: newIndent,
    textContext: null,
    indentLevel: 0
  };
  const eol = config2.eol === "crlf" ? "\r\n" : "\n";
  if (config2.pretty) {
    config2.doctypeEnd += eol;
    config2.procInstEnd += eol;
    config2.commentEnd += eol;
    config2.cdataEnd += eol;
    config2.tagShortEnd += eol;
    config2.tagOpenEnd += eol;
    config2.tagCloseEnd += eol;
    config2.textEnd += eol;
  }
  let svg = stringifyNode(data2, config2, state);
  if (config2.finalNewline && svg.length > 0 && svg[svg.length - 1] !== "\n") {
    svg += eol;
  }
  return {
    data: svg,
    info: {
      width: state.width,
      height: state.height
    }
  };
};
stringifier.stringifySvg = stringifySvg$1;
const stringifyNode = (data2, config2, state) => {
  let svg = "";
  state.indentLevel += 1;
  for (const item of data2.children) {
    if (item.type === "element") {
      svg += stringifyElement(item, config2, state);
    }
    if (item.type === "text") {
      svg += stringifyText(item, config2, state);
    }
    if (item.type === "doctype") {
      svg += stringifyDoctype(item, config2);
    }
    if (item.type === "instruction") {
      svg += stringifyInstruction(item, config2);
    }
    if (item.type === "comment") {
      svg += stringifyComment(item, config2);
    }
    if (item.type === "cdata") {
      svg += stringifyCdata(item, config2, state);
    }
  }
  state.indentLevel -= 1;
  return svg;
};
const createIndent = (config2, state) => {
  let indent = "";
  if (config2.pretty && state.textContext == null) {
    indent = state.indent.repeat(state.indentLevel - 1);
  }
  return indent;
};
const stringifyDoctype = (node2, config2) => {
  return config2.doctypeStart + node2.data.doctype + config2.doctypeEnd;
};
const stringifyInstruction = (node2, config2) => {
  return config2.procInstStart + node2.name + " " + node2.value + config2.procInstEnd;
};
const stringifyComment = (node2, config2) => {
  return config2.commentStart + node2.value + config2.commentEnd;
};
const stringifyCdata = (node2, config2, state) => {
  return createIndent(config2, state) + config2.cdataStart + node2.value + config2.cdataEnd;
};
const stringifyElement = (node2, config2, state) => {
  if (node2.name === "svg" && node2.attributes.width != null && node2.attributes.height != null) {
    state.width = node2.attributes.width;
    state.height = node2.attributes.height;
  }
  if (node2.children.length === 0) {
    if (config2.useShortTags) {
      return createIndent(config2, state) + config2.tagShortStart + node2.name + stringifyAttributes(node2, config2) + config2.tagShortEnd;
    } else {
      return createIndent(config2, state) + config2.tagShortStart + node2.name + stringifyAttributes(node2, config2) + config2.tagOpenEnd + config2.tagCloseStart + node2.name + config2.tagCloseEnd;
    }
  } else {
    let tagOpenStart = config2.tagOpenStart;
    let tagOpenEnd = config2.tagOpenEnd;
    let tagCloseStart = config2.tagCloseStart;
    let tagCloseEnd = config2.tagCloseEnd;
    let openIndent = createIndent(config2, state);
    let closeIndent = createIndent(config2, state);
    if (state.textContext) {
      tagOpenStart = defaults.tagOpenStart;
      tagOpenEnd = defaults.tagOpenEnd;
      tagCloseStart = defaults.tagCloseStart;
      tagCloseEnd = defaults.tagCloseEnd;
      openIndent = "";
    } else if (textElems.includes(node2.name)) {
      tagOpenEnd = defaults.tagOpenEnd;
      tagCloseStart = defaults.tagCloseStart;
      closeIndent = "";
      state.textContext = node2;
    }
    const children = stringifyNode(node2, config2, state);
    if (state.textContext === node2) {
      state.textContext = null;
    }
    return openIndent + tagOpenStart + node2.name + stringifyAttributes(node2, config2) + tagOpenEnd + children + closeIndent + tagCloseStart + node2.name + tagCloseEnd;
  }
};
const stringifyAttributes = (node2, config2) => {
  let attrs = "";
  for (const [name2, value2] of Object.entries(node2.attributes)) {
    if (value2 !== void 0) {
      const encodedValue = value2.toString().replace(config2.regValEntities, config2.encodeEntity);
      attrs += " " + name2 + config2.attrStart + encodedValue + config2.attrEnd;
    } else {
      attrs += " " + name2;
    }
  }
  return attrs;
};
const stringifyText = (node2, config2, state) => {
  return createIndent(config2, state) + config2.textStart + node2.value.replace(config2.regEntities, config2.encodeEntity) + (state.textContext ? "" : config2.textEnd);
};
const { resolvePluginConfig } = config$3;
const { parseSvg } = parser;
const { stringifySvg } = stringifier;
const { invokePlugins } = plugins;
const { encodeSVGDatauri } = tools;
const optimize = (input, config2) => {
  if (config2 == null) {
    config2 = {};
  }
  if (typeof config2 !== "object") {
    throw Error("Config should be an object");
  }
  const maxPassCount = config2.multipass ? 10 : 1;
  let prevResultSize = Number.POSITIVE_INFINITY;
  let svgjs = null;
  const info = {};
  if (config2.path != null) {
    info.path = config2.path;
  }
  for (let i = 0; i < maxPassCount; i += 1) {
    info.multipassCount = i;
    try {
      svgjs = parseSvg(input, config2.path);
    } catch (error2) {
      return { error: error2.toString(), modernError: error2 };
    }
    if (svgjs.error != null) {
      if (config2.path != null) {
        svgjs.path = config2.path;
      }
      return svgjs;
    }
    const plugins2 = config2.plugins || ["preset-default"];
    if (Array.isArray(plugins2) === false) {
      throw Error(
        "Invalid plugins list. Provided 'plugins' in config should be an array."
      );
    }
    const resolvedPlugins = plugins2.map(resolvePluginConfig);
    const globalOverrides = {};
    if (config2.floatPrecision != null) {
      globalOverrides.floatPrecision = config2.floatPrecision;
    }
    svgjs = invokePlugins(svgjs, info, resolvedPlugins, null, globalOverrides);
    svgjs = stringifySvg(svgjs, config2.js2svg);
    if (svgjs.data.length < prevResultSize) {
      input = svgjs.data;
      prevResultSize = svgjs.data.length;
    } else {
      break;
    }
  }
  if (config2.datauri) {
    svgjs.data = encodeSVGDatauri(svgjs.data, config2.datauri);
  }
  if (config2.path != null) {
    svgjs.path = config2.path;
  }
  return svgjs;
};
var optimize_1 = svgo.optimize = optimize;

export { svgo as default, optimize_1 as optimize };
//# sourceMappingURL=svgo.browser.c10bfed2.mjs.map
