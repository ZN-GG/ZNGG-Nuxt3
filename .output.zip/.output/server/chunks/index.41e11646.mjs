import { f as __nuxt_component_0$1 } from './server.mjs';
import { defineComponent, resolveComponent, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UserLeftContents = __nuxt_component_0$1;
      const _component_NuxtChild = resolveComponent("NuxtChild");
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="flex container mx-auto my-6"><div class="w-2/12"><div class="w-full bg-white rounded p-4">`);
      _push(ssrRenderComponent(_component_UserLeftContents, null, null, _parent));
      _push(`</div></div><div class="w-8/12"><div class="w-full bg-white rounded mx-2 p-4">`);
      _push(ssrRenderComponent(_component_NuxtChild, null, null, _parent));
      _push(`</div></div><div class="w-2/12"><div class="w-full bg-white rounded mx-2"></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index.41e11646.mjs.map
