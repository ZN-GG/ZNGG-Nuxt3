import { _ as __tla$1, a as _sfc_main } from './Adsbygoogle.98bf6f6f.mjs';
import { __tla as __tla$2, a as useNuxtApp, g as useRoute, u as useHead } from './server.mjs';
import { defineComponent, withAsyncContext, ref, computed, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderClass, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let M3U8V2Pro;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main$1 = defineComponent({
    __name: "M3U8V2Pro",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      [__temp, __restore] = withAsyncContext(() => import('./validate.476b29a2.mjs')), __temp = await __temp, __restore();
      useNuxtApp();
      useRoute();
      ([__temp, __restore] = withAsyncContext(() => import('./aes-decryptor.105ce5e9.mjs')), __temp = await __temp, __restore(), __temp).default;
      const tsList = ref([]);
      const url = ref("");
      const message = ref("\u7A7A\u95F2");
      const status = ref(0);
      ref({
        status: false,
        method: "",
        uri: "",
        iv: "",
        key: "",
        decryptor: null,
        stringToBuffer: function(str) {
          return new TextEncoder().encode(str);
        }
      });
      computed(() => {
        const arr = [
          ...new Set(tsList.value.map((v) => v.m3u8Src))
        ];
        const data = arr.map((m3u8Src) => {
          const list = tsList.value.filter((v) => v.m3u8Src === m3u8Src);
          const [item] = list;
          let status2 = item.status;
          const total = list.length;
          const doneNum = list.filter((li) => li.status === 2).length;
          const percentage = Number((doneNum / total * 100).toFixed(2));
          const duration = list.reduce((t, v) => t + v.duration, 0);
          if (tsList.value.some((t) => t.status === 1)) {
            status2 = 1;
          } else if (tsList.value.some((t) => t.status === 3)) {
            status2 = 3;
          } else if (percentage >= 100) {
            status2 = 2;
          }
          return {
            name: item.name,
            src: m3u8Src,
            filePath: item.filePath,
            status: status2,
            percentage,
            total,
            doneNum,
            duration
          };
        });
        return data;
      });
      useHead({
        title: "M3U8 \u89C6\u9891\u4E0B\u8F7DV2Pro\u7248",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "M3U8 \u89C6\u9891\u4E0B\u8F7DV2Pro\u7248\u662F\u4E00\u4E2A\u5728\u7EBF\u7535\u5F71\u7F51\u7AD9\u89C6\u9891\u4E0B\u8F7D\u5DE5\u5177\uFF0C\u89E3\u51B3\u5728\u7EBF\u89C6\u9891\u7535\u5F71\u7F51\u7AD9\u65E0\u6CD5\u4E0B\u8F7D\u89C6\u9891\u7684\u95EE\u9898\u3002"
          },
          {
            name: "description",
            content: "\u5728\u7EBFM3U8\u89C6\u9891\u4E0B\u8F7D,\u5728\u7EBF\u7535\u5F71\u89C6\u9891\u4E0B\u8F7D,\u89C6\u9891\u7F51\u7AD9\u89C6\u9891\u4E0B\u8F7DV2Pro\u7248"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        const _component_adsbygoogle = _sfc_main;
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))} data-v-cc9a3d27><div class="container mx-auto flex py-6" data-v-cc9a3d27><div class="w-full md:w-8/12" data-v-cc9a3d27><h1 class="font-bold text-3xl my-3" data-v-cc9a3d27>M3U8\u5728\u7EBF\u4E0B\u8F7D\u5DE5\u5177</h1><textarea autofocus class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3 my-3" rows="4" placeholder="\u8F93\u5165\u6709\u6548\u7684M3U8\u5730\u5740" data-v-cc9a3d27>${ssrInterpolate(unref(url))}</textarea><div class="flex justify-between items-center" data-v-cc9a3d27><div class="" data-v-cc9a3d27><span class="font-bold text-lg text-gray-600" data-v-cc9a3d27><span data-v-cc9a3d27>${ssrInterpolate(unref(message))}</span></span></div><div data-v-cc9a3d27><button style="${ssrRenderStyle(unref(status) == 0 ? null : {
          display: "none"
        })}" class="bg-blue-600 text-white py-2 text-center hover:bg-blue-800 cursor-pointer px-8 select-none" data-v-cc9a3d27>\u5F00\u59CB\u4E0B\u8F7D</button><button style="${ssrRenderStyle(unref(status) == 1 ? null : {
          display: "none"
        })}" class="bg-red-600 text-white py-2 text-center hover:bg-red-800 cursor-pointer px-8 select-none" data-v-cc9a3d27>\u505C\u6B62</button><button style="${ssrRenderStyle(unref(status) == 2 ? null : {
          display: "none"
        })}" class="btn-bg-save text-white py-2 text-center hover:bg-blue-800 cursor-pointer px-8 select-none" data-v-cc9a3d27>\u4FDD\u5B58</button></div></div><div class="item-box flex flex-wrap my-4 overflow-y-scroll pt-6" data-v-cc9a3d27><div style="${ssrRenderStyle(unref(tsList).length <= 0 ? null : {
          display: "none"
        })}" class="flex w-full justify-center items-center" data-v-cc9a3d27><div data-v-cc9a3d27><h1 class="text-xl font-bold text-gray-400" data-v-cc9a3d27>\u8FD8\u672A\u5F00\u59CB\u4E0B\u8F7D \u{1F609}</h1><br data-v-cc9a3d27><br data-v-cc9a3d27></div></div><!--[-->`);
        ssrRenderList(unref(tsList), (item, index) => {
          _push(`<div class="${ssrRenderClass([
            (item.status == 0 || item.status == 1 ? "bg-gray-500" : "") + (item.status == 2 ? "bg-green-500" : "") + (item.status == 3 ? "bg-red-700" : ""),
            "cursor-pointer select-none w-12 h-8 m-1 leading-8 text-center text-white"
          ])}" data-v-cc9a3d27>${ssrInterpolate(index + 1)}</div>`);
        });
        _push(`<!--]--></div><div class="py-2" data-v-cc9a3d27><br data-v-cc9a3d27><hr data-v-cc9a3d27><br data-v-cc9a3d27><p data-v-cc9a3d27>\u6E29\u99A8\u63D0\u793A\uFF1A</p><span class="leading-4 inline-block" data-v-cc9a3d27><span class="inline-block select-none w-8 h-4 m-1 align-middle leading-8 text-center text-white bg-gray-500" data-v-cc9a3d27></span><span class="align-middle" data-v-cc9a3d27>\u8868\u793A\u4E0B\u8F7D\u4E2D</span></span><span class="leading-4 inline-block" data-v-cc9a3d27><span class="inline-block select-none w-8 h-4 m-1 align-middle leading-8 text-center text-white bg-green-500" data-v-cc9a3d27></span><span class="align-middle" data-v-cc9a3d27>\u8868\u793A\u5B8C\u6210</span></span><span class="leading-4 inline-block" data-v-cc9a3d27><span class="inline-block select-none w-8 h-4 m-1 align-middle leading-8 text-center text-white bg-red-700" data-v-cc9a3d27></span><span class="align-middle" data-v-cc9a3d27>\u8868\u793A\u5931\u8D25</span></span><p data-v-cc9a3d27>\u70B9\u51FB<span class="leading-4 inline-block" data-v-cc9a3d27><span class="inline-block select-none w-8 h-4 m-1 align-middle leading-8 text-center text-white bg-red-700" data-v-cc9a3d27></span></span>\u53EF\u4EE5\u91CD\u65B0\u4E0B\u8F7D\u8BE5\u5757\u5185\u5BB9\u3002</p><br data-v-cc9a3d27><p data-v-cc9a3d27>\u5C06\u4E0B\u8F7D\u94FE\u63A5\u586B\u5165\u540E\uFF0C\u70B9\u51FB\u5F00\u59CB\u4E0B\u8F7D\uFF0C\u5F00\u59CB\u89E3\u6790\u89C6\u9891\u5185\u5BB9\uFF0C\u4E4B\u540E\u51FA\u73B0\u5F88\u591A\u989C\u8272\u5757\uFF0C\u7B49\u5230\u6240\u6709\u8272\u5757\u5747\u53D8\u6210\u540E\u7EFF\u8272\u540E\u8868\u793A\u4E0B\u8F7D\u5B8C\u6210\uFF0C\u6B64\u65F6\u4F1A\u81EA\u52A8\u5F39\u51FA\u4E0B\u8F7D\u6846\uFF0C\u5E76\u4E14\u663E\u793A\u4FDD\u5B58\u6309\u94AE\uFF0C\u60A8\u4E5F\u53EF\u4EE5\u70B9\u51FB\u4FDD\u5B58\u6309\u94AE\u8FDB\u884C\u4E0B\u8F7D\uFF08\u4E0B\u8F7D\u540E\u7684\u89C6\u9891\u683C\u5F0F\u4E3Amp4\uFF09\u3002 </p></div><div class="mt-14 pb-10" data-v-cc9a3d27><br data-v-cc9a3d27><hr data-v-cc9a3d27><br data-v-cc9a3d27><p class="font-bold text-lg" data-v-cc9a3d27>\u76F8\u5173\u6587\u7AE0</p><div class="flex flex-wrap mt-2" data-v-cc9a3d27><div class="w-4/12" data-v-cc9a3d27><div class="bg-gray-200 w-full h-full" data-v-cc9a3d27><img class="p-2" src="https://cdn.zngg.net/upload/image/cover/1059422373599510528.png" alt="" data-v-cc9a3d27><h2 class="p-2 hover:font-bold" data-v-cc9a3d27><a href="https://www.zngg.net/read/post/1059422545926684672" target="_blank" data-v-cc9a3d27>\u5982\u4F55\u83B7\u53D6\u5230\u89C6\u9891\u7F51\u7AD9\u7684\u89C6\u9891\u8D44\u6E90\u5730\u5740\uFF1F</a></h2></div></div></div></div></div><div class="w-full md:w-4/12 px-5 py-20" data-v-cc9a3d27>`);
        _push(ssrRenderComponent(_component_adsbygoogle, null, null, _parent));
        _push(`</div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main$1.setup;
  _sfc_main$1.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/M3U8V2Pro.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  M3U8V2Pro = _export_sfc(_sfc_main$1, [
    [
      "__scopeId",
      "data-v-cc9a3d27"
    ]
  ]);
});

export { __tla, M3U8V2Pro as default };
//# sourceMappingURL=M3U8V2Pro.7a360a8a.mjs.map
