const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-62bae878.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "_index-d96b7687.mjs",
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-806f62b3.mjs",
      "_dom-to-image-38bb6765.mjs",
      "_mpegts-335ba825.mjs",
      "_pinyin-web-6ec2b3c1.mjs",
      "_index.min-0fa75149.mjs",
      "_hls-58934b30.mjs",
      "_fabric-3d02e4be.mjs",
      "_RecordRTC-3fcc8c3c.mjs",
      "_lodash-a041f857.mjs",
      "_index-ebba77f0.mjs",
      "pages/index.vue",
      "pages/link/index.vue",
      "pages/link.vue",
      "pages/read/index.vue",
      "pages/read/post/[id].vue",
      "pages/read/post.vue",
      "pages/read.vue",
      "pages/tool/detail/Base64Convert.vue",
      "pages/tool/detail/CSSGradient.vue",
      "pages/tool/detail/EnglistConvert.vue",
      "pages/tool/detail/FancyBorderRadius.vue",
      "pages/tool/detail/FlvPlayer.vue",
      "pages/tool/detail/ImageToBase64.vue",
      "pages/tool/detail/MakePhrase.vue",
      "pages/tool/detail/NPlayer.vue",
      "pages/tool/detail/NationalDayAvatar.vue",
      "pages/tool/detail/ScreenRec.vue",
      "pages/tool/detail/TextDistinct.vue",
      "pages/tool/detail/Timestamp.vue",
      "pages/tool/detail/TraceReplay.vue",
      "pages/tool/detail/UnicodeConvert.vue",
      "pages/tool/detail/WeiBoGenerates.vue",
      "pages/tool/detail.vue",
      "pages/tool/index.vue",
      "pages/tool.vue",
      "pages/user/index/create.vue",
      "pages/user/index/index.vue",
      "pages/user/index/order.vue",
      "pages/user/index.vue",
      "pages/writer.vue",
      "middleware/auth.ts",
      "layouts/default.vue",
      "layouts/empty.vue"
    ],
    "css": [
      "entry.013ad0f5.css"
    ],
    "assets": [
      "iconfont.8c3eb7e7.woff2",
      "iconfont.c7a4bd31.woff",
      "iconfont.ec975a33.ttf"
    ]
  },
  "pages/index.vue": {
    "file": "index-67ae1dd4.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-ffa2a1be.mjs",
      "_api-2f53246f.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "_asyncData-ffa2a1be.mjs": {
    "file": "asyncData-ffa2a1be.mjs",
    "imports": [
      "_cookie-932df899.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_api-2f53246f.mjs": {
    "file": "api-2f53246f.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "_cookie-932df899.mjs": {
    "file": "cookie-932df899.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link/index.vue": {
    "file": "index-18741355.mjs",
    "src": "pages/link/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link.vue": {
    "file": "link-6e3c11d1.mjs",
    "src": "pages/link.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read/index.vue": {
    "file": "index-e4da83cf.mjs",
    "src": "pages/read/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-ffa2a1be.mjs",
      "_api-2f53246f.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "pages/read/post/[id].vue": {
    "file": "_id_-1a6360eb.mjs",
    "src": "pages/read/post/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-ffa2a1be.mjs",
      "_api-2f53246f.mjs",
      "_theme-8f7e0f28.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "_theme-8f7e0f28.mjs": {
    "file": "theme-8f7e0f28.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js",
      "node_modules/medium-zoom/dist/medium-zoom.esm.js",
      "node_modules/mermaid/dist/mermaid.esm.min.mjs"
    ]
  },
  "pages/read/post.vue": {
    "file": "post-20c77216.mjs",
    "src": "pages/read/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read.vue": {
    "file": "read-fe29d6a5.mjs",
    "src": "pages/read.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/Base64Convert.vue": {
    "file": "Base64Convert-b761121f.mjs",
    "src": "pages/tool/detail/Base64Convert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index-d96b7687.mjs"
    ]
  },
  "pages/tool/detail/CSSGradient.vue": {
    "file": "CSSGradient-29226c8c.mjs",
    "src": "pages/tool/detail/CSSGradient.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-806f62b3.mjs",
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail/EnglistConvert.vue": {
    "file": "EnglistConvert-71350457.mjs",
    "src": "pages/tool/detail/EnglistConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FancyBorderRadius.vue": {
    "file": "FancyBorderRadius-1a8bfd44.mjs",
    "src": "pages/tool/detail/FancyBorderRadius.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FlvPlayer.vue": {
    "file": "FlvPlayer-752e5597.mjs",
    "src": "pages/tool/detail/FlvPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_mpegts-335ba825.mjs"
    ]
  },
  "pages/tool/detail/ImageToBase64.vue": {
    "file": "ImageToBase64-4b14a7c2.mjs",
    "src": "pages/tool/detail/ImageToBase64.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index-d96b7687.mjs"
    ]
  },
  "pages/tool/detail/MakePhrase.vue": {
    "file": "MakePhrase-c88bfd66.mjs",
    "src": "pages/tool/detail/MakePhrase.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs",
      "_pinyin-web-6ec2b3c1.mjs"
    ]
  },
  "pages/tool/detail/NPlayer.vue": {
    "file": "NPlayer-a3698460.mjs",
    "src": "pages/tool/detail/NPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.min-0fa75149.mjs",
      "_hls-58934b30.mjs"
    ]
  },
  "pages/tool/detail/NationalDayAvatar.vue": {
    "file": "NationalDayAvatar-c85c8d0d.mjs",
    "src": "pages/tool/detail/NationalDayAvatar.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_fabric-3d02e4be.mjs"
    ]
  },
  "pages/tool/detail/ScreenRec.vue": {
    "file": "ScreenRec-c6ffa965.mjs",
    "src": "pages/tool/detail/ScreenRec.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_RecordRTC-3fcc8c3c.mjs"
    ]
  },
  "pages/tool/detail/TextDistinct.vue": {
    "file": "TextDistinct-6cbc813c.mjs",
    "src": "pages/tool/detail/TextDistinct.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_lodash-a041f857.mjs"
    ]
  },
  "pages/tool/detail/Timestamp.vue": {
    "file": "Timestamp-dffb2502.mjs",
    "src": "pages/tool/detail/Timestamp.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api-2f53246f.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "pages/tool/detail/TraceReplay.vue": {
    "file": "TraceReplay-31ff6d5d.mjs",
    "src": "pages/tool/detail/TraceReplay.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index-ebba77f0.mjs"
    ]
  },
  "pages/tool/detail/UnicodeConvert.vue": {
    "file": "UnicodeConvert-a4f4c282.mjs",
    "src": "pages/tool/detail/UnicodeConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/WeiBoGenerates.vue": {
    "file": "WeiBoGenerates-02e041f0.mjs",
    "src": "pages/tool/detail/WeiBoGenerates.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail.vue": {
    "file": "detail-e2fc6b39.mjs",
    "src": "pages/tool/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/index.vue": {
    "file": "index-6c06a3a0.mjs",
    "src": "pages/tool/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-ffa2a1be.mjs",
      "_api-2f53246f.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "pages/tool.vue": {
    "file": "tool-eb3a80f1.mjs",
    "src": "pages/tool.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/create.vue": {
    "file": "create-b4b69040.mjs",
    "src": "pages/user/index/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/index.vue": {
    "file": "index-68a33034.mjs",
    "src": "pages/user/index/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/order.vue": {
    "file": "order-0d5d8578.mjs",
    "src": "pages/user/index/order.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index.vue": {
    "file": "index-19b1e8d8.mjs",
    "src": "pages/user/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "pages/writer.vue": {
    "file": "writer-09be5dfd.mjs",
    "src": "pages/writer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_theme-8f7e0f28.mjs",
      "_api-2f53246f.mjs",
      "_cookie-932df899.mjs"
    ]
  },
  "middleware/auth.ts": {
    "file": "auth-1b960771.mjs",
    "src": "middleware/auth.ts",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-932df899.mjs",
      "_api-2f53246f.mjs"
    ]
  },
  "layouts/default.vue": {
    "file": "default-6caa4714.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-932df899.mjs",
      "_api-2f53246f.mjs"
    ],
    "css": [
      "default.f39aa63b.css"
    ]
  },
  "layouts/empty.vue": {
    "file": "empty-1d156fd6.mjs",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_index-d96b7687.mjs": {
    "file": "index-d96b7687.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "__commonjsHelpers-f27416a5.mjs": {
    "file": "_commonjsHelpers-f27416a5.mjs"
  },
  "utils/Drag.ts": {
    "file": "Drag-cac46c1e.mjs",
    "src": "utils/Drag.ts",
    "isDynamicEntry": true
  },
  "utils/color.ts": {
    "file": "color-c1be6728.mjs",
    "src": "utils/color.ts",
    "isDynamicEntry": true
  },
  "_interact.min-806f62b3.mjs": {
    "file": "interact.min-806f62b3.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_dom-to-image-38bb6765.mjs": {
    "file": "dom-to-image-38bb6765.mjs",
    "isDynamicEntry": true
  },
  "_mpegts-335ba825.mjs": {
    "file": "mpegts-335ba825.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_pinyin-web-6ec2b3c1.mjs": {
    "file": "pinyin-web-6ec2b3c1.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_index.min-0fa75149.mjs": {
    "file": "index.min-0fa75149.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_hls-58934b30.mjs": {
    "file": "hls-58934b30.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_fabric-3d02e4be.mjs": {
    "file": "fabric-3d02e4be.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_RecordRTC-3fcc8c3c.mjs": {
    "file": "RecordRTC-3fcc8c3c.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_lodash-a041f857.mjs": {
    "file": "lodash-a041f857.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "_index-ebba77f0.mjs": {
    "file": "index-ebba77f0.mjs",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers-f27416a5.mjs"
    ]
  },
  "node_modules/highlight.js/es/index.js": {
    "file": "index-5d39d920.mjs",
    "src": "node_modules/highlight.js/es/index.js",
    "isDynamicEntry": true
  },
  "node_modules/medium-zoom/dist/medium-zoom.esm.js": {
    "file": "medium-zoom.esm-76784ffc.mjs",
    "src": "node_modules/medium-zoom/dist/medium-zoom.esm.js",
    "isDynamicEntry": true
  },
  "node_modules/mermaid/dist/mermaid.esm.min.mjs": {
    "file": "mermaid.esm.min-69e0ceb1.mjs",
    "src": "node_modules/mermaid/dist/mermaid.esm.min.mjs",
    "isDynamicEntry": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
