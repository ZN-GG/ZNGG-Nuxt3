const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-2df678da.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "_mpegts-2d4e50f5.mjs",
      "_dom-to-image-38bb6765.mjs",
      "_pinyin-web-16b97b19.mjs",
      "_index.min-cc37c49e.mjs",
      "_hls-595fe25d.mjs",
      "_RecordRTC-51d76d44.mjs",
      "_lodash-c893a98e.mjs",
      "pages/index.vue",
      "pages/link/index.vue",
      "pages/link.vue",
      "pages/read/index.vue",
      "pages/read/post/[id].vue",
      "pages/read/post.vue",
      "pages/read.vue",
      "pages/tool/detail/EnglistConvert.vue",
      "pages/tool/detail/FlvPlayer.vue",
      "pages/tool/detail/ImageToBase64.vue",
      "pages/tool/detail/MakePhrase.vue",
      "pages/tool/detail/NPlayer.vue",
      "pages/tool/detail/ScreenRec.vue",
      "pages/tool/detail/TextDistinct.vue",
      "pages/tool/detail/Timestamp.vue",
      "pages/tool/detail/WeiBoGenerates.vue",
      "pages/tool/detail.vue",
      "pages/tool/index.vue",
      "pages/tool.vue",
      "pages/user/index/create.vue",
      "pages/user/index/index.vue",
      "pages/user/index/order.vue",
      "pages/user/index.vue",
      "pages/writer.vue",
      "middleware/auth.ts",
      "layouts/default.vue",
      "layouts/empty.vue"
    ],
    "css": [
      "entry.2010115f.css"
    ],
    "assets": [
      "iconfont.8c3eb7e7.woff2",
      "iconfont.c7a4bd31.woff",
      "iconfont.ec975a33.ttf"
    ]
  },
  "pages/index.vue": {
    "file": "index-d633f96b.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-a8d7ff8e.mjs",
      "_api-4ffa83de.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "_asyncData-a8d7ff8e.mjs": {
    "file": "asyncData-a8d7ff8e.mjs",
    "imports": [
      "_cookie-8f56e498.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_api-4ffa83de.mjs": {
    "file": "api-4ffa83de.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "_cookie-8f56e498.mjs": {
    "file": "cookie-8f56e498.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link/index.vue": {
    "file": "index-ffba3c79.mjs",
    "src": "pages/link/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link.vue": {
    "file": "link-af28bf31.mjs",
    "src": "pages/link.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read/index.vue": {
    "file": "index-7da2bccd.mjs",
    "src": "pages/read/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-a8d7ff8e.mjs",
      "_api-4ffa83de.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "pages/read/post/[id].vue": {
    "file": "_id_-70b1c264.mjs",
    "src": "pages/read/post/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-a8d7ff8e.mjs",
      "_api-4ffa83de.mjs",
      "_theme-7ed63218.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "_theme-7ed63218.mjs": {
    "file": "theme-7ed63218.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js",
      "node_modules/medium-zoom/dist/medium-zoom.esm.js",
      "node_modules/mermaid/dist/mermaid.esm.min.mjs"
    ]
  },
  "pages/read/post.vue": {
    "file": "post-758a845e.mjs",
    "src": "pages/read/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read.vue": {
    "file": "read-b75479ff.mjs",
    "src": "pages/read.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/EnglistConvert.vue": {
    "file": "EnglistConvert-13df82d0.mjs",
    "src": "pages/tool/detail/EnglistConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FlvPlayer.vue": {
    "file": "FlvPlayer-8d742d97.mjs",
    "src": "pages/tool/detail/FlvPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_mpegts-2d4e50f5.mjs"
    ]
  },
  "pages/tool/detail/ImageToBase64.vue": {
    "file": "ImageToBase64-acf03a48.mjs",
    "src": "pages/tool/detail/ImageToBase64.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/MakePhrase.vue": {
    "file": "MakePhrase-6c28d7a4.mjs",
    "src": "pages/tool/detail/MakePhrase.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs",
      "_pinyin-web-16b97b19.mjs"
    ]
  },
  "pages/tool/detail/NPlayer.vue": {
    "file": "NPlayer-4a762160.mjs",
    "src": "pages/tool/detail/NPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.min-cc37c49e.mjs",
      "_hls-595fe25d.mjs"
    ]
  },
  "pages/tool/detail/ScreenRec.vue": {
    "file": "ScreenRec-66b59a37.mjs",
    "src": "pages/tool/detail/ScreenRec.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_RecordRTC-51d76d44.mjs"
    ]
  },
  "pages/tool/detail/TextDistinct.vue": {
    "file": "TextDistinct-bbc646e4.mjs",
    "src": "pages/tool/detail/TextDistinct.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_lodash-c893a98e.mjs"
    ]
  },
  "pages/tool/detail/Timestamp.vue": {
    "file": "Timestamp-4ab4e481.mjs",
    "src": "pages/tool/detail/Timestamp.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api-4ffa83de.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "pages/tool/detail/WeiBoGenerates.vue": {
    "file": "WeiBoGenerates-6d2c4a8e.mjs",
    "src": "pages/tool/detail/WeiBoGenerates.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail.vue": {
    "file": "detail-23521665.mjs",
    "src": "pages/tool/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/index.vue": {
    "file": "index-375e0b57.mjs",
    "src": "pages/tool/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-a8d7ff8e.mjs",
      "_api-4ffa83de.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "pages/tool.vue": {
    "file": "tool-8c80fc9d.mjs",
    "src": "pages/tool.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/create.vue": {
    "file": "create-d0b1e64a.mjs",
    "src": "pages/user/index/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/index.vue": {
    "file": "index-f6e4b1da.mjs",
    "src": "pages/user/index/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/order.vue": {
    "file": "order-765c7e8c.mjs",
    "src": "pages/user/index/order.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index.vue": {
    "file": "index-b668b301.mjs",
    "src": "pages/user/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "pages/writer.vue": {
    "file": "writer-2aad72f9.mjs",
    "src": "pages/writer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_theme-7ed63218.mjs",
      "_api-4ffa83de.mjs",
      "_cookie-8f56e498.mjs"
    ]
  },
  "middleware/auth.ts": {
    "file": "auth-ebbc0fbc.mjs",
    "src": "middleware/auth.ts",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-8f56e498.mjs",
      "_api-4ffa83de.mjs"
    ]
  },
  "layouts/default.vue": {
    "file": "default-73fbbf72.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-8f56e498.mjs",
      "_api-4ffa83de.mjs"
    ],
    "css": [
      "default.f39aa63b.css"
    ]
  },
  "layouts/empty.vue": {
    "file": "empty-13814770.mjs",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_mpegts-2d4e50f5.mjs": {
    "file": "mpegts-2d4e50f5.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_dom-to-image-38bb6765.mjs": {
    "file": "dom-to-image-38bb6765.mjs",
    "isDynamicEntry": true
  },
  "_pinyin-web-16b97b19.mjs": {
    "file": "pinyin-web-16b97b19.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_index.min-cc37c49e.mjs": {
    "file": "index.min-cc37c49e.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_hls-595fe25d.mjs": {
    "file": "hls-595fe25d.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_RecordRTC-51d76d44.mjs": {
    "file": "RecordRTC-51d76d44.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_lodash-c893a98e.mjs": {
    "file": "lodash-c893a98e.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/highlight.js/es/index.js": {
    "file": "index-5d39d920.mjs",
    "src": "node_modules/highlight.js/es/index.js",
    "isDynamicEntry": true
  },
  "node_modules/medium-zoom/dist/medium-zoom.esm.js": {
    "file": "medium-zoom.esm-76784ffc.mjs",
    "src": "node_modules/medium-zoom/dist/medium-zoom.esm.js",
    "isDynamicEntry": true
  },
  "node_modules/mermaid/dist/mermaid.esm.min.mjs": {
    "file": "mermaid.esm.min-69e0ceb1.mjs",
    "src": "node_modules/mermaid/dist/mermaid.esm.min.mjs",
    "isDynamicEntry": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
