const client_manifest = {
  "assets/fonts/iconfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "iconfont.8c3eb7e7.woff2",
    "src": "assets/fonts/iconfont.woff2"
  },
  "node_modules/png-to-svg-wasm/png_to_svg_wasm_bg.wasm": {
    "file": "png_to_svg_wasm_bg.ad85097d.wasm",
    "src": "node_modules/png-to-svg-wasm/png_to_svg_wasm_bg.wasm"
  },
  "assets/fonts/iconfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "iconfont.c7a4bd31.woff",
    "src": "assets/fonts/iconfont.woff"
  },
  "assets/fonts/iconfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "iconfont.ec975a33.ttf",
    "src": "assets/fonts/iconfont.ttf"
  },
  "node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.ce6cd5bf.js",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "node_modules/@bytemd/vue-next/dist/index.mjs",
      "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
      "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
      "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
      "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
      "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
      "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
      "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
      "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
      "node_modules/marked/lib/marked.esm.js",
      "assets/theme.ts",
      "_index.1df7656a.js",
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min.3ac48332.js",
      "_dom-to-image.5044287b.js",
      "node_modules/@zackdk/m3u8tomp4/src/index.js",
      "_mpegts.e75d6339.js",
      "node_modules/pinyin-pro/lib/pinyin.ts",
      "_index.min.10aaf9f8.js",
      "_hls.2a7af7df.js",
      "_fabric.2646cadb.js",
      "node_modules/png-to-svg-wasm/png_to_svg_wasm.js",
      "utils/svgo.browser.mjs",
      "_index.efea0cb8.js",
      "_RecordRTC.d7a40e53.js",
      "_uniq.5ad30764.js",
      "_join.5e100562.js",
      "utils/ZWSP.ts",
      "_index.92c964f7.js",
      "middleware/auth.ts",
      "middleware/setSameOriginHeader.ts",
      "virtual:nuxt:/Volumes/D/ProjectDemo/nuxt-app/.nuxt/error-component.mjs",
      "layouts/default.vue",
      "layouts/empty.vue",
      "node_modules/nuxt/dist/app/entry.mjs-css"
    ],
    "css": [],
    "assets": [
      "iconfont.8c3eb7e7.woff2",
      "iconfont.c7a4bd31.woff",
      "iconfont.ec975a33.ttf"
    ]
  },
  "entry.ac2675fc.css": {
    "file": "entry.ac2675fc.css",
    "resourceType": "style"
  },
  "iconfont.8c3eb7e7.woff2": {
    "file": "iconfont.8c3eb7e7.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "iconfont.c7a4bd31.woff": {
    "file": "iconfont.c7a4bd31.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "iconfont.ec975a33.ttf": {
    "file": "iconfont.ec975a33.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "virtual:nuxt:/Volumes/D/ProjectDemo/nuxt-app/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.ecd5c9db.js",
    "src": "virtual:nuxt:/Volumes/D/ProjectDemo/nuxt-app/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.695a6ffb.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.13c5c192.js",
      "_ScreenRecAD.64ea18e0.js",
      "_NplayerAD.d981fd9c.js",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ],
    "css": []
  },
  "index.06cc0c9c.css": {
    "file": "index.06cc0c9c.css",
    "resourceType": "style"
  },
  "_asyncData.13c5c192.js": {
    "resourceType": "script",
    "module": true,
    "file": "asyncData.13c5c192.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_ScreenRecAD.64ea18e0.js": {
    "resourceType": "script",
    "module": true,
    "file": "ScreenRecAD.64ea18e0.js"
  },
  "_NplayerAD.d981fd9c.js": {
    "resourceType": "script",
    "module": true,
    "file": "NplayerAD.d981fd9c.js"
  },
  "_api.474f9956.js": {
    "resourceType": "script",
    "module": true,
    "file": "api.474f9956.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.664defff.js"
    ]
  },
  "_cookie.664defff.js": {
    "resourceType": "script",
    "module": true,
    "file": "cookie.664defff.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.8dc9edd5.js",
    "src": "pages/link/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link.vue": {
    "resourceType": "script",
    "module": true,
    "file": "link.c7a8955c.js",
    "src": "pages/link.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.c4af8c60.js",
    "src": "pages/read/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.13c5c192.js",
      "_ScreenRecAD.64ea18e0.js",
      "_NplayerAD.d981fd9c.js",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ],
    "css": []
  },
  "index.412ca2a9.css": {
    "file": "index.412ca2a9.css",
    "resourceType": "style"
  },
  "pages/read/post/[id].vue": {
    "resourceType": "script",
    "module": true,
    "file": "_id_.be6a5d5c.js",
    "src": "pages/read/post/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.13c5c192.js",
      "_ScreenRecAD.64ea18e0.js",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ],
    "dynamicImports": [
      "node_modules/@bytemd/vue-next/dist/index.mjs",
      "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
      "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
      "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
      "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
      "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
      "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
      "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
      "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
      "node_modules/marked/lib/marked.esm.js",
      "assets/theme.ts"
    ],
    "css": []
  },
  "_id_.a70ec486.css": {
    "file": "_id_.a70ec486.css",
    "resourceType": "style"
  },
  "atom-one-dark.a80f81b9.css": {
    "file": "atom-one-dark.a80f81b9.css",
    "resourceType": "style"
  },
  "pages/read/post.vue": {
    "resourceType": "script",
    "module": true,
    "file": "post.0978870b.js",
    "src": "pages/read/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read.vue": {
    "resourceType": "script",
    "module": true,
    "file": "read.b8874d4f.js",
    "src": "pages/read.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/Base64Convert.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Base64Convert.bffc1584.js",
    "src": "pages/tool/detail/Base64Convert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.1df7656a.js"
    ]
  },
  "pages/tool/detail/CSSGradient.vue": {
    "resourceType": "script",
    "module": true,
    "file": "CSSGradient.f1e100ce.js",
    "src": "pages/tool/detail/CSSGradient.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min.3ac48332.js",
      "_dom-to-image.5044287b.js"
    ]
  },
  "pages/tool/detail/DownloadM3U8.vue": {
    "resourceType": "script",
    "module": true,
    "file": "DownloadM3U8.ba41327c.js",
    "src": "pages/tool/detail/DownloadM3U8.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/@zackdk/m3u8tomp4/src/index.js"
    ]
  },
  "pages/tool/detail/EnglistConvert.vue": {
    "resourceType": "script",
    "module": true,
    "file": "EnglistConvert.f296ae6b.js",
    "src": "pages/tool/detail/EnglistConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FancyBorderRadius.vue": {
    "resourceType": "script",
    "module": true,
    "file": "FancyBorderRadius.90a10a5e.js",
    "src": "pages/tool/detail/FancyBorderRadius.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "FancyBorderRadius.a5b0c680.css": {
    "file": "FancyBorderRadius.a5b0c680.css",
    "resourceType": "style"
  },
  "pages/tool/detail/FlvPlayer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "FlvPlayer.f7272a27.js",
    "src": "pages/tool/detail/FlvPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_XGPlayer.ad8d9c23.js"
    ],
    "dynamicImports": [
      "_mpegts.e75d6339.js"
    ],
    "css": []
  },
  "FlvPlayer.4f97ec6b.css": {
    "file": "FlvPlayer.4f97ec6b.css",
    "resourceType": "style"
  },
  "_XGPlayer.ad8d9c23.js": {
    "resourceType": "script",
    "module": true,
    "file": "XGPlayer.ad8d9c23.js"
  },
  "pages/tool/detail/ImageToBase64.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ImageToBase64.4e7aaed3.js",
    "src": "pages/tool/detail/ImageToBase64.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.1df7656a.js"
    ]
  },
  "pages/tool/detail/MakePhrase.vue": {
    "resourceType": "script",
    "module": true,
    "file": "MakePhrase.197d0dba.js",
    "src": "pages/tool/detail/MakePhrase.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image.5044287b.js",
      "node_modules/pinyin-pro/lib/pinyin.ts"
    ],
    "css": []
  },
  "MakePhrase.fb714d87.css": {
    "file": "MakePhrase.fb714d87.css",
    "resourceType": "style"
  },
  "pages/tool/detail/NPlayer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "NPlayer.91ad6b0a.js",
    "src": "pages/tool/detail/NPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_XGPlayer.ad8d9c23.js"
    ],
    "dynamicImports": [
      "_index.min.10aaf9f8.js",
      "_hls.2a7af7df.js"
    ],
    "css": []
  },
  "NPlayer.4f97ec6b.css": {
    "file": "NPlayer.4f97ec6b.css",
    "resourceType": "style"
  },
  "pages/tool/detail/NationalDayAvatar.vue": {
    "resourceType": "script",
    "module": true,
    "file": "NationalDayAvatar.6c974f83.js",
    "src": "pages/tool/detail/NationalDayAvatar.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_fabric.2646cadb.js"
    ],
    "css": []
  },
  "NationalDayAvatar.d2c16d7b.css": {
    "file": "NationalDayAvatar.d2c16d7b.css",
    "resourceType": "style"
  },
  "pages/tool/detail/PngToSVG.vue": {
    "resourceType": "script",
    "module": true,
    "file": "PngToSVG.d70d5511.js",
    "src": "pages/tool/detail/PngToSVG.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/png-to-svg-wasm/png_to_svg_wasm.js",
      "utils/svgo.browser.mjs",
      "_index.efea0cb8.js"
    ]
  },
  "pages/tool/detail/ScreenRec.vue": {
    "resourceType": "script",
    "module": true,
    "file": "ScreenRec.c57dac25.js",
    "src": "pages/tool/detail/ScreenRec.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_RecordRTC.d7a40e53.js"
    ]
  },
  "pages/tool/detail/TextDistinct.vue": {
    "resourceType": "script",
    "module": true,
    "file": "TextDistinct.20548af2.js",
    "src": "pages/tool/detail/TextDistinct.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_uniq.5ad30764.js",
      "_join.5e100562.js"
    ]
  },
  "pages/tool/detail/TextSecret.vue": {
    "resourceType": "script",
    "module": true,
    "file": "TextSecret.23e9524d.js",
    "src": "pages/tool/detail/TextSecret.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/ZWSP.ts",
      "_index.efea0cb8.js"
    ],
    "css": []
  },
  "TextSecret.c1a8e657.css": {
    "file": "TextSecret.c1a8e657.css",
    "resourceType": "style"
  },
  "pages/tool/detail/Timestamp.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Timestamp.19c53ec4.js",
    "src": "pages/tool/detail/Timestamp.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ]
  },
  "pages/tool/detail/TraceReplay.vue": {
    "resourceType": "script",
    "module": true,
    "file": "TraceReplay.1d51ea4c.js",
    "src": "pages/tool/detail/TraceReplay.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.92c964f7.js"
    ]
  },
  "pages/tool/detail/UnicodeConvert.vue": {
    "resourceType": "script",
    "module": true,
    "file": "UnicodeConvert.a362a1b8.js",
    "src": "pages/tool/detail/UnicodeConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/WeiBoGenerates.vue": {
    "resourceType": "script",
    "module": true,
    "file": "WeiBoGenerates.9e9ab210.js",
    "src": "pages/tool/detail/WeiBoGenerates.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image.5044287b.js"
    ],
    "css": []
  },
  "WeiBoGenerates.c7984c87.css": {
    "file": "WeiBoGenerates.c7984c87.css",
    "resourceType": "style"
  },
  "pages/tool/detail/Whois.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Whois.81007c8d.js",
    "src": "pages/tool/detail/Whois.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ],
    "css": []
  },
  "Whois.4e0a190c.css": {
    "file": "Whois.4e0a190c.css",
    "resourceType": "style"
  },
  "pages/tool/detail.vue": {
    "resourceType": "script",
    "module": true,
    "file": "detail.30f8e8c6.js",
    "src": "pages/tool/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.3c88315d.js",
    "src": "pages/tool/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.13c5c192.js",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ]
  },
  "pages/tool.vue": {
    "resourceType": "script",
    "module": true,
    "file": "tool.cc10c86c.js",
    "src": "pages/tool.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.4371de61.js",
    "src": "pages/user/index/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.13c5c192.js",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ]
  },
  "pages/user/index/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.0b8e0b8c.js",
    "src": "pages/user/index/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/order.vue": {
    "resourceType": "script",
    "module": true,
    "file": "order.d3c8d194.js",
    "src": "pages/user/index/order.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.5d9eb7ce.js",
    "src": "pages/user/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.664defff.js"
    ]
  },
  "pages/writer.vue": {
    "resourceType": "script",
    "module": true,
    "file": "writer.05976ab9.js",
    "src": "pages/writer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData.13c5c192.js",
      "_api.474f9956.js",
      "_cookie.664defff.js"
    ],
    "dynamicImports": [
      "node_modules/@bytemd/vue-next/dist/index.mjs",
      "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
      "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
      "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
      "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
      "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
      "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
      "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
      "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
      "assets/theme.ts"
    ],
    "css": []
  },
  "writer.40077ed7.css": {
    "file": "writer.40077ed7.css",
    "resourceType": "style"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "file": "auth.0064af39.js",
    "src": "middleware/auth.ts",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.664defff.js",
      "_api.474f9956.js"
    ]
  },
  "middleware/setSameOriginHeader.ts": {
    "resourceType": "script",
    "module": true,
    "file": "setSameOriginHeader.dd7680ee.js",
    "src": "middleware/setSameOriginHeader.ts",
    "isDynamicEntry": true
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "file": "default.6f2d0ab3.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie.664defff.js",
      "_api.474f9956.js"
    ],
    "css": [
      "default.b85c3508.css"
    ]
  },
  "default.b85c3508.css": {
    "file": "default.b85c3508.css",
    "resourceType": "style"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "file": "empty.4c640d90.js",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@bytemd/vue-next/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.1b35b81d.js",
    "src": "node_modules/@bytemd/vue-next/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/@bytemd/plugin-breaks/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.b7a1c1e0.js",
    "src": "node_modules/@bytemd/plugin-breaks/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-gemoji/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.325e5bcb.js",
    "src": "node_modules/@bytemd/plugin-gemoji/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-gfm/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.e7f92d8d.js",
    "src": "node_modules/@bytemd/plugin-gfm/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-highlight/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.901c9f49.js",
    "src": "node_modules/@bytemd/plugin-highlight/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js"
    ]
  },
  "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.2eab1e9a.js",
    "src": "node_modules/@bytemd/plugin-math-ssr/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.30957fd6.js",
    "src": "node_modules/@bytemd/plugin-medium-zoom/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/medium-zoom/dist/medium-zoom.esm.js"
    ]
  },
  "node_modules/@bytemd/plugin-mermaid/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.c933a902.js",
    "src": "node_modules/@bytemd/plugin-mermaid/dist/index.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/mermaid/dist/mermaid.esm.min.mjs"
    ]
  },
  "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "index.18decebf.js",
    "src": "node_modules/@bytemd/plugin-frontmatter/dist/index.mjs",
    "isDynamicEntry": true
  },
  "node_modules/marked/lib/marked.esm.js": {
    "resourceType": "script",
    "module": true,
    "file": "marked.esm.551ebfac.js",
    "src": "node_modules/marked/lib/marked.esm.js",
    "isDynamicEntry": true
  },
  "assets/theme.ts": {
    "resourceType": "script",
    "module": true,
    "file": "theme.a19ed3dc.js",
    "src": "assets/theme.ts",
    "isDynamicEntry": true
  },
  "_index.1df7656a.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.1df7656a.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js",
      "____vite-browser-external_commonjs-proxy.b95c029b.js"
    ]
  },
  "__commonjsHelpers.a7148835.js": {
    "resourceType": "script",
    "module": true,
    "file": "_commonjsHelpers.a7148835.js"
  },
  "____vite-browser-external_commonjs-proxy.b95c029b.js": {
    "resourceType": "script",
    "module": true,
    "file": "___vite-browser-external_commonjs-proxy.b95c029b.js",
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "utils/Drag.ts": {
    "resourceType": "script",
    "module": true,
    "file": "Drag.fecf15e7.js",
    "src": "utils/Drag.ts",
    "isDynamicEntry": true
  },
  "utils/color.ts": {
    "resourceType": "script",
    "module": true,
    "file": "color.1a3a3075.js",
    "src": "utils/color.ts",
    "isDynamicEntry": true
  },
  "_interact.min.3ac48332.js": {
    "resourceType": "script",
    "module": true,
    "file": "interact.min.3ac48332.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_dom-to-image.5044287b.js": {
    "resourceType": "script",
    "module": true,
    "file": "dom-to-image.5044287b.js",
    "isDynamicEntry": true
  },
  "node_modules/@zackdk/m3u8tomp4/src/index.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.6810e914.js",
    "src": "node_modules/@zackdk/m3u8tomp4/src/index.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_mpegts.e75d6339.js": {
    "resourceType": "script",
    "module": true,
    "file": "mpegts.e75d6339.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "node_modules/pinyin-pro/lib/pinyin.ts": {
    "resourceType": "script",
    "module": true,
    "file": "pinyin.3f986354.js",
    "src": "node_modules/pinyin-pro/lib/pinyin.ts",
    "isDynamicEntry": true
  },
  "_index.min.10aaf9f8.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.min.10aaf9f8.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_hls.2a7af7df.js": {
    "resourceType": "script",
    "module": true,
    "file": "hls.2a7af7df.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_fabric.2646cadb.js": {
    "resourceType": "script",
    "module": true,
    "file": "fabric.2646cadb.js",
    "isDynamicEntry": true,
    "imports": [
      "____vite-browser-external_commonjs-proxy.b95c029b.js"
    ]
  },
  "node_modules/png-to-svg-wasm/png_to_svg_wasm.js": {
    "resourceType": "script",
    "module": true,
    "file": "png_to_svg_wasm.8ae99f4f.js",
    "src": "node_modules/png-to-svg-wasm/png_to_svg_wasm.js",
    "isDynamicEntry": true,
    "assets": [
      "png_to_svg_wasm_bg.ad85097d.wasm"
    ]
  },
  "png_to_svg_wasm_bg.ad85097d.wasm": {
    "file": "png_to_svg_wasm_bg.ad85097d.wasm"
  },
  "utils/svgo.browser.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "svgo.browser.3113e892.js",
    "src": "utils/svgo.browser.mjs",
    "isDynamicEntry": true
  },
  "_index.efea0cb8.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.efea0cb8.js",
    "isDynamicEntry": true
  },
  "_RecordRTC.d7a40e53.js": {
    "resourceType": "script",
    "module": true,
    "file": "RecordRTC.d7a40e53.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_uniq.5ad30764.js": {
    "resourceType": "script",
    "module": true,
    "file": "uniq.5ad30764.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "_join.5e100562.js": {
    "resourceType": "script",
    "module": true,
    "file": "join.5e100562.js",
    "isDynamicEntry": true
  },
  "utils/ZWSP.ts": {
    "resourceType": "script",
    "module": true,
    "file": "ZWSP.e88cbe23.js",
    "src": "utils/ZWSP.ts",
    "isDynamicEntry": true
  },
  "_index.92c964f7.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.92c964f7.js",
    "isDynamicEntry": true,
    "imports": [
      "__commonjsHelpers.a7148835.js"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.29ae6f39.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-404.18ced855.css": {
    "file": "error-404.18ced855.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.5ef73979.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-500.e60962de.css": {
    "file": "error-500.e60962de.css",
    "resourceType": "style"
  },
  "node_modules/highlight.js/es/index.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.5c5dd036.js",
    "src": "node_modules/highlight.js/es/index.js",
    "isDynamicEntry": true
  },
  "node_modules/medium-zoom/dist/medium-zoom.esm.js": {
    "resourceType": "script",
    "module": true,
    "file": "medium-zoom.esm.429efe94.js",
    "src": "node_modules/medium-zoom/dist/medium-zoom.esm.js",
    "isDynamicEntry": true
  },
  "node_modules/mermaid/dist/mermaid.esm.min.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "mermaid.esm.min.6d6fe547.js",
    "src": "node_modules/mermaid/dist/mermaid.esm.min.mjs",
    "isDynamicEntry": true
  },
  "pages/tool/detail/FancyBorderRadius.css": {
    "resourceType": "style",
    "file": "FancyBorderRadius.a5b0c680.css",
    "src": "pages/tool/detail/FancyBorderRadius.css"
  },
  "pages/tool/detail/NationalDayAvatar.css": {
    "resourceType": "style",
    "file": "NationalDayAvatar.d2c16d7b.css",
    "src": "pages/tool/detail/NationalDayAvatar.css"
  },
  "pages/tool/detail/FlvPlayer.css": {
    "resourceType": "style",
    "file": "FlvPlayer.4f97ec6b.css",
    "src": "pages/tool/detail/FlvPlayer.css"
  },
  "pages/tool/detail/TextSecret.css": {
    "resourceType": "style",
    "file": "TextSecret.c1a8e657.css",
    "src": "pages/tool/detail/TextSecret.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.e60962de.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.18ced855.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "pages/writer.css": {
    "resourceType": "style",
    "file": "writer.40077ed7.css",
    "src": "pages/writer.css"
  },
  "pages/tool/detail/WeiBoGenerates.css": {
    "resourceType": "style",
    "file": "WeiBoGenerates.c7984c87.css",
    "src": "pages/tool/detail/WeiBoGenerates.css"
  },
  "pages/tool/detail/Whois.css": {
    "resourceType": "style",
    "file": "Whois.4e0a190c.css",
    "src": "pages/tool/detail/Whois.css"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.06cc0c9c.css",
    "src": "pages/index.css"
  },
  "pages/tool/detail/NPlayer.css": {
    "resourceType": "style",
    "file": "NPlayer.4f97ec6b.css",
    "src": "pages/tool/detail/NPlayer.css"
  },
  "pages/read/index.css": {
    "resourceType": "style",
    "file": "index.412ca2a9.css",
    "src": "pages/read/index.css"
  },
  "pages/read/post/[id].css": {
    "resourceType": "style",
    "file": "_id_.a70ec486.css",
    "src": "pages/read/post/[id].css"
  },
  "atom-one-dark.css": {
    "resourceType": "style",
    "file": "atom-one-dark.a80f81b9.css",
    "src": "atom-one-dark.css"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.b85c3508.css",
    "src": "layouts/default.css"
  },
  "pages/tool/detail/MakePhrase.css": {
    "resourceType": "style",
    "file": "MakePhrase.fb714d87.css",
    "src": "pages/tool/detail/MakePhrase.css"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.ac2675fc.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.mjs-css": {
    "file": "",
    "css": [
      "entry.ac2675fc.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
