const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-51c93615.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-6f11d52b.mjs",
      "_dom-to-image-38bb6765.mjs",
      "_mpegts-58cf781d.mjs",
      "_pinyin-web-dfe70e18.mjs",
      "_index.min-b31bc1cd.mjs",
      "_hls-592b13b8.mjs",
      "_RecordRTC-4faa0ed4.mjs",
      "_lodash-fc9c5d58.mjs",
      "pages/index.vue",
      "pages/link/index.vue",
      "pages/link.vue",
      "pages/read/index.vue",
      "pages/read/post/[id].vue",
      "pages/read/post.vue",
      "pages/read.vue",
      "pages/tool/detail/CSSGradient.vue",
      "pages/tool/detail/EnglistConvert.vue",
      "pages/tool/detail/FancyBorderRadius.vue",
      "pages/tool/detail/FlvPlayer.vue",
      "pages/tool/detail/ImageToBase64.vue",
      "pages/tool/detail/MakePhrase.vue",
      "pages/tool/detail/NPlayer.vue",
      "pages/tool/detail/ScreenRec.vue",
      "pages/tool/detail/TextDistinct.vue",
      "pages/tool/detail/Timestamp.vue",
      "pages/tool/detail/UnicodeConvert.vue",
      "pages/tool/detail/WeiBoGenerates.vue",
      "pages/tool/detail.vue",
      "pages/tool/index.vue",
      "pages/tool.vue",
      "pages/user/index/create.vue",
      "pages/user/index/index.vue",
      "pages/user/index/order.vue",
      "pages/user/index.vue",
      "pages/writer.vue",
      "middleware/auth.ts",
      "layouts/default.vue",
      "layouts/empty.vue"
    ],
    "css": [
      "entry.2dbbf9c7.css"
    ],
    "assets": [
      "iconfont.8c3eb7e7.woff2",
      "iconfont.c7a4bd31.woff",
      "iconfont.ec975a33.ttf"
    ]
  },
  "pages/index.vue": {
    "file": "index-9addff24.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-f3da5c66.mjs",
      "_api-31f923db.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "_asyncData-f3da5c66.mjs": {
    "file": "asyncData-f3da5c66.mjs",
    "imports": [
      "_cookie-f4ffe027.mjs",
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_api-31f923db.mjs": {
    "file": "api-31f923db.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "_cookie-f4ffe027.mjs": {
    "file": "cookie-f4ffe027.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link/index.vue": {
    "file": "index-484744d2.mjs",
    "src": "pages/link/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/link.vue": {
    "file": "link-887863c1.mjs",
    "src": "pages/link.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read/index.vue": {
    "file": "index-24edac5b.mjs",
    "src": "pages/read/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-f3da5c66.mjs",
      "_api-31f923db.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "pages/read/post/[id].vue": {
    "file": "_id_-fd211885.mjs",
    "src": "pages/read/post/[id].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-f3da5c66.mjs",
      "_api-31f923db.mjs",
      "_theme-581310c5.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "_theme-581310c5.mjs": {
    "file": "theme-581310c5.mjs",
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "node_modules/highlight.js/es/index.js",
      "node_modules/medium-zoom/dist/medium-zoom.esm.js",
      "node_modules/mermaid/dist/mermaid.esm.min.mjs"
    ]
  },
  "pages/read/post.vue": {
    "file": "post-a15edfb3.mjs",
    "src": "pages/read/post.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/read.vue": {
    "file": "read-13f99f44.mjs",
    "src": "pages/read.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/CSSGradient.vue": {
    "file": "CSSGradient-c2167970.mjs",
    "src": "pages/tool/detail/CSSGradient.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "utils/Drag.ts",
      "utils/color.ts",
      "_interact.min-6f11d52b.mjs",
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail/EnglistConvert.vue": {
    "file": "EnglistConvert-e07934e9.mjs",
    "src": "pages/tool/detail/EnglistConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FancyBorderRadius.vue": {
    "file": "FancyBorderRadius-3071b840.mjs",
    "src": "pages/tool/detail/FancyBorderRadius.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/FlvPlayer.vue": {
    "file": "FlvPlayer-22b320b8.mjs",
    "src": "pages/tool/detail/FlvPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_mpegts-58cf781d.mjs"
    ]
  },
  "pages/tool/detail/ImageToBase64.vue": {
    "file": "ImageToBase64-2fe4994f.mjs",
    "src": "pages/tool/detail/ImageToBase64.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/MakePhrase.vue": {
    "file": "MakePhrase-bf2cc022.mjs",
    "src": "pages/tool/detail/MakePhrase.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs",
      "_pinyin-web-dfe70e18.mjs"
    ]
  },
  "pages/tool/detail/NPlayer.vue": {
    "file": "NPlayer-df143273.mjs",
    "src": "pages/tool/detail/NPlayer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_index.min-b31bc1cd.mjs",
      "_hls-592b13b8.mjs"
    ]
  },
  "pages/tool/detail/ScreenRec.vue": {
    "file": "ScreenRec-a8b232e7.mjs",
    "src": "pages/tool/detail/ScreenRec.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_RecordRTC-4faa0ed4.mjs"
    ]
  },
  "pages/tool/detail/TextDistinct.vue": {
    "file": "TextDistinct-c28920d3.mjs",
    "src": "pages/tool/detail/TextDistinct.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_lodash-fc9c5d58.mjs"
    ]
  },
  "pages/tool/detail/Timestamp.vue": {
    "file": "Timestamp-926c7aaf.mjs",
    "src": "pages/tool/detail/Timestamp.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_api-31f923db.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "pages/tool/detail/UnicodeConvert.vue": {
    "file": "UnicodeConvert-17c4c22b.mjs",
    "src": "pages/tool/detail/UnicodeConvert.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/detail/WeiBoGenerates.vue": {
    "file": "WeiBoGenerates-1e51f7b4.mjs",
    "src": "pages/tool/detail/WeiBoGenerates.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "_dom-to-image-38bb6765.mjs"
    ]
  },
  "pages/tool/detail.vue": {
    "file": "detail-bd48bb2f.mjs",
    "src": "pages/tool/detail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/tool/index.vue": {
    "file": "index-692f8ab6.mjs",
    "src": "pages/tool/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_asyncData-f3da5c66.mjs",
      "_api-31f923db.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "pages/tool.vue": {
    "file": "tool-7b9f4431.mjs",
    "src": "pages/tool.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/create.vue": {
    "file": "create-b46145f9.mjs",
    "src": "pages/user/index/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/index.vue": {
    "file": "index-ef5d2eeb.mjs",
    "src": "pages/user/index/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index/order.vue": {
    "file": "order-dc16792c.mjs",
    "src": "pages/user/index/order.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/user/index.vue": {
    "file": "index-e59f86c7.mjs",
    "src": "pages/user/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "pages/writer.vue": {
    "file": "writer-9b94a1ca.mjs",
    "src": "pages/writer.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_theme-581310c5.mjs",
      "_api-31f923db.mjs",
      "_cookie-f4ffe027.mjs"
    ]
  },
  "middleware/auth.ts": {
    "file": "auth-535b72c5.mjs",
    "src": "middleware/auth.ts",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-f4ffe027.mjs",
      "_api-31f923db.mjs"
    ]
  },
  "layouts/default.vue": {
    "file": "default-0402b8a8.mjs",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs",
      "_cookie-f4ffe027.mjs",
      "_api-31f923db.mjs"
    ],
    "css": [
      "default.f39aa63b.css"
    ]
  },
  "layouts/empty.vue": {
    "file": "empty-b2c42b34.mjs",
    "src": "layouts/empty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "utils/Drag.ts": {
    "file": "Drag-cac46c1e.mjs",
    "src": "utils/Drag.ts",
    "isDynamicEntry": true
  },
  "utils/color.ts": {
    "file": "color-c1be6728.mjs",
    "src": "utils/color.ts",
    "isDynamicEntry": true
  },
  "_interact.min-6f11d52b.mjs": {
    "file": "interact.min-6f11d52b.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_dom-to-image-38bb6765.mjs": {
    "file": "dom-to-image-38bb6765.mjs",
    "isDynamicEntry": true
  },
  "_mpegts-58cf781d.mjs": {
    "file": "mpegts-58cf781d.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_pinyin-web-dfe70e18.mjs": {
    "file": "pinyin-web-dfe70e18.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_index.min-b31bc1cd.mjs": {
    "file": "index.min-b31bc1cd.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_hls-592b13b8.mjs": {
    "file": "hls-592b13b8.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_RecordRTC-4faa0ed4.mjs": {
    "file": "RecordRTC-4faa0ed4.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_lodash-fc9c5d58.mjs": {
    "file": "lodash-fc9c5d58.mjs",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "node_modules/highlight.js/es/index.js": {
    "file": "index-5d39d920.mjs",
    "src": "node_modules/highlight.js/es/index.js",
    "isDynamicEntry": true
  },
  "node_modules/medium-zoom/dist/medium-zoom.esm.js": {
    "file": "medium-zoom.esm-76784ffc.mjs",
    "src": "node_modules/medium-zoom/dist/medium-zoom.esm.js",
    "isDynamicEntry": true
  },
  "node_modules/mermaid/dist/mermaid.esm.min.mjs": {
    "file": "mermaid.esm.min-69e0ceb1.mjs",
    "src": "node_modules/mermaid/dist/mermaid.esm.min.mjs",
    "isDynamicEntry": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
