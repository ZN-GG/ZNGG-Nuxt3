const _imports_0 = "" + globalThis.__publicAssetsURL("img/XGPlayer.png");

export { _imports_0 as _ };
//# sourceMappingURL=XGPlayer.ad8d9c23.mjs.map
