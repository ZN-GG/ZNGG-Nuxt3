const WordToPDF_vue_vue_type_style_index_0_scoped_403f14ce_lang = ".convert-bg[data-v-403f14ce]{background:url(" + globalThis.__publicAssetsURL("img/office/office_banner.svg") + ") bottom no-repeat;height:130px}.convert-bg[data-v-403f14ce],.office-bg[data-v-403f14ce]{background-color:#f1f3fe}.in-upload-box[data-v-403f14ce]{left:50%;position:absolute;top:50%;transform:translate(-50%,-50%)}";

const WordToPDFStyles_f9c9c062 = [WordToPDF_vue_vue_type_style_index_0_scoped_403f14ce_lang];

export { WordToPDFStyles_f9c9c062 as default };
//# sourceMappingURL=WordToPDF-styles.f9c9c062.mjs.map
