const LeftContents_vue_vue_type_style_index_0_scoped_f43709a0_lang = ".left-ul>li>a[data-v-f43709a0]{align-items:center;cursor:pointer;display:flex;font-weight:700;line-height:2.5rem;padding-left:.75rem;padding-right:.75rem}.left-ul>li[data-v-f43709a0]:hover{--tw-bg-opacity:1;background-color:#e5e7eb;background-color:rgb(229 231 235/var(--tw-bg-opacity));border-radius:.25rem}.left-ul>li.active>a[data-v-f43709a0]{--tw-text-opacity:1;color:#2563eb;color:rgb(37 99 235/var(--tw-text-opacity))}";

const LeftContentsStyles_a9439643 = [LeftContents_vue_vue_type_style_index_0_scoped_f43709a0_lang];

export { LeftContentsStyles_a9439643 as default };
//# sourceMappingURL=LeftContents-styles.a9439643.mjs.map
