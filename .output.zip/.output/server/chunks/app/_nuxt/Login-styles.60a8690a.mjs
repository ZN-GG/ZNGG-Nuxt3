const Login_vue_vue_type_style_index_0_scoped_48878da3_lang = ".modal-show[data-v-48878da3]{-webkit-backdrop-filter:saturate(180%) blur(25px);backdrop-filter:saturate(180%) blur(25px);background:rgba(0,0,0,.35)}";

const LoginStyles_60a8690a = [Login_vue_vue_type_style_index_0_scoped_48878da3_lang];

export { LoginStyles_60a8690a as default };
//# sourceMappingURL=Login-styles.60a8690a.mjs.map
