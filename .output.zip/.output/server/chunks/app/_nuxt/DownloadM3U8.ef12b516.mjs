import { defineComponent, reactive, ref, mergeProps, useSSRContext } from 'vue';
import { a as useNuxtApp, u as useHead } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "DownloadM3U8",
  __ssrInlineRender: true,
  setup(__props) {
    const state = reactive({ videoUrl: "", logs: [] });
    const text = ref("");
    useNuxtApp();
    useHead({
      title: "\u5728\u7EBF\u4E0B\u8F7D M3U8 \u89C6\u9891",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        {
          name: "Keywords",
          content: "M3U8\u89C6\u9891\u5728\u7EBF\u4E0B\u8F7D,M3U8\u5728\u7EBF\u5408\u5E76MP4\uFF0Cm3u8,download m3u8 online"
        },
        {
          name: "description",
          content: "\u5728\u7EBF\u4E0B\u8F7D M3U8 \u89C6\u9891, \u5408\u5E76\u4E3A MP4"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white" }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">M3U8\u89C6\u9891\u5728\u7EBF\u4E0B\u8F7D</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12"><div class="w-full flex flex-wrap bg-black text-sm">`);
      if (state.videoUrl) {
        _push(`<video controls${ssrRenderAttr("src", state.videoUrl)}></video>`);
      } else {
        _push(`<div class="overflow-auto h-20 w-full"><!--[-->`);
        ssrRenderList(state.logs, (msg) => {
          _push(`<div><div class="text-white">${ssrInterpolate(msg)}</div></div>`);
        });
        _push(`<!--]--></div>`);
      }
      _push(`</div><div class="w-full flex flex-wrap"><div class="relative w-full"><div class="relative"><textarea autofocus class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3 h-full" rows="8" placeholder="\u8F93\u5165\u6709\u6548\u7684M3U8\u5730\u5740">${ssrInterpolate(text.value)}</textarea><span class="absolute px-2 py-1 text-xs text-white bg-blue-500 rounded right-4 bottom-6">${ssrInterpolate(text.value.length)}</span></div></div></div>`);
      if (state.videoUrl) {
        _push(`<button class="flex my-2 mr-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u4FDD\u5B58\u89C6\u9891 </button>`);
      } else {
        _push(`<button class="flex my-2 mr-2 py-2 px-4 font-medium tracking-widest text-white bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u4E0B\u8F7D\u89C6\u9891 </button>`);
      }
      _push(`</section><section class="bg-white w-full container mx-auto px-4 py-6"><article class="prose lg:prose-xl" style="${ssrRenderStyle({ "max-width": "none" })}"><h4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote><p>\u8F93\u5165 m3u8 \u5730\u5740\uFF0C\u70B9\u51FB\u4E0B\u8F7D\u540E\u7B49\u5F85\u4E0B\u8F7D\u5B8C\u6210\uFF0C\u968F\u540E\u4F1A\u5408\u5E76\u4E3A\u4E00\u4E2Amp4\u6587\u4EF6\uFF0C\u5408\u6210\u5B8C\u6BD5\u4EE5\u540E\u70B9\u51FB\u4FDD\u5B58\u89C6\u9891\u6309\u94AE\u5373\u53EF\u4E0B\u8F7D\u3002</p></blockquote><ul><li>\u627E\u4E0D\u5230 M3U8 \u94FE\u63A5\uFF0C\u53EF\u4EE5\u53BB <a href="https://movie.zackdk.com/" target="_blank">movie.zackdk.com</a> \u627E</li><li>\u7531\u4E8E WebAssembly \u7684\u9650\u5236,\u6700\u5927\u652F\u6301 2GB \u6587\u4EF6\u7684\u8F93\u5165\u3002</li><li>\u6682\u65F6\u4E0D\u652F\u6301\u7EC8\u6B62\u4E0B\u8F7D\uFF0C\u8BF7\u624B\u52A8\u5237\u65B0\u7F51\u9875\u3002</li></ul></article></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/DownloadM3U8.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=DownloadM3U8.ef12b516.mjs.map
