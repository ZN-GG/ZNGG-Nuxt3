import { c as _export_sfc, a as useNuxtApp, u as useHead } from '../server.mjs';
import { useSSRContext, defineComponent, ref, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FancyBorderRadius",
  __ssrInlineRender: true,
  setup(__props) {
    useNuxtApp();
    ref(null);
    ref(null);
    ref(null);
    ref(null);
    ref(null);
    const bgColor = ref("");
    const config = ref({
      left: 30,
      top: 34,
      right: 73,
      bottom: 30
    });
    ref({
      v: false,
      type: "",
      lastXY: 0,
      base: 1,
      baseP: 0
    });
    useHead({
      title: "CSS\u8FB9\u6846\u53EF\u89C6\u5316",
      titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
      viewport: "width=device-width, initial-scale=1, maximum-scale=1",
      charset: "utf-8",
      meta: [
        { name: "Keywords", content: "CSS\u8FB9\u6846\u53EF\u89C6\u5316,CSS\u82B1\u5F0F\u8FB9\u6846,CSS\u82B1\u5F0F\u80CC\u666F,css\u4E0D\u89C4\u5219\u80CC\u666F,CSS\u8FB9\u6846\u53EF\u89C6\u5316,\u81EA\u5B9A\u4E49css\u8FB9\u6846\u6837\u5F0F" },
        { name: "description", content: "\u62D6\u62FD\u5F0F\u53EF\u89C6\u5316\u8C03\u6574CSS\u8FB9\u6846\u6837\u5F0F\uFF0C\u524D\u7AEF\u7A0B\u5E8F\u5458\u5FC5\u5907\u7684\u5DE5\u5177\u4E4B\u4E00\u3002css\u6247\u5F62\u80CC\u666F\u3001css\u5706\u89D2\u8FB9\u6846\u3001css\u96E8\u6EF4\u5F62\u72B6\u7B49\u81EA\u5B9A\u4E49\u6837\u5F0F\u4E00\u952E\u751F\u6210\u3002" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white" }, _attrs))} data-v-7b3330f4><section class="bg-gray-100" data-v-7b3330f4><div class="container px-4 mx-auto" data-v-7b3330f4><div class="md:flex md:-mx-4 md:items-center py-8" data-v-7b3330f4><div class="md:w-1/2 px-4" data-v-7b3330f4><h1 class="text-2xl text-black" data-v-7b3330f4>CSS\u8FB9\u6846\u53EF\u89C6\u5316</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12" data-v-7b3330f4><div class="flex flex-wrap" data-v-7b3330f4><div class="w-full md:w-5/12 px-6 mb-6" data-v-7b3330f4><div class="core-box" data-v-7b3330f4><div class="core-shape" style="${ssrRenderStyle("border-radius: " + config.value.top + "% " + (100 - config.value.top) + "% " + (100 - config.value.bottom) + "% " + config.value.bottom + "% / " + config.value.left + "% " + config.value.right + "% " + (100 - config.value.right) + "% " + (100 - config.value.left) + "%;background-image:" + bgColor.value)}" data-v-7b3330f4></div><span class="core-btn" id="left" style="${ssrRenderStyle("top: " + config.value.left + "%;")}" data-v-7b3330f4></span><span class="core-btn" id="top" style="${ssrRenderStyle("left:" + config.value.top + "%;")}" data-v-7b3330f4></span><span class="core-btn" id="right" style="${ssrRenderStyle("top: " + config.value.right + "%;")}" data-v-7b3330f4></span><span class="core-btn" id="bottom" style="${ssrRenderStyle("left: " + config.value.bottom + "%;")}" data-v-7b3330f4></span></div></div><div class="w-full md:w-7/12 md:pl-8" data-v-7b3330f4><div class="flex flex-wrap mb-6" data-v-7b3330f4><h2 class="w-full font-semibold text-gray-900" data-v-7b3330f4>\u9009\u62E9\u80CC\u666F\u989C\u8272\uFF1A</h2><div class="flex" data-v-7b3330f4><div class="w-8 h-8 mr-2" style="${ssrRenderStyle({ "background-image": "linear-gradient(90deg, rgb(2, 0, 36) 0%, rgb(9, 9, 121) 31%, rgb(0, 212, 255) 100%)" })}" data-v-7b3330f4></div><div class="w-8 h-8 mr-2" style="${ssrRenderStyle({ "background-image": "linear-gradient(0deg, rgb(34, 193, 195) 0%, rgb(253, 187, 45) 100%)" })}" data-v-7b3330f4></div><div class="w-8 h-8 mr-2" style="${ssrRenderStyle({ "background-image": "radial-gradient(circle, rgb(63, 94, 251) 0%, rgb(252, 70, 107) 100%)" })}" data-v-7b3330f4></div><div class="w-8 h-8 mr-2" style="${ssrRenderStyle({ "background-image": "linear-gradient(90deg, rgb(131, 58, 180) 0%, rgb(253, 29, 29) 50%, rgb(252, 176, 69) 100%)" })}" data-v-7b3330f4></div><div class="w-8 h-8 mr-2" style="${ssrRenderStyle({ "background-image": "radial-gradient(circle, rgb(238, 174, 202) 0%, rgb(148, 187, 233) 100%)" })}" data-v-7b3330f4></div></div></div><div class="flex flex-wrap mb-4" data-v-7b3330f4><h2 class="w-full font-semibold text-gray-900" data-v-7b3330f4>\u5F53\u524D\u8FB9\u6846\u6837\u5F0F\uFF1A</h2><div class="flex my-1 w-full" data-v-7b3330f4><p disabled class="bg-gray-100 outline-none p-2 w-auto font-bold" data-v-7b3330f4>${ssrInterpolate("border-radius: " + config.value.top + "% " + (100 - config.value.top) + "% " + (100 - config.value.bottom) + "% " + config.value.bottom + "% / " + config.value.left + "% " + config.value.right + "% " + (100 - config.value.right) + "% " + (100 - config.value.left) + "%;")}</p></div><button type="button" class="flex mr-2 py-2 px-4 my-2 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none" data-v-7b3330f4> \u590D\u5236 </button></div></div></div></section><hr class="container mx-auto" data-v-7b3330f4><section class="bg-white w-full container mx-auto px-4 py-6" data-v-7b3330f4><article class="prose lg:prose-xl" style="${ssrRenderStyle({ "max-width": "none" })}" data-v-7b3330f4><h4 data-v-7b3330f4>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote data-v-7b3330f4><p data-v-7b3330f4>\u968F\u610F\u62D6\u62FD\u5B9A\u5236CSS\u8FB9\u6846\u5F62\u72B6\u7684\u5C0F\u5DE5\u5177\uFF0C\u524D\u7AEF\u5FC5\u5907\u5DE5\u5177\u4E4B\u4E00\u3002 </p></blockquote><ul data-v-7b3330f4><li data-v-7b3330f4>\u524D\u7AEFCSS\u62D6\u62FD\u5F0F\u8FB9\u6846\u751F\u6210\uFF0C\u6548\u7387\u63D0\u534799%\u3002</li><li data-v-7b3330f4>CSS\u7ED8\u5236\u5706\u5F62\uFF0CCSS\u7ED8\u5236\u692D\u5706\uFF0CCSS\u7ED8\u5236\u96E8\u6EF4\uFF0CCSS\u7ED8\u5236\u6247\u5F62\u7B49\u5404\u79CD\u5F62\u72B6\u3002</li><li data-v-7b3330f4>\u7075\u611F\u6765\u6E90\uFF1Ahttps://github.com/9elements/fancy-border-radius\u3002</li></ul></article></section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/FancyBorderRadius.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const FancyBorderRadius = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-7b3330f4"]]);

export { FancyBorderRadius as default };
//# sourceMappingURL=FancyBorderRadius.f3ef81be.mjs.map
