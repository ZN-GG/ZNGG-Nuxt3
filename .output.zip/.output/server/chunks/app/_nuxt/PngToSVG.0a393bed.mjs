import { defineComponent, withAsyncContext, ref, mergeProps, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate } from 'vue/server-renderer';
import 'ohmyfetch';
import 'ufo';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'destr';
import 'h3';
import 'defu';
import '@vue/shared';
import 'cookie-es';
import 'ohash';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "PngToSVG",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      ([__temp, __restore] = withAsyncContext(() => import('./png_to_svg_wasm.368901b1.mjs')), __temp = await __temp, __restore(), __temp).default;
      ([__temp, __restore] = withAsyncContext(() => import('./png_to_svg_wasm.368901b1.mjs')), __temp = await __temp, __restore(), __temp).get_svg;
      ([__temp, __restore] = withAsyncContext(() => import('./svgo.browser.c10bfed2.mjs')), __temp = await __temp, __restore(), __temp).optimize;
      ([__temp, __restore] = withAsyncContext(() => import('copy-to-clipboard').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      useNuxtApp();
      const emptyData = '<p style="line-height:18rem;text-align:center;">SVG\u5C55\u793A\u533A\u57DF</p>';
      const svgData = ref("");
      useHead({
        title: "Png\u8F6CSVG",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        viewport: "width=device-width, initial-scale=1, maximum-scale=1",
        charset: "utf-8",
        meta: [
          {
            name: "Keywords",
            content: "Png\u8F6CSVG,\u5728\u7EBF\u5C06PNG\u8F6C\u6362\u6210SVG\u683C\u5F0F,\u514D\u8D39PNG\u8F6C\u6362\u6210SVG,Png to SVG,png conver to svg"
          },
          {
            name: "description",
            content: "\u4E00\u4E2A\u53EF\u4EE5\u5728\u7EBF\u5C06PNG\u56FE\u7247\u8F6C\u6362\u6210SVG\u683C\u5F0F\u7684\u5DE5\u5177\u3002A tool that can convert PNG images to SVG format online."
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white min-h-screen"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">Png\u8F6CSVG</h1></div></div></div></section><div class="container px-4 mx-auto py-6"><div class="form-group"><div class="text-center relative py-12 mb-4 border-2 hover:bg-gray-100 custom-font-14 rounded" id="fileInput"><span>\u62D6\u62FD\u6587\u4EF6\u5230\u8FD9\u91CC\u6216\u8005\u70B9\u51FB\u9009\u62E9\u6587\u4EF6</span><input type="file" id="file" accept="image/*" style="${ssrRenderStyle({
          "opacity": "0",
          "position": "absolute",
          "cursor": "pointer",
          "width": "100%",
          "height": "100%",
          "left": "0",
          "top": "0"
        })}"></div></div><div class="flex flex-wrap"><div class="w-full md:w-6/12 md:pr-2"><div class="w-full h-72 object-contain border-2">${svgData.value == "" ? emptyData : svgData.value}</div></div><div class="w-full md:w-6/12 md:pl-2 mt-4 md:mt-0"><textarea class="w-full bg-gray-100 outline-none p-2 h-72 text-gray-700 custom-font-14" name="" id="" cols="30" rows="10">${ssrInterpolate(svgData.value)}</textarea></div></div><div class="flex flex-row flex-wrap justify-around"><div></div><div class="flex flex-row flex-wrap"><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none leading"> \u590D\u5236 </button></div></div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/PngToSVG.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=PngToSVG.0a393bed.mjs.map
