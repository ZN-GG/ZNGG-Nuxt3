const Toolbar_vue_vue_type_style_index_0_scoped_1827a941_lang = "header[data-v-1827a941]{background:#fff}.menu>li[data-v-1827a941]:hover,.router-link-active[data-v-1827a941],.router-link-exact-active[data-v-1827a941]{color:#3955f6;font-weight:900}.icon-category[data-v-1827a941]{font-size:24px}";

const ToolbarStyles_d5a61d75 = [Toolbar_vue_vue_type_style_index_0_scoped_1827a941_lang];

export { ToolbarStyles_d5a61d75 as default };
//# sourceMappingURL=Toolbar-styles.d5a61d75.mjs.map
