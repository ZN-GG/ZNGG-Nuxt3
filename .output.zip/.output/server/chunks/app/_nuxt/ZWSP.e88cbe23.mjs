const CODE_MAP = {
  "0": "\u200E",
  "1": "\u200F"
};
const CODE_MAP2 = {
  ["\u200F"]: "1",
  ["\u200E"]: "0"
};
const str2binary = (str) => {
  if (!str.length)
    return [];
  const binaryMap = str.split("").map((c) => c.charCodeAt(0).toString(2));
  return binaryMap;
};
const binary2str = (bArr) => {
  const cArr = bArr.map((b) => String.fromCharCode(parseInt(b, 2)));
  return cArr.join("");
};
const covertBinary2ZWSP = (barr) => {
  const covertSingle = (binaryStr) => {
    if (!binaryStr.length)
      return "";
    return binaryStr.split("").map((c) => CODE_MAP[c]).join("");
  };
  const str = barr.map((b) => covertSingle(b)).join("\u200C");
  return str;
};
const ZWSP2Binary = (zwspStr) => {
  const cArr = zwspStr.split("\u200C");
  console.log(cArr);
  const covertSingle = (zwspC) => {
    if (!zwspC.length)
      return "";
    return zwspC.split("").map((c) => CODE_MAP2[c]).join("");
  };
  return cArr.map(covertSingle);
};
const encode = (string) => covertBinary2ZWSP(str2binary(string));
const decode = (encodeStr) => binary2str(ZWSP2Binary(encodeStr));
const zwsp = {
  encode,
  decode
};

export { zwsp as default };
//# sourceMappingURL=ZWSP.e88cbe23.mjs.map
