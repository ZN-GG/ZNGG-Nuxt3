import { defineComponent, ref, withAsyncContext, watch, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, a as useNuxtApp, u as useHead } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrRenderStyle, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let MakePhrase;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main = defineComponent({
    __name: "MakePhrase",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      ref();
      useNuxtApp();
      const word = ref("\u85AA\u6EE1\u610F\u8DB3");
      const pinyin = ref("x\u012Bn m\u01CEn y\xEC z\xFA");
      const meta = ref("\u610F\u601D\u662F\u6307\u85AA\u6C34\u3001\u5DE5\u8D44\u5F88\u5408\u9002\uFF0C\u800C\u8BA9\u81EA\u5DF1\u89C9\u5F97\u5F88\u6EE1\u8DB3\u3001\u5F88\u6EE1\u610F\u3002");
      const img = ref("");
      const loading = ref(false);
      ([__temp, __restore] = withAsyncContext(() => import('dom-to-image').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore(), __temp).default;
      const pinyinUtil = ([__temp, __restore] = withAsyncContext(() => import('./pinyin.3f986354.mjs')), __temp = await __temp, __restore(), __temp).pinyin;
      watch(() => word, (o, n) => {
        console.log(word.value);
        pinyin.value = pinyinUtil(word.value);
      }, {
        deep: true
      });
      useHead({
        title: "\u9020\u65B0\u8BCD\u751F\u6210\u5668",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u6210\u8BED\u751F\u6210\u5668,\u65B0\u8BCD\u751F\u6210\u5668,\u9020\u65B0\u8BCD\u751F\u6210\u5668,\u7530\u5B57\u683C\u6210\u8BED\u751F\u6210\u5668,\u6D41\u884C\u6210\u8BED\u751F\u6210\u89E3\u91CA"
          },
          {
            name: "description",
            content: "\u6D41\u884C\u7684\u65B0\u8BCD\u751F\u6210\u5668\uFF0C\u7528\u6765\u9020\u65B0\u8BCD\u7684\u5DE5\u5177\uFF0C\u6709\u7530\u5B57\u683C\u80CC\u666F\u3001\u62FC\u97F3\u548C\u91CA\u4E49\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white"
        }, _attrs))} data-v-36e4a64d><section class="bg-gray-100" data-v-36e4a64d><div class="container px-4 mx-auto" data-v-36e4a64d><div class="md:flex md:-mx-4 md:items-center py-8" data-v-36e4a64d><div class="md:w-1/2 px-4" data-v-36e4a64d><h1 class="text-2xl text-black" data-v-36e4a64d>\u9020\u65B0\u8BCD\u751F\u6210\u5668</h1></div></div></div></section><section class="w-full container px-4 mx-auto py-12" data-v-36e4a64d><div class="flex flex-wrap mb-4" data-v-36e4a64d><h2 class="w-full font-semibold text-gray-900 text-lg" data-v-36e4a64d>\u8BCD\u8BED\uFF1A</h2><input${ssrRenderAttr("value", unref(word))} autofocus class="bg-gray-100 outline-none px-2 py-1 mr-2 my-1 text-red-700" type="text" data-v-36e4a64d></div><div class="flex flex-wrap mb-4" data-v-36e4a64d><h2 class="w-full font-semibold text-gray-900 text-lg" data-v-36e4a64d>\u91CA\u4E49\uFF1A</h2><textarea placeholder="" class="text-gray-600 w-full bg-gray-100 boder-left boder-bottom outline-none p-3" rows="3" data-v-36e4a64d>${ssrInterpolate(unref(meta))}</textarea></div><div class="flex flex-wrap mb-4" data-v-36e4a64d><h2 class="w-full font-semibold text-gray-900 text-lg" data-v-36e4a64d>\u62FC\u97F3\uFF1A</h2><input${ssrRenderAttr("value", unref(pinyin))} class="bg-gray-100 outline-none px-2 py-1 mr-2 my-1 w-full" type="text" data-v-36e4a64d></div><div class="new_word" data-v-36e4a64d><div class="preview" data-v-36e4a64d><div class="box" data-v-36e4a64d><div class="pinyin" data-v-36e4a64d><!--[-->`);
        ssrRenderList(unref(pinyin).split(" "), (w) => {
          _push(`<div class="text" data-v-36e4a64d>${ssrInterpolate(w)}</div>`);
        });
        _push(`<!--]--></div><div class="words" data-v-36e4a64d><!--[-->`);
        ssrRenderList(unref(word), (w) => {
          _push(`<div class="word" data-v-36e4a64d><span class="line" data-v-36e4a64d></span><span class="line" data-v-36e4a64d></span><span class="text" data-v-36e4a64d>${ssrInterpolate(w)}</span></div>`);
        });
        _push(`<!--]--></div><div class="paraphrase" style="${ssrRenderStyle("width:" + unref(word).length * 6.25 + "rem")}" data-v-36e4a64d>${ssrInterpolate(unref(meta))}</div></div></div></div><button type="button"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="flex my-4 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none" data-v-36e4a64d>${ssrInterpolate(unref(loading) ? "\u751F\u6210\u4E2D" : "\u5F00\u59CB\u751F\u6210")}</button><div class="my-4" data-v-36e4a64d><img${ssrRenderAttr("src", unref(img))} class="img mx-auto md:ml-0" data-v-36e4a64d></div></section><section class="bg-white w-full container mx-auto px-4 py-6" data-v-36e4a64d><article class="prose lg:prose-xl" style="${ssrRenderStyle({
          "max-width": "none"
        })}" data-v-36e4a64d><h4 data-v-36e4a64d>\u4F7F\u7528\u8BF4\u660E\uFF1A</h4><blockquote data-v-36e4a64d><p data-v-36e4a64d>\u672C\u5DE5\u5177\u7EAF\u5C5E\u5A31\u4E50\uFF0C\u5207\u52FF\u7528\u505A\u975E\u6CD5\u7528\u9014 </p></blockquote><ul data-v-36e4a64d><li data-v-36e4a64d>\u6076\u641E\u6210\u8BED\uFF0C\u4EC5\u7528\u4E8E\u5A31\u4E50\u4F7F\u7528\u3002</li><li data-v-36e4a64d>\u4FDD\u5B58\uFF1A\u751F\u6210\u56FE\u7247\u4E4B\u540E\u4F1A\u81EA\u52A8\u4E0B\u8F7D\u56FE\u7247\u3002</li><li data-v-36e4a64d>\u6CE8\u610F\uFF1A\u8F93\u5165\u6587\u5B57\u540E\u4F1A\u81EA\u52A8\u751F\u6210\u62FC\u97F3\uFF0C\u5982\u679C\u51FA\u73B0\u591A\u97F3\u5B57\u9519\u8BEF\u9700\u8981\u624B\u52A8\u8F93\u5165\u62FC\u97F3\u7684\u8BDD\uFF0C\u62FC\u97F3\u4E4B\u95F4\u8BF7\u7528\u7A7A\u683C\u5206\u5F00\u3002</li></ul></article></section></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/MakePhrase.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  MakePhrase = _export_sfc(_sfc_main, [
    [
      "__scopeId",
      "data-v-36e4a64d"
    ]
  ]);
});

export { __tla, MakePhrase as default };
//# sourceMappingURL=MakePhrase.7dc1cee2.mjs.map
