const _imports_1 = "" + globalThis.__publicAssetsURL("ad/NplayerAD.jpg");

export { _imports_1 as _ };
//# sourceMappingURL=NplayerAD.d981fd9c.mjs.map
