const index_vue_vue_type_style_index_0_lang = ".RightFixedContainer-absolute{position:absolute}.RightFixedContainer-fixed{position:fixed;top:.5rem}";

const indexStyles_db5db422 = [index_vue_vue_type_style_index_0_lang];

export { indexStyles_db5db422 as default };
//# sourceMappingURL=index-styles.db5db422.mjs.map
