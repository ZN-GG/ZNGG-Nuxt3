const Whois_vue_vue_type_style_index_0_scoped_9379fee7_lang = '.searchBtn[data-v-9379fee7]:before{border:6px solid transparent;border-right-color:#000;content:"";position:absolute;right:100%;top:38%}';

const WhoisStyles_f20b712d = [Whois_vue_vue_type_style_index_0_scoped_9379fee7_lang];

export { WhoisStyles_f20b712d as default };
//# sourceMappingURL=Whois-styles.f20b712d.mjs.map
