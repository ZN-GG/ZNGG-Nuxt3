const M3U8V2Pro_vue_vue_type_style_index_0_scoped_4c3f4b14_lang = ".item-box[data-v-4c3f4b14]{max-height:24rem;min-height:8rem}.item-box[data-v-4c3f4b14]::-webkit-scrollbar{height:10px;width:10px}.item-box[data-v-4c3f4b14]::-webkit-scrollbar-thumb{background-color:#49b1f5;background-image:-webkit-linear-gradient(45deg,hsla(0,0%,100%,.4) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.4) 0,hsla(0,0%,100%,.4) 75%,transparent 0,transparent);border-radius:32px}.item-box[data-v-4c3f4b14]::-webkit-scrollbar-track{background-color:#dbeffd;border-radius:32px}.btn-bg-save[data-v-4c3f4b14]{background-color:#49b1f5;background-image:-webkit-linear-gradient(45deg,hsla(0,0%,100%,.4) 25%,transparent 0,transparent 50%,hsla(0,0%,100%,.4) 0,hsla(0,0%,100%,.4) 75%,transparent 0,transparent)}";

const M3U8V2ProStyles_8c9b3f3c = [M3U8V2Pro_vue_vue_type_style_index_0_scoped_4c3f4b14_lang];

export { M3U8V2ProStyles_8c9b3f3c as default };
//# sourceMappingURL=M3U8V2Pro-styles.8c9b3f3c.mjs.map
