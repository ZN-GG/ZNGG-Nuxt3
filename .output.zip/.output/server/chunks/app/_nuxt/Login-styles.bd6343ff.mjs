const Login_vue_vue_type_style_index_0_scoped_7df540eb_lang = ".modal-show[data-v-7df540eb]{-webkit-backdrop-filter:saturate(180%) blur(25px);backdrop-filter:saturate(180%) blur(25px);background:rgba(0,0,0,.35)}";

const LoginStyles_bd6343ff = [Login_vue_vue_type_style_index_0_scoped_7df540eb_lang];

export { LoginStyles_bd6343ff as default };
//# sourceMappingURL=Login-styles.bd6343ff.mjs.map
