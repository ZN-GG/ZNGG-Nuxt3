import { __tla as __tla$1, a as useNuxtApp, u as useHead } from '../server.mjs';
import { defineComponent, withAsyncContext, ref, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  _sfc_main = defineComponent({
    __name: "ImageToBase64",
    __ssrInlineRender: true,
    async setup(__props) {
      let __temp, __restore;
      [__temp, __restore] = withAsyncContext(() => import('crypto-js').then(async (m) => {
        await m.__tla;
        return m;
      })), __temp = await __temp, __restore();
      useNuxtApp();
      const base64Data = ref("");
      useHead({
        title: "\u56FE\u7247\u8F6CBase64",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u5728\u7EBFBase64\u8F6C\u56FE\u7247,\u56FE\u7247\u8F6CBase64\u7F16\u7801,\u5728\u7EBF\u56FE\u7247\u8F6C\u6362"
          },
          {
            name: "description",
            content: "\u4E00\u4E2A\u53EF\u4EE5\u5C06\u56FE\u7247\u548CBase64\u7F16\u7801\u76F8\u4E92\u8F6C\u6362\u7684\u5DE5\u5177\uFF0C\u5728\u56FE\u7247\u683C\u5F0F\u8F6C\u6362\u65F6\u4F1A\u7528\u5230\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "bg-white min-h-screen"
        }, _attrs))}><section class="bg-gray-100"><div class="container px-4 mx-auto"><div class="md:flex md:-mx-4 md:items-center py-8"><div class="md:w-1/2 px-4"><h1 class="text-2xl text-black">\u56FE\u7247\u8F6Cbase64</h1></div></div></div></section><div class="container px-4 mx-auto py-6"><div class="form-group"><div class="text-center relative pt-6 pb-6 mb-4 border-2 hover:bg-gray-100 custom-font-14 rounded" id="fileInput"><span>\u62D6\u62FD\u6587\u4EF6\u5230\u8FD9\u91CC\u6216\u8005\u70B9\u51FB\u9009\u62E9\u6587\u4EF6</span><input type="file" id="file" accept="image/*" style="${ssrRenderStyle({
          "opacity": "0",
          "position": "absolute",
          "cursor": "pointer",
          "width": "100%",
          "height": "100%",
          "left": "0",
          "top": "0"
        })}"></div></div><div class="flex flex-wrap"><div class="w-full md:w-6/12 md:pr-2"><img${ssrRenderAttr("src", unref(base64Data).length == 0 ? "/logo-black.png" : unref(base64Data))} class="w-full h-72 object-contain border-2"></div><div class="w-full md:w-6/12 md:pl-2 mt-4 md:mt-0"><textarea class="w-full bg-gray-100 outline-none p-2 h-72 text-gray-700 custom-font-14" name="" id="" cols="30" rows="10">${ssrInterpolate(unref(base64Data))}</textarea></div></div><div class="flex flex-row flex-wrap justify-around"><button class="flex my-2 mr-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> Base64\u8F6C\u56FE\u7247 </button><div class="flex flex-row flex-wrap"><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u52A0\u5934 </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u6E05\u7A7A </button><button class="flex m-2 py-2 px-4 font-medium tracking-widest text-white uppercase bg-black shadow-lg focus:outline-none hover:bg-gray-900 hover:shadow-none"> \u590D\u5236 </button></div></div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/ImageToBase64.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=ImageToBase64.1234408b.mjs.map
