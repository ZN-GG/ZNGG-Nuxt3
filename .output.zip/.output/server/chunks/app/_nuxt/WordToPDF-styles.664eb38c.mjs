const WordToPDF_vue_vue_type_style_index_0_scoped_fa8f29b0_lang = ".convert-bg[data-v-fa8f29b0]{background:url(" + globalThis.__publicAssetsURL("img/office/office_banner.svg") + ") bottom no-repeat;height:130px}.convert-bg[data-v-fa8f29b0],.office-bg[data-v-fa8f29b0]{background-color:#f1f3fe}.in-upload-box[data-v-fa8f29b0]{left:50%;position:absolute;top:50%;transform:translate(-50%,-50%)}";

const WordToPDFStyles_664eb38c = [WordToPDF_vue_vue_type_style_index_0_scoped_fa8f29b0_lang];

export { WordToPDFStyles_664eb38c as default };
//# sourceMappingURL=WordToPDF-styles.664eb38c.mjs.map
