import { i as iconfont } from '../styles.mjs';

const app_vue_vue_type_script_setup_true_langStyles_f2003895 = [iconfont];

export { app_vue_vue_type_script_setup_true_langStyles_f2003895 as default };
//# sourceMappingURL=app.vue_vue_type_script_setup_true_lang-styles.f2003895.mjs.map
