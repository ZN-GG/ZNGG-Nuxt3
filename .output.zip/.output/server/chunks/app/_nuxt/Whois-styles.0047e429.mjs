const Whois_vue_vue_type_style_index_0_scoped_b7bd412c_lang = '.searchBtn[data-v-b7bd412c]:before{border:6px solid transparent;border-right-color:#000;content:"";position:absolute;right:100%;top:38%}';

const WhoisStyles_0047e429 = [Whois_vue_vue_type_style_index_0_scoped_b7bd412c_lang];

export { WhoisStyles_0047e429 as default };
//# sourceMappingURL=Whois-styles.0047e429.mjs.map
