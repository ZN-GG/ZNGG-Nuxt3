import { __tla as __tla$1, g as defineStore } from '../server.mjs';

let userStore;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  userStore = defineStore("user", {
    state() {
      return {
        showLogin: false,
        isLogin: false
      };
    }
  });
});

export { __tla as _, userStore as u };
//# sourceMappingURL=user.d2768ed9.mjs.map
