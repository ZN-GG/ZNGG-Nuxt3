import { getCurrentInstance, ref, inject, computed, defineComponent, provide, h, Suspense, Transition, reactive, mergeProps, withCtx, openBlock, createBlock, createCommentVNode, createVNode, toDisplayString, useSSRContext, defineAsyncComponent, isRef, resolveComponent, watchEffect, markRaw, shallowRef, createApp, toRef, effectScope, onErrorCaptured, unref, watch, isReactive, toRaw, onUnmounted, nextTick, toRefs } from 'vue';
import { $fetch } from 'ohmyfetch';
import { hasProtocol, parseURL, joinURL, isEqual as isEqual$1 } from 'ufo';
import { createHooks } from 'hookable';
import { getContext, executeAsync } from 'unctx';
import { RouterView, createMemoryHistory, createRouter } from 'vue-router';
import destr from 'destr';
import { sendRedirect, appendHeader, createError } from 'h3';
import defu, { defuFn } from 'defu';
import { isFunction } from '@vue/shared';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrRenderComponent, ssrInterpolate, ssrRenderSuspense } from 'vue/server-renderer';
import { parse, serialize } from 'cookie-es';
import { isEqual } from 'ohash';
import { a as useRuntimeConfig } from '../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'fs';
import 'pathe';
import 'url';

let __nuxt_component_0$2, useNuxtApp, useCookie, _export_sfc, useRoute, entry$1, useRequestHeaders, __nuxt_component_0$1, defineNuxtRouteMiddleware, userStore, navigateTo, useHead;
let __tla = (async () => {
  const appConfig = useRuntimeConfig().app;
  const baseURL = () => appConfig.baseURL;
  const buildAssetsDir = () => appConfig.buildAssetsDir;
  const buildAssetsURL = (...path) => joinURL(publicAssetsURL(), buildAssetsDir(), ...path);
  const publicAssetsURL = (...path) => {
    const publicBase = appConfig.cdnURL || appConfig.baseURL;
    return path.length ? joinURL(publicBase, ...path) : publicBase;
  };
  globalThis.__buildAssetsURL = buildAssetsURL;
  globalThis.__publicAssetsURL = publicAssetsURL;
  const nuxtAppCtx = getContext("nuxt-app");
  const NuxtPluginIndicator = "__nuxt_plugin";
  function createNuxtApp(options) {
    const nuxtApp = {
      provide: void 0,
      globalName: "nuxt",
      payload: reactive({
        data: {},
        state: {},
        _errors: {},
        ...{
          serverRendered: true
        }
      }),
      isHydrating: false,
      _asyncDataPromises: {},
      _asyncData: {},
      ...options
    };
    nuxtApp.hooks = createHooks();
    nuxtApp.hook = nuxtApp.hooks.hook;
    nuxtApp.callHook = nuxtApp.hooks.callHook;
    nuxtApp.provide = (name, value) => {
      const $name = "$" + name;
      defineGetter(nuxtApp, $name, value);
      defineGetter(nuxtApp.vueApp.config.globalProperties, $name, value);
    };
    defineGetter(nuxtApp.vueApp, "$nuxt", nuxtApp);
    defineGetter(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
    {
      if (nuxtApp.ssrContext) {
        nuxtApp.ssrContext.nuxt = nuxtApp;
      }
      nuxtApp.ssrContext = nuxtApp.ssrContext || {};
      if (nuxtApp.ssrContext.payload) {
        Object.assign(nuxtApp.payload, nuxtApp.ssrContext.payload);
      }
      nuxtApp.ssrContext.payload = nuxtApp.payload;
      nuxtApp.payload.config = {
        public: options.ssrContext.runtimeConfig.public,
        app: options.ssrContext.runtimeConfig.app
      };
    }
    const runtimeConfig = options.ssrContext.runtimeConfig;
    const compatibilityConfig = new Proxy(runtimeConfig, {
      get(target, prop) {
        var _a;
        if (prop === "public") {
          return target.public;
        }
        return (_a = target[prop]) != null ? _a : target.public[prop];
      },
      set(target, prop, value) {
        {
          return false;
        }
      }
    });
    nuxtApp.provide("config", compatibilityConfig);
    return nuxtApp;
  }
  async function applyPlugin(nuxtApp, plugin) {
    if (typeof plugin !== "function") {
      return;
    }
    const { provide: provide2 } = await callWithNuxt(nuxtApp, plugin, [
      nuxtApp
    ]) || {};
    if (provide2 && typeof provide2 === "object") {
      for (const key in provide2) {
        nuxtApp.provide(key, provide2[key]);
      }
    }
  }
  async function applyPlugins(nuxtApp, plugins2) {
    for (const plugin of plugins2) {
      await applyPlugin(nuxtApp, plugin);
    }
  }
  function normalizePlugins(_plugins2) {
    const plugins2 = _plugins2.map((plugin) => {
      if (typeof plugin !== "function") {
        return null;
      }
      if (plugin.length > 1) {
        return (nuxtApp) => plugin(nuxtApp, nuxtApp.provide);
      }
      return plugin;
    }).filter(Boolean);
    return plugins2;
  }
  function defineNuxtPlugin(plugin) {
    plugin[NuxtPluginIndicator] = true;
    return plugin;
  }
  function callWithNuxt(nuxt, setup, args) {
    const fn = () => args ? setup(...args) : setup();
    {
      return nuxtAppCtx.callAsync(nuxt, fn);
    }
  }
  useNuxtApp = function useNuxtApp2() {
    const nuxtAppInstance = nuxtAppCtx.tryUse();
    if (!nuxtAppInstance) {
      const vm = getCurrentInstance();
      if (!vm) {
        throw new Error("nuxt instance unavailable");
      }
      return vm.appContext.app.$nuxt;
    }
    return nuxtAppInstance;
  };
  function useRuntimeConfig$1() {
    return useNuxtApp().$config;
  }
  function defineGetter(obj, key, val) {
    Object.defineProperty(obj, key, {
      get: () => val
    });
  }
  function useState(...args) {
    const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
    if (typeof args[0] !== "string") {
      args.unshift(autoKey);
    }
    const [_key, init] = args;
    if (!_key || typeof _key !== "string") {
      throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
    }
    if (init !== void 0 && typeof init !== "function") {
      throw new Error("[nuxt] [useState] init must be a function: " + init);
    }
    const key = "$s" + _key;
    const nuxt = useNuxtApp();
    const state = toRef(nuxt.payload.state, key);
    if (state.value === void 0 && init) {
      const initialValue = init();
      if (isRef(initialValue)) {
        nuxt.payload.state[key] = initialValue;
        return initialValue;
      }
      state.value = initialValue;
    }
    return state;
  }
  const useError = () => toRef(useNuxtApp().payload, "error");
  const showError = (_err) => {
    const err = createError$1(_err);
    try {
      const nuxtApp = useNuxtApp();
      nuxtApp.callHook("app:error", err);
      const error = useError();
      error.value = error.value || err;
    } catch {
      throw err;
    }
    return err;
  };
  const createError$1 = (err) => {
    const _err = createError(err);
    _err.__nuxt_error = true;
    return _err;
  };
  useRequestHeaders = function useRequestHeaders2(include) {
    var _a, _b;
    const headers = (_b = (_a = useNuxtApp().ssrContext) == null ? void 0 : _a.event.req.headers) != null ? _b : {};
    if (!include) {
      return headers;
    }
    return Object.fromEntries(include.filter((key) => headers[key]).map((key) => [
      key,
      headers[key]
    ]));
  };
  function useRequestEvent(nuxtApp = useNuxtApp()) {
    var _a;
    return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
  }
  const CookieDefaults = {
    path: "/",
    decode: (val) => destr(decodeURIComponent(val)),
    encode: (val) => encodeURIComponent(typeof val === "string" ? val : JSON.stringify(val))
  };
  useCookie = function useCookie2(name, _opts) {
    var _a, _b;
    const opts = {
      ...CookieDefaults,
      ..._opts
    };
    const cookies = readRawCookies(opts) || {};
    const cookie = ref((_b = cookies[name]) != null ? _b : (_a = opts.default) == null ? void 0 : _a.call(opts));
    {
      const nuxtApp = useNuxtApp();
      const writeFinalCookieValue = () => {
        if (!isEqual(cookie.value, cookies[name])) {
          writeServerCookie(useRequestEvent(nuxtApp), name, cookie.value, opts);
        }
      };
      const unhook = nuxtApp.hooks.hookOnce("app:rendered", writeFinalCookieValue);
      nuxtApp.hooks.hookOnce("app:redirected", () => {
        unhook();
        return writeFinalCookieValue();
      });
    }
    return cookie;
  };
  function readRawCookies(opts = {}) {
    var _a;
    {
      return parse(((_a = useRequestEvent()) == null ? void 0 : _a.req.headers.cookie) || "", opts);
    }
  }
  function serializeCookie(name, value, opts = {}) {
    if (value === null || value === void 0) {
      return serialize(name, value, {
        ...opts,
        maxAge: -1
      });
    }
    return serialize(name, value, opts);
  }
  function writeServerCookie(event, name, value, opts = {}) {
    if (event) {
      appendHeader(event, "Set-Cookie", serializeCookie(name, value, opts));
    }
  }
  const useRouter = () => {
    var _a;
    return (_a = useNuxtApp()) == null ? void 0 : _a.$router;
  };
  useRoute = () => {
    if (getCurrentInstance()) {
      return inject("_route", useNuxtApp()._route);
    }
    return useNuxtApp()._route;
  };
  defineNuxtRouteMiddleware = (middleware) => middleware;
  navigateTo = (to, options) => {
    if (!to) {
      to = "/";
    }
    const toPath = typeof to === "string" ? to : to.path || "/";
    const isExternal = hasProtocol(toPath, true);
    if (isExternal && !(options == null ? void 0 : options.external)) {
      throw new Error("Navigating to external URL is not allowed by default. Use `nagivateTo (url, { external: true })`.");
    }
    if (isExternal && parseURL(toPath).protocol === "script:") {
      throw new Error("Cannot navigate to an URL with script protocol.");
    }
    const router = useRouter();
    {
      const nuxtApp = useNuxtApp();
      if (nuxtApp.ssrContext && nuxtApp.ssrContext.event) {
        const redirectLocation = isExternal ? toPath : joinURL(useRuntimeConfig$1().app.baseURL, router.resolve(to).fullPath || "/");
        return nuxtApp.callHook("app:redirected").then(() => sendRedirect(nuxtApp.ssrContext.event, redirectLocation, (options == null ? void 0 : options.redirectCode) || 302));
      }
    }
    if (isExternal) {
      if (options == null ? void 0 : options.replace) {
        location.replace(toPath);
      } else {
        location.href = toPath;
      }
      return Promise.resolve();
    }
    return (options == null ? void 0 : options.replace) ? router.replace(to) : router.push(to);
  };
  const firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
  const DEFAULT_EXTERNAL_REL_ATTRIBUTE = "noopener noreferrer";
  function defineNuxtLink(options) {
    const componentName = options.componentName || "NuxtLink";
    return defineComponent({
      name: componentName,
      props: {
        to: {
          type: [
            String,
            Object
          ],
          default: void 0,
          required: false
        },
        href: {
          type: [
            String,
            Object
          ],
          default: void 0,
          required: false
        },
        target: {
          type: String,
          default: void 0,
          required: false
        },
        rel: {
          type: String,
          default: void 0,
          required: false
        },
        noRel: {
          type: Boolean,
          default: void 0,
          required: false
        },
        prefetch: {
          type: Boolean,
          default: void 0,
          required: false
        },
        noPrefetch: {
          type: Boolean,
          default: void 0,
          required: false
        },
        activeClass: {
          type: String,
          default: void 0,
          required: false
        },
        exactActiveClass: {
          type: String,
          default: void 0,
          required: false
        },
        prefetchedClass: {
          type: String,
          default: void 0,
          required: false
        },
        replace: {
          type: Boolean,
          default: void 0,
          required: false
        },
        ariaCurrentValue: {
          type: String,
          default: void 0,
          required: false
        },
        external: {
          type: Boolean,
          default: void 0,
          required: false
        },
        custom: {
          type: Boolean,
          default: void 0,
          required: false
        }
      },
      setup(props, { slots }) {
        const router = useRouter();
        const to = computed(() => {
          return props.to || props.href || "";
        });
        const isExternal = computed(() => {
          if (props.external) {
            return true;
          }
          if (props.target && props.target !== "_self") {
            return true;
          }
          if (typeof to.value === "object") {
            return false;
          }
          return to.value === "" || hasProtocol(to.value, true);
        });
        const prefetched = ref(false);
        return () => {
          var _a, _b, _c;
          if (!isExternal.value) {
            return h(resolveComponent("RouterLink"), {
              ref: void 0,
              to: to.value,
              ...prefetched.value && !props.custom ? {
                class: props.prefetchedClass || options.prefetchedClass
              } : {},
              activeClass: props.activeClass || options.activeClass,
              exactActiveClass: props.exactActiveClass || options.exactActiveClass,
              replace: props.replace,
              ariaCurrentValue: props.ariaCurrentValue,
              custom: props.custom
            }, slots.default);
          }
          const href = typeof to.value === "object" ? (_b = (_a = router.resolve(to.value)) == null ? void 0 : _a.href) != null ? _b : null : to.value || null;
          const target = props.target || null;
          const rel = props.noRel ? null : firstNonUndefined(props.rel, options.externalRelAttribute, href ? DEFAULT_EXTERNAL_REL_ATTRIBUTE : "") || null;
          const navigate = () => navigateTo(href, {
            replace: props.replace
          });
          if (props.custom) {
            if (!slots.default) {
              return null;
            }
            return slots.default({
              href,
              navigate,
              route: router.resolve(href),
              rel,
              target,
              isActive: false,
              isExactActive: false
            });
          }
          return h("a", {
            href,
            rel,
            target
          }, (_c = slots.default) == null ? void 0 : _c.call(slots));
        };
      }
    });
  }
  __nuxt_component_0$2 = defineNuxtLink({
    componentName: "NuxtLink"
  });
  const inlineConfig = {};
  defuFn(inlineConfig);
  useHead = function useHead2(meta2) {
    const resolvedMeta = isFunction(meta2) ? computed(meta2) : meta2;
    useNuxtApp()._useHead(resolvedMeta);
  };
  const components = {};
  const _nuxt_components_plugin_mjs_KR1HBZs4kY = defineNuxtPlugin((nuxtApp) => {
    for (const name in components) {
      nuxtApp.vueApp.component(name, components[name]);
      nuxtApp.vueApp.component("Lazy" + name, components[name]);
    }
  });
  var PROVIDE_KEY = `usehead`;
  var HEAD_COUNT_KEY = `head:count`;
  var HEAD_ATTRS_KEY = `data-head-attrs`;
  var SELF_CLOSING_TAGS = [
    "meta",
    "link",
    "base"
  ];
  var BODY_TAG_ATTR_NAME = `data-meta-body`;
  var createElement = (tag, attrs, document2) => {
    const el = document2.createElement(tag);
    for (const key of Object.keys(attrs)) {
      if (key === "body" && attrs.body === true) {
        el.setAttribute(BODY_TAG_ATTR_NAME, "true");
      } else {
        let value = attrs[key];
        if (key === "renderPriority" || key === "key" || value === false) {
          continue;
        }
        if (key === "children") {
          el.textContent = value;
        } else {
          el.setAttribute(key, value);
        }
      }
    }
    return el;
  };
  var stringifyAttrName = (str) => str.replace(/[\s"'><\/=]/g, "").replace(/[^a-zA-Z0-9_-]/g, "");
  var stringifyAttrValue = (str) => str.replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  var stringifyAttrs = (attributes) => {
    const handledAttributes = [];
    for (let [key, value] of Object.entries(attributes)) {
      if (key === "children" || key === "key") {
        continue;
      }
      if (value === false || value == null) {
        continue;
      }
      let attribute = stringifyAttrName(key);
      if (value !== true) {
        attribute += `="${stringifyAttrValue(String(value))}"`;
      }
      handledAttributes.push(attribute);
    }
    return handledAttributes.length > 0 ? " " + handledAttributes.join(" ") : "";
  };
  function isEqualNode(oldTag, newTag) {
    if (oldTag instanceof HTMLElement && newTag instanceof HTMLElement) {
      const nonce = newTag.getAttribute("nonce");
      if (nonce && !oldTag.getAttribute("nonce")) {
        const cloneTag = newTag.cloneNode(true);
        cloneTag.setAttribute("nonce", "");
        cloneTag.nonce = nonce;
        return nonce === oldTag.nonce && oldTag.isEqualNode(cloneTag);
      }
    }
    return oldTag.isEqualNode(newTag);
  }
  var tagDedupeKey = (tag) => {
    if (![
      "meta",
      "base",
      "script",
      "link"
    ].includes(tag.tag)) {
      return false;
    }
    const { props, tag: tagName } = tag;
    if (tagName === "base") {
      return "base";
    }
    if (tagName === "link" && props.rel === "canonical") {
      return "canonical";
    }
    if (props.charset) {
      return "charset";
    }
    const name = [
      "key",
      "id",
      "name",
      "property",
      "http-equiv"
    ];
    for (const n of name) {
      let value = void 0;
      if (typeof props.getAttribute === "function" && props.hasAttribute(n)) {
        value = props.getAttribute(n);
      } else {
        value = props[n];
      }
      if (value !== void 0) {
        return `${tagName}-${n}-${value}`;
      }
    }
    return false;
  };
  var acceptFields = [
    "title",
    "meta",
    "link",
    "base",
    "style",
    "script",
    "noscript",
    "htmlAttrs",
    "bodyAttrs"
  ];
  var renderTemplate = (template, title) => {
    if (template == null)
      return "";
    if (typeof template === "string") {
      return template.replace("%s", title != null ? title : "");
    }
    return template(unref(title));
  };
  var headObjToTags = (obj) => {
    const tags = [];
    const keys = Object.keys(obj);
    for (const key of keys) {
      if (obj[key] == null)
        continue;
      switch (key) {
        case "title":
          tags.push({
            tag: key,
            props: {
              children: obj[key]
            }
          });
          break;
        case "titleTemplate":
          break;
        case "base":
          tags.push({
            tag: key,
            props: {
              key: "default",
              ...obj[key]
            }
          });
          break;
        default:
          if (acceptFields.includes(key)) {
            const value = obj[key];
            if (Array.isArray(value)) {
              value.forEach((item) => {
                tags.push({
                  tag: key,
                  props: unref(item)
                });
              });
            } else if (value) {
              tags.push({
                tag: key,
                props: value
              });
            }
          }
          break;
      }
    }
    return tags;
  };
  var setAttrs = (el, attrs) => {
    const existingAttrs = el.getAttribute(HEAD_ATTRS_KEY);
    if (existingAttrs) {
      for (const key of existingAttrs.split(",")) {
        if (!(key in attrs)) {
          el.removeAttribute(key);
        }
      }
    }
    const keys = [];
    for (const key in attrs) {
      const value = attrs[key];
      if (value == null)
        continue;
      if (value === false) {
        el.removeAttribute(key);
      } else {
        el.setAttribute(key, value);
      }
      keys.push(key);
    }
    if (keys.length) {
      el.setAttribute(HEAD_ATTRS_KEY, keys.join(","));
    } else {
      el.removeAttribute(HEAD_ATTRS_KEY);
    }
  };
  var updateElements = (document2 = window.document, type, tags) => {
    var _a, _b;
    const head = document2.head;
    const body = document2.body;
    let headCountEl = head.querySelector(`meta[name="${HEAD_COUNT_KEY}"]`);
    let bodyMetaElements = body.querySelectorAll(`[${BODY_TAG_ATTR_NAME}]`);
    const headCount = headCountEl ? Number(headCountEl.getAttribute("content")) : 0;
    const oldHeadElements = [];
    const oldBodyElements = [];
    if (bodyMetaElements) {
      for (let i = 0; i < bodyMetaElements.length; i++) {
        if (bodyMetaElements[i] && ((_a = bodyMetaElements[i].tagName) == null ? void 0 : _a.toLowerCase()) === type) {
          oldBodyElements.push(bodyMetaElements[i]);
        }
      }
    }
    if (headCountEl) {
      for (let i = 0, j = headCountEl.previousElementSibling; i < headCount; i++, j = (j == null ? void 0 : j.previousElementSibling) || null) {
        if (((_b = j == null ? void 0 : j.tagName) == null ? void 0 : _b.toLowerCase()) === type) {
          oldHeadElements.push(j);
        }
      }
    } else {
      headCountEl = document2.createElement("meta");
      headCountEl.setAttribute("name", HEAD_COUNT_KEY);
      headCountEl.setAttribute("content", "0");
      head.append(headCountEl);
    }
    let newElements = tags.map((tag) => {
      var _a2;
      return {
        element: createElement(tag.tag, tag.props, document2),
        body: (_a2 = tag.props.body) != null ? _a2 : false
      };
    });
    newElements = newElements.filter((newEl) => {
      for (let i = 0; i < oldHeadElements.length; i++) {
        const oldEl = oldHeadElements[i];
        if (isEqualNode(oldEl, newEl.element)) {
          oldHeadElements.splice(i, 1);
          return false;
        }
      }
      for (let i = 0; i < oldBodyElements.length; i++) {
        const oldEl = oldBodyElements[i];
        if (isEqualNode(oldEl, newEl.element)) {
          oldBodyElements.splice(i, 1);
          return false;
        }
      }
      return true;
    });
    oldBodyElements.forEach((t) => {
      var _a2;
      return (_a2 = t.parentNode) == null ? void 0 : _a2.removeChild(t);
    });
    oldHeadElements.forEach((t) => {
      var _a2;
      return (_a2 = t.parentNode) == null ? void 0 : _a2.removeChild(t);
    });
    newElements.forEach((t) => {
      if (t.body === true) {
        body.insertAdjacentElement("beforeend", t.element);
      } else {
        head.insertBefore(t.element, headCountEl);
      }
    });
    headCountEl.setAttribute("content", "" + (headCount - oldHeadElements.length + newElements.filter((t) => !t.body).length));
  };
  var createHead = (initHeadObject) => {
    let allHeadObjs = [];
    let previousTags = /* @__PURE__ */ new Set();
    if (initHeadObject) {
      allHeadObjs.push(shallowRef(initHeadObject));
    }
    const head = {
      install(app) {
        app.config.globalProperties.$head = head;
        app.provide(PROVIDE_KEY, head);
      },
      get headTags() {
        const deduped = [];
        const deduping = {};
        const titleTemplate = allHeadObjs.map((i) => unref(i).titleTemplate).reverse().find((i) => i != null);
        allHeadObjs.forEach((objs, headObjectIdx) => {
          const tags = headObjToTags(unref(objs));
          tags.forEach((tag, tagIdx) => {
            tag._position = headObjectIdx * 1e4 + tagIdx;
            if (titleTemplate && tag.tag === "title") {
              tag.props.children = renderTemplate(titleTemplate, tag.props.children);
            }
            const dedupeKey = tagDedupeKey(tag);
            if (dedupeKey) {
              deduping[dedupeKey] = tag;
            } else {
              deduped.push(tag);
            }
          });
        });
        deduped.push(...Object.values(deduping));
        return deduped.sort((a, b) => a._position - b._position);
      },
      addHeadObjs(objs) {
        allHeadObjs.push(objs);
      },
      removeHeadObjs(objs) {
        allHeadObjs = allHeadObjs.filter((_objs) => _objs !== objs);
      },
      updateDOM(document2 = window.document) {
        let title;
        let htmlAttrs = {};
        let bodyAttrs = {};
        const actualTags = {};
        for (const tag of head.headTags.sort(sortTags)) {
          if (tag.tag === "title") {
            title = tag.props.children;
            continue;
          }
          if (tag.tag === "htmlAttrs") {
            Object.assign(htmlAttrs, tag.props);
            continue;
          }
          if (tag.tag === "bodyAttrs") {
            Object.assign(bodyAttrs, tag.props);
            continue;
          }
          actualTags[tag.tag] = actualTags[tag.tag] || [];
          actualTags[tag.tag].push(tag);
        }
        if (title !== void 0) {
          document2.title = title;
        }
        setAttrs(document2.documentElement, htmlAttrs);
        setAttrs(document2.body, bodyAttrs);
        const tags = /* @__PURE__ */ new Set([
          ...Object.keys(actualTags),
          ...previousTags
        ]);
        for (const tag of tags) {
          updateElements(document2, tag, actualTags[tag] || []);
        }
        previousTags.clear();
        Object.keys(actualTags).forEach((i) => previousTags.add(i));
      }
    };
    return head;
  };
  var tagToString = (tag) => {
    let isBodyTag = false;
    if (tag.props.body) {
      isBodyTag = true;
      delete tag.props.body;
    }
    if (tag.props.renderPriority) {
      delete tag.props.renderPriority;
    }
    let attrs = stringifyAttrs(tag.props);
    if (SELF_CLOSING_TAGS.includes(tag.tag)) {
      return `<${tag.tag}${attrs}${isBodyTag ? `  ${BODY_TAG_ATTR_NAME}="true"` : ""}>`;
    }
    return `<${tag.tag}${attrs}${isBodyTag ? ` ${BODY_TAG_ATTR_NAME}="true"` : ""}>${tag.props.children || ""}</${tag.tag}>`;
  };
  var sortTags = (aTag, bTag) => {
    const tagWeight = (tag) => {
      if (tag.props.renderPriority) {
        return tag.props.renderPriority;
      }
      switch (tag.tag) {
        case "base":
          return -1;
        case "meta":
          if (tag.props.charset) {
            return -2;
          }
          if (tag.props["http-equiv"] === "content-security-policy") {
            return 0;
          }
          return 10;
        default:
          return 10;
      }
    };
    return tagWeight(aTag) - tagWeight(bTag);
  };
  var renderHeadToString = (head) => {
    const tags = [];
    let titleTag = "";
    let htmlAttrs = {};
    let bodyAttrs = {};
    let bodyTags = [];
    for (const tag of head.headTags.sort(sortTags)) {
      if (tag.tag === "title") {
        titleTag = tagToString(tag);
      } else if (tag.tag === "htmlAttrs") {
        Object.assign(htmlAttrs, tag.props);
      } else if (tag.tag === "bodyAttrs") {
        Object.assign(bodyAttrs, tag.props);
      } else if (tag.props.body) {
        bodyTags.push(tagToString(tag));
      } else {
        tags.push(tagToString(tag));
      }
    }
    tags.push(`<meta name="${HEAD_COUNT_KEY}" content="${tags.length}">`);
    return {
      get headTags() {
        return titleTag + tags.join("");
      },
      get htmlAttrs() {
        return stringifyAttrs({
          ...htmlAttrs,
          [HEAD_ATTRS_KEY]: Object.keys(htmlAttrs).join(",")
        });
      },
      get bodyAttrs() {
        return stringifyAttrs({
          ...bodyAttrs,
          [HEAD_ATTRS_KEY]: Object.keys(bodyAttrs).join(",")
        });
      },
      get bodyTags() {
        return bodyTags.join("");
      }
    };
  };
  const node_modules_nuxt_dist_head_runtime_lib_vueuse_head_plugin_mjs_D7WGfuP1A0 = defineNuxtPlugin((nuxtApp) => {
    const head = createHead();
    nuxtApp.vueApp.use(head);
    nuxtApp.hooks.hookOnce("app:mounted", () => {
      watchEffect(() => {
        head.updateDOM();
      });
    });
    nuxtApp._useHead = (_meta) => {
      const meta2 = ref(_meta);
      const headObj = computed(() => {
        const overrides = {
          meta: []
        };
        if (meta2.value.charset) {
          overrides.meta.push({
            key: "charset",
            charset: meta2.value.charset
          });
        }
        if (meta2.value.viewport) {
          overrides.meta.push({
            name: "viewport",
            content: meta2.value.viewport
          });
        }
        return defu(overrides, meta2.value);
      });
      head.addHeadObjs(headObj);
      {
        return;
      }
    };
    {
      nuxtApp.ssrContext.renderMeta = () => {
        const meta2 = renderHeadToString(head);
        return {
          ...meta2,
          bodyScripts: meta2.bodyTags
        };
      };
    }
  });
  const removeUndefinedProps = (props) => Object.fromEntries(Object.entries(props).filter(([, value]) => value !== void 0));
  const setupForUseMeta = (metaFactory, renderChild) => (props, ctx) => {
    useHead(() => metaFactory({
      ...removeUndefinedProps(props),
      ...ctx.attrs
    }, ctx));
    return () => {
      var _a, _b;
      return renderChild ? (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a) : null;
    };
  };
  const globalProps = {
    accesskey: String,
    autocapitalize: String,
    autofocus: {
      type: Boolean,
      default: void 0
    },
    class: String,
    contenteditable: {
      type: Boolean,
      default: void 0
    },
    contextmenu: String,
    dir: String,
    draggable: {
      type: Boolean,
      default: void 0
    },
    enterkeyhint: String,
    exportparts: String,
    hidden: {
      type: Boolean,
      default: void 0
    },
    id: String,
    inputmode: String,
    is: String,
    itemid: String,
    itemprop: String,
    itemref: String,
    itemscope: String,
    itemtype: String,
    lang: String,
    nonce: String,
    part: String,
    slot: String,
    spellcheck: {
      type: Boolean,
      default: void 0
    },
    style: String,
    tabindex: String,
    title: String,
    translate: String
  };
  const Script = defineComponent({
    name: "Script",
    inheritAttrs: false,
    props: {
      ...globalProps,
      async: Boolean,
      crossorigin: {
        type: [
          Boolean,
          String
        ],
        default: void 0
      },
      defer: Boolean,
      fetchpriority: String,
      integrity: String,
      nomodule: Boolean,
      nonce: String,
      referrerpolicy: String,
      src: String,
      type: String,
      charset: String,
      language: String
    },
    setup: setupForUseMeta((script) => ({
      script: [
        script
      ]
    }))
  });
  const NoScript = defineComponent({
    name: "NoScript",
    inheritAttrs: false,
    props: {
      ...globalProps,
      title: String
    },
    setup: setupForUseMeta((props, { slots }) => {
      var _a;
      const noscript = {
        ...props
      };
      const textContent = (((_a = slots.default) == null ? void 0 : _a.call(slots)) || []).filter(({ children }) => children).map(({ children }) => children).join("");
      if (textContent) {
        noscript.children = textContent;
      }
      return {
        noscript: [
          noscript
        ]
      };
    })
  });
  const Link = defineComponent({
    name: "Link",
    inheritAttrs: false,
    props: {
      ...globalProps,
      as: String,
      crossorigin: String,
      disabled: Boolean,
      fetchpriority: String,
      href: String,
      hreflang: String,
      imagesizes: String,
      imagesrcset: String,
      integrity: String,
      media: String,
      prefetch: {
        type: Boolean,
        default: void 0
      },
      referrerpolicy: String,
      rel: String,
      sizes: String,
      title: String,
      type: String,
      methods: String,
      target: String
    },
    setup: setupForUseMeta((link) => ({
      link: [
        link
      ]
    }))
  });
  const Base = defineComponent({
    name: "Base",
    inheritAttrs: false,
    props: {
      ...globalProps,
      href: String,
      target: String
    },
    setup: setupForUseMeta((base) => ({
      base
    }))
  });
  const Title = defineComponent({
    name: "Title",
    inheritAttrs: false,
    setup: setupForUseMeta((_, { slots }) => {
      var _a, _b, _c;
      const title = ((_c = (_b = (_a = slots.default) == null ? void 0 : _a.call(slots)) == null ? void 0 : _b[0]) == null ? void 0 : _c.children) || null;
      return {
        title
      };
    })
  });
  const Meta = defineComponent({
    name: "Meta",
    inheritAttrs: false,
    props: {
      ...globalProps,
      charset: String,
      content: String,
      httpEquiv: String,
      name: String
    },
    setup: setupForUseMeta((props) => {
      const meta2 = {
        ...props
      };
      if (meta2.httpEquiv) {
        meta2["http-equiv"] = meta2.httpEquiv;
        delete meta2.httpEquiv;
      }
      return {
        meta: [
          meta2
        ]
      };
    })
  });
  const Style = defineComponent({
    name: "Style",
    inheritAttrs: false,
    props: {
      ...globalProps,
      type: String,
      media: String,
      nonce: String,
      title: String,
      scoped: {
        type: Boolean,
        default: void 0
      }
    },
    setup: setupForUseMeta((props, { slots }) => {
      var _a, _b, _c;
      const style = {
        ...props
      };
      const textContent = (_c = (_b = (_a = slots.default) == null ? void 0 : _a.call(slots)) == null ? void 0 : _b[0]) == null ? void 0 : _c.children;
      if (textContent) {
        style.children = textContent;
      }
      return {
        style: [
          style
        ]
      };
    })
  });
  const Head = defineComponent({
    name: "Head",
    inheritAttrs: false,
    setup: (_props, ctx) => () => {
      var _a, _b;
      return (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a);
    }
  });
  const Html = defineComponent({
    name: "Html",
    inheritAttrs: false,
    props: {
      ...globalProps,
      manifest: String,
      version: String,
      xmlns: String
    },
    setup: setupForUseMeta((htmlAttrs) => ({
      htmlAttrs
    }), true)
  });
  const Body = defineComponent({
    name: "Body",
    inheritAttrs: false,
    props: globalProps,
    setup: setupForUseMeta((bodyAttrs) => ({
      bodyAttrs
    }), true)
  });
  const Components = Object.freeze(Object.defineProperty({
    __proto__: null,
    Script,
    NoScript,
    Link,
    Base,
    Title,
    Meta,
    Style,
    Head,
    Html,
    Body
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  const appHead = {
    "meta": [],
    "link": [],
    "style": [],
    "script": [],
    "noscript": [],
    "charset": "utf-8",
    "viewport": "width=device-width, initial-scale=1"
  };
  const appLayoutTransition = {
    "name": "layout",
    "mode": "out-in"
  };
  const appPageTransition = {
    "name": "page",
    "mode": "out-in"
  };
  const appKeepalive = false;
  const metaMixin = {
    created() {
      const instance = getCurrentInstance();
      if (!instance) {
        return;
      }
      const options = instance.type;
      if (!options || !("head" in options)) {
        return;
      }
      const nuxtApp = useNuxtApp();
      const source = typeof options.head === "function" ? computed(() => options.head(nuxtApp)) : options.head;
      useHead(source);
    }
  };
  const node_modules_nuxt_dist_head_runtime_plugin_mjs_1QO0gqa6n2 = defineNuxtPlugin((nuxtApp) => {
    useHead(markRaw({
      title: "",
      ...appHead
    }));
    nuxtApp.vueApp.mixin(metaMixin);
    for (const name in Components) {
      nuxtApp.vueApp.component(name, Components[name]);
    }
  });
  const interpolatePath = (route, match) => {
    return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
      var _a;
      return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
    });
  };
  const generateRouteKey = (override, routeProps) => {
    var _a;
    const matchedRoute = routeProps.route.matched.find((m) => {
      var _a2;
      return ((_a2 = m.components) == null ? void 0 : _a2.default) === routeProps.Component.type;
    });
    const source = (_a = override != null ? override : matchedRoute == null ? void 0 : matchedRoute.meta.key) != null ? _a : matchedRoute && interpolatePath(routeProps.route, matchedRoute);
    return typeof source === "function" ? source(routeProps.route) : source;
  };
  const wrapInKeepAlive = (props, children) => {
    return {
      default: () => children
    };
  };
  const Fragment = defineComponent({
    setup(_props, { slots }) {
      return () => {
        var _a;
        return (_a = slots.default) == null ? void 0 : _a.call(slots);
      };
    }
  });
  const _wrapIf = (component, props, slots) => {
    return {
      default: () => props ? h(component, props === true ? {} : props, slots) : h(Fragment, {}, slots)
    };
  };
  const isNestedKey = Symbol("isNested");
  const NuxtPage = defineComponent({
    name: "NuxtPage",
    inheritAttrs: false,
    props: {
      name: {
        type: String
      },
      transition: {
        type: [
          Boolean,
          Object
        ],
        default: void 0
      },
      keepalive: {
        type: [
          Boolean,
          Object
        ],
        default: void 0
      },
      route: {
        type: Object
      },
      pageKey: {
        type: [
          Function,
          String
        ],
        default: null
      }
    },
    setup(props, { attrs }) {
      const nuxtApp = useNuxtApp();
      const isNested = inject(isNestedKey, false);
      provide(isNestedKey, true);
      return () => {
        return h(RouterView, {
          name: props.name,
          route: props.route,
          ...attrs
        }, {
          default: (routeProps) => {
            var _a, _b, _c, _d;
            if (!routeProps.Component) {
              return;
            }
            const key = generateRouteKey(props.pageKey, routeProps);
            const transitionProps = (_b = (_a = props.transition) != null ? _a : routeProps.route.meta.pageTransition) != null ? _b : appPageTransition;
            return _wrapIf(Transition, transitionProps, wrapInKeepAlive((_d = (_c = props.keepalive) != null ? _c : routeProps.route.meta.keepalive) != null ? _d : appKeepalive, isNested && nuxtApp.isHydrating ? h(Component, {
              key,
              routeProps,
              pageKey: key,
              hasTransition: !!transitionProps
            }) : h(Suspense, {
              onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
              onResolve: () => nuxtApp.callHook("page:finish", routeProps.Component)
            }, {
              default: () => h(Component, {
                key,
                routeProps,
                pageKey: key,
                hasTransition: !!transitionProps
              })
            }))).default();
          }
        });
      };
    }
  });
  const Component = defineComponent({
    props: [
      "routeProps",
      "pageKey",
      "hasTransition"
    ],
    setup(props) {
      const previousKey = props.pageKey;
      const previousRoute = props.routeProps.route;
      const route = {};
      for (const key in props.routeProps.route) {
        route[key] = computed(() => previousKey === props.pageKey ? props.routeProps.route[key] : previousRoute[key]);
      }
      provide("_route", reactive(route));
      return () => {
        return h(props.routeProps.Component);
      };
    }
  });
  const meta$x = {
    title: "Some Page"
  };
  _export_sfc = (sfc, props) => {
    const target = sfc.__vccOpts || sfc;
    for (const [key, val] of props) {
      target[key] = val;
    }
    return target;
  };
  const meta$w = void 0;
  const meta$v = void 0;
  const meta$u = void 0;
  const meta$t = void 0;
  const meta$s = void 0;
  const meta$r = void 0;
  const meta$q = void 0;
  const meta$p = void 0;
  const meta$o = void 0;
  const meta$n = void 0;
  const meta$m = void 0;
  const meta$l = void 0;
  const meta$k = void 0;
  const meta$j = void 0;
  const meta$i = void 0;
  const meta$h = void 0;
  const meta$g = void 0;
  const meta$f = void 0;
  const cachedTextDecoder = new TextDecoder("utf-8", {
    ignoreBOM: true,
    fatal: true
  });
  cachedTextDecoder.decode();
  const meta$e = {
    layout: "empty"
  };
  const meta$d = void 0;
  const meta$c = void 0;
  const meta$b = void 0;
  const meta$a = void 0;
  const meta$9 = {
    layout: "empty"
  };
  const meta$8 = void 0;
  const meta$7 = void 0;
  const meta$6 = void 0;
  const meta$5 = void 0;
  const isVue2 = false;
  let activePinia;
  const setActivePinia = (pinia) => activePinia = pinia;
  const piniaSymbol = Symbol();
  function isPlainObject(o) {
    return o && typeof o === "object" && Object.prototype.toString.call(o) === "[object Object]" && typeof o.toJSON !== "function";
  }
  var MutationType;
  (function(MutationType2) {
    MutationType2["direct"] = "direct";
    MutationType2["patchObject"] = "patch object";
    MutationType2["patchFunction"] = "patch function";
  })(MutationType || (MutationType = {}));
  function createPinia() {
    const scope = effectScope(true);
    const state = scope.run(() => ref({}));
    let _p = [];
    let toBeInstalled = [];
    const pinia = markRaw({
      install(app) {
        setActivePinia(pinia);
        {
          pinia._a = app;
          app.provide(piniaSymbol, pinia);
          app.config.globalProperties.$pinia = pinia;
          toBeInstalled.forEach((plugin) => _p.push(plugin));
          toBeInstalled = [];
        }
      },
      use(plugin) {
        if (!this._a && !isVue2) {
          toBeInstalled.push(plugin);
        } else {
          _p.push(plugin);
        }
        return this;
      },
      _p,
      _a: null,
      _e: scope,
      _s: /* @__PURE__ */ new Map(),
      state
    });
    return pinia;
  }
  const noop = () => {
  };
  function addSubscription(subscriptions, callback, detached, onCleanup = noop) {
    subscriptions.push(callback);
    const removeSubscription = () => {
      const idx = subscriptions.indexOf(callback);
      if (idx > -1) {
        subscriptions.splice(idx, 1);
        onCleanup();
      }
    };
    if (!detached && getCurrentInstance()) {
      onUnmounted(removeSubscription);
    }
    return removeSubscription;
  }
  function triggerSubscriptions(subscriptions, ...args) {
    subscriptions.slice().forEach((callback) => {
      callback(...args);
    });
  }
  function mergeReactiveObjects(target, patchToApply) {
    if (target instanceof Map && patchToApply instanceof Map) {
      patchToApply.forEach((value, key) => target.set(key, value));
    }
    if (target instanceof Set && patchToApply instanceof Set) {
      patchToApply.forEach(target.add, target);
    }
    for (const key in patchToApply) {
      if (!patchToApply.hasOwnProperty(key))
        continue;
      const subPatch = patchToApply[key];
      const targetValue = target[key];
      if (isPlainObject(targetValue) && isPlainObject(subPatch) && target.hasOwnProperty(key) && !isRef(subPatch) && !isReactive(subPatch)) {
        target[key] = mergeReactiveObjects(targetValue, subPatch);
      } else {
        target[key] = subPatch;
      }
    }
    return target;
  }
  const skipHydrateSymbol = Symbol();
  function shouldHydrate(obj) {
    return !isPlainObject(obj) || !obj.hasOwnProperty(skipHydrateSymbol);
  }
  const { assign } = Object;
  function isComputed(o) {
    return !!(isRef(o) && o.effect);
  }
  function createOptionsStore(id, options, pinia, hot) {
    const { state, actions, getters } = options;
    const initialState = pinia.state.value[id];
    let store;
    function setup() {
      if (!initialState && (!("production" !== "production") )) {
        {
          pinia.state.value[id] = state ? state() : {};
        }
      }
      const localState = toRefs(pinia.state.value[id]);
      return assign(localState, actions, Object.keys(getters || {}).reduce((computedGetters, name) => {
        computedGetters[name] = markRaw(computed(() => {
          setActivePinia(pinia);
          const store2 = pinia._s.get(id);
          return getters[name].call(store2, store2);
        }));
        return computedGetters;
      }, {}));
    }
    store = createSetupStore(id, setup, options, pinia, hot, true);
    store.$reset = function $reset() {
      const newState = state ? state() : {};
      this.$patch(($state) => {
        assign($state, newState);
      });
    };
    return store;
  }
  function createSetupStore($id, setup, options = {}, pinia, hot, isOptionsStore) {
    let scope;
    const optionsForPlugin = assign({
      actions: {}
    }, options);
    const $subscribeOptions = {
      deep: true
    };
    let isListening;
    let isSyncListening;
    let subscriptions = markRaw([]);
    let actionSubscriptions = markRaw([]);
    let debuggerEvents;
    const initialState = pinia.state.value[$id];
    if (!isOptionsStore && !initialState && (!("production" !== "production") )) {
      {
        pinia.state.value[$id] = {};
      }
    }
    const hotState = ref({});
    let activeListener;
    function $patch(partialStateOrMutator) {
      let subscriptionMutation;
      isListening = isSyncListening = false;
      if (typeof partialStateOrMutator === "function") {
        partialStateOrMutator(pinia.state.value[$id]);
        subscriptionMutation = {
          type: MutationType.patchFunction,
          storeId: $id,
          events: debuggerEvents
        };
      } else {
        mergeReactiveObjects(pinia.state.value[$id], partialStateOrMutator);
        subscriptionMutation = {
          type: MutationType.patchObject,
          payload: partialStateOrMutator,
          storeId: $id,
          events: debuggerEvents
        };
      }
      const myListenerId = activeListener = Symbol();
      nextTick().then(() => {
        if (activeListener === myListenerId) {
          isListening = true;
        }
      });
      isSyncListening = true;
      triggerSubscriptions(subscriptions, subscriptionMutation, pinia.state.value[$id]);
    }
    const $reset = noop;
    function $dispose() {
      scope.stop();
      subscriptions = [];
      actionSubscriptions = [];
      pinia._s.delete($id);
    }
    function wrapAction(name, action) {
      return function() {
        setActivePinia(pinia);
        const args = Array.from(arguments);
        const afterCallbackList = [];
        const onErrorCallbackList = [];
        function after(callback) {
          afterCallbackList.push(callback);
        }
        function onError(callback) {
          onErrorCallbackList.push(callback);
        }
        triggerSubscriptions(actionSubscriptions, {
          args,
          name,
          store,
          after,
          onError
        });
        let ret;
        try {
          ret = action.apply(this && this.$id === $id ? this : store, args);
        } catch (error) {
          triggerSubscriptions(onErrorCallbackList, error);
          throw error;
        }
        if (ret instanceof Promise) {
          return ret.then((value) => {
            triggerSubscriptions(afterCallbackList, value);
            return value;
          }).catch((error) => {
            triggerSubscriptions(onErrorCallbackList, error);
            return Promise.reject(error);
          });
        }
        triggerSubscriptions(afterCallbackList, ret);
        return ret;
      };
    }
    markRaw({
      actions: {},
      getters: {},
      state: [],
      hotState
    });
    const partialStore = {
      _p: pinia,
      $id,
      $onAction: addSubscription.bind(null, actionSubscriptions),
      $patch,
      $reset,
      $subscribe(callback, options2 = {}) {
        const removeSubscription = addSubscription(subscriptions, callback, options2.detached, () => stopWatcher());
        const stopWatcher = scope.run(() => watch(() => pinia.state.value[$id], (state) => {
          if (options2.flush === "sync" ? isSyncListening : isListening) {
            callback({
              storeId: $id,
              type: MutationType.direct,
              events: debuggerEvents
            }, state);
          }
        }, assign({}, $subscribeOptions, options2)));
        return removeSubscription;
      },
      $dispose
    };
    const store = reactive(assign({}, partialStore));
    pinia._s.set($id, store);
    const setupStore = pinia._e.run(() => {
      scope = effectScope();
      return scope.run(() => setup());
    });
    for (const key in setupStore) {
      const prop = setupStore[key];
      if (isRef(prop) && !isComputed(prop) || isReactive(prop)) {
        if (!isOptionsStore) {
          if (initialState && shouldHydrate(prop)) {
            if (isRef(prop)) {
              prop.value = initialState[key];
            } else {
              mergeReactiveObjects(prop, initialState[key]);
            }
          }
          {
            pinia.state.value[$id][key] = prop;
          }
        }
      } else if (typeof prop === "function") {
        const actionValue = wrapAction(key, prop);
        {
          setupStore[key] = actionValue;
        }
        optionsForPlugin.actions[key] = prop;
      } else ;
    }
    {
      assign(store, setupStore);
      assign(toRaw(store), setupStore);
    }
    Object.defineProperty(store, "$state", {
      get: () => pinia.state.value[$id],
      set: (state) => {
        $patch(($state) => {
          assign($state, state);
        });
      }
    });
    pinia._p.forEach((extender) => {
      {
        assign(store, scope.run(() => extender({
          store,
          app: pinia._a,
          pinia,
          options: optionsForPlugin
        })));
      }
    });
    if (initialState && isOptionsStore && options.hydrate) {
      options.hydrate(store.$state, initialState);
    }
    isListening = true;
    isSyncListening = true;
    return store;
  }
  function defineStore(idOrOptions, setup, setupOptions) {
    let id;
    let options;
    const isSetupStore = typeof setup === "function";
    if (typeof idOrOptions === "string") {
      id = idOrOptions;
      options = isSetupStore ? setupOptions : setup;
    } else {
      options = idOrOptions;
      id = idOrOptions.id;
    }
    function useStore(pinia, hot) {
      const currentInstance = getCurrentInstance();
      pinia = (pinia) || currentInstance && inject(piniaSymbol);
      if (pinia)
        setActivePinia(pinia);
      pinia = activePinia;
      if (!pinia._s.has(id)) {
        if (isSetupStore) {
          createSetupStore(id, setup, options, pinia);
        } else {
          createOptionsStore(id, options, pinia);
        }
      }
      const store = pinia._s.get(id);
      return store;
    }
    useStore.$id = id;
    return useStore;
  }
  userStore = defineStore("user", {
    state() {
      return {
        showLogin: false,
        isLogin: false
      };
    }
  });
  const _sfc_main$2 = defineComponent({
    __name: "LeftContents",
    __ssrInlineRender: true,
    setup(__props) {
      userStore();
      useCookie("token");
      const menu = ref([
        {
          path: "/user",
          name: "\u4E3B\u9875",
          icon: "false"
        },
        {
          path: "/user/create",
          name: "\u521B\u4F5C\u4E2D\u5FC3",
          icon: "icon-pencil-fill"
        },
        {
          path: "/user/order",
          name: "\u8BA2\u5355\u7BA1\u7406",
          icon: "icon-favorites-fill"
        }
      ]);
      return (_ctx, _push, _parent, _attrs) => {
        const _component_nuxt_link = __nuxt_component_0$2;
        _push(`<ul${ssrRenderAttrs(mergeProps({
          class: "left-ul"
        }, _attrs))} data-v-445dfa0f><!--[-->`);
        ssrRenderList(menu.value, (item, index) => {
          _push(`<li class="${ssrRenderClass([
            _ctx.$route.path == item.path ? "active" : "",
            "my-2"
          ])}" data-v-445dfa0f>`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: item.path
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                if (item.icon != "false") {
                  _push2(`<div class="${ssrRenderClass([
                    item.icon,
                    "mr-3 iconfont"
                  ])}" data-v-445dfa0f${_scopeId}></div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<p data-v-445dfa0f${_scopeId}>${ssrInterpolate(item.name)}</p>`);
              } else {
                return [
                  item.icon != "false" ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: [
                      "mr-3 iconfont",
                      item.icon
                    ]
                  }, null, 2)) : createCommentVNode("", true),
                  createVNode("p", {
                    textContent: toDisplayString(item.name)
                  }, null, 8, [
                    "textContent"
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--><hr class="my-2" data-v-445dfa0f><li data-v-445dfa0f><a data-v-445dfa0f><p class="text-red-600" data-v-445dfa0f>\u9000\u51FA\u767B\u9646</p></a></li></ul>`);
      };
    }
  });
  const _sfc_setup$2 = _sfc_main$2.setup;
  _sfc_main$2.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/user/LeftContents.vue");
    return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
  };
  __nuxt_component_0$1 = _export_sfc(_sfc_main$2, [
    [
      "__scopeId",
      "data-v-445dfa0f"
    ]
  ]);
  const meta$4 = {
    layout: "default",
    middleware: [
      "auth"
    ]
  };
  const meta$3 = void 0;
  const meta$2 = void 0;
  const meta$1 = void 0;
  const meta = {
    layout: "empty",
    middleware: [
      "auth"
    ]
  };
  const _routes = [
    {
      name: "index",
      path: "/",
      file: "/Volumes/D/ProjectDemo/nuxt-app/pages/index.vue",
      children: [],
      meta: meta$x,
      alias: (meta$x == null ? void 0 : meta$x.alias) || [],
      component: () => import('./_nuxt/index.e6c5550b.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    },
    {
      path: "/link",
      file: "/Volumes/D/ProjectDemo/nuxt-app/pages/link.vue",
      children: [
        {
          name: "link",
          path: "",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/link/index.vue",
          children: [],
          meta: meta$v,
          alias: [],
          component: () => import('./_nuxt/index.c83f1cda.mjs').then((m) => m.default || m)
        }
      ],
      meta: meta$w,
      alias: [],
      component: () => import('./_nuxt/link.ffb8f375.mjs').then((m) => m.default || m)
    },
    {
      path: "/read",
      file: "/Volumes/D/ProjectDemo/nuxt-app/pages/read.vue",
      children: [
        {
          name: "read",
          path: "",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/read/index.vue",
          children: [],
          meta: meta$t,
          alias: [],
          component: () => import('./_nuxt/index.c424cc3f.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        },
        {
          name: "read-post",
          path: "post",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/read/post.vue",
          children: [
            {
              name: "read-post-id",
              path: ":id",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/read/post/[id].vue",
              children: [],
              meta: meta$r,
              alias: [],
              component: () => import('./_nuxt/_id_.a2979d90.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            }
          ],
          meta: meta$s,
          alias: [],
          component: () => import('./_nuxt/post.7630c53a.mjs').then((m) => m.default || m)
        }
      ],
      meta: meta$u,
      alias: [],
      component: () => import('./_nuxt/read.a3925963.mjs').then((m) => m.default || m)
    },
    {
      path: "/tool",
      file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool.vue",
      children: [
        {
          name: "tool-detail",
          path: "detail",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail.vue",
          children: [
            {
              name: "tool-detail-Base64Convert",
              path: "Base64Convert",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/Base64Convert.vue",
              children: [],
              meta: meta$o,
              alias: [],
              component: () => import('./_nuxt/Base64Convert.c1d0217c.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: "tool-detail-CSSGradient",
              path: "CSSGradient",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/CSSGradient.vue",
              children: [],
              meta: meta$n,
              alias: [],
              component: () => import('./_nuxt/CSSGradient.594293ce.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-DownloadM3U8",
              path: "DownloadM3U8",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/DownloadM3U8.vue",
              children: [],
              meta: meta$m,
              alias: [],
              component: () => import('./_nuxt/DownloadM3U8.26b75aee.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-EnglistConvert",
              path: "EnglistConvert",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/EnglistConvert.vue",
              children: [],
              meta: meta$l,
              alias: [],
              component: () => import('./_nuxt/EnglistConvert.f34f858f.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-FancyBorderRadius",
              path: "FancyBorderRadius",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/FancyBorderRadius.vue",
              children: [],
              meta: meta$k,
              alias: [],
              component: () => import('./_nuxt/FancyBorderRadius.96ab967f.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-FlvPlayer",
              path: "FlvPlayer",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/FlvPlayer.vue",
              children: [],
              meta: meta$j,
              alias: [],
              component: () => import('./_nuxt/FlvPlayer.17042171.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-ImageToBase64",
              path: "ImageToBase64",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/ImageToBase64.vue",
              children: [],
              meta: meta$i,
              alias: [],
              component: () => import('./_nuxt/ImageToBase64.a14d0622.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: "tool-detail-MakePhrase",
              path: "MakePhrase",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/MakePhrase.vue",
              children: [],
              meta: meta$h,
              alias: [],
              component: () => import('./_nuxt/MakePhrase.2ab839e7.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: "tool-detail-NPlayer",
              path: "NPlayer",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/NPlayer.vue",
              children: [],
              meta: meta$g,
              alias: [],
              component: () => import('./_nuxt/NPlayer.c02e3de9.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-NationalDayAvatar",
              path: "NationalDayAvatar",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/NationalDayAvatar.vue",
              children: [],
              meta: meta$f,
              alias: [],
              component: () => import('./_nuxt/NationalDayAvatar.d361d382.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-PngToSVG",
              path: "PngToSVG",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/PngToSVG.vue",
              children: [],
              meta: meta$e,
              alias: (meta$e == null ? void 0 : meta$e.alias) || [],
              component: () => import('./_nuxt/PngToSVG.1bd119f0.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: "tool-detail-ScreenRec",
              path: "ScreenRec",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/ScreenRec.vue",
              children: [],
              meta: meta$d,
              alias: [],
              component: () => import('./_nuxt/ScreenRec.4c601803.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-TextDistinct",
              path: "TextDistinct",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/TextDistinct.vue",
              children: [],
              meta: meta$c,
              alias: [],
              component: () => import('./_nuxt/TextDistinct.c132998e.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: "tool-detail-TextSecret",
              path: "TextSecret",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/TextSecret.vue",
              children: [],
              meta: meta$b,
              alias: [],
              component: () => import('./_nuxt/TextSecret.25824947.mjs').then(async (m) => {
                await m.__tla;
                return m;
              }).then((m) => m.default || m)
            },
            {
              name: "tool-detail-Timestamp",
              path: "Timestamp",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/Timestamp.vue",
              children: [],
              meta: meta$a,
              alias: [],
              component: () => import('./_nuxt/Timestamp.8cd9a9ac.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-TraceReplay",
              path: "TraceReplay",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/TraceReplay.vue",
              children: [],
              meta: meta$9,
              alias: (meta$9 == null ? void 0 : meta$9.alias) || [],
              component: () => import('./_nuxt/TraceReplay.1014743f.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-UnicodeConvert",
              path: "UnicodeConvert",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/UnicodeConvert.vue",
              children: [],
              meta: meta$8,
              alias: [],
              component: () => import('./_nuxt/UnicodeConvert.dac4272c.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-WeiBoGenerates",
              path: "WeiBoGenerates",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/WeiBoGenerates.vue",
              children: [],
              meta: meta$7,
              alias: [],
              component: () => import('./_nuxt/WeiBoGenerates.7b3d8682.mjs').then((m) => m.default || m)
            },
            {
              name: "tool-detail-Whois",
              path: "Whois",
              file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/detail/Whois.vue",
              children: [],
              meta: meta$6,
              alias: [],
              component: () => import('./_nuxt/Whois.bcc80576.mjs').then((m) => m.default || m)
            }
          ],
          meta: meta$p,
          alias: [],
          component: () => import('./_nuxt/detail.0eb251bf.mjs').then((m) => m.default || m)
        },
        {
          name: "tool",
          path: "",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/tool/index.vue",
          children: [],
          meta: meta$5,
          alias: [],
          component: () => import('./_nuxt/index.3999a824.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        }
      ],
      meta: meta$q,
      alias: [],
      component: () => import('./_nuxt/tool.bbb7b583.mjs').then((m) => m.default || m)
    },
    {
      path: "/user",
      file: "/Volumes/D/ProjectDemo/nuxt-app/pages/user/index.vue",
      children: [
        {
          name: "user-index-create",
          path: "create",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/user/index/create.vue",
          children: [],
          meta: meta$3,
          alias: [],
          component: () => import('./_nuxt/create.ee52de97.mjs').then(async (m) => {
            await m.__tla;
            return m;
          }).then((m) => m.default || m)
        },
        {
          name: "user-index",
          path: "",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/user/index/index.vue",
          children: [],
          meta: meta$2,
          alias: [],
          component: () => import('./_nuxt/index.8d1919a5.mjs').then((m) => m.default || m)
        },
        {
          name: "user-index-order",
          path: "order",
          file: "/Volumes/D/ProjectDemo/nuxt-app/pages/user/index/order.vue",
          children: [],
          meta: meta$1,
          alias: [],
          component: () => import('./_nuxt/order.8f216075.mjs').then((m) => m.default || m)
        }
      ],
      meta: meta$4,
      alias: (meta$4 == null ? void 0 : meta$4.alias) || [],
      component: () => import('./_nuxt/index.b316f18c.mjs').then((m) => m.default || m)
    },
    {
      name: "writer",
      path: "/writer",
      file: "/Volumes/D/ProjectDemo/nuxt-app/pages/writer.vue",
      children: [],
      meta,
      alias: (meta == null ? void 0 : meta.alias) || [],
      component: () => import('./_nuxt/writer.449f2940.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((m) => m.default || m)
    }
  ];
  const configRouterOptions = {};
  const routerOptions = {
    ...configRouterOptions
  };
  const globalMiddleware = [];
  const namedMiddleware = {
    auth: () => import('./_nuxt/auth.07097b18.mjs'),
    "set-same-origin-header": () => import('./_nuxt/setSameOriginHeader.dd7680ee.mjs')
  };
  const node_modules_nuxt_dist_pages_runtime_router_mjs_qNv5Ky2ZmB = defineNuxtPlugin(async (nuxtApp) => {
    var _a, _b, _c, _d;
    let __temp, __restore;
    nuxtApp.vueApp.component("NuxtPage", NuxtPage);
    nuxtApp.vueApp.component("NuxtNestedPage", NuxtPage);
    nuxtApp.vueApp.component("NuxtChild", NuxtPage);
    let routerBase = useRuntimeConfig$1().app.baseURL;
    if (routerOptions.hashMode && !routerBase.includes("#")) {
      routerBase += "#";
    }
    const history = (_b = (_a = routerOptions.history) == null ? void 0 : _a.call(routerOptions, routerBase)) != null ? _b : createMemoryHistory(routerBase);
    const routes = (_d = (_c = routerOptions.routes) == null ? void 0 : _c.call(routerOptions, _routes)) != null ? _d : _routes;
    const initialURL = nuxtApp.ssrContext.url;
    const router = createRouter({
      ...routerOptions,
      history,
      routes
    });
    nuxtApp.vueApp.use(router);
    const previousRoute = shallowRef(router.currentRoute.value);
    router.afterEach((_to, from) => {
      previousRoute.value = from;
    });
    Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
      get: () => previousRoute.value
    });
    const _route = shallowRef(router.resolve(initialURL));
    const syncCurrentRoute = () => {
      _route.value = router.currentRoute.value;
    };
    nuxtApp.hook("page:finish", syncCurrentRoute);
    router.afterEach((to, from) => {
      var _a2, _b2, _c2, _d2;
      if (((_b2 = (_a2 = to.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d2 = (_c2 = from.matched[0]) == null ? void 0 : _c2.components) == null ? void 0 : _d2.default)) {
        syncCurrentRoute();
      }
    });
    const route = {};
    for (const key in _route.value) {
      route[key] = computed(() => _route.value[key]);
    }
    nuxtApp._route = reactive(route);
    nuxtApp._middleware = nuxtApp._middleware || {
      global: [],
      named: {}
    };
    useError();
    try {
      if (true) {
        ;
        [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
        ;
      }
      ;
      [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
      ;
    } catch (error2) {
      callWithNuxt(nuxtApp, showError, [
        error2
      ]);
    }
    const initialLayout = useState("_layout");
    router.beforeEach(async (to, from) => {
      var _a2, _b2;
      to.meta = reactive(to.meta);
      if (nuxtApp.isHydrating) {
        to.meta.layout = (_a2 = initialLayout.value) != null ? _a2 : to.meta.layout;
      }
      nuxtApp._processingMiddleware = true;
      const middlewareEntries = /* @__PURE__ */ new Set([
        ...globalMiddleware,
        ...nuxtApp._middleware.global
      ]);
      for (const component of to.matched) {
        const componentMiddleware = component.meta.middleware;
        if (!componentMiddleware) {
          continue;
        }
        if (Array.isArray(componentMiddleware)) {
          for (const entry2 of componentMiddleware) {
            middlewareEntries.add(entry2);
          }
        } else {
          middlewareEntries.add(componentMiddleware);
        }
      }
      for (const entry2 of middlewareEntries) {
        const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_b2 = namedMiddleware[entry2]) == null ? void 0 : _b2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
        if (!middleware) {
          throw new Error(`Unknown route middleware: '${entry2}'.`);
        }
        const result = await callWithNuxt(nuxtApp, middleware, [
          to,
          from
        ]);
        {
          if (result === false || result instanceof Error) {
            const error2 = result || createError({
              statusMessage: `Route navigation aborted: ${initialURL}`
            });
            return callWithNuxt(nuxtApp, showError, [
              error2
            ]);
          }
        }
        if (result || result === false) {
          return result;
        }
      }
    });
    router.afterEach(async (to) => {
      delete nuxtApp._processingMiddleware;
      if (to.matched.length === 0) {
        callWithNuxt(nuxtApp, showError, [
          createError({
            statusCode: 404,
            fatal: false,
            statusMessage: `Page not found: ${to.fullPath}`
          })
        ]);
      } else if (to.matched[0].name === "404" && nuxtApp.ssrContext) {
        nuxtApp.ssrContext.event.res.statusCode = 404;
      } else {
        const currentURL = to.fullPath || "/";
        if (!isEqual$1(currentURL, initialURL)) {
          await callWithNuxt(nuxtApp, navigateTo, [
            currentURL
          ]);
        }
      }
    });
    nuxtApp.hooks.hookOnce("app:created", async () => {
      try {
        await router.replace({
          ...router.resolve(initialURL),
          name: void 0,
          force: true
        });
      } catch (error2) {
        callWithNuxt(nuxtApp, showError, [
          error2
        ]);
      }
    });
    return {
      provide: {
        router
      }
    };
  });
  const node_modules__64pinia_nuxt_dist_runtime_plugin_vue3_mjs_A0OWXRrUgq = defineNuxtPlugin((nuxtApp) => {
    const pinia = createPinia();
    nuxtApp.vueApp.use(pinia);
    setActivePinia(pinia);
    {
      nuxtApp.payload.pinia = pinia.state.value;
    }
    return {
      provide: {
        pinia
      }
    };
  });
  const plugins_router_ts_WMnTGednOQ = defineNuxtPlugin((nuxtApp) => {
    nuxtApp.$router.options.scrollBehavior = () => {
      return {
        left: 0,
        top: 0
      };
    };
  });
  const _plugins = [
    _nuxt_components_plugin_mjs_KR1HBZs4kY,
    node_modules_nuxt_dist_head_runtime_lib_vueuse_head_plugin_mjs_D7WGfuP1A0,
    node_modules_nuxt_dist_head_runtime_plugin_mjs_1QO0gqa6n2,
    node_modules_nuxt_dist_pages_runtime_router_mjs_qNv5Ky2ZmB,
    node_modules__64pinia_nuxt_dist_runtime_plugin_vue3_mjs_A0OWXRrUgq,
    plugins_router_ts_WMnTGednOQ
  ];
  const _sfc_main$1 = {
    __name: "nuxt-root",
    __ssrInlineRender: true,
    setup(__props) {
      const ErrorComponent = defineAsyncComponent(() => import('./_nuxt/error-component.3d07c5ba.mjs').then(async (m) => {
        await m.__tla;
        return m;
      }).then((r) => r.default || r));
      const nuxtApp = useNuxtApp();
      provide("_route", useRoute());
      nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
      const error = useError();
      onErrorCaptured((err, target, info) => {
        nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
        {
          callWithNuxt(nuxtApp, showError, [
            err
          ]);
        }
      });
      return (_ctx, _push, _parent, _attrs) => {
        const _component_App = resolveComponent("App");
        ssrRenderSuspense(_push, {
          default: () => {
            if (unref(error)) {
              _push(ssrRenderComponent(unref(ErrorComponent), {
                error: unref(error)
              }, null, _parent));
            } else {
              _push(ssrRenderComponent(_component_App, null, null, _parent));
            }
          },
          _: 1
        });
      };
    }
  };
  const _sfc_setup$1 = _sfc_main$1.setup;
  _sfc_main$1.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt/dist/app/components/nuxt-root.vue");
    return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
  };
  const layouts = {
    default: defineAsyncComponent(() => import('./_nuxt/default.f48cc6be.mjs').then((m) => m.default || m)),
    empty: defineAsyncComponent(() => import('./_nuxt/empty.c19f7ea0.mjs').then((m) => m.default || m))
  };
  const __nuxt_component_0 = defineComponent({
    props: {
      name: {
        type: [
          String,
          Boolean,
          Object
        ],
        default: null
      }
    },
    setup(props, context) {
      const route = useRoute();
      return () => {
        var _a, _b, _c;
        const layout = (_b = (_a = isRef(props.name) ? props.name.value : props.name) != null ? _a : route.meta.layout) != null ? _b : "default";
        const hasLayout = layout && layout in layouts;
        const transitionProps = (_c = route.meta.layoutTransition) != null ? _c : appLayoutTransition;
        return _wrapIf(Transition, hasLayout && transitionProps, {
          default: () => {
            return _wrapIf(layouts[layout], hasLayout, context.slots).default();
          }
        }).default();
      };
    }
  });
  const _sfc_main = defineComponent({
    __name: "app",
    __ssrInlineRender: true,
    setup(__props) {
      return (_ctx, _push, _parent, _attrs) => {
        const _component_NuxtLayout = __nuxt_component_0;
        _push(ssrRenderComponent(_component_NuxtLayout, _attrs, null, _parent));
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  if (!globalThis.$fetch) {
    globalThis.$fetch = $fetch.create({
      baseURL: baseURL()
    });
  }
  let entry;
  const plugins = normalizePlugins(_plugins);
  {
    entry = async function createNuxtAppServer(ssrContext) {
      const vueApp = createApp(_sfc_main$1);
      vueApp.component("App", _sfc_main);
      const nuxt = createNuxtApp({
        vueApp,
        ssrContext
      });
      try {
        await applyPlugins(nuxt, plugins);
        await nuxt.hooks.callHook("app:created", vueApp);
      } catch (err) {
        await nuxt.callHook("app:error", err);
        nuxt.payload.error = nuxt.payload.error || err;
      }
      return vueApp;
    };
  }
  entry$1 = (ctx) => entry(ctx);
})();

export { __nuxt_component_0$2 as _, __tla, useNuxtApp as a, useCookie as b, _export_sfc as c, useRoute as d, entry$1 as default, useRequestHeaders as e, __nuxt_component_0$1 as f, defineNuxtRouteMiddleware as g, userStore as h, navigateTo as n, useHead as u };
//# sourceMappingURL=server.mjs.map
