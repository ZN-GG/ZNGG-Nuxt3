const interopDefault = r => r.default || r || [];
const styles = {
  "pages/index.vue": () => import('./_nuxt/index-styles.db5db422.mjs').then(interopDefault),
  "pages/read/index.vue": () => import('./_nuxt/index-styles.34e0185f.mjs').then(interopDefault),
  "pages/read/post/[id].vue": () => import('./_nuxt/_id_-styles.b8e4579a.mjs').then(interopDefault),
  "pages/tool/detail/FancyBorderRadius.vue": () => import('./_nuxt/FancyBorderRadius-styles.0a22ead3.mjs').then(interopDefault),
  "pages/tool/detail/FlvPlayer.vue": () => import('./_nuxt/FlvPlayer-styles.d919c4a9.mjs').then(interopDefault),
  "pages/tool/detail/M3U8V2Pro.vue": () => import('./_nuxt/M3U8V2Pro-styles.8c9b3f3c.mjs').then(interopDefault),
  "pages/tool/detail/MakePhrase.vue": () => import('./_nuxt/MakePhrase-styles.f0aeb1dc.mjs').then(interopDefault),
  "pages/tool/detail/NPlayer.vue": () => import('./_nuxt/NPlayer-styles.eceed04a.mjs').then(interopDefault),
  "pages/tool/detail/NationalDayAvatar.vue": () => import('./_nuxt/NationalDayAvatar-styles.c3071d02.mjs').then(interopDefault),
  "pages/tool/detail/TextSecret.vue": () => import('./_nuxt/TextSecret-styles.09cf8948.mjs').then(interopDefault),
  "pages/tool/detail/WeiBoGenerates.vue": () => import('./_nuxt/WeiBoGenerates-styles.f1248467.mjs').then(interopDefault),
  "pages/tool/detail/Whois.vue": () => import('./_nuxt/Whois-styles.0047e429.mjs').then(interopDefault),
  "pages/tool/detail/WordToPDF.vue": () => import('./_nuxt/WordToPDF-styles.f9c9c062.mjs').then(interopDefault),
  "pages/tool/detail/office/[type].vue": () => import('./_nuxt/_type_-styles.173eea4a.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.43414ea3.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.4087d4fb.mjs').then(interopDefault),
  "pages/writer.vue": () => import('./_nuxt/writer-styles.d0537891.mjs').then(interopDefault),
  "pages/read/post/[id].vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/_id_.vue_vue_type_script_setup_true_lang-styles.036c6780.mjs').then(interopDefault),
  "pages/writer.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/_id_.vue_vue_type_script_setup_true_lang-styles.036c6780.mjs').then(interopDefault),
  "app.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/app.vue_vue_type_script_setup_true_lang-styles.773ca2f9.mjs').then(interopDefault),
  "components/user/LeftContents.vue": () => import('./_nuxt/LeftContents-styles.a9439643.mjs').then(interopDefault),
  "components/Toolbar.vue": () => import('./_nuxt/Toolbar-styles.d5a61d75.mjs').then(interopDefault),
  "components/Login.vue": () => import('./_nuxt/Login-styles.bd6343ff.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
