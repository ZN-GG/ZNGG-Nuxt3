import { __tla as __tla$1, u as useHead, _ as __nuxt_component_0$1 } from './server.mjs';
import { defineComponent, ref, mergeProps, unref, withCtx, openBlock, createBlock, createCommentVNode, createVNode, toDisplayString, useSSRContext } from 'vue';
import { _ as __tla$2, u as useCookie } from './cookie.20b5dbf0.mjs';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as __tla$3, u as userStore } from './user.2a916038.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import { _ as __tla$4, a as __nuxt_component_0 } from './page.357e6c19.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'cookie-es';

let _sfc_main;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$2;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$3;
    } catch {
    }
  })(),
  (() => {
    try {
      return __tla$4;
    } catch {
    }
  })()
]).then(async () => {
  const _sfc_main$1 = defineComponent({
    __name: "LeftContents",
    __ssrInlineRender: true,
    setup(__props) {
      userStore();
      useCookie("token");
      const menu = ref([
        {
          path: "/user",
          name: "\u4E3B\u9875",
          icon: "false"
        },
        {
          path: "/user/create",
          name: "\u521B\u4F5C\u4E2D\u5FC3",
          icon: "icon-pencil-fill"
        },
        {
          path: "/user/order",
          name: "\u8BA2\u5355\u7BA1\u7406",
          icon: "icon-favorites-fill"
        },
        {
          path: "/user/info",
          name: "\u7528\u6237\u4FE1\u606F",
          icon: "icon-yonghu"
        }
      ]);
      return (_ctx, _push, _parent, _attrs) => {
        const _component_nuxt_link = __nuxt_component_0$1;
        _push(`<ul${ssrRenderAttrs(mergeProps({
          class: "left-ul"
        }, _attrs))} data-v-66e63fe3><!--[-->`);
        ssrRenderList(unref(menu), (item, index) => {
          _push(`<li class="${ssrRenderClass([
            _ctx.$route.path == item.path ? "active" : "",
            "my-2"
          ])}" data-v-66e63fe3>`);
          _push(ssrRenderComponent(_component_nuxt_link, {
            to: item.path
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                if (item.icon != "false") {
                  _push2(`<div class="${ssrRenderClass([
                    item.icon,
                    "mr-3 iconfont"
                  ])}" data-v-66e63fe3${_scopeId}></div>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`<p data-v-66e63fe3${_scopeId}>${ssrInterpolate(item.name)}</p>`);
              } else {
                return [
                  item.icon != "false" ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: [
                      "mr-3 iconfont",
                      item.icon
                    ]
                  }, null, 2)) : createCommentVNode("", true),
                  createVNode("p", {
                    textContent: toDisplayString(item.name)
                  }, null, 8, [
                    "textContent"
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--><hr class="my-2" data-v-66e63fe3><li data-v-66e63fe3><a data-v-66e63fe3><p class="text-red-600" data-v-66e63fe3>\u9000\u51FA\u767B\u9646</p></a></li></ul>`);
      };
    }
  });
  const _sfc_setup$1 = _sfc_main$1.setup;
  _sfc_main$1.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/user/LeftContents.vue");
    return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
  };
  const __nuxt_component_0$2 = _export_sfc(_sfc_main$1, [
    [
      "__scopeId",
      "data-v-66e63fe3"
    ]
  ]);
  _sfc_main = defineComponent({
    __name: "index",
    __ssrInlineRender: true,
    setup(__props) {
      useHead({
        title: "\u7528\u6237\u4E2D\u5FC3",
        titleTemplate: (title) => `${title} - \u6301\u7EED\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA`,
        meta: [
          {
            name: "Keywords",
            content: "\u524D\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u540E\u7AEF\u6280\u672F\u5206\u4EAB\uFF0C\u5728\u7EBF\u5C0F\u5DE5\u5177\uFF0C\u8BBE\u8BA1\u6280\u5DE7"
          },
          {
            name: "description",
            content: "ZNGG\u5728\u7EBF\u5DE5\u5177\u662F\u4E00\u4E2A\u6301\u7EED\u63D0\u4F9B\u9AD8\u8D28\u91CF\u5185\u5BB9\u8F93\u51FA\u5E73\u53F0\uFF0C\u5E76\u5C06\u8F93\u51FA\u5185\u5BB9\u8F6C\u53D8\u4E3A\u6210\u679C\uFF0C\u63D0\u4F9B\u5404\u79CD\u5404\u6837\u7684\u5728\u7EBF\u5DE5\u5177\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        const _component_UserLeftContents = __nuxt_component_0$2;
        const _component_NuxtPage = __nuxt_component_0;
        _push(`<div${ssrRenderAttrs(_attrs)}><div class="flex container mx-auto my-6"><div class="w-2/12"><div class="w-full bg-white rounded p-4">`);
        _push(ssrRenderComponent(_component_UserLeftContents, null, null, _parent));
        _push(`</div></div><div class="w-8/12"><div class="w-full bg-white rounded mx-2 p-4">`);
        _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
        _push(`</div></div><div class="w-2/12"><div class="w-full bg-white rounded mx-2"></div></div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
});

export { __tla, _sfc_main as default };
//# sourceMappingURL=index.af41bc23.mjs.map
