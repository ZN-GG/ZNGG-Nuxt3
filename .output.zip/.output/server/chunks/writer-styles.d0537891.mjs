const writer_vue_vue_type_style_index_0_lang = ".relaseCard{background:rgba(0,0,0,.25)}.relaseCard .card{width:560px}";

const writerStyles_d0537891 = [writer_vue_vue_type_style_index_0_lang];

export { writerStyles_d0537891 as default };
//# sourceMappingURL=writer-styles.d0537891.mjs.map
