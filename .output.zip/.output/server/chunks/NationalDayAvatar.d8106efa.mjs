import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { __tla as __tla$1, u as useHead } from './server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let NationalDayAvatar;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const _imports_0 = "" + globalThis.__publicAssetsURL("img/NationalDayAvatar/tool-logo.png");
  const _imports_1 = "" + globalThis.__publicAssetsURL("img/NationalDayAvatar/message.png");
  const _sfc_main = defineComponent({
    __name: "NationalDayAvatar",
    __ssrInlineRender: true,
    setup(__props) {
      const sum = 15;
      ref();
      ref();
      let activeIndex = ref(1);
      let uploaded = ref(false);
      let isShowResult = ref(false);
      let resultData = ref("");
      useHead({
        title: "\u56FD\u5E86\u5934\u50CF\u751F\u6210\u5668",
        titleTemplate: (title) => `${title} - \u5DE5\u5177 - ZNGG\u5728\u7EBF\u5DE5\u5177`,
        meta: [
          {
            name: "Keywords",
            content: "\u56FD\u5E86\u5934\u50CF\u751F\u6210\u5668,\u5728\u7EBF\u751F\u6210\u56FD\u5E86\u5934\u50CF,\u4E00\u952E\u5FAE\u4FE1\u56FD\u5E86\u5934\u50CF\u751F\u6210,\u5FAE\u4FE1\u5934\u50CF\u52A0\u4E94\u661F\u7EA2\u65D7,\u56FD\u5E86\u5FAE\u4FE1\u5934\u50CF"
          },
          {
            name: "description",
            content: "\u8FD9\u662F\u4E00\u4E2A\u4E00\u952E\u751F\u6210\u56FD\u5E86\u5934\u50CF\u7684\u5C0F\u7A0B\u5E8F\uFF0C\u4E0A\u4F20\u81EA\u5DF1\u5934\u50CF\u540E\u53EF\u4EE5\u9009\u62E9\u5408\u9002\u7684\u56FD\u5E86\u5934\u50CF\u6837\u5F0F\uFF0C\u968F\u540E\u4FDD\u5B58\u5934\u50CF\u5373\u53EF\u3002"
          }
        ]
      });
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: "main"
        }, _attrs))} data-v-523dd35b><div class="container mx-auto" data-v-523dd35b><img class="mx-auto mt-12 md:mt-28 tool-logo"${ssrRenderAttr("src", _imports_0)} alt="" data-v-523dd35b></div><div class="mx-auto mt-8" data-v-523dd35b><div class="flex items-center justify-center" data-v-523dd35b><a class="prev" data-v-523dd35b></a><div class="canvasAvatarBoxBorder p-1 relative" data-v-523dd35b><div class="canvasAvatarBox" data-v-523dd35b><canvas class="canvasAvatar" id="canvasAvatar" data-v-523dd35b></canvas></div><img style="${ssrRenderStyle([
          unref(isShowResult) ? null : {
            display: "none"
          },
          {
            "width": "9.6rem",
            "height": "9.6rem",
            "top": "0.25rem",
            "left": "0.25rem",
            "position": "absolute"
          }
        ])}"${ssrRenderAttr("src", unref(resultData))} data-v-523dd35b></div><a class="next" data-v-523dd35b></a></div></div><div data-v-523dd35b><div class="container mt-6 mx-auto" data-v-523dd35b><div class="text-center relative pt-6 pb-6 mb-4 custom-font-14 rounded w-44 mx-auto" style="${ssrRenderStyle({
          "background": "url(/img/NationalDayAvatar/upload-btn.png)",
          "background-size": "11rem"
        })}" id="fileInput" alt="\u4E0A\u4F20\u5934\u50CF" data-v-523dd35b><input type="file" id="file" accept="image/*" style="${ssrRenderStyle({
          "opacity": "0",
          "position": "absolute",
          "cursor": "pointer",
          "width": "100%",
          "height": "100%",
          "left": "0",
          "top": "0"
        })}" data-v-523dd35b></div><div style="${ssrRenderStyle([
          unref(uploaded) ? null : {
            display: "none"
          },
          {
            "background": "url(/img/NationalDayAvatar/save-btn.png)",
            "background-size": "11rem"
          }
        ])}" class="text-center relative pt-6 pb-6 mb-4 custom-font-14 rounded w-44 mx-auto" alt="\u4FDD\u5B58\u5934\u50CF" data-v-523dd35b></div><div class="w-full text-center" data-v-523dd35b><p class="text-yellow-300" data-v-523dd35b>\u624B\u673A\u7528\u6237\u8BF7\u70B9\u51FB\u4FDD\u5B58\u5934\u50CF\u540E\u957F\u6309\u5934\u50CF\u8FDB\u884C\u4E0B\u8F7D</p></div></div><div style="${ssrRenderStyle({
          "display": "none"
        })}" data-v-523dd35b><!--[-->`);
        ssrRenderList(sum, (index) => {
          _push(`<img${ssrRenderAttr("id", "avatar-" + index)}${ssrRenderAttr("src", "/img/NationalDayAvatar/avatar-" + index + ".png")} style="${ssrRenderStyle({
            "display": "none"
          })}" data-v-523dd35b>`);
        });
        _push(`<!--]--></div><div class="container flex flex-wrap mx-auto justify-around" data-v-523dd35b><!--[-->`);
        ssrRenderList(sum, (index) => {
          _push(`<div class="${ssrRenderClass([
            index == unref(activeIndex) ? "active" : "",
            "w-16 md:w-20 m-3 md:m-4 canvasAvatarBoxBorder"
          ])}" data-v-523dd35b><img${ssrRenderAttr("src", "/img/NationalDayAvatar/avatar-" + index + ".png")} data-v-523dd35b></div>`);
        });
        _push(`<!--]--><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-523dd35b></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-523dd35b></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-523dd35b></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-523dd35b></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-523dd35b></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-523dd35b></div><div class="w-16 mx-3 md:w-20 md:mx-4" data-v-523dd35b></div></div><div class="container mx-auto" data-v-523dd35b><img${ssrRenderAttr("src", _imports_1)} alt="" data-v-523dd35b></div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/NationalDayAvatar.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  NationalDayAvatar = _export_sfc(_sfc_main, [
    [
      "__scopeId",
      "data-v-523dd35b"
    ]
  ]);
});

export { __tla, NationalDayAvatar as default };
//# sourceMappingURL=NationalDayAvatar.d8106efa.mjs.map
