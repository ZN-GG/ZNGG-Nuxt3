import { ref } from 'vue';
import { parse, serialize } from 'cookie-es';
import { appendHeader } from 'h3';
import destr from 'destr';
import { isEqual } from 'ohash';
import { __tla as __tla$1, a as useNuxtApp } from './server.mjs';

let useRequestHeaders, useCookie;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  useRequestHeaders = function useRequestHeaders2(include) {
    var _a, _b;
    const headers = (_b = (_a = useNuxtApp().ssrContext) == null ? void 0 : _a.event.node.req.headers) != null ? _b : {};
    if (!include) {
      return headers;
    }
    return Object.fromEntries(include.map((key) => key.toLowerCase()).filter((key) => headers[key]).map((key) => [
      key,
      headers[key]
    ]));
  };
  function useRequestEvent(nuxtApp = useNuxtApp()) {
    var _a;
    return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
  }
  const CookieDefaults = {
    path: "/",
    decode: (val) => destr(decodeURIComponent(val)),
    encode: (val) => encodeURIComponent(typeof val === "string" ? val : JSON.stringify(val))
  };
  useCookie = function useCookie2(name, _opts) {
    var _a, _b;
    const opts = {
      ...CookieDefaults,
      ..._opts
    };
    const cookies = readRawCookies(opts) || {};
    const cookie = ref((_b = cookies[name]) != null ? _b : (_a = opts.default) == null ? void 0 : _a.call(opts));
    {
      const nuxtApp = useNuxtApp();
      const writeFinalCookieValue = () => {
        if (!isEqual(cookie.value, cookies[name])) {
          writeServerCookie(useRequestEvent(nuxtApp), name, cookie.value, opts);
        }
      };
      const unhook = nuxtApp.hooks.hookOnce("app:rendered", writeFinalCookieValue);
      nuxtApp.hooks.hookOnce("app:redirected", () => {
        unhook();
        return writeFinalCookieValue();
      });
    }
    return cookie;
  };
  function readRawCookies(opts = {}) {
    var _a;
    {
      return parse(((_a = useRequestEvent()) == null ? void 0 : _a.req.headers.cookie) || "", opts);
    }
  }
  function serializeCookie(name, value, opts = {}) {
    if (value === null || value === void 0) {
      return serialize(name, value, {
        ...opts,
        maxAge: -1
      });
    }
    return serialize(name, value, opts);
  }
  function writeServerCookie(event, name, value, opts = {}) {
    if (event) {
      appendHeader(event, "Set-Cookie", serializeCookie(name, value, opts));
    }
  }
});

export { __tla as _, useRequestHeaders as a, useCookie as u };
//# sourceMappingURL=cookie.bd9fc59c.mjs.map
