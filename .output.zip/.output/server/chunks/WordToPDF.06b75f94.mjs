import { __tla as __tla$1, a as useNuxtApp } from './server.mjs';
import { defineComponent, ref, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderAttr, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper.a1a6add7.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'ohash';
import 'unstorage';
import 'defu';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

let WordToPDF;
let __tla = Promise.all([
  (() => {
    try {
      return __tla$1;
    } catch {
    }
  })()
]).then(async () => {
  const _imports_0 = "" + globalThis.__publicAssetsURL("img/office/upload-btn.svg");
  const _sfc_main = defineComponent({
    __name: "WordToPDF",
    __ssrInlineRender: true,
    setup(__props) {
      useNuxtApp();
      ref();
      const isConverting = ref(false);
      const isDone = ref(false);
      const fileList = ref([]);
      return (_ctx, _push, _parent, _attrs) => {
        _push(`<div${ssrRenderAttrs(mergeProps({
          class: ""
        }, _attrs))} data-v-8c7d5e60><div class="convert-bg" data-v-8c7d5e60></div><div class="office-bg pb-28" data-v-8c7d5e60><div class="container mx-auto" data-v-8c7d5e60><div class="bg-white px-6 rounded-2xl relative shadow-lg" data-v-8c7d5e60><div class="pt-4" data-v-8c7d5e60><div class="text-center" data-v-8c7d5e60><h1 class="text-2xl font-bold" data-v-8c7d5e60>Word \u8F6C PDF</h1></div></div><div style="${ssrRenderStyle(unref(fileList).length == 0 ? null : {
          display: "none"
        })}" class="upload-box py-6" data-v-8c7d5e60><div class="border-gray-500 border-2 border-dashed relative h-72" data-v-8c7d5e60><div class="in-upload-box" data-v-8c7d5e60><img${ssrRenderAttr("src", _imports_0)} class="mx-auto w-32 h-32 mb-4" alt="" data-v-8c7d5e60></div><input type="file" id="file" accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" style="${ssrRenderStyle({
          "opacity": "0",
          "position": "absolute",
          "cursor": "pointer",
          "width": "100%",
          "height": "100%",
          "left": "0",
          "top": "0"
        })}" data-v-8c7d5e60><div class="in-upload-box" data-v-8c7d5e60><div class="mt-32 btn-3 bg-blue-600 text-white py-2 text-center hover:bg-blue-800 cursor-pointer px-8" data-v-8c7d5e60> \u9009\u62E9\u6587\u4EF6 </div></div></div></div><div style="${ssrRenderStyle(unref(fileList).length > 0 ? null : {
          display: "none"
        })}" class="py-6" data-v-8c7d5e60><div class="border-gray-500 border-2 border-dashed relative p-4 md:p-6" data-v-8c7d5e60>`);
        if (!unref(isConverting)) {
          _push(`<ul data-v-8c7d5e60><!--[-->`);
          ssrRenderList(unref(fileList), (item, index) => {
            _push(`<li class="flex flex-wrap border-b-2 py-1 w-full mb-2 justify-between" data-v-8c7d5e60><div class="w-full md:w-4/12 flex items-center" data-v-8c7d5e60><p class="font-bold break-words" data-v-8c7d5e60>${ssrInterpolate(item.name)}</p></div><div style="${ssrRenderStyle(item.status == 1 ? null : {
              display: "none"
            })}" class="md:w-4/12 flex items-center justify-center" data-v-8c7d5e60><i class="iconfont icon-ok text-green-600" style="${ssrRenderStyle({
              "font-size": "24px"
            })}" data-v-8c7d5e60></i><span data-v-8c7d5e60>\xA0\u4E0A\u4F20\u5B8C\u6210</span></div><div style="${ssrRenderStyle(item.status == 0 ? null : {
              display: "none"
            })}" class="md:w-4/12 flex items-center justify-center" data-v-8c7d5e60><i class="iconfont icon-upload text-blue-600" style="${ssrRenderStyle({
              "font-size": "24px"
            })}" data-v-8c7d5e60></i><span data-v-8c7d5e60>\xA0\u6B63\u5728\u4E0A\u4F20</span></div><div class="md:w-4/12 flex items-center justify-end" data-v-8c7d5e60><i class="iconfont icon-ashbin" style="${ssrRenderStyle({
              "font-size": "24px"
            })}" data-v-8c7d5e60></i></div></li>`);
          });
          _push(`<!--]--></ul>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<ul style="${ssrRenderStyle(unref(isConverting) ? null : {
          display: "none"
        })}" data-v-8c7d5e60><!--[-->`);
        ssrRenderList(unref(fileList), (item, index) => {
          _push(`<li class="flex flex-wrap border-b-2 py-1 w-full mb-2 justify-between" data-v-8c7d5e60><div class="w-full md:w-4/12 flex items-center" data-v-8c7d5e60><p class="font-bold break-words" data-v-8c7d5e60>${ssrInterpolate(item.name)}</p></div><div style="${ssrRenderStyle(item.status == 1 ? null : {
            display: "none"
          })}" class="md:w-4/12 flex items-center justify-center" data-v-8c7d5e60><i class="iconfont icon-ok text-green-600" style="${ssrRenderStyle({
            "font-size": "24px"
          })}" data-v-8c7d5e60></i><span data-v-8c7d5e60>\xA0\u8F6C\u6362\u5B8C\u6210</span></div><div style="${ssrRenderStyle(item.status == 0 ? null : {
            display: "none"
          })}" class="md:w-4/12 flex items-center justify-center" data-v-8c7d5e60><i class="iconfont icon-upload text-blue-600" style="${ssrRenderStyle({
            "font-size": "24px"
          })}" data-v-8c7d5e60></i><span data-v-8c7d5e60>\xA0\u6B63\u5728\u8F6C\u6362</span></div><div class="md:w-4/12 flex items-center justify-end" data-v-8c7d5e60><a style="${ssrRenderStyle(item.status == 1 ? null : {
            display: "none"
          })}" target="_blank"${ssrRenderAttr("href", "https://api.zngg.net/api/common/download/taskTempFile/" + item.resultId + "/" + item.name.substring(0, item.name.lastIndexOf(".")) + ".pdf")} data-v-8c7d5e60><i class="iconfont icon-falling" style="${ssrRenderStyle({
            "font-size": "24px"
          })}" data-v-8c7d5e60></i></a></div></li>`);
        });
        _push(`<!--]--></ul><div class="mt-24" data-v-8c7d5e60><div style="${ssrRenderStyle(!unref(isDone) ? null : {
          display: "none"
        })}" class="bg-blue-600 text-white py-2 text-center hover:bg-blue-800 cursor-pointer px-8" data-v-8c7d5e60>${ssrInterpolate(unref(isConverting) ? "\u6B63\u5728\u8F6C\u6362" : "\u5F00\u59CB\u8F6C\u6362")}</div><div style="${ssrRenderStyle(unref(isDone) ? null : {
          display: "none"
        })}" class="bg-gray-600 text-white py-2 text-center hover:bg-green-900 cursor-pointer px-8" data-v-8c7d5e60> \u91CD\u65B0\u5F00\u59CB</div></div></div></div></div></div></div></div>`);
      };
    }
  });
  const _sfc_setup = _sfc_main.setup;
  _sfc_main.setup = (props, ctx) => {
    const ssrContext = useSSRContext();
    (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tool/detail/WordToPDF.vue");
    return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
  };
  WordToPDF = _export_sfc(_sfc_main, [
    [
      "__scopeId",
      "data-v-8c7d5e60"
    ]
  ]);
});

export { __tla, WordToPDF as default };
//# sourceMappingURL=WordToPDF.06b75f94.mjs.map
