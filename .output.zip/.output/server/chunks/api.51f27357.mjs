import { b as useCookie } from './server.mjs';

const baseUrl = "https://api.zngg.net";
const errorResponse = {
  success: false,
  code: 0,
  message: "",
  data: null
};
const get = async (url, params = {}) => {
  try {
    const token = useCookie("token");
    const res = await $fetch(baseUrl + url, {
      headers: {
        "Authorization": token.value
      },
      method: "GET",
      params
    });
    return res;
  } catch (error) {
    errorResponse.message = error;
    return errorResponse;
  }
};
const post = async (url, params = {}) => {
  try {
    const token = useCookie("token");
    const res = await $fetch(baseUrl + url, {
      headers: {
        "Authorization": token.value
      },
      method: "POST",
      body: params
    });
    return res;
  } catch (error) {
    errorResponse.message = error;
    return errorResponse;
  }
};
const put = async (url, params = {}) => {
  try {
    const token = useCookie("token");
    const res = await $fetch(baseUrl + url, {
      headers: {
        "Authorization": token.value
      },
      method: "PUT",
      body: params
    });
    return res;
  } catch (error) {
    errorResponse.message = error;
    return errorResponse;
  }
};
const http = { get, post, put };
const article = {
  getDetail(id) {
    return http.get("/portal/article/" + id);
  },
  getList(page, size, params) {
    return http.get("/portal/article/" + page + "/" + size, params);
  },
  getCategories() {
    return http.get("/portal/article_category");
  },
  postArticle(params) {
    return http.post("/user/article", params);
  }
};
const user = {
  login(params, captcha, captcha_key) {
    return http.post("/user/user/" + captcha + "/" + captcha_key, params);
  },
  getInfo() {
    return http.get("/user/user/info");
  },
  register(params, email_code, captcha_code, captcha_key) {
    return http.post("/user/user?email_code=" + email_code + "&captcha_code=" + captcha_code + "&captcha_uuid=" + captcha_key, params);
  },
  sendEmailCaptcha(email) {
    return http.get("/user/user/email_verify_code?type=register&email=" + email);
  }
};
const upload = {
  uploadImage(params) {
    return http.post("/user/image", params);
  },
  uploadImageCover(params) {
    return http.post("/user/image/cover", params);
  }
};
const fun = {
  stringToTimestamp(str) {
    return http.get("/api/common/stringToTimestamp/v1", {
      str
    });
  },
  getWhois(domain) {
    return http.get("/api/common/whois/" + domain);
  }
};
const tool = {
  getCategories() {
    return http.get("/portal/tool_category");
  },
  getList(page, size, params) {
    return http.get("/portal/tool/" + page + "/" + size, params);
  }
};
const api = {
  article,
  user,
  upload,
  fun,
  tool
};

export { api as a };
//# sourceMappingURL=api.51f27357.mjs.map
