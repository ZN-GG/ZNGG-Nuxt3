globalThis._importMeta_={url:import.meta.url,env:process.env};export { n as default } from './chunks/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'destr';
import 'h3';
import 'ohmyfetch';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'unstorage';
import 'ufo';
import 'fs';
import 'pathe';
import 'url';
//# sourceMappingURL=index.mjs.map
